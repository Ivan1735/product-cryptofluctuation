"""
CryptoFluctuation Intelligence Tracker — серверна частина (Інкремент 2).

Помічник для дослідження крипторинку та навчальний симулятор. Усі угоди віртуальні, реальних грошей немає.
Не є фінансовою порадою.

Запуск:  python app.py   ->   http://127.0.0.1:5000

Мови API: 13 мов, параметр ?lang=ua|en|ru|es|hi|vi|de|pl|zh|ja|ko|pt|tr (або поле "lang" у JSON, або заголовок Accept-Language).
"""
import html
import math
import hashlib
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
import json
import os
import random
import re
import sqlite3
import statistics
import threading
import time
from collections import deque
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

import feedparser
import requests
from flask import Flask, jsonify, render_template, request
from jinja2 import TemplateNotFound

# ───────────────────────── Конфігурація ─────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("CRYPTO_TRACKER_DB", os.path.join(BASE_DIR, "data", "crypto_tracker.db"))

PRICE_REFRESH_SECONDS = 10      # період фонового оновлення цін (вимога: 10 с)
MARKET_MAX_AGE = 60             # UI: older quotes are stale; research retains its stricter limit
NEWS_CACHE_SECONDS = 60         # RSS опитуємо не частіше разу на хвилину
NEWS_ITEMS = 10
HTTP_TIMEOUT = 6
HISTORY_LEN = 60                # 60 точок = остання година (крок 1 хвилина)
HISTORY_STEP_SECONDS = 60

DROP_THRESHOLD = -5.0           # сповіщення про рух, не наказ купувати
RISE_THRESHOLD = 5.0            # сповіщення про рух, не наказ продавати
NEWS_RISK_INDEX = -0.25         # індекс настрою новин не вище цього = високий ризик
CHAT_MAX_LEN = 500

LANGS = ("ua", "en", "ru", "es", "hi", "vi", "de", "pl", "zh", "ja", "ko", "pt", "tr")
DEFAULT_LANG = "ua"
LANG_ALIASES = {"ua": "ua", "uk": "ua", "uk-ua": "ua", "en": "en", "en-us": "en", "en-gb": "en",
                "ru": "ru", "ru-ru": "ru"}
MYMEMORY_PAIRS = {"ua": "en|uk", "ru": "en|ru"}

# 15 обраних активів; MATIC показує актуальний POL після міграції.
COINS = {
    "BTC": {"name": "Bitcoin",  "binance": "BTCUSDT", "gecko": "bitcoin",     "base": 65000.0},
    "ETH": {"name": "Ethereum", "binance": "ETHUSDT", "gecko": "ethereum",    "base": 3300.0},
    "SOL": {"name": "Solana",   "binance": "SOLUSDT", "gecko": "solana",      "base": 150.0},
    "BNB": {"name": "BNB",      "binance": "BNBUSDT", "gecko": "binancecoin", "base": 580.0},
    "XRP": {"name": "XRP",      "binance": "XRPUSDT", "gecko": "ripple",      "base": 0.55},
    'DOGE': {'name': 'Dogecoin', 'binance': 'DOGEUSDT', 'gecko': 'dogecoin', 'base': 0.12},
    'TON': {'name': 'Toncoin', 'binance': 'TONUSDT', 'gecko': 'the-open-network', 'base': 3},
    'ADA': {'name': 'Cardano', 'binance': 'ADAUSDT', 'gecko': 'cardano', 'base': 0.4},
    'DOT': {'name': 'Polkadot', 'binance': 'DOTUSDT', 'gecko': 'polkadot', 'base': 4},
    'LINK': {'name': 'Chainlink', 'binance': 'LINKUSDT', 'gecko': 'chainlink', 'base': 12},
    'MATIC': {'name': 'Polygon · MATIC → POL', 'binance': 'POLUSDT', 'gecko': 'polygon-ecosystem-token', 'base': 0.2},
    'SHIB': {'name': 'Shiba Inu', 'binance': 'SHIBUSDT', 'gecko': 'shiba-inu', 'base': 1.2e-05},
    'TRX': {'name': 'TRON', 'binance': 'TRXUSDT', 'gecko': 'tron', 'base': 0.2},
    'LTC': {'name': 'Litecoin', 'binance': 'LTCUSDT', 'gecko': 'litecoin', 'base': 80},
    'NEAR': {'name': 'NEAR Protocol', 'binance': 'NEARUSDT', 'gecko': 'near', 'base': 3},
}
COIN_ALIASES = {
    "BTC": ["біткоїн", "біткойн", "биткоин", "bitcoin"],
    "ETH": ["ефіріум", "ефір", "эфир", "ethereum"],
    "SOL": ["солана", "solana"],
    "BNB": ["bnb", "binance coin"],
    "XRP": ["ріпл", "рипл", "ripple"],
}

# RSS-стрічки: перша — основна (CoinTelegraph), друга — резервна
NEWS_FEEDS = [("cointelegraph", "CoinTelegraph", "https://cointelegraph.com/rss"),
              ("coindesk", "CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/")]
FEED_HEADERS = {"User-Agent": "Mozilla/5.0 (CryptoFluctuationTracker student project)"}

# Офіційні джерела, які показуємо у віджеті ШІ-новин.
# rss=True — наш сервер реально читає стрічку; rss=False — лише посилання для читача.
OFFICIAL_SOURCES = [
    {"id": "cointelegraph", "name": "CoinTelegraph",   "url": "https://cointelegraph.com",           "rss": True},
    {"id": "coindesk",      "name": "CoinDesk",        "url": "https://www.coindesk.com",            "rss": True},
    {"id": "bloomberg",     "name": "Bloomberg Crypto", "url": "https://www.bloomberg.com/crypto",   "rss": False},
    {"id": "binance",       "name": "Binance News",    "url": "https://www.binance.com/en/news",     "rss": False},
]

app = Flask(__name__)
db_write_lock = threading.Lock()   # одна операція запису в БД за раз


# ───────────────────────── Локалізація (13 мов) ─────────────────────────
def t(key, lang, **kw):
    entry = I18N[key]
    text = entry.get(lang) or entry[DEFAULT_LANG]
    return text.format(**kw) if kw else text


def get_lang():
    """Мова з ?lang=, JSON-поля "lang" або заголовка Accept-Language; за замовчуванням — UA."""
    raw = request.args.get("lang")
    if not raw and request.is_json:
        body = request.get_json(silent=True)
        raw = body.get("lang") if isinstance(body, dict) else None
    if not raw:
        raw = request.headers.get("Accept-Language", "").split(",")[0].split(";")[0].strip()
    key = str(raw or "").lower()
    return LANG_ALIASES.get(key) or LANG_ALIASES.get(key.split("-")[0]) or DEFAULT_LANG


def err(key, code=400, **kw):
    return jsonify({"error": t(key, get_lang(), **kw), "code": key}), code


# ───────────────────────── База даних ─────────────────────────
@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS positions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol        TEXT NOT NULL,
            quantity      REAL NOT NULL CHECK (quantity > 0),
            avg_price     REAL NOT NULL CHECK (avg_price > 0),
            stop_loss_pct REAL,                       -- NULL = вимкнено
            buys_count    INTEGER NOT NULL DEFAULT 1,
            opened_at     TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS closed_trades (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol      TEXT NOT NULL,
            quantity    REAL NOT NULL,
            buy_price   REAL NOT NULL,
            sell_price  REAL NOT NULL,
            pnl         REAL NOT NULL,
            pnl_pct     REAL NOT NULL,
            reason      TEXT NOT NULL,                -- manual | stop_loss
            opened_at   TEXT NOT NULL,
            closed_at   TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS events (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            kind       TEXT NOT NULL,                 -- stop_loss | info
            message    TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        # міграція зі старої БД Інкремента 1: payload зберігає дані події для локалізації
        cols = [r["name"] for r in db.execute("PRAGMA table_info(events)")]
        if "payload" not in cols:
            db.execute("ALTER TABLE events ADD COLUMN payload TEXT")
        init_research_tables(db)


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ───────────────────────── Ціни (фонове оновлення) ─────────────────────────
prices_state = {"coins": {}, "updated_at": None, "source": "none", "updated_epoch": 0.0}
prices_lock = threading.RLock()
# історія: (unix-час, ціна); крок — 1 хвилина, остання точка живо оновлюється
price_history = {sym: deque(maxlen=HISTORY_LEN) for sym in COINS}


def fetch_binance():
    """Binance: ціна + зміна за ковзне вікно 1 година."""
    symbols = json.dumps([c["binance"] for c in COINS.values()], separators=(",", ":"))
    r = requests.get("https://data-api.binance.vision/api/v3/ticker",
                     params={"symbols": symbols, "windowSize": "1h"}, timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    by_pair = {row["symbol"]: row for row in r.json()}
    return {sym: {"price": float(by_pair[m["binance"]]["lastPrice"]),
                  "change_1h": float(by_pair[m["binance"]]["priceChangePercent"]),
                  "quote_volume_1h": float(by_pair[m["binance"]]["quoteVolume"]),
                  "exchange_epoch": float(by_pair[m["binance"]]["closeTime"]) / 1000}
            for sym, m in COINS.items()}


def fetch_coingecko():
    """CoinGecko: резервне джерело."""
    ids = ",".join(c["gecko"] for c in COINS.values())
    r = requests.get("https://api.coingecko.com/api/v3/coins/markets",
                     params={"vs_currency": "usd", "ids": ids, "price_change_percentage": "1h"},
                     timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    by_id = {row["id"]: row for row in r.json()}
    return {sym: {"price": float(by_id[m["gecko"]]["current_price"]),
                  "change_1h": float(by_id[m["gecko"]].get("price_change_percentage_1h_in_currency") or 0.0)}
            for sym, m in COINS.items()}


def simulate_prices():
    """Остання черга: імітація, щоб застосунок працював без інтернету (демо/захист)."""
    out = {}
    for sym, meta in COINS.items():
        prev = prices_state["coins"].get(sym)
        price = prev["price"] if prev else meta["base"]
        price *= 1 + random.uniform(-0.004, 0.004)
        change = (prev["change_1h"] if prev else 0.0) + random.uniform(-0.6, 0.6)
        if random.random() < 0.03:                     # зрідка різкий рух для демо індикації
            change += random.choice([-6.0, 6.0])
        out[sym] = {"price": price, "change_1h": max(-12.0, min(12.0, change))}
    return out


def prefill_history():
    """Seed actual minute candles; also prime the research/chart cache."""
    def get_one(symbol):
        try:
            candles = fetch_candles(symbol, "1h")
            with prices_lock:
                price_history[symbol].clear()
                price_history[symbol].extend((p["t"], p["close"]) for p in candles["points"][-60:])
        except Exception as exc:
            app.logger.warning("History %s unavailable: %s", symbol, exc)
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(get_one, COINS))


def push_history(sym, price):
    """Хвилинні точки; поточну свічку уточнюємо кожні 10 секунд."""
    now = time.time()
    bucket = int(now // HISTORY_STEP_SECONDS) * HISTORY_STEP_SECONDS
    with prices_lock:
        h = price_history[sym]
        if h and bucket <= h[-1][0]:
            h[-1] = (h[-1][0], price)
        else:
            h.append((bucket, price))


def refresh_prices():
    data, source = None, None
    for name, fn in (("binance", fetch_binance), ("coingecko", fetch_coingecko)):
        try:
            data, source = fn(), name
            break
        except Exception as exc:                       # мережа/ліміти/формат — пробуємо далі
            app.logger.warning("Джерело %s недоступне: %s", name, exc)
    if data is None:
        data, source = simulate_prices(), "simulation"

    with prices_lock:
        previous_source = prices_state["source"]
        if previous_source != "none" and ((previous_source == "simulation") != (source == "simulation")):
            for history in price_history.values():
                history.clear()
    coins = {}
    for sym, meta in COINS.items():
        ch = round(data[sym]["change_1h"], 2)
        push_history(sym, data[sym]["price"])
        coins[sym] = {**data[sym], "symbol": sym, "name": meta["name"], "price": data[sym]["price"], "change_1h": ch,
                      "signal": "buy" if ch <= DROP_THRESHOLD else "sell" if ch >= RISE_THRESHOLD else "neutral",
                      "alert": ch <= DROP_THRESHOLD}   # фронтенд грає звук
    with prices_lock:
        prices_state.update(coins=coins, updated_at=now_iso(), source=source, updated_epoch=time.time())


def serialize_coin(c, lang):
    """Монета + локалізована рекомендація + історія ціни (до 60 точок)."""
    with prices_lock:
        pts = list(price_history[c["symbol"]])
    return {**c, "recommendation": t("rec_" + c["signal"], lang),
            "history": [round(p, 8) for _, p in pts]}


def current_price(symbol):
    with prices_lock:
        c = prices_state["coins"].get(symbol)
    return c["price"] if c else None


def coin_analysis(sym, lang):
    """Дані для модального вікна аналітики монети (і для відповідей чату)."""
    with prices_lock:
        c = prices_state["coins"].get(sym)
    if not c:
        return None
    with prices_lock:
        pts = list(price_history[sym])
    prices = [p for _, p in pts]
    stats = None
    if len(prices) >= 2:
        returns = [(b / a - 1) * 100 for a, b in zip(prices, prices[1:])]
        short = statistics.mean(prices[-10:])
        long_ = statistics.mean(prices)
        gap = (short / long_ - 1) * 100
        stats = {"high": max(prices), "low": min(prices), "avg": statistics.mean(prices),
                 "window_change_pct": (prices[-1] / prices[0] - 1) * 100,
                 "volatility_pct": statistics.pstdev(returns) if len(returns) > 1 else 0.0,
                 "trend": "up" if gap > 0.1 else "down" if gap < -0.1 else "flat"}
    with get_db() as db:
        rows = db.execute("SELECT quantity, avg_price FROM positions WHERE symbol = ?", (sym,)).fetchall()
    mine = None
    if rows:
        q = sum(r["quantity"] for r in rows)
        cost = sum(r["quantity"] * r["avg_price"] for r in rows)
        mine = {"quantity": q, "avg_price": cost / q, "pnl": c["price"] * q - cost,
                "pnl_pct": (c["price"] * q / cost - 1) * 100}
    return {**serialize_coin(c, lang),
            "points": [{"t": datetime.fromtimestamp(ts, timezone.utc).isoformat(timespec="seconds"), "p": p} for ts, p in pts],
            "stats": stats, "my_position": mine, "step_seconds": HISTORY_STEP_SECONDS, "lang": lang}


# ───────────────────────── Угоди та Stop-Loss ─────────────────────────
def close_position(db, pos, sell_price, reason):
    """Закрити позицію: записати результат у closed_trades і видалити з блокнота."""
    pnl = (sell_price - pos["avg_price"]) * pos["quantity"]
    pnl_pct = (sell_price / pos["avg_price"] - 1) * 100
    db.execute("""INSERT INTO closed_trades
                  (symbol, quantity, buy_price, sell_price, pnl, pnl_pct, reason, opened_at, closed_at)
                  VALUES (?,?,?,?,?,?,?,?,?)""",
               (pos["symbol"], pos["quantity"], pos["avg_price"], sell_price,
                pnl, pnl_pct, reason, pos["opened_at"], now_iso()))
    db.execute("DELETE FROM positions WHERE id = ?", (pos["id"],))
    return pnl, pnl_pct


def check_stop_losses():
    with db_write_lock, get_db() as db:
        rows = db.execute("SELECT * FROM positions WHERE stop_loss_pct IS NOT NULL").fetchall()
        for pos in rows:
            price = current_price(pos["symbol"])
            if price is None:
                continue
            pnl_pct = (price / pos["avg_price"] - 1) * 100
            if pnl_pct <= -pos["stop_loss_pct"]:
                pnl, pct = close_position(db, pos, price, "stop_loss")
                payload = {"symbol": pos["symbol"], "price": price, "pct": pct, "pnl": pnl}
                db.execute("INSERT INTO events (kind, message, payload, created_at) VALUES (?,?,?,?)",
                           ("stop_loss", t("sl_event", DEFAULT_LANG, **payload), json.dumps(payload), now_iso()))


def background_worker():
    while True:
        try:
            refresh_prices()
            check_stop_losses()
        except Exception:
            app.logger.exception("Помилка фонового оновлення")
        time.sleep(PRICE_REFRESH_SECONDS)


# ───────────────────────── Новини: RSS CoinTelegraph + аналіз заголовків ─────────────────────────
# Словник ключових слів із вагами (англійські заголовки). Ключ — початок слова.
SENTIMENT_LEXICON = {
    # негативні
    "crash": -2, "plunge": -2, "hack": -2, "exploit": -2, "ban": -2, "fraud": -2, "scam": -2, "collapse": -2,
    "bankrupt": -2, "crackdown": -2, "rug pull": -2, "stolen": -2, "theft": -2, "lawsuit": -1.5, "sues": -1.5,
    "liquidat": -1.5, "selloff": -1.5, "sell-off": -1.5, "slump": -1.5, "dump": -1.5, "tumble": -1.5,
    "arrest": -1.5, "fear": -1, "drop": -1, "falls": -1, "plummet": -2, "probe": -1, "outflow": -1,
    "warning": -1, "decline": -1, "sink": -1, "loses": -1,
    # позитивні
    "surge": 2, "rally": 2, "soar": 2, "record high": 2, "all-time high": 2, "approval": 1.5, "approve": 1.5,
    "bullish": 1.5, "rebound": 1.5, "jump": 1.5, "breakout": 1.5, "adoption": 1, "gain": 1, "inflow": 1,
    "partnership": 1, "upgrade": 1, "growth": 1, "climb": 1, "launch": 0.5, "etf": 0.5,
}
_LEXICON_RE = [(re.compile(r"\b" + re.escape(w)), s) for w, s in SENTIMENT_LEXICON.items()]


def score_headline(title):
    """Сума ваг ключових слів: < 0 негативний заголовок, > 0 позитивний."""
    low = title.lower()
    return round(sum(s for rx, s in _LEXICON_RE if rx.search(low)), 2)


def sentiment_label(score):
    return "negative" if score <= -1 else "positive" if score >= 1 else "neutral"


news_raw = {"ts": 0.0, "items": [], "source": "unavailable", "feeds": [],
            "success_epoch": None, "degraded": True, "cached": False}
news_lock = threading.Lock()
translation_cache = {}


def translate(text, lang):
    """Безкоштовний переклад EN -> UK/RU (MyMemory) із кешем; при помилці повертає None."""
    key = (lang, text)
    if key in translation_cache:
        return translation_cache[key]
    try:
        r = requests.get("https://api.mymemory.translated.net/get",
                         params={"q": text[:400], "langpair": MYMEMORY_PAIRS[lang]}, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        j = r.json()
        out = html.unescape(j["responseData"]["translatedText"]).strip()
        if int(j.get("responseStatus", 0)) != 200 or not out or "MYMEMORY" in out.upper():
            return None
    except Exception:
        return None
    if len(translation_cache) > 500:
        translation_cache.clear()
    translation_cache[key] = out
    return out


# ───────────────────────── Допоміжне ─────────────────────────
def parse_positive(payload, key):
    if isinstance(payload.get(key), bool):
        return None
    try:
        value = float(payload.get(key))
    except (TypeError, ValueError):
        return None
    return value if 0 < value < float("inf") else None


def portfolio_snapshot():
    with get_db() as db:
        rows = db.execute("SELECT * FROM positions ORDER BY id DESC").fetchall()
    positions, total_value, total_cost = [], 0.0, 0.0
    for p in rows:
        price = current_price(p["symbol"]) or p["avg_price"]
        cost, value = p["avg_price"] * p["quantity"], price * p["quantity"]
        total_cost += cost
        total_value += value
        positions.append({
            "id": p["id"], "symbol": p["symbol"], "quantity": p["quantity"],
            "avg_price": p["avg_price"], "current_price": price,
            "cost": cost, "value": value, "pnl": value - cost,
            "pnl_pct": (price / p["avg_price"] - 1) * 100,
            "stop_loss_pct": p["stop_loss_pct"], "buys_count": p["buys_count"],
            "opened_at": p["opened_at"],
        })
    pnl = total_value - total_cost
    with prices_lock:
        updated_at, source = prices_state["updated_at"], prices_state["source"]
    return {"positions": positions,
            "totals": {"value": total_value, "cost": total_cost, "pnl": pnl,
                       "pnl_pct": (pnl / total_cost * 100) if total_cost else 0.0},
            "prices_updated_at": updated_at, "price_source": source}


UI_TRANSLATIONS = {
  "ua": {
    "ШАПКА": "ШАПКА",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · навчальний симулятор",
    "📈 Ринок": "📈 Ринок",
    "💼 Портфель": "💼 Портфель",
    "📊 Статистика": "📊 Статистика",
    "📚 Школа новачка": "📚 Школа новачка",
    "Підключення…": "Підключення…",
    "БАНЕР РИЗИКУ": "БАНЕР РИЗИКУ",
    "ТАБЛО ПОРТФЕЛЯ": "ТАБЛО ПОРТФЕЛЯ",
    "Загальна вартість портфеля": "Загальна вартість портфеля",
    "віртуальний": "віртуальний",
    "результат відносно ціни покупки": "результат відносно ціни покупки",
    "Вкладено (за цінами покупки)": "Вкладено (за цінами покупки)",
    "Відкритих позицій": "Відкритих позицій",
    "Скинути систему": "Скинути систему",
    "Очікуємо перші дані…": "Очікуємо перші дані…",
    "оновлення через —": "оновлення через —",
    "ОСНОВНА СІТКА": "ОСНОВНА СІТКА",
    "Ринок": "Ринок",
    "15 обраних монет · зміна за 1 годину": "15 обраних монет · зміна за 1 годину",
    "падіння ≥ 5% — сигнал «купити»": "падіння ≥ 5% — сигнал «купити»",
    "ріст ≥ 5% — сигнал «продати»": "ріст ≥ 5% — сигнал «продати»",
    "Портфель": "Портфель",
    "Віртуальний блокнот покупок": "Віртуальний блокнот покупок",
    "＋ Додати покупку": "＋ Додати покупку",
    "Статистика": "Статистика",
    "Фінансовий підсумок місяця": "Фінансовий підсумок місяця",
    "Місяць:": "Місяць:",
    "Школа новачка": "Школа новачка",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.",
    "Новини": "Новини",
    "🤖 ШІ-моніторинг новин": "🤖 ШІ-моніторинг новин",
    "Аналіз настрою світових заголовків про крипторинок": "Аналіз настрою світових заголовків про крипторинок",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.",
    "МОДАЛЬНЕ ВІКНО": "МОДАЛЬНЕ ВІКНО",
    "🤖 Довідковий асистент": "🤖 Довідковий асистент",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.",
    "Надіслати": "Надіслати",
    "Стан зʼєднання та джерело цін": "Стан зʼєднання та джерело цін",
    "Звукові сповіщення: увімк./вимк.": "Звукові сповіщення: увімк./вимк.",
    "Мова інтерфейсу": "Мова інтерфейсу",
    "Перемкнути темну / світлу тему": "Перемкнути темну / світлу тему",
    "Пошук за назвою або символом": "Пошук за назвою або символом",
    "Оновити новини": "Оновити новини",
    "Діалог": "Діалог",
    "Довідковий асистент": "Довідковий асистент",
    "Закрити": "Закрити",
    "Ваше запитання": "Ваше запитання",
    "Binance · наживо": "Binance · наживо",
    "CoinGecko · наживо": "CoinGecko · наживо",
    "Демо-режим (імітація цін)": "Демо-режим (імітація цін)",
    "Немає даних": "Немає даних",
    "Вручну": "Вручну",
    "Помилка сервера": "Помилка сервера",
    "Звукові сповіщення увімкнено": "Звукові сповіщення увімкнено",
    "Звукові сповіщення вимкнено": "Звукові сповіщення вимкнено",
    "Історія ціни": "Історія ціни",
    "Аналітика": "Аналітика",
    "у плюсі відносно ціни покупки": "у плюсі відносно ціни покупки",
    "у мінусі відносно ціни покупки": "у мінусі відносно ціни покупки",
    "додайте першу покупку у вкладці «Портфель»": "додайте першу покупку у вкладці «Портфель»",
    "Оновлено о": "Оновлено о",
    "/ 1 год": "/ 1 год",
    "Блокнот порожній": "Блокнот порожній",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.",
    "＋ Додати першу покупку": "＋ Додати першу покупку",
    "% · спрацює на": "% · спрацює на",
    "Stop-Loss не задано": "Stop-Loss не задано",
    "Відкрито": "Відкрито",
    "· докупівель:": "· докупівель:",
    "Кількість": "Кількість",
    "Середня ціна покупки": "Середня ціна покупки",
    "Поточна ціна": "Поточна ціна",
    "Поточна вартість": "Поточна вартість",
    "Негативний фон": "Негативний фон",
    "Позитивний фон": "Позитивний фон",
    "Нейтральний фон": "Нейтральний фон",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Демо-стрічка (імітація): реальні новини зараз недоступні",
    "Джерело:": "Джерело:",
    "Оригінальні або перекладені заголовки": "Оригінальні або перекладені заголовки",
    "Негативна": "Негативна",
    "Позитивна": "Позитивна",
    "Нейтральна": "Нейтральна",
    "індекс:": "індекс:",
    "▼ негативних:": "▼ негативних:",
    "нейтральних:": "нейтральних:",
    "▲ позитивних:": "▲ позитивних:",
    "· оригінал англійською": "· оригінал англійською",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о",
    "Ще немає закритих угод.": "Ще немає закритих угод.",
    "угод:": "угод:",
    "У цьому місяці угод немає.": "У цьому місяці угод немає.",
    "Чистий результат ·": "Чистий результат ·",
    "Закритих угод": "Закритих угод",
    "Прибуткових": "Прибуткових",
    "з": "з",
    "Найкраща / найгірша": "Найкраща / найгірша",
    "Результат за місяцями": "Результат за місяцями",
    "За монетами ·": "За монетами ·",
    "Останні закриті угоди": "Останні закриті угоди",
    "Час": "Час",
    "Монета": "Монета",
    "К-сть": "К-сть",
    "Купівля": "Купівля",
    "Продаж": "Продаж",
    "Причина": "Причина",
    "Результат": "Результат",
    "Продайте першу позицію — і тут зʼявиться історія.": "Продайте першу позицію — і тут зʼявиться історія.",
    "Не вдалося завантажити статистику:": "Не вдалося завантажити статистику:",
    "Віртуальна покупка": "Віртуальна покупка",
    "Без обмеження стартовим капіталом": "Без обмеження стартовим капіталом",
    "Ціна, за яку ви її віртуально купили ($)": "Ціна, за яку ви її віртуально купили ($)",
    "Підставити ринкову ціну": "Підставити ринкову ціну",
    "Введіть кількість і ціну.": "Введіть кількість і ціну.",
    "Додати до блокнота": "Додати до блокнота",
    "напр. 0,5": "напр. 0,5",
    "напр. 64 500": "напр. 64 500",
    "Підставити ринкову ціну:": "Підставити ринкову ціну:",
    "Сума покупки:": "Сума покупки:",
    "Зараз ця позиція була б у": "Зараз ця позиція була б у",
    "(ринок:": "(ринок:",
    "Введіть додатні числа для кількості та ціни": "Введіть додатні числа для кількості та ціни",
    "Додано:": "Додано:",
    "за": "за",
    "Усереднення ·": "Усереднення ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Докупівля за нижчою ціною з автоматичним перерахунком середньої",
    "Зараз:": "Зараз:",
    "· середня": "· середня",
    "· ринок": "· ринок",
    "Скільки докуповуємо": "Скільки докуповуємо",
    "Ціна докупівлі ($) — має бути нижчою за": "Ціна докупівлі ($) — має бути нижчою за",
    "Усереднити": "Усереднити",
    "Введіть додатні числа.": "Введіть додатні числа.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Ціна докупівлі має бути нижчою за поточну середню (",
    "Нова кількість:": "Нова кількість:",
    "Нова середня ціна:": "Нова середня ціна:",
    "Додаткові вкладення:": "Додаткові вкладення:",
    "Середня ціна": "Середня ціна",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Автоматичне віртуальне закриття угоди при заданому мінусі",
    "Середня ціна:": "Середня ціна:",
    "· зараз": "· зараз",
    "Закрити угоду, коли збиток досягне (%)": "Закрити угоду, коли збиток досягне (%)",
    "Зберегти": "Зберегти",
    "Вимкнути": "Вимкнути",
    "Вкажіть відсоток від 0,1 до 99.": "Вкажіть відсоток від 0,1 до 99.",
    "Спрацює при ціні ≤": "Спрацює при ціні ≤",
    "Плановий збиток на порозі:": "Плановий збиток на порозі:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Ціна вже нижча за поріг — угода закриється одразу!",
    "Stop-Loss для": "Stop-Loss для",
    "встановлено: −": "встановлено: −",
    "вимкнено": "вимкнено",
    "Продати": "Продати",
    "Віртуальний продаж за поточною ринковою ціною": "Віртуальний продаж за поточною ринковою ціною",
    "Кількість:": "Кількість:",
    "Ціна продажу:": "Ціна продажу:",
    "Результат угоди:": "Результат угоди:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Результат буде збережено в базі даних і потрапить у статистику місяця.",
    "Так, продати": "Так, продати",
    "Скасувати": "Скасувати",
    "продано за": "продано за",
    "різко впала:": "різко впала:",
    "за годину": "за годину",
    "Немає зв’язку з сервером": "Немає зв’язку з сервером",
    "Новини оновлено": "Новини оновлено",
    "Не вдалося оновити новини": "Не вдалося оновити новини",
    "оновлення через": "оновлення через",
    "с": "с",
    "повтор спроби підключення…": "повтор спроби підключення…",
    "Видалити без фіксації ·": "Видалити без фіксації ·",
    "Виправлення випадково введеної позиції": "Виправлення випадково введеної позиції",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.",
    "Видалити без фіксації": "Видалити без фіксації",
    "Позицію видалено без запису в статистику": "Позицію видалено без запису в статистику",
    "Незворотна дія": "Незворотна дія",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.",
    "Так, очистити всі угоди": "Так, очистити всі угоди",
    "Систему скинуто": "Систему скинуто",
    "Аналітика монети": "Аналітика монети",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.",
    "Максимум вікна": "Максимум вікна",
    "Мінімум вікна": "Мінімум вікна",
    "Зміна у вікні": "Зміна у вікні",
    "Волатильність дохідностей": "Волатильність дохідностей",
    "Історія ціни · до 60 точок": "Історія ціни · до 60 точок",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.",
    "Ще недостатньо спостережень для графіка.": "Ще недостатньо спостережень для графіка.",
    "Таблиця спостережень": "Таблиця спостережень",
    "Ціна": "Ціна",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.",
    "КУПИТИ за вигідною ціною": "КУПИТИ за вигідною ціною",
    "НЕ КУПУВАТИ / ПРОДАТИ": "НЕ КУПУВАТИ / ПРОДАТИ",
    "Утримуватись, ринок спокійний": "Утримуватись, ринок спокійний",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Високий ризик падіння ринку через негативні світові новини!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Невідома монета. Доступні: {coins}",
    "Кількість і ціна мають бути додатними числами": "Кількість і ціна мають бути додатними числами",
    "Позицію не знайдено": "Позицію не знайдено",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss — це відсоток від 0.1 до 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Ціни ще не завантажені, спробуйте за кілька секунд",
    "Формат місяця: РРРР-ММ": "Формат місяця: РРРР-ММ",
    "Для повного скидання надішліть {\"confirm\": true}": "Для повного скидання надішліть {\"confirm\": true}",
    "Повідомлення порожнє": "Повідомлення порожнє",
    "Повідомлення задовге (максимум {n} символів)": "Повідомлення задовге (максимум {n} символів)",
    "висхідний": "висхідний",
    "низхідний": "низхідний",
    "боковий": "боковий",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Портфель порожній. Додайте першу віртуальну покупку на картці монети.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Новинний фон без критичного ризику (індекс {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Огляд ринку за годину: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».",
    "Це навчальна демонстрація, а не фінансова порада.": "Це навчальна демонстрація, а не фінансова порада.",
    "Прибуток і збиток (P&L)": "Прибуток і збиток (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.",
    "Зміна ціни за годину": "Зміна ціни за годину",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.",
    "Усереднення": "Усереднення",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.",
    "Настрій новин": "Настрій новин",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.",
    "Віртуальна торгівля": "Віртуальна торгівля",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.",
    "Готую відповідь…": "Готую відповідь…",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.",
    "Зміна ціни за останню годину": "Зміна ціни за останню годину",
    "Ціна за останні хвилини": "Ціна за останні хвилини",
    "Додати віртуальну покупку": "Додати віртуальну покупку",
    "＋ До блокнота": "＋ До блокнота",
    "Докупити за нижчою ціною та перерахувати середню": "Докупити за нижчою ціною та перерахувати середню",
    "⚖ Усереднити": "⚖ Усереднити",
    "Автоматично закрити угоду при заданому відсотку збитку": "Автоматично закрити угоду при заданому відсотку збитку",
    "Віртуально продати за поточною ціною": "Віртуально продати за поточною ціною"
  },
  "en": {
    "ШАПКА": "HAT",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · educational simulator",
    "📈 Ринок": "📈 Market",
    "💼 Портфель": "💼 Portfolio",
    "📊 Статистика": "📊 Statistics",
    "📚 Школа новачка": "📚 Beginner school",
    "Підключення…": "Connecting…",
    "БАНЕР РИЗИКУ": "RISK BANNER",
    "ТАБЛО ПОРТФЕЛЯ": "PORTFOLIO BOARD",
    "Загальна вартість портфеля": "The total value of the portfolio",
    "віртуальний": "virtual",
    "результат відносно ціни покупки": "the result relative to the purchase price",
    "Вкладено (за цінами покупки)": "Invested (at purchase prices)",
    "Відкритих позицій": "Open positions",
    "Скинути систему": "Reset the system",
    "Очікуємо перші дані…": "We are waiting for the first data...",
    "оновлення через —": "update via —",
    "ОСНОВНА СІТКА": "MAIN GRID",
    "Ринок": "the market",
    "15 обраних монет · зміна за 1 годину": "15 selected coins · change in 1 hour",
    "падіння ≥ 5% — сигнал «купити»": "drop ≥ 5% - \"buy\" signal",
    "ріст ≥ 5% — сигнал «продати»": "growth ≥ 5% - \"sell\" signal",
    "Портфель": "Portfolio",
    "Віртуальний блокнот покупок": "Virtual notebook of purchases",
    "＋ Додати покупку": "＋ Add purchase",
    "Статистика": "Statistics",
    "Фінансовий підсумок місяця": "Financial summary of the month",
    "Місяць:": "Month:",
    "Школа новачка": "Beginner school",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Explanations, life examples and risks. Training does not guarantee income.",
    "Новини": "News",
    "🤖 ШІ-моніторинг новин": "🤖 AI news monitoring",
    "Аналіз настрою світових заголовків про крипторинок": "Sentiment analysis of global crypto market headlines",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Educational project from the \"Software Development\" course. All transactions are virtual, no real funds are used.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Buy / sell signals are a demonstration of logic, not financial advice.",
    "МОДАЛЬНЕ ВІКНО": "MODAL WINDOW",
    "🤖 Довідковий асистент": "🤖 Reference assistant",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "API rules and data reference, not generative model. Does not constitute financial advice.",
    "Надіслати": "Send",
    "Стан зʼєднання та джерело цін": "Connection status and price source",
    "Звукові сповіщення: увімк./вимк.": "Sound notifications: on/off",
    "Мова інтерфейсу": "Interface language",
    "Перемкнути темну / світлу тему": "Toggle dark / light theme",
    "Пошук за назвою або символом": "Search by name or symbol",
    "Оновити новини": "Update news",
    "Діалог": "Dialogue",
    "Довідковий асистент": "Reference assistant",
    "Закрити": "close",
    "Ваше запитання": "Your question",
    "Binance · наживо": "Binance · live",
    "CoinGecko · наживо": "CoinGecko · live",
    "Демо-режим (імітація цін)": "Demo mode (imitation of prices)",
    "Немає даних": "No data available",
    "Вручну": "Manually",
    "Помилка сервера": "Server error",
    "Звукові сповіщення увімкнено": "Sound notifications are enabled",
    "Звукові сповіщення вимкнено": "Sound notifications are turned off",
    "Історія ціни": "Price history",
    "Аналітика": "Analytics",
    "у плюсі відносно ціни покупки": "in the plus relative to the purchase price",
    "у мінусі відносно ціни покупки": "in the red relative to the purchase price",
    "додайте першу покупку у вкладці «Портфель»": "add your first purchase in the \"Portfolio\" tab",
    "Оновлено о": "Updated by",
    "/ 1 год": "/ 1 hour",
    "Блокнот порожній": "The notebook is empty",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Add a virtual purchase — and the scoreboard at the top will start counting profits in real time.",
    "＋ Додати першу покупку": "＋ Add first purchase",
    "% · спрацює на": "% · will work on",
    "Stop-Loss не задано": "Stop-Loss is not set",
    "Відкрито": "It's open",
    "· докупівель:": "Additional purchase:",
    "Кількість": "Quantity",
    "Середня ціна покупки": "Average purchase price",
    "Поточна ціна": "Current price",
    "Поточна вартість": "Current value",
    "Негативний фон": "Negative background",
    "Позитивний фон": "Positive background",
    "Нейтральний фон": "Neutral background",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Demo tape (mock): Real news is not available at this time",
    "Джерело:": "Source:",
    "Оригінальні або перекладені заголовки": "Original or translated titles",
    "Негативна": "Negative",
    "Позитивна": "Positive",
    "Нейтральна": "Neutral",
    "індекс:": "index:",
    "▼ негативних:": "▼ negative:",
    "нейтральних:": "neutral:",
    "▲ позитивних:": "▲ positive:",
    "· оригінал англійською": "· original in English",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "The mood is determined automatically by the keywords of the titles. Updated by",
    "Ще немає закритих угод.": "There are no closed deals yet.",
    "угод:": "agreements:",
    "У цьому місяці угод немає.": "There are no deals this month.",
    "Чистий результат ·": "Net result ·",
    "Закритих угод": "Closed deals",
    "Прибуткових": "Profitable",
    "з": "of",
    "Найкраща / найгірша": "The best / the worst",
    "Результат за місяцями": "Result by month",
    "За монетами ·": "By coins",
    "Останні закриті угоди": "Last closed deals",
    "Час": "time",
    "Монета": "Coin",
    "К-сть": "Mr",
    "Купівля": "Purchase",
    "Продаж": "Sale",
    "Причина": "The reason",
    "Результат": "The result",
    "Продайте першу позицію — і тут зʼявиться історія.": "Sell the first position - and here the story will appear.",
    "Не вдалося завантажити статистику:": "Failed to load statistics:",
    "Віртуальна покупка": "Virtual purchase",
    "Без обмеження стартовим капіталом": "No limit on starting capital",
    "Ціна, за яку ви її віртуально купили ($)": "The price at which you virtually bought it ($)",
    "Підставити ринкову ціну": "Substitute the market price",
    "Введіть кількість і ціну.": "Enter quantity and price.",
    "Додати до блокнота": "Add to notebook",
    "напр. 0,5": "e.g. 0.5",
    "напр. 64 500": "e.g. 64,500",
    "Підставити ринкову ціну:": "Substitute the market price:",
    "Сума покупки:": "Purchase amount:",
    "Зараз ця позиція була б у": "Now this position would be in",
    "(ринок:": "(market:",
    "Введіть додатні числа для кількості та ціни": "Enter positive numbers for quantity and price",
    "Додано:": "Added:",
    "за": "for",
    "Усереднення ·": "Averaging ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Additional purchase at a lower price with automatic recalculation of the average",
    "Зараз:": "Now:",
    "· середня": "· average",
    "· ринок": "· the market",
    "Скільки докуповуємо": "How much do we buy?",
    "Ціна докупівлі ($) — має бути нижчою за": "The additional purchase price ($) must be lower than",
    "Усереднити": "Average",
    "Введіть додатні числа.": "Enter positive numbers.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "The repurchase price must be lower than the current average (",
    "Нова кількість:": "New quantity:",
    "Нова середня ціна:": "New average price:",
    "Додаткові вкладення:": "Additional attachments:",
    "Середня ціна": "Average price",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Automatic virtual closing of the transaction at a given minus",
    "Середня ціна:": "Average price:",
    "· зараз": "· now",
    "Закрити угоду, коли збиток досягне (%)": "Close the deal when the loss reaches (%)",
    "Зберегти": "save",
    "Вимкнути": "Turn off",
    "Вкажіть відсоток від 0,1 до 99.": "Enter a percentage from 0.1 to 99.",
    "Спрацює при ціні ≤": "It will work if the price ≤",
    "Плановий збиток на порозі:": "Planned loss at the threshold:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "The price is already below the threshold - the deal will close immediately!",
    "Stop-Loss для": "Stop-Loss for",
    "встановлено: −": "established: −",
    "вимкнено": "turned off",
    "Продати": "to sell",
    "Віртуальний продаж за поточною ринковою ціною": "Virtual sale at current market price",
    "Кількість:": "Quantity:",
    "Ціна продажу:": "Sale price:",
    "Результат угоди:": "The result of the agreement:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "The result will be saved in the database and will be included in the statistics of the month.",
    "Так, продати": "Yes, sell",
    "Скасувати": "cancel",
    "продано за": "sold for",
    "різко впала:": "fell sharply:",
    "за годину": "in an hour",
    "Немає зв’язку з сервером": "No connection to the server",
    "Новини оновлено": "News updated",
    "Не вдалося оновити новини": "Failed to update news",
    "оновлення через": "update via",
    "с": "s",
    "повтор спроби підключення…": "retry connection…",
    "Видалити без фіксації ·": "Delete without fixing ·",
    "Виправлення випадково введеної позиції": "Correction of accidentally entered position",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "The position will be permanently deleted. Profit or loss will not be included in the monthly statistics.",
    "Видалити без фіксації": "Delete without recording",
    "Позицію видалено без запису в статистику": "The position was deleted without recording in the statistics",
    "Незворотна дія": "Irreversible action",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "All active positions and closed deals will be deleted. Pricing, news, and theme settings will remain.",
    "Так, очистити всі угоди": "Yes, clear all agreements",
    "Систему скинуто": "System reset",
    "Аналітика монети": "Coin analytics",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: The current POL/USDT pair is shown, not the price of the old MATIC token.",
    "Максимум вікна": "Maximum window",
    "Мінімум вікна": "Minimum window",
    "Зміна у вікні": "Change in the window",
    "Волатильність дохідностей": "Volatility of returns",
    "Історія ціни · до 60 точок": "Price history · up to 60 points",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Minute points; the current point is updated every 10 seconds. Demo prices are indicated separately.",
    "Ще недостатньо спостережень для графіка.": "Not enough observations to graph yet.",
    "Таблиця спостережень": "Table of observations",
    "Ціна": "Price",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Volatility is the standard deviation of percentage changes between the points of this window, not a maximum per day.",
    "КУПИТИ за вигідною ціною": "BUY at a good price",
    "НЕ КУПУВАТИ / ПРОДАТИ": "DO NOT BUY / SELL",
    "Утримуватись, ринок спокійний": "Hold on, the market is calm",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ High risk of market fall due to negative world news!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss worked: {symbol} closed at ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Unknown coin. Available: {coins}",
    "Кількість і ціна мають бути додатними числами": "Quantity and price must be positive numbers",
    "Позицію не знайдено": "No position found",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Averaging is possible only at a price lower than the current average (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss is a percentage from 0.1 to 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Prices are not loaded yet, try in a few seconds",
    "Формат місяця: РРРР-ММ": "Month format: YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "For hard reset send {\"confirm\": true}",
    "Повідомлення порожнє": "The message is empty",
    "Повідомлення задовге (максимум {n} символів)": "Message is too long (maximum of {n} characters)",
    "висхідний": "ascending",
    "низхідний": "descending",
    "боковий": "lateral",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: price ${price}, per hour {change:+.2f}%. Trend for 60 min: {trend}, fluctuation {vol:.2f}%. System signal: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Portfolio: cost ${value:,.2f}, result {pnl:+,.2f}$ ({pct:+.2f}%), open positions: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "The briefcase is empty. Add your first virtual purchase on a coin card.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "The news background is negative ({index:+.2f} index): the risk of a market fall is increased.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "News background without critical risk (index {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Hourly market overview: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Greetings! I am an educational AI assistant. Ask about Coin, Portfolio, News, Stop-Loss or Averaging.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "For now, I work according to simple rules (plug). Try: \"BTC price\", \"my portfolio\", \"what's new\", \"what is Stop-Loss\".",
    "Це навчальна демонстрація, а не фінансова порада.": "This is an educational demonstration, not financial advice.",
    "Прибуток і збиток (P&L)": "Profit and Loss (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L is the difference between the current value of the coins and the amount you bought them for. Plus means profit, minus means loss. Until you sell, the result is only on paper.",
    "Зміна ціни за годину": "Hourly price change",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Shows how much the price has changed in the last hour. A sharp drop (from −5%) is highlighted by the system in red, a sharp increase (from +5%) in green.",
    "Усереднення": "Averaging",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Additional purchase of the same coin at a lower price. The average purchase price is decreasing, so less growth is needed to break even. Risk: You invest more in an asset that continues to fall.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "A predetermined loss percentage, upon reaching which the deal is closed automatically. It's a hedge: you're limiting your losses even if you're not following the market.",
    "Настрій новин": "The mood of the news",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "The system reads global crypto news headlines and evaluates whether the background is positive, neutral or negative based on keywords. This is a simplified analysis, not a forecast.",
    "Віртуальна торгівля": "Virtual trade",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "All purchases here are conditional: real money is not debited. This is a safe way to learn how price movements affect the portfolio and not risk your own funds.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "I am a reference assistant: I explain terms and show current data according to rules, without a generative language model. Choose a topic below or ask about BTC, portfolio or news.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Greetings! I explain the terms from the beginner's school and show the market data. Answers are generated by rules, not a generative model.",
    "Готую відповідь…": "I am preparing an answer...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "In this simulator, the Stop-Loss is checked by the background process every 10 seconds at the received price; performance at an exact level is not guaranteed.",
    "Зміна ціни за останню годину": "Price change in the last hour",
    "Ціна за останні хвилини": "Last minute price",
    "Додати віртуальну покупку": "Add a virtual purchase",
    "＋ До блокнота": "＋ To the notebook",
    "Докупити за нижчою ціною та перерахувати середню": "Buy more at a lower price and recalculate the average",
    "⚖ Усереднити": "⚖ Average",
    "Автоматично закрити угоду при заданому відсотку збитку": "Automatically close the deal at a specified percentage of loss",
    "Віртуально продати за поточною ціною": "Virtually sell at the current price"
  },
  "ru": {
    "ШАПКА": "ШАПКА",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · обучающий симулятор",
    "📈 Ринок": "📈 Рынок",
    "💼 Портфель": "💼 Портфель",
    "📊 Статистика": "📊 Статистика",
    "📚 Школа новачка": "📚 Школа новичка",
    "Підключення…": "Подключение…",
    "БАНЕР РИЗИКУ": "БАНЕР РИСК",
    "ТАБЛО ПОРТФЕЛЯ": "ТАБЛО ПОРТФЕЛЯ",
    "Загальна вартість портфеля": "Общая стоимость портфеля",
    "віртуальний": "виртуальный",
    "результат відносно ціни покупки": "результат относительно цены покупки",
    "Вкладено (за цінами покупки)": "Вложено (по ценам покупки)",
    "Відкритих позицій": "Открытых позиций",
    "Скинути систему": "Сбросить систему",
    "Очікуємо перші дані…": "Ожидаем первые данные…",
    "оновлення через —": "обновление через —",
    "ОСНОВНА СІТКА": "ОСНОВНАЯ СЕТКА",
    "Ринок": "Рынок",
    "15 обраних монет · зміна за 1 годину": "15 выбранных монет · изменение за 1 час",
    "падіння ≥ 5% — сигнал «купити»": "падение ≥ 5% - сигнал «купить»",
    "ріст ≥ 5% — сигнал «продати»": "рост ≥ 5% - сигнал «продать»",
    "Портфель": "Портфель",
    "Віртуальний блокнот покупок": "Виртуальный блокнот покупок",
    "＋ Додати покупку": "＋ Добавить покупку",
    "Статистика": "Статистика",
    "Фінансовий підсумок місяця": "Финансовый итог месяца",
    "Місяць:": "Луна:",
    "Школа новачка": "Школа новичка",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Объяснения, примеры жизни и риски. Учеба не гарантирует прибыли.",
    "Новини": "Новости",
    "🤖 ШІ-моніторинг новин": "🤖 ШИ-мониторинг новостей",
    "Аналіз настрою світових заголовків про крипторинок": "Анализ настроения мировых заголовков о крипторынках",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Учебный проект по курсу \"Разработка программного обеспечения\". Все сделки виртуальны, реальные средства не используются.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Сигналы «купить/продать» – демонстрация логики, а не финансовый совет.",
    "МОДАЛЬНЕ ВІКНО": "МОДАЛЬНОЕ ОКНО",
    "🤖 Довідковий асистент": "🤖 Справочный ассистент",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Справка по правилам и данным API, не генеративная модель. Не является финансовым советом.",
    "Надіслати": "Отправить",
    "Стан зʼєднання та джерело цін": "Состояние соединения и источник цен",
    "Звукові сповіщення: увімк./вимк.": "Звуковые оповещения: вкл./выкл.",
    "Мова інтерфейсу": "Язык интерфейса",
    "Перемкнути темну / світлу тему": "Переключить темную/светлую тему",
    "Пошук за назвою або символом": "Поиск по названию или символу",
    "Оновити новини": "Обновить новости",
    "Діалог": "Диалог",
    "Довідковий асистент": "Справочный ассистент",
    "Закрити": "Закрыть",
    "Ваше запитання": "Ваш вопрос",
    "Binance · наживо": "Binance · вживую",
    "CoinGecko · наживо": "CoinGecko · вживую",
    "Демо-режим (імітація цін)": "Демо-режим (имитация цен)",
    "Немає даних": "Нет данных",
    "Вручну": "вручную",
    "Помилка сервера": "Ошибка сервера",
    "Звукові сповіщення увімкнено": "Звуковые оповещения включены",
    "Звукові сповіщення вимкнено": "Звуковые уведомления отключены",
    "Історія ціни": "История цены",
    "Аналітика": "Аналитика",
    "у плюсі відносно ціни покупки": "в плюсе относительно цены покупки",
    "у мінусі відносно ціни покупки": "в минусе относительно цены покупки",
    "додайте першу покупку у вкладці «Портфель»": "добавьте первую покупку во вкладке «Портфель»",
    "Оновлено о": "Обновлено о",
    "/ 1 год": "/ 1 год",
    "Блокнот порожній": "Блокнот пустой",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Разместите виртуальную покупку — и табло наверху начнет считать прибыль в реальном времени.",
    "＋ Додати першу покупку": "＋ Добавить первую покупку",
    "% · спрацює на": "% · сработает на",
    "Stop-Loss не задано": "Stop-Loss не задан",
    "Відкрито": "Открыто",
    "· докупівель:": "· докупок:",
    "Кількість": "Количество",
    "Середня ціна покупки": "Средняя цена покупки",
    "Поточна ціна": "Текущая цена",
    "Поточна вартість": "Текущая стоимость",
    "Негативний фон": "Негативный фон",
    "Позитивний фон": "Положительный фон",
    "Нейтральний фон": "Нейтральный фон",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Демо-лента (имитация): реальные новости сейчас недоступны",
    "Джерело:": "Источник:",
    "Оригінальні або перекладені заголовки": "Оригинальные или переведенные заголовки",
    "Негативна": "Отрицательная",
    "Позитивна": "Положительная",
    "Нейтральна": "Нейтрально",
    "індекс:": "индекс:",
    "▼ негативних:": "▼ отрицательных:",
    "нейтральних:": "нейтральных:",
    "▲ позитивних:": "▲ положительных:",
    "· оригінал англійською": "· оригинал на английском",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Настройка определяется автоматически по ключевым словам заголовков. Обновлено о",
    "Ще немає закритих угод.": "Еще нет закрытых сделок.",
    "угод:": "сделок:",
    "У цьому місяці угод немає.": "В этом месяце сделок нет.",
    "Чистий результат ·": "Чистый результат ·",
    "Закритих угод": "Закрытых сделок",
    "Прибуткових": "Прибыльных",
    "з": "из",
    "Найкраща / найгірша": "Самая лучшая / худшая",
    "Результат за місяцями": "Результат по месяцам",
    "За монетами ·": "За монетами ·",
    "Останні закриті угоди": "Последние закрытые сделки",
    "Час": "Время",
    "Монета": "Монета",
    "К-сть": "Кол-во",
    "Купівля": "Покупка",
    "Продаж": "Продажа",
    "Причина": "Причина",
    "Результат": "Результат",
    "Продайте першу позицію — і тут зʼявиться історія.": "Продайте первую позицию – и здесь появится история.",
    "Не вдалося завантажити статистику:": "Не удалось загрузить статистику:",
    "Віртуальна покупка": "Виртуальная покупка",
    "Без обмеження стартовим капіталом": "Без ограничения стартовым капиталом",
    "Ціна, за яку ви її віртуально купили ($)": "Цена, за которую вы ее виртуально купили ($)",
    "Підставити ринкову ціну": "Подставить рыночную цену",
    "Введіть кількість і ціну.": "Введите количество и стоимость.",
    "Додати до блокнота": "Добавить в блокнот",
    "напр. 0,5": "напр. 0,5",
    "напр. 64 500": "напр. 64 500",
    "Підставити ринкову ціну:": "Подставить рыночную цену:",
    "Сума покупки:": "Сумма покупки:",
    "Зараз ця позиція була б у": "Сейчас эта позиция была бы у",
    "(ринок:": "(рынок:",
    "Введіть додатні числа для кількості та ціни": "Введите положительные числа для количества и цены",
    "Додано:": "Добавлено:",
    "за": "за",
    "Усереднення ·": "Усреднение ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Докупка по более низкой цене с автоматическим пересчетом средней",
    "Зараз:": "Теперь:",
    "· середня": "· средняя",
    "· ринок": "· рынок",
    "Скільки докуповуємо": "Сколько докупаем",
    "Ціна докупівлі ($) — має бути нижчою за": "Цена покупки ($) — должна быть ниже",
    "Усереднити": "Усреднить",
    "Введіть додатні числа.": "Введите положительные числа.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Цена докупки должна быть ниже текущей средней (",
    "Нова кількість:": "Новое количество:",
    "Нова середня ціна:": "Новая средняя цена:",
    "Додаткові вкладення:": "Дополнительные вложения:",
    "Середня ціна": "Средняя цена",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Автоматическое виртуальное закрытие сделки при заданном минусе",
    "Середня ціна:": "Средняя цена:",
    "· зараз": "· сейчас",
    "Закрити угоду, коли збиток досягне (%)": "Закрыть сделку, когда убыток достигнет (%)",
    "Зберегти": "Сохранить",
    "Вимкнути": "Выключить",
    "Вкажіть відсоток від 0,1 до 99.": "Укажите процент от 0,1 до 99.",
    "Спрацює при ціні ≤": "Сработает при цене ≤",
    "Плановий збиток на порозі:": "Плановый ущерб на пороге:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Цена уже ниже порога — сделка закроется сразу!",
    "Stop-Loss для": "Stop-Loss для",
    "встановлено: −": "установлено: −",
    "вимкнено": "выключено",
    "Продати": "Продать",
    "Віртуальний продаж за поточною ринковою ціною": "Виртуальная продажа по текущей рыночной цене",
    "Кількість:": "Количество:",
    "Ціна продажу:": "Цена продажи:",
    "Результат угоди:": "Итог сделки:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Результат будет сохранен в базе данных и попадет в статистику месяца.",
    "Так, продати": "Да, продать",
    "Скасувати": "Отменить",
    "продано за": "продано за",
    "різко впала:": "резко упала:",
    "за годину": "в час",
    "Немає зв’язку з сервером": "Нет связи с сервером",
    "Новини оновлено": "Новости обновлены",
    "Не вдалося оновити новини": "Не удалось обновить новости",
    "оновлення через": "обновление через",
    "с": "с",
    "повтор спроби підключення…": "повтор попытки подключения…",
    "Видалити без фіксації ·": "Удалить без фиксации ·",
    "Виправлення випадково введеної позиції": "Исправление случайно введенной позиции",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Позиция будет удалена навсегда. Прибыль или убыток не попадет в месячную статистику.",
    "Видалити без фіксації": "Удалить без фиксации",
    "Позицію видалено без запису в статистику": "Позиция удалена без записи в статистику",
    "Незворотна дія": "Необратимое действие",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Все активные позиции и закрытые сделки будут удалены. Цены, новости и настройки темы останутся.",
    "Так, очистити всі угоди": "Да, очистить все сделки",
    "Систему скинуто": "Система сброшена",
    "Аналітика монети": "Аналитика монеты",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: показана актуальная пара POL/USDT, не цена старого токена MATIC.",
    "Максимум вікна": "Максимум окна",
    "Мінімум вікна": "Минимум окна",
    "Зміна у вікні": "Изменение в окне",
    "Волатильність дохідностей": "Волатильность доходностей",
    "Історія ціни · до 60 точок": "История цены · до 60 точек",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Минутные точки; текущая точка обновляется каждые 10 секунд. Демо-цены обозначаются раздельно.",
    "Ще недостатньо спостережень для графіка.": "Еще недостаточно наблюдений для графика.",
    "Таблиця спостережень": "Таблица наблюдений",
    "Ціна": "Цена",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Волатильность – стандартное отклонение процентных изменений между точками этого окна, не максимум в сутки.",
    "КУПИТИ за вигідною ціною": "КУПИТЬ по выгодной цене",
    "НЕ КУПУВАТИ / ПРОДАТИ": "НЕ ПОКУПАТЬ / ПРОДАТЬ",
    "Утримуватись, ринок спокійний": "Удерживаться, рынок спокоен",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Высокий риск падения рынка из-за негативных мировых новостей!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss сработал: {symbol} закрыт за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Неизвестная монета. Доступны: {coins}",
    "Кількість і ціна мають бути додатними числами": "Количество и цена должны быть положительными числами",
    "Позицію не знайдено": "Позиция не найдена",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Усреднение возможно только по цене ниже текущей средней (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss – это процент от 0.1 до 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Цены еще не загружены, попробуйте через несколько секунд",
    "Формат місяця: РРРР-ММ": "Формат луны: РРРР-ММ",
    "Для повного скидання надішліть {\"confirm\": true}": "Для полного сброса отправьте {\"confirm\": true}",
    "Повідомлення порожнє": "Сообщение пустое",
    "Повідомлення задовге (максимум {n} символів)": "Сообщение длинное (максимум {n} символов)",
    "висхідний": "восходящий",
    "низхідний": "нисходящий",
    "боковий": "боковой",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: цена ${price}, в час {change:+.2f}%. Тренд за 60 мин: {trend}, колебания {vol:.2f}%. Сигнал системы {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Портфель: стоимость ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), открытых позиций: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Портфель пуст. Разместите первую виртуальную покупку на карте монеты.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Новинный фон отрицательный (индекс {index:+.2f}): риск падения рынка повышен.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Новостной фон без критического риска (индекс {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Обзор рынка в час: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Привет! Я обучающий ШИ-помощник. Спросите монету, портфель, новости, Stop-Loss или усреднение.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Я пока работаю по простым правилам (заглушка). Попробуйте: «цена BTC», «мой портфель», «совместно с новостями», «что такое Stop-Loss».",
    "Це навчальна демонстрація, а не фінансова порада.": "Это обучающая демонстрация, а не финансовый совет.",
    "Прибуток і збиток (P&L)": "Прибыль и убыток (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L – разница между текущей стоимостью монет и суммой, за которую вы их купили. Плюс означает прибыль, минус – убыток. Пока вы не продали результат только на бумаге.",
    "Зміна ціни за годину": "Изменение цены в час",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Показывает, на сколько процентов цена изменилась за последний час. Резкое падение (от -5%) система подсвечивает красным, резкий рост (от +5%) - зеленым.",
    "Усереднення": "Усреднение",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Докупка той же монеты по более низкой цене. Средняя цена покупки уменьшается, поэтому для выхода в плюс требуется меньше роста. Риск: Вы вкладываете больше в актив, который продолжает падать.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Заранее задан процент ущерба, при достижении которого сделка закрывается автоматически. Это предохранитель: вы ограничиваете потери, даже если не следите за рынком.",
    "Настрій новин": "Настроение новостей",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "Система читает заголовки мировых крипто-новостей и по ключевым словам оценивает, положительный, нейтральный или отрицательный фон. Это упрощенный анализ, а не прогноз.",
    "Віртуальна торгівля": "Виртуальная торговля",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Все покупки здесь условны: реальные деньги не списываются. Это безопасный способ учиться, как движение цены влияет на портфель, и не рисковать своими средствами.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Я справочный ассистент: объясняю сроки и показываю текущие данные по правилам без генеративной языковой модели. Выберите тему ниже или попросите BTC, портфель или новости.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Привет! Объясняю сроки школы новичка и показываю данные рынка. Ответы формируются по правилам, а не по генеративной модели.",
    "Готую відповідь…": "Готовлю ответ…",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "В этом симуляторе Stop-Loss проверяется фоновым процессом каждые 10 секунд по полученной цене; исполнение на точном уровне не гарантируется.",
    "Зміна ціни за останню годину": "Изменение цены за последний час",
    "Ціна за останні хвилини": "Цена за последние минуты",
    "Додати віртуальну покупку": "Добавить виртуальную покупку",
    "＋ До блокнота": "＋ В блокнот",
    "Докупити за нижчою ціною та перерахувати середню": "Докупить по более низкой цене и перечислить среднюю",
    "⚖ Усереднити": "⚖ Усреднить",
    "Автоматично закрити угоду при заданому відсотку збитку": "Автоматически закрыть сделку при заданном проценте убытка",
    "Віртуально продати за поточною ціною": "Виртуально продать по текущей цене"
  },
  "es": {
    "ШАПКА": "SOMBRERO",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · simulador educativo",
    "📈 Ринок": "📈 Mercado",
    "💼 Портфель": "💼 Portafolio",
    "📊 Статистика": "📊 Estadísticas",
    "📚 Школа новачка": "📚 Escuela para principiantes",
    "Підключення…": "Conectando…",
    "БАНЕР РИЗИКУ": "BANNER DE RIESGO",
    "ТАБЛО ПОРТФЕЛЯ": "JUNTA DE CARTERA",
    "Загальна вартість портфеля": "El valor total de la cartera.",
    "віртуальний": "virtuales",
    "результат відносно ціни покупки": "el resultado relativo al precio de compra",
    "Вкладено (за цінами покупки)": "Invertido (a precios de compra)",
    "Відкритих позицій": "Posiciones abiertas",
    "Скинути систему": "Reiniciar el sistema",
    "Очікуємо перші дані…": "Estamos esperando los primeros datos...",
    "оновлення через —": "actualizar a través de -",
    "ОСНОВНА СІТКА": "RED PRINCIPAL",
    "Ринок": "el mercado",
    "15 обраних монет · зміна за 1 годину": "15 monedas seleccionadas · cambio en 1 hora",
    "падіння ≥ 5% — сигнал «купити»": "caída ≥ 5% - señal de \"compra\"",
    "ріст ≥ 5% — сигнал «продати»": "crecimiento ≥ 5% - señal de \"venta\"",
    "Портфель": "Portafolio",
    "Віртуальний блокнот покупок": "Cuaderno virtual de compras",
    "＋ Додати покупку": "＋ Agregar compra",
    "Статистика": "Estadísticas",
    "Фінансовий підсумок місяця": "Resumen financiero del mes",
    "Місяць:": "Mes:",
    "Школа новачка": "Escuela para principiantes",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Explicaciones, ejemplos de vida y riesgos. La formación no garantiza ingresos.",
    "Новини": "Noticias",
    "🤖 ШІ-моніторинг новин": "🤖 Monitoreo de noticias por IA",
    "Аналіз настрою світових заголовків про крипторинок": "Análisis de sentimiento de los titulares del mercado criptográfico mundial",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Proyecto educativo del curso \"Desarrollo de Software\". Todas las transacciones son virtuales, no se utilizan fondos reales.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Las señales de compra/venta son una demostración de lógica, no un consejo financiero.",
    "МОДАЛЬНЕ ВІКНО": "VENTANA MODAL",
    "🤖 Довідковий асистент": "🤖 Asistente de referencia",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Reglas API y referencia de datos, no modelo generativo. No constituye asesoramiento financiero.",
    "Надіслати": "enviar",
    "Стан зʼєднання та джерело цін": "Estado de conexión y fuente de precio",
    "Звукові сповіщення: увімк./вимк.": "Notificaciones sonoras: activar/desactivar",
    "Мова інтерфейсу": "Idioma de la interfaz",
    "Перемкнути темну / світлу тему": "Alternar tema oscuro/claro",
    "Пошук за назвою або символом": "Buscar por nombre o símbolo",
    "Оновити новини": "Actualizar noticias",
    "Діалог": "Diálogo",
    "Довідковий асистент": "Asistente de referencia",
    "Закрити": "cerrar",
    "Ваше запитання": "Tu pregunta",
    "Binance · наживо": "Binance · en vivo",
    "CoinGecko · наживо": "CoinGecko · en vivo",
    "Демо-режим (імітація цін)": "Modo demo (imitación de precios)",
    "Немає даних": "No hay datos disponibles",
    "Вручну": "Manualmente",
    "Помилка сервера": "error del servidor",
    "Звукові сповіщення увімкнено": "Las notificaciones sonoras están habilitadas.",
    "Звукові сповіщення вимкнено": "Las notificaciones sonoras están desactivadas",
    "Історія ціни": "Historial de precios",
    "Аналітика": "Analítica",
    "у плюсі відносно ціни покупки": "en el plus relativo al precio de compra",
    "у мінусі відносно ціни покупки": "en rojo en relación con el precio de compra",
    "додайте першу покупку у вкладці «Портфель»": "añade tu primera compra en la pestaña \"Portafolio\"",
    "Оновлено о": "Actualizado por",
    "/ 1 год": "/ 1 hora",
    "Блокнот порожній": "el cuaderno esta vacio",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Agregue una compra virtual y el marcador en la parte superior comenzará a contar las ganancias en tiempo real.",
    "＋ Додати першу покупку": "＋ Agregar primera compra",
    "% · спрацює на": "% · trabajará en",
    "Stop-Loss не задано": "El stop-loss no está establecido",
    "Відкрито": "esta abierto",
    "· докупівель:": "Compra adicional:",
    "Кількість": "Cantidad",
    "Середня ціна покупки": "Precio medio de compra",
    "Поточна ціна": "Precio actual",
    "Поточна вартість": "Valor actual",
    "Негативний фон": "Antecedentes negativos",
    "Позитивний фон": "Antecedentes positivos",
    "Нейтральний фон": "fondo neutro",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Cinta de demostración (simulacro): Las noticias reales no están disponibles en este momento",
    "Джерело:": "Fuente:",
    "Оригінальні або перекладені заголовки": "Títulos originales o traducidos",
    "Негативна": "Negativo",
    "Позитивна": "Positivo",
    "Нейтральна": "Neutro",
    "індекс:": "índice:",
    "▼ негативних:": "▼ negativo:",
    "нейтральних:": "neutro:",
    "▲ позитивних:": "▲ positivo:",
    "· оригінал англійською": "· original en inglés",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "El estado de ánimo lo determinan automáticamente las palabras clave de los títulos. Actualizado por",
    "Ще немає закритих угод.": "Aún no hay acuerdos cerrados.",
    "угод:": "acuerdos:",
    "У цьому місяці угод немає.": "Este mes no hay ofertas.",
    "Чистий результат ·": "Resultado neto ·",
    "Закритих угод": "Negocios cerrados",
    "Прибуткових": "Rentable",
    "з": "de",
    "Найкраща / найгірша": "Lo mejor/lo peor",
    "Результат за місяцями": "Resultado por mes",
    "За монетами ·": "Por monedas",
    "Останні закриті угоди": "Últimos negocios cerrados",
    "Час": "tiempo",
    "Монета": "moneda",
    "К-сть": "señor",
    "Купівля": "Compra",
    "Продаж": "Venta",
    "Причина": "la razon",
    "Результат": "El resultado",
    "Продайте першу позицію — і тут зʼявиться історія.": "Venda la primera posición y aquí aparecerá la historia.",
    "Не вдалося завантажити статистику:": "No se pudieron cargar las estadísticas:",
    "Віртуальна покупка": "Compra virtual",
    "Без обмеження стартовим капіталом": "Sin límite de capital inicial",
    "Ціна, за яку ви її віртуально купили ($)": "El precio al que lo compraste virtualmente ($)",
    "Підставити ринкову ціну": "Sustituir el precio de mercado",
    "Введіть кількість і ціну.": "Introduzca cantidad y precio.",
    "Додати до блокнота": "Agregar al cuaderno",
    "напр. 0,5": "por ej. 0,5",
    "напр. 64 500": "por ej. 64.500",
    "Підставити ринкову ціну:": "Sustituir el precio de mercado:",
    "Сума покупки:": "Monto de la compra:",
    "Зараз ця позиція була б у": "Ahora esta posición estaría en",
    "(ринок:": "(mercado:",
    "Введіть додатні числа для кількості та ціни": "Ingrese números positivos para cantidad y precio",
    "Додано:": "Añadido:",
    "за": "para",
    "Усереднення ·": "Promediando ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Compra adicional a un precio más bajo con recálculo automático del promedio",
    "Зараз:": "Ahora:",
    "· середня": "· promedio",
    "· ринок": "· el mercado",
    "Скільки докуповуємо": "¿Cuánto compramos?",
    "Ціна докупівлі ($) — має бути нижчою за": "El precio de compra adicional ($) debe ser inferior a",
    "Усереднити": "Promedio",
    "Введіть додатні числа.": "Introduzca números positivos.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "El precio de recompra debe ser inferior al promedio actual (",
    "Нова кількість:": "Nueva cantidad:",
    "Нова середня ціна:": "Nuevo precio medio:",
    "Додаткові вкладення:": "Archivos adjuntos adicionales:",
    "Середня ціна": "Precio medio",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Cierre virtual automático de la transacción en un punto negativo determinado.",
    "Середня ціна:": "Precio medio:",
    "· зараз": "· ahora",
    "Закрити угоду, коли збиток досягне (%)": "Cierra el trato cuando la pérdida alcance (%)",
    "Зберегти": "guardar",
    "Вимкнути": "Apagar",
    "Вкажіть відсоток від 0,1 до 99.": "Introduzca un porcentaje entre 0,1 y 99.",
    "Спрацює при ціні ≤": "Funcionará si el precio ≤",
    "Плановий збиток на порозі:": "Pérdida planificada en el umbral:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "El precio ya está por debajo del umbral: ¡el trato se cerrará inmediatamente!",
    "Stop-Loss для": "Stop Loss para",
    "встановлено: −": "establecido: −",
    "вимкнено": "apagado",
    "Продати": "vender",
    "Віртуальний продаж за поточною ринковою ціною": "Venta virtual al precio actual de mercado",
    "Кількість:": "Cantidad:",
    "Ціна продажу:": "Precio de venta:",
    "Результат угоди:": "El resultado del acuerdo:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "El resultado se guardará en la base de datos y se incluirá en las estadísticas del mes.",
    "Так, продати": "si, vender",
    "Скасувати": "cancelar",
    "продано за": "vendido por",
    "різко впала:": "cayó bruscamente:",
    "за годину": "en una hora",
    "Немає зв’язку з сервером": "Sin conexión al servidor",
    "Новини оновлено": "Noticias actualizadas",
    "Не вдалося оновити новини": "No se pudo actualizar la noticia",
    "оновлення через": "actualizar a través de",
    "с": "s",
    "повтор спроби підключення…": "reintentar la conexión…",
    "Видалити без фіксації ·": "Eliminar sin arreglar ·",
    "Виправлення випадково введеної позиції": "Corrección de posición introducida accidentalmente",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "La posición será eliminada permanentemente. Las ganancias o pérdidas no se incluirán en las estadísticas mensuales.",
    "Видалити без фіксації": "Eliminar sin registrar",
    "Позицію видалено без запису в статистику": "La posición fue eliminada sin registrarse en las estadísticas.",
    "Незворотна дія": "Acción irreversible",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Se eliminarán todas las posiciones activas y acuerdos cerrados. Se mantendrán las configuraciones de precios, noticias y temas.",
    "Так, очистити всі угоди": "Sí, borrar todos los acuerdos",
    "Систему скинуто": "Reinicio del sistema",
    "Аналітика монети": "Análisis de monedas",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: se muestra el par POL/USDT actual, no el precio del antiguo token MATIC.",
    "Максимум вікна": "Ventana máxima",
    "Мінімум вікна": "Ventana mínima",
    "Зміна у вікні": "Cambio en la ventana",
    "Волатильність дохідностей": "Volatilidad de los rendimientos",
    "Історія ціни · до 60 точок": "Historial de precios · hasta 60 puntos",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Puntos minutos; el punto actual se actualiza cada 10 segundos. Los precios de demostración se indican por separado.",
    "Ще недостатньо спостережень для графіка.": "Aún no hay suficientes observaciones para graficar.",
    "Таблиця спостережень": "Tabla de observaciones",
    "Ціна": "Precio",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "La volatilidad es la desviación estándar de los cambios porcentuales entre los puntos de esta ventana, no un máximo por día.",
    "КУПИТИ за вигідною ціною": "COMPRAR a buen precio",
    "НЕ КУПУВАТИ / ПРОДАТИ": "NO COMPRAR/VENDER",
    "Утримуватись, ринок спокійний": "Espera, el mercado está tranquilo.",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ ¡Alto riesgo de caída del mercado debido a noticias mundiales negativas!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss funcionó: {symbol} cerró en ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Moneda desconocida. Disponible: {coins}",
    "Кількість і ціна мають бути додатними числами": "La cantidad y el precio deben ser números positivos.",
    "Позицію не знайдено": "No se encontró ninguna posición",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "El promedio sólo es posible a un precio inferior al promedio actual (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss es un porcentaje de 0,1 a 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Los precios aún no están cargados, inténtalo en unos segundos.",
    "Формат місяця: РРРР-ММ": "Formato de mes: AAAA-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "Para restablecimiento completo envíe {\"confirm\": true}",
    "Повідомлення порожнє": "El mensaje esta vacio",
    "Повідомлення задовге (максимум {n} символів)": "El mensaje es demasiado largo (máximo de caracteres {n})",
    "висхідний": "ascendiendo",
    "низхідний": "descendiendo",
    "боковий": "laterales",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: precio ${price}, por hora {change:+.2f}%. Tendencia durante 60 min: {trend}, fluctuación {vol:.2f}%. Señal del sistema: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Cartera: costo ${value:,.2f}, resultado {pnl:+,.2f}$ ({pct:+.2f}%), posiciones abiertas: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "El maletín está vacío. Agrega tu primera compra virtual en una tarjeta de monedas.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "El trasfondo de las noticias es negativo (índice {index:+.2f}): aumenta el riesgo de caída del mercado.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Antecedentes de noticias sin riesgo crítico (índice {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Resumen del mercado horario: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "¡Saludos! Soy un asistente educativo de IA. Pregunte sobre monedas, carteras, noticias, stop-loss o promedios.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Por ahora trabajo según reglas simples (enchufe). Pruebe: \"precio BTC\", \"mi cartera\", \"novedades\", \"qué es el Stop-Loss\".",
    "Це навчальна демонстрація, а не фінансова порада.": "Esta es una demostración educativa, no un consejo financiero.",
    "Прибуток і збиток (P&L)": "Ganancias y pérdidas (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L es la diferencia entre el valor actual de las monedas y el monto por el que las compraste. Más significa ganancia, menos significa pérdida. Hasta que lo vendas, el resultado sólo está en el papel.",
    "Зміна ціни за годину": "Cambio de precio por hora",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Muestra cuánto ha cambiado el precio en la última hora. El sistema resalta en rojo una fuerte caída (desde -5%) y un fuerte aumento (desde +5%) en verde.",
    "Усереднення": "promediando",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Compra adicional de la misma moneda a un precio menor. El precio de compra promedio está disminuyendo, por lo que se necesita menos crecimiento para alcanzar el punto de equilibrio. Riesgo: Inviertes más en un activo que sigue cayendo.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Un porcentaje de pérdida predeterminado, al alcanzarse el cual el trato se cierra automáticamente. Es una cobertura: estás limitando tus pérdidas incluso si no estás siguiendo el mercado.",
    "Настрій новин": "El estado de ánimo de las noticias",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "El sistema lee los titulares de noticias criptográficas globales y evalúa si el fondo es positivo, neutral o negativo en función de las palabras clave. Este es un análisis simplificado, no un pronóstico.",
    "Віртуальна торгівля": "comercio virtual",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Todas las compras aquí son condicionales: no se carga dinero real. Esta es una forma segura de aprender cómo los movimientos de precios afectan la cartera y no arriesgar sus propios fondos.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Soy un asistente de referencia: explico términos y muestro datos actuales según reglas, sin un modelo de lenguaje generativo. Elija un tema a continuación o pregunte sobre BTC, cartera o noticias.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "¡Saludos! Explico los términos de la escuela para principiantes y muestro los datos del mercado. Las respuestas se generan mediante reglas, no mediante un modelo generativo.",
    "Готую відповідь…": "Estoy preparando una respuesta...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "En este simulador, el proceso en segundo plano verifica el Stop-Loss cada 10 segundos al precio recibido; No se garantiza un rendimiento a un nivel exacto.",
    "Зміна ціни за останню годину": "Cambio de precio en la última hora.",
    "Ціна за останні хвилини": "Precio de última hora",
    "Додати віртуальну покупку": "Añadir una compra virtual",
    "＋ До блокнота": "＋ Al cuaderno",
    "Докупити за нижчою ціною та перерахувати середню": "Compra más a menor precio y recalcula la media",
    "⚖ Усереднити": "⚖ Promedio",
    "Автоматично закрити угоду при заданому відсотку збитку": "Cerrar automáticamente el trato con un porcentaje específico de pérdida",
    "Віртуально продати за поточною ціною": "Prácticamente se vende al precio actual."
  },
  "hi": {
    "ШАПКА": "टोपी",
    "Intelligence Tracker · навчальний симулятор": "इंटेलिजेंस ट्रैकर · शैक्षिक सिम्युलेटर",
    "📈 Ринок": "📈 बाज़ार",
    "💼 Портфель": "💼पोर्टफोलियो",
    "📊 Статистика": "📊सांख्यिकी",
    "📚 Школа новачка": "📚 शुरुआती पाठशाला",
    "Підключення…": "कनेक्ट हो रहा है...",
    "БАНЕР РИЗИКУ": "जोखिम बैनर",
    "ТАБЛО ПОРТФЕЛЯ": "पोर्टफोलियो बोर्ड",
    "Загальна вартість портфеля": "पोर्टफोलियो का कुल मूल्य",
    "віртуальний": "आभासी",
    "результат відносно ціни покупки": "खरीद मूल्य के सापेक्ष परिणाम",
    "Вкладено (за цінами покупки)": "निवेशित (खरीद मूल्य पर)",
    "Відкритих позицій": "खुली स्थिति",
    "Скинути систему": "सिस्टम को रीसेट करें",
    "Очікуємо перші дані…": "हम पहले डेटा का इंतजार कर रहे हैं...",
    "оновлення через —": "के माध्यम से अद्यतन करें -",
    "ОСНОВНА СІТКА": "मुख्य ग्रिड",
    "Ринок": "बाजार",
    "15 обраних монет · зміна за 1 годину": "15 चयनित सिक्के · 1 घंटे में परिवर्तन",
    "падіння ≥ 5% — сигнал «купити»": "गिरावट ≥ 5% - \"खरीदें\" संकेत",
    "ріст ≥ 5% — сигнал «продати»": "वृद्धि ≥ 5% - \"बेचना\" संकेत",
    "Портфель": "पोर्टफोलियो",
    "Віртуальний блокнот покупок": "खरीदारी की आभासी नोटबुक",
    "＋ Додати покупку": "＋ खरीदारी जोड़ें",
    "Статистика": "सांख्यिकी",
    "Фінансовий підсумок місяця": "माह का वित्तीय सारांश",
    "Місяць:": "महीना:",
    "Школа новачка": "शुरुआती पाठशाला",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "स्पष्टीकरण, जीवन उदाहरण और जोखिम। प्रशिक्षण आय की गारंटी नहीं देता.",
    "Новини": "समाचार",
    "🤖 ШІ-моніторинг новин": "🤖 एआई समाचार निगरानी",
    "Аналіз настрою світових заголовків про крипторинок": "वैश्विक क्रिप्टो बाजार की सुर्खियों का भावना विश्लेषण",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "\"सॉफ़्टवेयर डेवलपमेंट\" पाठ्यक्रम से शैक्षिक परियोजना। सभी लेन-देन आभासी हैं, किसी वास्तविक धनराशि का उपयोग नहीं किया जाता है।",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "खरीदें/बेचें संकेत तर्क का प्रदर्शन हैं, वित्तीय सलाह नहीं।",
    "МОДАЛЬНЕ ВІКНО": "मॉडल विंडो",
    "🤖 Довідковий асистент": "🤖संदर्भ सहायक",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "एपीआई नियम और डेटा संदर्भ, जेनरेटिव मॉडल नहीं। वित्तीय सलाह का गठन नहीं करता.",
    "Надіслати": "भेजें",
    "Стан зʼєднання та джерело цін": "कनेक्शन की स्थिति और मूल्य स्रोत",
    "Звукові сповіщення: увімк./вимк.": "ध्वनि सूचनाएँ: चालू/बंद",
    "Мова інтерфейсу": "इंटरफ़ेस भाषा",
    "Перемкнути темну / світлу тему": "डार्क/लाइट थीम को टॉगल करें",
    "Пошук за назвою або символом": "नाम या प्रतीक से खोजें",
    "Оновити новини": "समाचार अपडेट करें",
    "Діалог": "संवाद",
    "Довідковий асистент": "संदर्भ सहायक",
    "Закрити": "बंद करें",
    "Ваше запитання": "आपका प्रश्न",
    "Binance · наживо": "बायनेन्स · लाइव",
    "CoinGecko · наживо": "कॉइनगेको · लाइव",
    "Демо-режим (імітація цін)": "डेमो मोड (कीमतों की नकल)",
    "Немає даних": "कोई डेटा उपलब्ध नहीं है",
    "Вручну": "मैन्युअल रूप से",
    "Помилка сервера": "सर्वर त्रुटि",
    "Звукові сповіщення увімкнено": "ध्वनि सूचनाएं सक्षम हैं",
    "Звукові сповіщення вимкнено": "ध्वनि सूचनाएं बंद हैं",
    "Історія ціни": "मूल्य इतिहास",
    "Аналітика": "विश्लेषिकी",
    "у плюсі відносно ціни покупки": "खरीद मूल्य के सापेक्ष प्लस में",
    "у мінусі відносно ціни покупки": "खरीद मूल्य के सापेक्ष लाल रंग में",
    "додайте першу покупку у вкладці «Портфель»": "अपनी पहली खरीदारी \"पोर्टफोलियो\" टैब में जोड़ें",
    "Оновлено о": "द्वारा अद्यतन किया गया",
    "/ 1 год": "/ 1 घंटा",
    "Блокнот порожній": "नोटबुक खाली है",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "एक आभासी खरीदारी जोड़ें - और शीर्ष पर स्कोरबोर्ड वास्तविक समय में मुनाफे की गिनती शुरू कर देगा।",
    "＋ Додати першу покупку": "＋ पहली खरीदारी जोड़ें",
    "% · спрацює на": "% · पर काम होगा",
    "Stop-Loss не задано": "स्टॉप-लॉस सेट नहीं है",
    "Відкрито": "यह खुला है",
    "· докупівель:": "अतिरिक्त खरीदारी:",
    "Кількість": "मात्रा",
    "Середня ціна покупки": "औसत खरीद मूल्य",
    "Поточна ціна": "वर्तमान कीमत",
    "Поточна вартість": "वर्तमान मूल्य",
    "Негативний фон": "नकारात्मक पृष्ठभूमि",
    "Позитивний фон": "सकारात्मक पृष्ठभूमि",
    "Нейтральний фон": "तटस्थ पृष्ठभूमि",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "डेमो टेप (नकली): वास्तविक समाचार इस समय उपलब्ध नहीं है",
    "Джерело:": "स्रोत:",
    "Оригінальні або перекладені заголовки": "मूल या अनुवादित शीर्षक",
    "Негативна": "नकारात्मक",
    "Позитивна": "सकारात्मक",
    "Нейтральна": "तटस्थ",
    "індекс:": "सूचकांक:",
    "▼ негативних:": "▼ नकारात्मक:",
    "нейтральних:": "तटस्थ:",
    "▲ позитивних:": "▲ सकारात्मक:",
    "· оригінал англійською": "· मूल अंग्रेजी में",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "मूड शीर्षकों के कीवर्ड द्वारा स्वचालित रूप से निर्धारित होता है। द्वारा अद्यतन किया गया",
    "Ще немає закритих угод.": "अभी तक कोई बंद सौदे नहीं हुए हैं.",
    "угод:": "समझौते:",
    "У цьому місяці угод немає.": "इस महीने कोई डील नहीं है.",
    "Чистий результат ·": "शुद्ध परिणाम ·",
    "Закритих угод": "बंद सौदे",
    "Прибуткових": "लाभदायक",
    "з": "में से",
    "Найкраща / найгірша": "सबसे अच्छा/सबसे खराब",
    "Результат за місяцями": "महीने के अनुसार परिणाम",
    "За монетами ·": "सिक्कों से",
    "Останні закриті угоди": "अंतिम बंद सौदे",
    "Час": "समय",
    "Монета": "सिक्का",
    "К-сть": "श्रीमान",
    "Купівля": "खरीद",
    "Продаж": "बिक्री",
    "Причина": "कारण",
    "Результат": "नतीजा",
    "Продайте першу позицію — і тут зʼявиться історія.": "पहली स्थिति बेचें - और यहां कहानी दिखाई देगी।",
    "Не вдалося завантажити статистику:": "आँकड़े लोड करने में विफल:",
    "Віртуальна покупка": "आभासी खरीदारी",
    "Без обмеження стартовим капіталом": "आरंभिक पूंजी की कोई सीमा नहीं",
    "Ціна, за яку ви її віртуально купили ($)": "वह कीमत जिस पर आपने इसे वस्तुतः खरीदा ($)",
    "Підставити ринкову ціну": "बाज़ार मूल्य का स्थानापन्न करें",
    "Введіть кількість і ціну.": "मात्रा और कीमत दर्ज करें.",
    "Додати до блокнота": "नोटबुक में जोड़ें",
    "напр. 0,5": "जैसे 0.5",
    "напр. 64 500": "जैसे 64,500",
    "Підставити ринкову ціну:": "बाज़ार मूल्य को प्रतिस्थापित करें:",
    "Сума покупки:": "खरीद राशि:",
    "Зараз ця позиція була б у": "अब यह पद रहेगा",
    "(ринок:": "(बाजार:",
    "Введіть додатні числа для кількості та ціни": "मात्रा और कीमत के लिए सकारात्मक संख्याएँ दर्ज करें",
    "Додано:": "जोड़ा गया:",
    "за": "के लिए",
    "Усереднення ·": "औसत ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "औसत की स्वचालित पुनर्गणना के साथ कम कीमत पर अतिरिक्त खरीदारी",
    "Зараз:": "अब:",
    "· середня": "· औसत",
    "· ринок": "· बाज़ार",
    "Скільки докуповуємо": "हम कितना खरीदते हैं?",
    "Ціна докупівлі ($) — має бути нижчою за": "अतिरिक्त खरीद मूल्य ($) से कम होना चाहिए",
    "Усереднити": "औसत",
    "Введіть додатні числа.": "सकारात्मक संख्याएँ दर्ज करें.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "पुनर्खरीद मूल्य मौजूदा औसत से कम होना चाहिए (",
    "Нова кількість:": "नई मात्रा:",
    "Нова середня ціна:": "नई औसत कीमत:",
    "Додаткові вкладення:": "अतिरिक्त अनुलग्नक:",
    "Середня ціна": "औसत कीमत",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "किसी दिए गए माइनस पर लेन-देन का स्वचालित आभासी समापन",
    "Середня ціна:": "औसत कीमत:",
    "· зараз": "· अभी",
    "Закрити угоду, коли збиток досягне (%)": "जब घाटा (%) तक पहुँच जाए तो सौदा बंद कर दें",
    "Зберегти": "सहेजें",
    "Вимкнути": "बंद करो",
    "Вкажіть відсоток від 0,1 до 99.": "0.1 और 99 के बीच प्रतिशत दर्ज करें।",
    "Спрацює при ціні ≤": "यदि कीमत ≤ हो तो यह काम करेगा",
    "Плановий збиток на порозі:": "दहलीज पर नियोजित हानि:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "कीमत पहले से ही सीमा से नीचे है - सौदा तुरंत बंद हो जाएगा!",
    "Stop-Loss для": "स्टॉप-लॉस के लिए",
    "встановлено: −": "स्थापित: −",
    "вимкнено": "बंद कर दिया",
    "Продати": "बेचने के लिए",
    "Віртуальний продаж за поточною ринковою ціною": "वर्तमान बाजार मूल्य पर आभासी बिक्री",
    "Кількість:": "मात्रा:",
    "Ціна продажу:": "बिक्री मूल्य:",
    "Результат угоди:": "समझौते का परिणाम:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "परिणाम डेटाबेस में सहेजा जाएगा और महीने के आंकड़ों में शामिल किया जाएगा।",
    "Так, продати": "हाँ, बेचो",
    "Скасувати": "रद्द करें",
    "продано за": "के लिए बेचा गया",
    "різко впала:": "तेजी से गिर गया:",
    "за годину": "एक घंटे में",
    "Немає зв’язку з сервером": "सर्वर से कोई कनेक्शन नहीं",
    "Новини оновлено": "समाचार अद्यतन किया गया",
    "Не вдалося оновити новини": "समाचार अद्यतन करने में विफल",
    "оновлення через": "के माध्यम से अद्यतन करें",
    "с": "सेकंड",
    "повтор спроби підключення…": "कनेक्शन पुनः प्रयास करें...",
    "Видалити без фіксації ·": "बिना ठीक किए हटाएं ·",
    "Виправлення випадково введеної позиції": "गलती से दर्ज की गई स्थिति का सुधार",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "पद स्थायी रूप से हटा दिया जाएगा. लाभ या हानि को मासिक आँकड़ों में शामिल नहीं किया जाएगा।",
    "Видалити без фіксації": "दर्ज किए बिना हटाएँ",
    "Позицію видалено без запису в статистику": "आँकड़ों में दर्ज किए बिना स्थिति हटा दी गई",
    "Незворотна дія": "अपरिवर्तनीय क्रिया",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "सभी सक्रिय पद और बंद सौदे हटा दिए जाएंगे। मूल्य निर्धारण, समाचार और थीम सेटिंग बनी रहेंगी.",
    "Так, очистити всі угоди": "हां, सभी समझौते साफ़ करें",
    "Систему скинуто": "सिस्टम रीसेट",
    "Аналітика монети": "सिक्का विश्लेषण",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: वर्तमान POL/USDT जोड़ी दिखाई गई है, पुराने MATIC टोकन की कीमत नहीं।",
    "Максимум вікна": "अधिकतम विंडो",
    "Мінімум вікна": "न्यूनतम विंडो",
    "Зміна у вікні": "विंडो में बदलें",
    "Волатильність дохідностей": "रिटर्न की अस्थिरता",
    "Історія ціни · до 60 точок": "मूल्य इतिहास · 60 अंक तक",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "मिनट अंक; वर्तमान बिंदु हर 10 सेकंड में अपडेट किया जाता है। डेमो कीमतें अलग से दर्शाई गई हैं।",
    "Ще недостатньо спостережень для графіка.": "ग्राफ़ बनाने के लिए अभी तक पर्याप्त अवलोकन नहीं हैं।",
    "Таблиця спостережень": "प्रेक्षणों की तालिका",
    "Ціна": "कीमत",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "अस्थिरता इस विंडो के बिंदुओं के बीच प्रतिशत परिवर्तन का मानक विचलन है, प्रति दिन अधिकतम नहीं।",
    "КУПИТИ за вигідною ціною": "अच्छी कीमत पर खरीदें",
    "НЕ КУПУВАТИ / ПРОДАТИ": "खरीदें/बेचें नहीं",
    "Утримуватись, ринок спокійний": "रुकिए, बाजार शांत है",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ दुनिया की नकारात्मक खबरों से बाजार में गिरावट का खतरा ज्यादा!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "स्टॉप-लॉस काम किया: {symbol} ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$) पर बंद हुआ",
    "Невідома монета. Доступні: {coins}": "अज्ञात सिक्का. उपलब्ध: {coins}",
    "Кількість і ціна мають бути додатними числами": "मात्रा और कीमत धनात्मक संख्या होनी चाहिए",
    "Позицію не знайдено": "कोई पद नहीं मिला",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "औसतीकरण केवल वर्तमान औसत (${avg:,.4f}) से कम कीमत पर ही संभव है",
    "Stop-Loss — це відсоток від 0.1 до 99": "स्टॉप-लॉस 0.1 से 99 तक का प्रतिशत है",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "कीमतें अभी तक लोड नहीं की गई हैं, कुछ सेकंड में प्रयास करें",
    "Формат місяця: РРРР-ММ": "माह प्रारूप: YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "हार्ड रीसेट के लिए {\"confirm\": true} भेजें",
    "Повідомлення порожнє": "संदेश खाली है",
    "Повідомлення задовге (максимум {n} символів)": "संदेश बहुत लंबा है (अधिकतम {n} वर्ण)",
    "висхідний": "आरोही",
    "низхідний": "अवरोही",
    "боковий": "पार्श्व",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: मूल्य ${price}, प्रति घंटा {change:+.2f}%। 60 मिनट के लिए रुझान: {trend}, उतार-चढ़ाव {vol:.2f}%। सिस्टम सिग्नल: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "पोर्टफोलियो: लागत ${value:,.2f}, परिणाम {pnl:+,.2f}$ ({pct:+.2f}%), खुली स्थिति: {count}।",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "ब्रीफकेस खाली है. कॉइन कार्ड पर अपनी पहली आभासी खरीदारी जोड़ें।",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "समाचार पृष्ठभूमि नकारात्मक है ({index:+.2f} सूचकांक): बाजार में गिरावट का जोखिम बढ़ गया है।",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "गंभीर जोखिम के बिना समाचार पृष्ठभूमि (सूचकांक {index:+.2f})।",
    "Огляд ринку за годину: {items}.": "प्रति घंटा बाज़ार अवलोकन: {items}।",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "अभिवादन! मैं एक शैक्षिक एआई सहायक हूं। कॉइन, पोर्टफोलियो, समाचार, स्टॉप-लॉस या एवरेजिंग के बारे में पूछें।",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "अभी के लिए, मैं सरल नियमों (प्लग) के अनुसार काम करता हूं। आज़माएँ: \"बीटीसी मूल्य\", \"मेरा पोर्टफोलियो\", \"नया क्या है\", \"स्टॉप-लॉस क्या है\"।",
    "Це навчальна демонстрація, а не фінансова порада.": "यह एक शैक्षिक प्रदर्शन है, वित्तीय सलाह नहीं।",
    "Прибуток і збиток (P&L)": "लाभ और हानि (पी एंड एल)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L सिक्कों के वर्तमान मूल्य और आपके द्वारा उन्हें खरीदी गई राशि के बीच का अंतर है। प्लस का अर्थ है लाभ, माइनस का अर्थ है हानि। जब तक आप बेचते नहीं, परिणाम केवल कागज़ पर ही होता है।",
    "Зміна ціни за годину": "प्रति घंटा मूल्य परिवर्तन",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "दिखाता है कि पिछले घंटे में कीमत में कितना बदलाव आया है। सिस्टम द्वारा एक तेज गिरावट (-5% से) को लाल रंग में, एक तेज वृद्धि (+5% से) को हरे रंग में हाइलाइट किया जाता है।",
    "Усереднення": "औसत",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "कम कीमत पर उसी सिक्के की अतिरिक्त खरीदारी। औसत खरीद मूल्य घट रहा है, इसलिए संतुलन के लिए कम वृद्धि की आवश्यकता है। जोखिम: आप ऐसी परिसंपत्ति में अधिक निवेश करते हैं जिसमें गिरावट जारी रहती है।",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "एक पूर्व निर्धारित हानि प्रतिशत, जिस पर पहुँचने पर सौदा स्वतः बंद हो जाता है। यह एक बचाव है: आप अपने घाटे को सीमित कर रहे हैं, भले ही आप बाज़ार का अनुसरण नहीं कर रहे हों।",
    "Настрій новин": "खबर का मिजाज",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "सिस्टम वैश्विक क्रिप्टो समाचार सुर्खियों को पढ़ता है और कीवर्ड के आधार पर मूल्यांकन करता है कि पृष्ठभूमि सकारात्मक, तटस्थ या नकारात्मक है या नहीं। यह एक सरलीकृत विश्लेषण है, पूर्वानुमान नहीं।",
    "Віртуальна торгівля": "आभासी व्यापार",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "यहां सभी खरीदारी सशर्त हैं: वास्तविक पैसा डेबिट नहीं किया जाता है। यह यह जानने का एक सुरक्षित तरीका है कि मूल्य परिवर्तन पोर्टफोलियो को कैसे प्रभावित करते हैं और अपने स्वयं के फंड को जोखिम में नहीं डालते हैं।",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "मैं एक संदर्भ सहायक हूं: मैं नियमों के अनुसार शब्दों की व्याख्या करता हूं और वर्तमान डेटा दिखाता हूं, बिना किसी जनरेटिव भाषा मॉडल के। नीचे कोई विषय चुनें या बीटीसी, पोर्टफोलियो या समाचार के बारे में पूछें।",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "अभिवादन! मैं शुरुआती स्कूल की शर्तों को समझाता हूं और बाजार डेटा दिखाता हूं। उत्तर नियमों द्वारा उत्पन्न होते हैं, जनरेटिव मॉडल से नहीं।",
    "Готую відповідь…": "मैं एक उत्तर तैयार कर रहा हूँ...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "इस सिम्युलेटर में, प्राप्त मूल्य पर हर 10 सेकंड में पृष्ठभूमि प्रक्रिया द्वारा स्टॉप-लॉस की जाँच की जाती है; सटीक स्तर पर प्रदर्शन की गारंटी नहीं है.",
    "Зміна ціни за останню годину": "आखिरी घंटे में कीमत में बदलाव",
    "Ціна за останні хвилини": "अंतिम मिनट की कीमत",
    "Додати віртуальну покупку": "एक आभासी खरीदारी जोड़ें",
    "＋ До блокнота": "＋नोटबुक को",
    "Докупити за нижчою ціною та перерахувати середню": "कम कीमत पर अधिक खरीदें और औसत की पुनर्गणना करें",
    "⚖ Усереднити": "⚖ औसत",
    "Автоматично закрити угоду при заданому відсотку збитку": "हानि के एक निर्दिष्ट प्रतिशत पर सौदा स्वचालित रूप से बंद करें",
    "Віртуально продати за поточною ціною": "वस्तुतः मौजूदा कीमत पर बेचें"
  },
  "vi": {
    "ШАПКА": "MŨ",
    "Intelligence Tracker · навчальний симулятор": "Trình theo dõi trí thông minh · mô phỏng giáo dục",
    "📈 Ринок": "📈 Chợ",
    "💼 Портфель": "💼 Danh mục đầu tư",
    "📊 Статистика": "📊 Thống kê",
    "📚 Школа новачка": "📚 Trường học cho người mới",
    "Підключення…": "Đang kết nối…",
    "БАНЕР РИЗИКУ": "BIỂU NGUYÊN RỦI RO",
    "ТАБЛО ПОРТФЕЛЯ": "BẢNG DANH MỤC ĐẦU TƯ",
    "Загальна вартість портфеля": "Tổng giá trị của danh mục đầu tư",
    "віртуальний": "ảo",
    "результат відносно ціни покупки": "kết quả liên quan đến giá mua",
    "Вкладено (за цінами покупки)": "Đã đầu tư (theo giá mua)",
    "Відкритих позицій": "Vị thế mở",
    "Скинути систему": "Đặt lại hệ thống",
    "Очікуємо перші дані…": "Chúng tôi đang chờ đợi dữ liệu đầu tiên...",
    "оновлення через —": "cập nhật qua -",
    "ОСНОВНА СІТКА": "LƯỚI CHÍNH",
    "Ринок": "thị trường",
    "15 обраних монет · зміна за 1 годину": "15 xu đã chọn · thay đổi sau 1 giờ",
    "падіння ≥ 5% — сигнал «купити»": "giảm ≥ 5% - tín hiệu \"mua\"",
    "ріст ≥ 5% — сигнал «продати»": "tăng trưởng ≥ 5% - tín hiệu “bán”",
    "Портфель": "danh mục đầu tư",
    "Віртуальний блокнот покупок": "Sổ ghi chép ảo mua hàng",
    "＋ Додати покупку": "＋ Thêm mua hàng",
    "Статистика": "Thống kê",
    "Фінансовий підсумок місяця": "Tóm tắt tài chính trong tháng",
    "Місяць:": "Tháng:",
    "Школа новачка": "Trường học cho người mới",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Giải thích, ví dụ cuộc sống và rủi ro. Đào tạo không đảm bảo thu nhập.",
    "Новини": "Tin tức",
    "🤖 ШІ-моніторинг новин": "🤖 Giám sát tin tức AI",
    "Аналіз настрою світових заголовків про крипторинок": "Phân tích tình cảm của các tiêu đề thị trường tiền điện tử toàn cầu",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Dự án giáo dục từ khóa học \"Phát triển phần mềm\". Tất cả các giao dịch đều là ảo, không sử dụng tiền thật.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Tín hiệu mua/bán là sự thể hiện logic chứ không phải lời khuyên tài chính.",
    "МОДАЛЬНЕ ВІКНО": "CỬA SỔ PHƯƠNG THỨC",
    "🤖 Довідковий асистент": "🤖 Trợ lý tham khảo",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Quy tắc API và tham chiếu dữ liệu, không phải mô hình tổng quát. Không cấu thành tư vấn tài chính.",
    "Надіслати": "Gửi",
    "Стан зʼєднання та джерело цін": "Trạng thái kết nối và nguồn giá",
    "Звукові сповіщення: увімк./вимк.": "Thông báo âm thanh: bật/tắt",
    "Мова інтерфейсу": "Ngôn ngữ giao diện",
    "Перемкнути темну / світлу тему": "Chuyển đổi chủ đề tối / sáng",
    "Пошук за назвою або символом": "Tìm kiếm theo tên hoặc biểu tượng",
    "Оновити новини": "Cập nhật tin tức",
    "Діалог": "Đối thoại",
    "Довідковий асистент": "Trợ lý tham khảo",
    "Закрити": "đóng",
    "Ваше запитання": "Câu hỏi của bạn",
    "Binance · наживо": "Binance · trực tiếp",
    "CoinGecko · наживо": "CoinGecko · trực tiếp",
    "Демо-режим (імітація цін)": "Chế độ demo (bắt chước giá)",
    "Немає даних": "Không có sẵn dữ liệu",
    "Вручну": "thủ công",
    "Помилка сервера": "Lỗi máy chủ",
    "Звукові сповіщення увімкнено": "Thông báo âm thanh được bật",
    "Звукові сповіщення вимкнено": "Thông báo âm thanh đã bị tắt",
    "Історія ціни": "Lịch sử giá",
    "Аналітика": "Phân tích",
    "у плюсі відносно ціни покупки": "cộng thêm so với giá mua",
    "у мінусі відносно ціни покупки": "màu đỏ so với giá mua",
    "додайте першу покупку у вкладці «Портфель»": "thêm giao dịch mua đầu tiên của bạn vào tab \"Danh mục đầu tư\"",
    "Оновлено о": "Cập nhật bởi",
    "/ 1 год": "/ 1 giờ",
    "Блокнот порожній": "Cuốn sổ trống rỗng",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Thêm giao dịch mua ảo — và bảng điểm ở trên cùng sẽ bắt đầu tính lợi nhuận theo thời gian thực.",
    "＋ Додати першу покупку": "＋ Thêm lần mua hàng đầu tiên",
    "% · спрацює на": "% · sẽ hoạt động",
    "Stop-Loss не задано": "Lệnh dừng lỗ chưa được đặt",
    "Відкрито": "Nó mở",
    "· докупівель:": "Mua thêm:",
    "Кількість": "số lượng",
    "Середня ціна покупки": "Giá mua trung bình",
    "Поточна ціна": "Giá hiện tại",
    "Поточна вартість": "Giá trị hiện tại",
    "Негативний фон": "Nền âm bản",
    "Позитивний фон": "Nền tích cực",
    "Нейтральний фон": "Nền trung tính",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Băng demo (giả): Tin tức thực tế không có sẵn tại thời điểm này",
    "Джерело:": "Nguồn:",
    "Оригінальні або перекладені заголовки": "Tiêu đề gốc hoặc dịch",
    "Негативна": "Tiêu cực",
    "Позитивна": "tích cực",
    "Нейтральна": "trung lập",
    "індекс:": "chỉ số:",
    "▼ негативних:": "▼ tiêu cực:",
    "нейтральних:": "trung lập:",
    "▲ позитивних:": "▲ tích cực:",
    "· оригінал англійською": "· nguyên bản bằng tiếng Anh",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Tâm trạng được xác định tự động bởi từ khóa của tiêu đề. Cập nhật bởi",
    "Ще немає закритих угод.": "Chưa có giao dịch đóng nào.",
    "угод:": "thỏa thuận:",
    "У цьому місяці угод немає.": "Không có giao dịch nào trong tháng này.",
    "Чистий результат ·": "Kết quả ròng ·",
    "Закритих угод": "giao dịch đã đóng",
    "Прибуткових": "Có lợi nhuận",
    "з": "trên",
    "Найкраща / найгірша": "Tốt nhất/tệ nhất",
    "Результат за місяцями": "Kết quả theo tháng",
    "За монетами ·": "Bằng tiền xu",
    "Останні закриті угоди": "Giao dịch đã đóng gần đây nhất",
    "Час": "thời gian",
    "Монета": "đồng xu",
    "К-сть": "Ông",
    "Купівля": "Mua hàng",
    "Продаж": "bán hàng",
    "Причина": "Lý do",
    "Результат": "kết quả",
    "Продайте першу позицію — і тут зʼявиться історія.": "Bán vị trí đầu tiên - và ở đây câu chuyện sẽ xuất hiện.",
    "Не вдалося завантажити статистику:": "Không thể tải số liệu thống kê:",
    "Віртуальна покупка": "Mua hàng ảo",
    "Без обмеження стартовим капіталом": "Không giới hạn số vốn ban đầu",
    "Ціна, за яку ви її віртуально купили ($)": "Mức giá mà bạn thực tế đã mua nó ($)",
    "Підставити ринкову ціну": "Thay thế giá thị trường",
    "Введіть кількість і ціну.": "Nhập số lượng và giá cả.",
    "Додати до блокнота": "Thêm vào sổ tay",
    "напр. 0,5": "ví dụ: 0,5",
    "напр. 64 500": "ví dụ: 64.500",
    "Підставити ринкову ціну:": "Thay thế giá thị trường:",
    "Сума покупки:": "Số tiền mua:",
    "Зараз ця позиція була б у": "Bây giờ vị trí này sẽ ở",
    "(ринок:": "(thị trường:",
    "Введіть додатні числа для кількості та ціни": "Nhập số dương cho số lượng và giá cả",
    "Додано:": "Đã thêm:",
    "за": "cho",
    "Усереднення ·": "Tính trung bình ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Mua thêm ở mức giá thấp hơn với tính toán lại tự động mức trung bình",
    "Зараз:": "Bây giờ:",
    "· середня": "· trung bình",
    "· ринок": "· thị trường",
    "Скільки докуповуємо": "Chúng ta mua bao nhiêu?",
    "Ціна докупівлі ($) — має бути нижчою за": "Giá mua bổ sung ($) phải thấp hơn",
    "Усереднити": "trung bình",
    "Введіть додатні числа.": "Nhập số dương.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Giá mua lại phải thấp hơn mức trung bình hiện tại (",
    "Нова кількість:": "Số lượng mới:",
    "Нова середня ціна:": "Giá trung bình mới:",
    "Додаткові вкладення:": "Tệp đính kèm bổ sung:",
    "Середня ціна": "Giá trung bình",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Tự động đóng ảo giao dịch ở mức trừ nhất định",
    "Середня ціна:": "Giá trung bình:",
    "· зараз": "· bây giờ",
    "Закрити угоду, коли збиток досягне (%)": "Chốt giao dịch khi mức lỗ đạt đến (%)",
    "Зберегти": "lưu lại",
    "Вимкнути": "Tắt",
    "Вкажіть відсоток від 0,1 до 99.": "Nhập tỷ lệ phần trăm từ 0,1 đến 99.",
    "Спрацює при ціні ≤": "Nó sẽ hoạt động nếu giá ≤",
    "Плановий збиток на порозі:": "Tổn thất dự kiến ở ngưỡng:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Giá đã ở dưới ngưỡng - giao dịch sẽ kết thúc ngay lập tức!",
    "Stop-Loss для": "Dừng lỗ cho",
    "встановлено: −": "được thành lập: -",
    "вимкнено": "tắt",
    "Продати": "bán",
    "Віртуальний продаж за поточною ринковою ціною": "Bán ảo theo giá thị trường hiện tại",
    "Кількість:": "Số lượng:",
    "Ціна продажу:": "Giá bán:",
    "Результат угоди:": "Kết quả của thỏa thuận:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Kết quả sẽ được lưu vào cơ sở dữ liệu và đưa vào số liệu thống kê của tháng.",
    "Так, продати": "Có, bán",
    "Скасувати": "hủy bỏ",
    "продано за": "được bán với giá",
    "різко впала:": "giảm mạnh:",
    "за годину": "trong một giờ nữa",
    "Немає зв’язку з сервером": "Không có kết nối với máy chủ",
    "Новини оновлено": "Tin tức cập nhật",
    "Не вдалося оновити новини": "Cập nhật tin tức không thành công",
    "оновлення через": "cập nhật qua",
    "с": "giây",
    "повтор спроби підключення…": "thử lại kết nối…",
    "Видалити без фіксації ·": "Xóa mà không sửa ·",
    "Виправлення випадково введеної позиції": "Sửa vị trí vô tình nhập vào",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Vị trí sẽ bị xóa vĩnh viễn. Lãi hoặc lỗ sẽ không được đưa vào số liệu thống kê hàng tháng.",
    "Видалити без фіксації": "Xóa không ghi nhận",
    "Позицію видалено без запису в статистику": "Vị trí đã bị xóa mà không ghi vào số liệu thống kê",
    "Незворотна дія": "Hành động không thể đảo ngược",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Tất cả các vị trí đang hoạt động và giao dịch đã đóng sẽ bị xóa. Giá cả, tin tức và cài đặt chủ đề sẽ vẫn còn.",
    "Так, очистити всі угоди": "Có, xóa tất cả các thỏa thuận",
    "Систему скинуто": "Thiết lập lại hệ thống",
    "Аналітика монети": "Phân tích tiền xu",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: Cặp POL/USDT hiện tại được hiển thị, không phải giá của token MATIC cũ.",
    "Максимум вікна": "Cửa sổ tối đa",
    "Мінімум вікна": "Cửa sổ tối thiểu",
    "Зміна у вікні": "Thay đổi trong cửa sổ",
    "Волатильність дохідностей": "Sự biến động của lợi nhuận",
    "Історія ціни · до 60 точок": "Lịch sử giá · lên tới 60 điểm",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Điểm phút; điểm hiện tại được cập nhật cứ sau 10 giây. Giá demo được chỉ định riêng.",
    "Ще недостатньо спостережень для графіка.": "Chưa đủ quan sát để lập biểu đồ.",
    "Таблиця спостережень": "Bảng quan sát",
    "Ціна": "Giá",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Biến động là độ lệch chuẩn của phần trăm thay đổi giữa các điểm trong cửa sổ này, không phải mức tối đa mỗi ngày.",
    "КУПИТИ за вигідною ціною": "MUA với giá tốt",
    "НЕ КУПУВАТИ / ПРОДАТИ": "KHÔNG MUA / BÁN",
    "Утримуватись, ринок спокійний": "Cố lên, thị trường bình yên",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Nguy cơ thị trường sụt giảm cao do tin tức tiêu cực trên thế giới!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Lệnh dừng lỗ đã hoạt động: {symbol} đóng ở mức ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Đồng xu không xác định. Có sẵn: {coins}",
    "Кількість і ціна мають бути додатними числами": "Số lượng và giá phải là số dương",
    "Позицію не знайдено": "Không tìm thấy vị trí nào",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Chỉ có thể tính trung bình ở mức giá thấp hơn mức trung bình hiện tại (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Dừng lỗ là tỷ lệ phần trăm từ 0,1 đến 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Giá chưa được tải, hãy thử sau vài giây",
    "Формат місяця: РРРР-ММ": "Định dạng tháng: YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "Để thiết lập lại cứng, hãy gửi {\"confirm\": true}",
    "Повідомлення порожнє": "Tin nhắn trống",
    "Повідомлення задовге (максимум {n} символів)": "Tin nhắn quá dài (tối đa ký tự {n})",
    "висхідний": "tăng dần",
    "низхідний": "giảm dần",
    "боковий": "bên",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: giá ${price}, mỗi giờ {change:+.2f}%. Xu hướng trong 60 phút: {trend}, biến động {vol:.2f}%. Tín hiệu hệ thống: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Danh mục đầu tư: chi phí ${value:,.2f}, kết quả {pnl:+,.2f}$ ({pct:+.2f}%), vị trí mở: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Chiếc cặp trống rỗng. Thêm giao dịch mua ảo đầu tiên của bạn trên thẻ xu.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Nền tin tức tiêu cực (chỉ số {index:+.2f}): nguy cơ thị trường sụt giảm tăng lên.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Nền tin tức không có rủi ro nghiêm trọng (chỉ số {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Tổng quan về thị trường hàng giờ: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Xin chào! Tôi là trợ lý AI giáo dục. Hỏi về Tiền xu, Danh mục đầu tư, Tin tức, Dừng lỗ hoặc Tính trung bình.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Hiện tại, tôi làm việc theo các quy tắc đơn giản (cắm). Hãy thử: \"Giá BTC\", \"danh mục đầu tư của tôi\", \"có gì mới\", \"Dừng lỗ là gì\".",
    "Це навчальна демонстрація, а не фінансова порада.": "Đây là một minh chứng giáo dục, không phải lời khuyên tài chính.",
    "Прибуток і збиток (P&L)": "Lãi và Lỗ (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L là chênh lệch giữa giá trị hiện tại của đồng tiền và số tiền bạn mua chúng. Cộng là lãi, trừ là lỗ. Cho đến khi bạn bán, kết quả chỉ có trên giấy.",
    "Зміна ціни за годину": "Thay đổi giá hàng giờ",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Cho biết giá đã thay đổi bao nhiêu trong giờ qua. Mức giảm mạnh (từ −5%) được hệ thống đánh dấu bằng màu đỏ, mức tăng mạnh (từ +5%) được đánh dấu bằng màu xanh lục.",
    "Усереднення": "Tính trung bình",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Mua thêm cùng một loại tiền với giá thấp hơn. Giá mua trung bình đang giảm, do đó cần tăng trưởng ít hơn để hòa vốn. Rủi ro: Bạn đầu tư nhiều hơn vào một tài sản tiếp tục giảm.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Tỷ lệ phần trăm thua lỗ được xác định trước, khi đạt đến mức đó thì giao dịch sẽ tự động được đóng lại. Đó là một biện pháp phòng ngừa rủi ro: bạn đang hạn chế tổn thất của mình ngay cả khi bạn không theo dõi thị trường.",
    "Настрій новин": "Tâm trạng của tin tức",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "Hệ thống đọc các tiêu đề tin tức về tiền điện tử toàn cầu và đánh giá xem nền tảng đó là tích cực, trung lập hay tiêu cực dựa trên các từ khóa. Đây là một phân tích đơn giản, không phải là một dự báo.",
    "Віртуальна торгівля": "Giao dịch ảo",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Tất cả các giao dịch mua ở đây đều có điều kiện: tiền thật không bị ghi nợ. Đây là một cách an toàn để tìm hiểu biến động giá ảnh hưởng đến danh mục đầu tư như thế nào và không gây rủi ro cho quỹ của chính bạn.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Tôi là trợ lý tham khảo: Tôi giải thích các thuật ngữ và hiển thị dữ liệu hiện tại theo các quy tắc mà không cần mô hình ngôn ngữ khái quát. Chọn một chủ đề bên dưới hoặc hỏi về BTC, danh mục đầu tư hoặc tin tức.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Xin chào! Tôi giải thích các thuật ngữ từ trường dành cho người mới bắt đầu và hiển thị dữ liệu thị trường. Câu trả lời được tạo ra bởi các quy tắc, không phải là một mô hình tổng quát.",
    "Готую відповідь…": "Tôi đang chuẩn bị câu trả lời...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "Trong trình mô phỏng này, lệnh Cắt lỗ được kiểm tra bằng quy trình nền cứ sau 10 giây ở mức giá nhận được; hiệu suất ở mức chính xác không được đảm bảo.",
    "Зміна ціни за останню годину": "Thay đổi giá trong giờ qua",
    "Ціна за останні хвилини": "Giá phút cuối",
    "Додати віртуальну покупку": "Thêm mua hàng ảo",
    "＋ До блокнота": "＋ Vào sổ tay",
    "Докупити за нижчою ціною та перерахувати середню": "Mua nhiều hơn với giá thấp hơn và tính lại mức trung bình",
    "⚖ Усереднити": "⚖ Trung bình",
    "Автоматично закрити угоду при заданому відсотку збитку": "Tự động kết thúc giao dịch ở mức phần trăm thua lỗ được chỉ định",
    "Віртуально продати за поточною ціною": "Hầu như bán ở mức giá hiện tại"
  },
  "de": {
    "ШАПКА": "HUT",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · Bildungssimulator",
    "📈 Ринок": "📈 Markt",
    "💼 Портфель": "💼 Portfolio",
    "📊 Статистика": "📊 Statistiken",
    "📚 Школа новачка": "📚 Einsteigerschule",
    "Підключення…": "Verbinden…",
    "БАНЕР РИЗИКУ": "RISIKOBANNER",
    "ТАБЛО ПОРТФЕЛЯ": "PORTFOLIO-BOARD",
    "Загальна вартість портфеля": "Der Gesamtwert des Portfolios",
    "віртуальний": "virtuell",
    "результат відносно ціни покупки": "das Ergebnis im Verhältnis zum Kaufpreis",
    "Вкладено (за цінами покупки)": "Investiert (zu Einkaufspreisen)",
    "Відкритих позицій": "Offene Stellen",
    "Скинути систему": "Setzen Sie das System zurück",
    "Очікуємо перші дані…": "Wir warten auf die ersten Daten...",
    "оновлення через —": "Update über —",
    "ОСНОВНА СІТКА": "HAUPTGITTER",
    "Ринок": "Der Markt",
    "15 обраних монет · зміна за 1 годину": "15 ausgewählte Münzen · Wechsel in 1 Stunde",
    "падіння ≥ 5% — сигнал «купити»": "Rückgang ≥ 5 % - „Kauf“-Signal",
    "ріст ≥ 5% — сигнал «продати»": "Wachstum ≥ 5 % - „Verkauf“-Signal",
    "Портфель": "Portfolio",
    "Віртуальний блокнот покупок": "Virtuelles Einkaufsbuch",
    "＋ Додати покупку": "＋ Kauf hinzufügen",
    "Статистика": "Statistiken",
    "Фінансовий підсумок місяця": "Finanzielle Zusammenfassung des Monats",
    "Місяць:": "Monat:",
    "Школа новачка": "Einsteigerschule",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Erklärungen, Lebensbeispiele und Risiken. Eine Ausbildung garantiert kein Einkommen.",
    "Новини": "Nachrichten",
    "🤖 ШІ-моніторинг новин": "🤖 KI-Nachrichtenüberwachung",
    "Аналіз настрою світових заголовків про крипторинок": "Stimmungsanalyse der Schlagzeilen des globalen Kryptomarktes",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Bildungsprojekt aus dem Studiengang „Softwareentwicklung“. Alle Transaktionen sind virtuell, es werden keine echten Gelder verwendet.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Kauf-/Verkaufssignale sind eine Demonstration der Logik, keine Finanzberatung.",
    "МОДАЛЬНЕ ВІКНО": "Modales Fenster",
    "🤖 Довідковий асистент": "🤖 Referenzassistent",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "API-Regeln und Datenreferenz, kein generatives Modell. Stellt keine Finanzberatung dar.",
    "Надіслати": "Senden",
    "Стан зʼєднання та джерело цін": "Verbindungsstatus und Preisquelle",
    "Звукові сповіщення: увімк./вимк.": "Tonbenachrichtigungen: ein/aus",
    "Мова інтерфейсу": "Schnittstellensprache",
    "Перемкнути темну / світлу тему": "Schalten Sie das dunkle/helle Thema um",
    "Пошук за назвою або символом": "Suchen Sie nach Namen oder Symbol",
    "Оновити новини": "Neuigkeiten aktualisieren",
    "Діалог": "Dialog",
    "Довідковий асистент": "Referenzassistent",
    "Закрити": "schließen",
    "Ваше запитання": "Deine Frage",
    "Binance · наживо": "Binance · live",
    "CoinGecko · наживо": "CoinGecko · live",
    "Демо-режим (імітація цін)": "Demomodus (Nachahmung von Preisen)",
    "Немає даних": "Keine Daten verfügbar",
    "Вручну": "Manuell",
    "Помилка сервера": "Serverfehler",
    "Звукові сповіщення увімкнено": "Akustische Benachrichtigungen sind aktiviert",
    "Звукові сповіщення вимкнено": "Tonbenachrichtigungen sind deaktiviert",
    "Історія ціни": "Preisverlauf",
    "Аналітика": "Analytik",
    "у плюсі відносно ціни покупки": "im Plus gegenüber dem Kaufpreis",
    "у мінусі відносно ціни покупки": "relativ zum Kaufpreis im Minus",
    "додайте першу покупку у вкладці «Портфель»": "Fügen Sie Ihren ersten Einkauf im Reiter „Portfolio“ hinzu",
    "Оновлено о": "Aktualisiert von",
    "/ 1 год": "/ 1 Stunde",
    "Блокнот порожній": "Das Notizbuch ist leer",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Fügen Sie einen virtuellen Kauf hinzu – und die Anzeigetafel oben beginnt, die Gewinne in Echtzeit zu zählen.",
    "＋ Додати першу покупку": "＋ Erstkauf hinzufügen",
    "% · спрацює на": "% · wird weiterarbeiten",
    "Stop-Loss не задано": "Stop-Loss ist nicht gesetzt",
    "Відкрито": "Es ist offen",
    "· докупівель:": "Zusätzlicher Kauf:",
    "Кількість": "Menge",
    "Середня ціна покупки": "Durchschnittlicher Kaufpreis",
    "Поточна ціна": "Aktueller Preis",
    "Поточна вартість": "Aktueller Wert",
    "Негативний фон": "Negativer Hintergrund",
    "Позитивний фон": "Positiver Hintergrund",
    "Нейтральний фон": "Neutraler Hintergrund",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Demoband (Mock): Echte Nachrichten sind derzeit nicht verfügbar",
    "Джерело:": "Quelle:",
    "Оригінальні або перекладені заголовки": "Originaltitel oder übersetzte Titel",
    "Негативна": "Negativ",
    "Позитивна": "Positiv",
    "Нейтральна": "Neutral",
    "індекс:": "Index:",
    "▼ негативних:": "▼ negativ:",
    "нейтральних:": "neutral:",
    "▲ позитивних:": "▲ positiv:",
    "· оригінал англійською": "· Original in Englisch",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Die Stimmung wird automatisch durch die Schlüsselwörter der Titel bestimmt. Aktualisiert von",
    "Ще немає закритих угод.": "Es liegen noch keine abgeschlossenen Deals vor.",
    "угод:": "Vereinbarungen:",
    "У цьому місяці угод немає.": "Diesen Monat gibt es keine Angebote.",
    "Чистий результат ·": "Nettoergebnis ·",
    "Закритих угод": "Abgeschlossene Geschäfte",
    "Прибуткових": "Profitabel",
    "з": "von",
    "Найкраща / найгірша": "Das Beste / das Schlimmste",
    "Результат за місяцями": "Ergebnis pro Monat",
    "За монетами ·": "Durch Münzen",
    "Останні закриті угоди": "Letzte abgeschlossene Deals",
    "Час": "Zeit",
    "Монета": "Münze",
    "К-сть": "Herr",
    "Купівля": "Kauf",
    "Продаж": "Verkauf",
    "Причина": "Der Grund",
    "Результат": "Das Ergebnis",
    "Продайте першу позицію — і тут зʼявиться історія.": "Verkaufen Sie die erste Position – und hier erscheint die Geschichte.",
    "Не вдалося завантажити статистику:": "Statistiken konnten nicht geladen werden:",
    "Віртуальна покупка": "Virtueller Kauf",
    "Без обмеження стартовим капіталом": "Keine Begrenzung des Startkapitals",
    "Ціна, за яку ви її віртуально купили ($)": "Der Preis, zu dem Sie es virtuell gekauft haben ($)",
    "Підставити ринкову ціну": "Ersetzen Sie den Marktpreis",
    "Введіть кількість і ціну.": "Geben Sie Menge und Preis ein.",
    "Додати до блокнота": "Zum Notizbuch hinzufügen",
    "напр. 0,5": "z.B. 0,5",
    "напр. 64 500": "z.B. 64.500",
    "Підставити ринкову ціну:": "Ersetzen Sie den Marktpreis:",
    "Сума покупки:": "Kaufbetrag:",
    "Зараз ця позиція була б у": "Nun wäre diese Position in",
    "(ринок:": "(Markt:",
    "Введіть додатні числа для кількості та ціни": "Geben Sie positive Zahlen für Menge und Preis ein",
    "Додано:": "Hinzugefügt:",
    "за": "für",
    "Усереднення ·": "Mittelung ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Zusätzlicher Kauf zu einem günstigeren Preis mit automatischer Neuberechnung des Durchschnitts",
    "Зараз:": "Jetzt:",
    "· середня": "· durchschnittlich",
    "· ринок": "· der Markt",
    "Скільки докуповуємо": "Wie viel kaufen wir?",
    "Ціна докупівлі ($) — має бути нижчою за": "Der zusätzliche Kaufpreis ($) muss niedriger sein als",
    "Усереднити": "Durchschnittlich",
    "Введіть додатні числа.": "Geben Sie positive Zahlen ein.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Der Rückkaufpreis muss niedriger sein als der aktuelle Durchschnitt (",
    "Нова кількість:": "Neue Menge:",
    "Нова середня ціна:": "Neuer Durchschnittspreis:",
    "Додаткові вкладення:": "Zusätzliche Anhänge:",
    "Середня ціна": "Durchschnittspreis",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Automatischer virtueller Abschluss der Transaktion bei einem bestimmten Minus",
    "Середня ціна:": "Durchschnittspreis:",
    "· зараз": "· jetzt",
    "Закрити угоду, коли збиток досягне (%)": "Schließen Sie das Geschäft ab, wenn der Verlust (%) erreicht.",
    "Зберегти": "sparen",
    "Вимкнути": "Ausschalten",
    "Вкажіть відсоток від 0,1 до 99.": "Geben Sie einen Prozentsatz zwischen 0,1 und 99 ein.",
    "Спрацює при ціні ≤": "Es funktioniert, wenn der Preis ≤",
    "Плановий збиток на порозі:": "Geplanter Schwellenverlust:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Der Preis liegt bereits unter der Schwelle – der Deal wird sofort abgeschlossen!",
    "Stop-Loss для": "Stop-Loss für",
    "встановлено: −": "gegründet: −",
    "вимкнено": "ausgeschaltet",
    "Продати": "zu verkaufen",
    "Віртуальний продаж за поточною ринковою ціною": "Virtueller Verkauf zum aktuellen Marktpreis",
    "Кількість:": "Menge:",
    "Ціна продажу:": "Verkaufspreis:",
    "Результат угоди:": "Das Ergebnis der Vereinbarung:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Das Ergebnis wird in der Datenbank gespeichert und fließt in die Statistik des Monats ein.",
    "Так, продати": "Ja, verkaufen",
    "Скасувати": "abbrechen",
    "продано за": "verkauft für",
    "різко впала:": "stark gesunken:",
    "за годину": "in einer Stunde",
    "Немає зв’язку з сервером": "Keine Verbindung zum Server",
    "Новини оновлено": "Nachrichten aktualisiert",
    "Не вдалося оновити новини": "Nachrichten konnten nicht aktualisiert werden",
    "оновлення через": "Update über",
    "с": "s",
    "повтор спроби підключення…": "Verbindung erneut versuchen…",
    "Видалити без фіксації ·": "Ohne Reparatur löschen ·",
    "Виправлення випадково введеної позиції": "Korrektur einer versehentlich eingegebenen Position",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Die Position wird endgültig gelöscht. Gewinne oder Verluste werden nicht in die monatliche Statistik einbezogen.",
    "Видалити без фіксації": "Ohne Erfassung löschen",
    "Позицію видалено без запису в статистику": "Die Stelle wurde ohne Erfassung in der Statistik gelöscht",
    "Незворотна дія": "Irreversible Aktion",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Alle aktiven Positionen und abgeschlossenen Geschäfte werden gelöscht. Preise, Neuigkeiten und Themeneinstellungen bleiben bestehen.",
    "Так, очистити всі угоди": "Ja, löschen Sie alle Vereinbarungen",
    "Систему скинуто": "System-Reset",
    "Аналітика монети": "Münzanalyse",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: Es wird das aktuelle POL/USDT-Paar angezeigt, nicht der Preis des alten MATIC-Tokens.",
    "Максимум вікна": "Maximales Fenster",
    "Мінімум вікна": "Mindestfenster",
    "Зміна у вікні": "Wechsel im Fenster",
    "Волатильність дохідностей": "Volatilität der Renditen",
    "Історія ціни · до 60 точок": "Preisverlauf · bis zu 60 Punkte",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Minutenpunkte; Der aktuelle Punkt wird alle 10 Sekunden aktualisiert. Demopreise werden gesondert ausgewiesen.",
    "Ще недостатньо спостережень для графіка.": "Noch nicht genügend Beobachtungen für eine grafische Darstellung.",
    "Таблиця спостережень": "Beobachtungstabelle",
    "Ціна": "Preis",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Die Volatilität ist die Standardabweichung der prozentualen Änderungen zwischen den Punkten dieses Fensters, kein Maximum pro Tag.",
    "КУПИТИ за вигідною ціною": "Kaufen Sie zu einem guten Preis",
    "НЕ КУПУВАТИ / ПРОДАТИ": "NICHT KAUFEN/VERKAUFEN",
    "Утримуватись, ринок спокійний": "Moment, der Markt ist ruhig",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Hohes Risiko eines Marktrückgangs aufgrund negativer Weltnachrichten!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss funktionierte: {symbol} schloss bei ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Unbekannte Münze. Verfügbar: {coins}",
    "Кількість і ціна мають бути додатними числами": "Menge und Preis müssen positive Zahlen sein",
    "Позицію не знайдено": "Keine Position gefunden",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Eine Mittelwertbildung ist nur zu einem Preis möglich, der unter dem aktuellen Durchschnitt (${avg:,.4f}) liegt.",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss ist ein Prozentsatz von 0,1 bis 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Die Preise sind noch nicht geladen. Versuchen Sie es in ein paar Sekunden",
    "Формат місяця: РРРР-ММ": "Monatsformat: JJJJ-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "Für einen Hard-Reset senden Sie {\"confirm\": true}",
    "Повідомлення порожнє": "Die Nachricht ist leer",
    "Повідомлення задовге (максимум {n} символів)": "Nachricht ist zu lang (maximal {n} Zeichen)",
    "висхідний": "aufsteigend",
    "низхідний": "absteigend",
    "боковий": "seitlich",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: Preis ${price}, pro Stunde {change:+.2f}%. Trend für 60 Min.: {trend}, Schwankung {vol:.2f} %. Systemsignal: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Portfolio: Kosten ${value:,.2f}, Ergebnis {pnl:+,.2f}$ ({pct:+.2f}%), offene Positionen: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Die Aktentasche ist leer. Fügen Sie Ihren ersten virtuellen Einkauf einer Münzkarte hinzu.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Der Nachrichtenhintergrund ist negativ ({index:+.2f}-Index): Das Risiko eines Marktrückgangs ist erhöht.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Nachrichtenhintergrund ohne kritisches Risiko (Index {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Stündliche Marktübersicht: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Grüße! Ich bin ein pädagogischer KI-Assistent. Fragen Sie nach Münzen, Portfolios, Nachrichten, Stop-Loss oder Mittelwertbildung.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Im Moment arbeite ich nach einfachen Regeln (Stecker). Versuchen Sie: „BTC-Preis“, „Mein Portfolio“, „Was ist neu“, „Was ist Stop-Loss“.",
    "Це навчальна демонстрація, а не фінансова порада.": "Dies ist eine pädagogische Demonstration, keine Finanzberatung.",
    "Прибуток і збиток (P&L)": "Gewinn und Verlust (GuV)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "GuV ist die Differenz zwischen dem aktuellen Wert der Münzen und dem Betrag, für den Sie sie gekauft haben. Plus bedeutet Gewinn, Minus bedeutet Verlust. Bis zum Verkauf steht das Ergebnis nur auf dem Papier.",
    "Зміна ціни за годину": "Stündliche Preisänderung",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Zeigt an, wie stark sich der Preis in der letzten Stunde verändert hat. Ein starker Abfall (von −5 %) wird vom System rot hervorgehoben, ein starker Anstieg (von +5 %) grün.",
    "Усереднення": "Mittelung",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Zusätzlicher Kauf derselben Münze zu einem günstigeren Preis. Der durchschnittliche Kaufpreis sinkt, sodass weniger Wachstum erforderlich ist, um die Gewinnschwelle zu erreichen. Risiko: Sie investieren mehr in einen Vermögenswert, der weiter fällt.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Ein vorgegebener Verlustprozentsatz, bei dessen Erreichen das Geschäft automatisch abgeschlossen wird. Es handelt sich um eine Absicherung: Sie begrenzen Ihre Verluste, auch wenn Sie nicht dem Markt folgen.",
    "Настрій новин": "Die Stimmung der Nachrichten",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "Das System liest globale Schlagzeilen zu Krypto-Nachrichten und bewertet anhand von Schlüsselwörtern, ob der Hintergrund positiv, neutral oder negativ ist. Dies ist eine vereinfachte Analyse, keine Prognose.",
    "Віртуальна торгівля": "Virtueller Handel",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Alle Käufe hier erfolgen unter Vorbehalt: Es wird kein echtes Geld abgebucht. Dies ist eine sichere Möglichkeit, zu erfahren, wie sich Preisbewegungen auf das Portfolio auswirken, ohne Ihr eigenes Geld zu riskieren.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Ich bin Nachschlagewerker: Ich erkläre Begriffe und zeige aktuelle Daten nach Regeln, ohne generatives Sprachmodell. Wählen Sie unten ein Thema oder fragen Sie nach BTC, Portfolio oder Neuigkeiten.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Grüße! Ich erkläre die Begriffe aus der Einsteigerschule und zeige die Marktdaten. Antworten werden durch Regeln generiert, nicht durch ein generatives Modell.",
    "Готую відповідь…": "Ich bereite eine Antwort vor ...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "In diesem Simulator wird der Stop-Loss durch den Hintergrundprozess alle 10 Sekunden zum erhaltenen Preis überprüft; Die Leistung auf einem exakten Niveau kann nicht garantiert werden.",
    "Зміна ціни за останню годину": "Preisänderung in der letzten Stunde",
    "Ціна за останні хвилини": "Last-Minute-Preis",
    "Додати віртуальну покупку": "Fügen Sie einen virtuellen Kauf hinzu",
    "＋ До блокнота": "＋ Zum Notizbuch",
    "Докупити за нижчою ціною та перерахувати середню": "Kaufen Sie mehr zu einem niedrigeren Preis und berechnen Sie den Durchschnitt neu",
    "⚖ Усереднити": "⚖ Durchschnittlich",
    "Автоматично закрити угоду при заданому відсотку збитку": "Schließen Sie das Geschäft automatisch bei einem bestimmten Prozentsatz des Verlusts ab",
    "Віртуально продати за поточною ціною": "Praktisch zum aktuellen Preis verkaufen"
  },
  "pl": {
    "ШАПКА": "CZAPKA",
    "Intelligence Tracker · навчальний симулятор": "Inteligencja Tracker · symulator edukacyjny",
    "📈 Ринок": "📈Rynek",
    "💼 Портфель": "💼Portfolio",
    "📊 Статистика": "📊 Statystyki",
    "📚 Школа новачка": "📚 Szkoła dla początkujących",
    "Підключення…": "Łączę…",
    "БАНЕР РИЗИКУ": "BANNER RYZYKA",
    "ТАБЛО ПОРТФЕЛЯ": "PŁYTA PORTFOLIO",
    "Загальна вартість портфеля": "Całkowita wartość portfela",
    "віртуальний": "wirtualny",
    "результат відносно ціни покупки": "wynik w stosunku do ceny zakupu",
    "Вкладено (за цінами покупки)": "Zainwestowane (według cen zakupu)",
    "Відкритих позицій": "Otwarte stanowiska",
    "Скинути систему": "Zresetuj system",
    "Очікуємо перші дані…": "Czekamy na pierwsze dane...",
    "оновлення через —": "aktualizacja przez —",
    "ОСНОВНА СІТКА": "SIATKA GŁÓWNA",
    "Ринок": "rynek",
    "15 обраних монет · зміна за 1 годину": "15 wybranych monet · wymiana w 1 godzinę",
    "падіння ≥ 5% — сигнал «купити»": "spadek ≥ 5% - sygnał „kupuj”.",
    "ріст ≥ 5% — сигнал «продати»": "wzrost ≥ 5% - sygnał „sprzedaży”.",
    "Портфель": "Portfel",
    "Віртуальний блокнот покупок": "Wirtualny notatnik zakupów",
    "＋ Додати покупку": "+ Dodaj zakup",
    "Статистика": "Statystyki",
    "Фінансовий підсумок місяця": "Podsumowanie finansowe miesiąca",
    "Місяць:": "Miesiąc:",
    "Школа новачка": "Szkoła dla początkujących",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Wyjaśnienia, przykłady życiowe i zagrożenia. Szkolenie nie gwarantuje dochodu.",
    "Новини": "Wiadomości",
    "🤖 ШІ-моніторинг новин": "🤖 Monitorowanie wiadomości AI",
    "Аналіз настрою світових заголовків про крипторинок": "Analiza nastrojów nagłówków światowego rynku kryptowalut",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Projekt edukacyjny z kursu „Tworzenie oprogramowania”. Wszystkie transakcje są wirtualne, nie są wykorzystywane żadne prawdziwe środki.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Sygnały kupna/sprzedaży są demonstracją logiki, a nie poradą finansową.",
    "МОДАЛЬНЕ ВІКНО": "OKNO MODALNE",
    "🤖 Довідковий асистент": "🤖 Asystent referencyjny",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Reguły API i odniesienie do danych, a nie model generatywny. Nie stanowi porady finansowej.",
    "Надіслати": "Wyślij",
    "Стан зʼєднання та джерело цін": "Stan połączenia i źródło ceny",
    "Звукові сповіщення: увімк./вимк.": "Powiadomienia dźwiękowe: wł./wył",
    "Мова інтерфейсу": "Język interfejsu",
    "Перемкнути темну / світлу тему": "Przełącz ciemny/jasny motyw",
    "Пошук за назвою або символом": "Szukaj według nazwy lub symbolu",
    "Оновити новини": "Aktualizuj wiadomości",
    "Діалог": "Dialog",
    "Довідковий асистент": "Asystent referencyjny",
    "Закрити": "blisko",
    "Ваше запитання": "Twoje pytanie",
    "Binance · наживо": "Binance · na żywo",
    "CoinGecko · наживо": "CoinGecko · na żywo",
    "Демо-режим (імітація цін)": "Tryb demonstracyjny (imitacja cen)",
    "Немає даних": "Brak dostępnych danych",
    "Вручну": "Ręcznie",
    "Помилка сервера": "Błąd serwera",
    "Звукові сповіщення увімкнено": "Powiadomienia dźwiękowe są włączone",
    "Звукові сповіщення вимкнено": "Powiadomienia dźwiękowe są wyłączone",
    "Історія ціни": "Historia cen",
    "Аналітика": "Analityka",
    "у плюсі відносно ціни покупки": "na plus w stosunku do ceny zakupu",
    "у мінусі відносно ціни покупки": "na czerwono w stosunku do ceny zakupu",
    "додайте першу покупку у вкладці «Портфель»": "dodaj swój pierwszy zakup w zakładce „Portfolio”.",
    "Оновлено о": "Zaktualizowany przez",
    "/ 1 год": "/ 1 godzina",
    "Блокнот порожній": "Notatnik jest pusty",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Dodaj wirtualny zakup – a tablica wyników na górze zacznie zliczać zyski w czasie rzeczywistym.",
    "＋ Додати першу покупку": "+ Dodaj pierwszy zakup",
    "% · спрацює на": "% · będę pracować dalej",
    "Stop-Loss не задано": "Stop-Loss nie jest ustawiony",
    "Відкрито": "Jest otwarte",
    "· докупівель:": "Dodatkowy zakup:",
    "Кількість": "Ilość",
    "Середня ціна покупки": "Średnia cena zakupu",
    "Поточна ціна": "Aktualna cena",
    "Поточна вартість": "Aktualna wartość",
    "Негативний фон": "Negatywne tło",
    "Позитивний фон": "Pozytywne tło",
    "Нейтральний фон": "Neutralne tło",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Taśma demonstracyjna (próba): Prawdziwe wiadomości nie są obecnie dostępne",
    "Джерело:": "Źródło:",
    "Оригінальні або перекладені заголовки": "Tytuły oryginalne lub przetłumaczone",
    "Негативна": "Negatywne",
    "Позитивна": "Pozytywny",
    "Нейтральна": "Neutralny",
    "індекс:": "indeks:",
    "▼ негативних:": "▼ negatywny:",
    "нейтральних:": "neutralny:",
    "▲ позитивних:": "▲ pozytywne:",
    "· оригінал англійською": "· oryginał w języku angielskim",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Nastrój jest określany automatycznie na podstawie słów kluczowych tytułów. Zaktualizowany przez",
    "Ще немає закритих угод.": "Nie ma jeszcze żadnych zamkniętych transakcji.",
    "угод:": "umowy:",
    "У цьому місяці угод немає.": "W tym miesiącu nie ma żadnych ofert.",
    "Чистий результат ·": "Wynik netto ·",
    "Закритих угод": "Zamknięte transakcje",
    "Прибуткових": "Opłacalne",
    "з": "z",
    "Найкраща / найгірша": "Najlepszy/najgorszy",
    "Результат за місяцями": "Wynik według miesiąca",
    "За монетами ·": "Przez monety",
    "Останні закриті угоди": "Ostatnie zamknięte transakcje",
    "Час": "czas",
    "Монета": "Moneta",
    "К-сть": "Pan",
    "Купівля": "Zakup",
    "Продаж": "Sprzedaż",
    "Причина": "Powód",
    "Результат": "Wynik",
    "Продайте першу позицію — і тут зʼявиться історія.": "Sprzedaj pierwszą pozycję - i tu pojawi się historia.",
    "Не вдалося завантажити статистику:": "Nie udało się załadować statystyk:",
    "Віртуальна покупка": "Wirtualny zakup",
    "Без обмеження стартовим капіталом": "Brak limitu kapitału początkowego",
    "Ціна, за яку ви її віртуально купили ($)": "Cena, za jaką wirtualnie go kupiłeś ($)",
    "Підставити ринкову ціну": "Zastąp cenę rynkową",
    "Введіть кількість і ціну.": "Podaj ilość i cenę.",
    "Додати до блокнота": "Dodaj do notatnika",
    "напр. 0,5": "np. 0,5",
    "напр. 64 500": "np. 64 500",
    "Підставити ринкову ціну:": "Zastąp cenę rynkową:",
    "Сума покупки:": "Kwota zakupu:",
    "Зараз ця позиція була б у": "Teraz to stanowisko byłoby aktualne",
    "(ринок:": "(rynek:",
    "Введіть додатні числа для кількості та ціни": "Wprowadź liczby dodatnie dla ilości i ceny",
    "Додано:": "Dodano:",
    "за": "dla",
    "Усереднення ·": "Uśrednianie ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Dodatkowy zakup po niższej cenie z automatycznym przeliczeniem średniej",
    "Зараз:": "Teraz:",
    "· середня": "· średnia",
    "· ринок": "· rynek",
    "Скільки докуповуємо": "Ile kupujemy?",
    "Ціна докупівлі ($) — має бути нижчою за": "Dodatkowa cena zakupu ($) musi być niższa niż",
    "Усереднити": "Średnia",
    "Введіть додатні числа.": "Wprowadź liczby dodatnie.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Cena odkupu musi być niższa od aktualnej średniej (",
    "Нова кількість:": "Nowa ilość:",
    "Нова середня ціна:": "Nowa średnia cena:",
    "Додаткові вкладення:": "Dodatkowe załączniki:",
    "Середня ціна": "Średnia cena",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Automatyczne wirtualne zamknięcie transakcji przy zadanym minusie",
    "Середня ціна:": "Średnia cena:",
    "· зараз": "· teraz",
    "Закрити угоду, коли збиток досягне (%)": "Zamknij transakcję, gdy strata osiągnie (%)",
    "Зберегти": "zapisz",
    "Вимкнути": "Wyłącz",
    "Вкажіть відсоток від 0,1 до 99.": "Wprowadź wartość procentową z zakresu od 0,1 do 99.",
    "Спрацює при ціні ≤": "Będzie działać, jeśli cena ≤",
    "Плановий збиток на порозі:": "Planowana strata na progu:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Cena jest już poniżej progu - transakcja zostanie natychmiast zamknięta!",
    "Stop-Loss для": "Stop-Loss dla",
    "встановлено: −": "ustalono: −",
    "вимкнено": "wyłączony",
    "Продати": "sprzedać",
    "Віртуальний продаж за поточною ринковою ціною": "Wirtualna sprzedaż po aktualnej cenie rynkowej",
    "Кількість:": "Ilość:",
    "Ціна продажу:": "Cena sprzedaży:",
    "Результат угоди:": "Wynik porozumienia:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Wynik zostanie zapisany w bazie danych i uwzględniony w statystykach miesiąca.",
    "Так, продати": "Tak, sprzedaj",
    "Скасувати": "anulować",
    "продано за": "sprzedany za",
    "різко впала:": "spadł gwałtownie:",
    "за годину": "za godzinę",
    "Немає зв’язку з сервером": "Brak połączenia z serwerem",
    "Новини оновлено": "Aktualności zaktualizowane",
    "Не вдалося оновити новини": "Nie udało się zaktualizować wiadomości",
    "оновлення через": "zaktualizować przez",
    "с": "s",
    "повтор спроби підключення…": "spróbuj ponownie połączyć…",
    "Видалити без фіксації ·": "Usuń bez poprawiania ·",
    "Виправлення випадково введеної позиції": "Korekta przypadkowo wprowadzonej pozycji",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Stanowisko zostanie trwale usunięte. Zysk lub strata nie będą uwzględniane w miesięcznych statystykach.",
    "Видалити без фіксації": "Usuń bez zapisu",
    "Позицію видалено без запису в статистику": "Pozycja została usunięta bez odnotowania w statystykach",
    "Незворотна дія": "Nieodwracalne działanie",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Wszystkie aktywne pozycje i zamknięte transakcje zostaną usunięte. Ceny, nowości i ustawienia motywów pozostaną bez zmian.",
    "Так, очистити всі угоди": "Tak, wyczyść wszystkie umowy",
    "Систему скинуто": "Reset systemu",
    "Аналітика монети": "Analityka monet",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: Pokazana jest bieżąca para POL/USDT, a nie cena starego tokena MATIC.",
    "Максимум вікна": "Maksymalne okno",
    "Мінімум вікна": "Minimalne okno",
    "Зміна у вікні": "Zmień w oknie",
    "Волатильність дохідностей": "Zmienność zwrotów",
    "Історія ціни · до 60 точок": "Historia cen · do 60 punktów",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Punkty minutowe; bieżący punkt jest aktualizowany co 10 sekund. Ceny demonstracyjne podane są osobno.",
    "Ще недостатньо спостережень для графіка.": "Za mało obserwacji, aby utworzyć wykres.",
    "Таблиця спостережень": "Tabela obserwacji",
    "Ціна": "Cena",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Zmienność to odchylenie standardowe procentowych zmian pomiędzy punktami tego okna, a nie maksymalna wartość dzienna.",
    "КУПИТИ за вигідною ціною": "KUPIĘ w dobrej cenie",
    "НЕ КУПУВАТИ / ПРОДАТИ": "NIE KUPUJ/SPRZEDAJ",
    "Утримуватись, ринок спокійний": "Poczekaj, rynek jest spokojny",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Wysokie ryzyko spadków rynku w związku z negatywnymi wiadomościami ze świata!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss zadziałał: {symbol} zamknął się na poziomie ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Nieznana moneta. Dostępne: {coins}",
    "Кількість і ціна мають бути додатними числами": "Ilość i cena muszą być liczbami dodatnimi",
    "Позицію не знайдено": "Nie znaleziono pozycji",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Uśrednianie jest możliwe tylko po cenie niższej niż bieżąca średnia (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss to wartość procentowa od 0,1 do 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Ceny nie są jeszcze załadowane, spróbuj za kilka sekund",
    "Формат місяця: РРРР-ММ": "Format miesiąca: RRRR-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "W celu twardego resetu wyślij {\"confirm\": true}",
    "Повідомлення порожнє": "Wiadomość jest pusta",
    "Повідомлення задовге (максимум {n} символів)": "Wiadomość jest za długa (maksymalnie {n} znaków)",
    "висхідний": "rosnąco",
    "низхідний": "malejąco",
    "боковий": "boczny",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: cena ${price}, za godzinę {change:+.2f}%. Trend przez 60 min: {trend}, wahania {vol:.2f}%. Sygnał systemowy: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Portfel: koszt ${value:,.2f}, wynik {pnl:+,.2f}$ ({pct:+.2f}%), otwarte pozycje: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Teczka jest pusta. Dodaj swój pierwszy wirtualny zakup na karcie monety.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Tło wiadomości jest negatywne (indeks {index:+.2f}): ryzyko spadku rynku wzrasta.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Tło wiadomości bez ryzyka krytycznego (indeks {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Przegląd rynku godzinowego: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Pozdrowienia! Jestem edukacyjnym asystentem AI. Zapytaj o monetę, portfel, aktualności, Stop-Loss lub uśrednianie.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Na razie pracuję według prostych zasad (wtyczka). Wypróbuj: „Cena BTC”, „mój portfel”, „co nowego”, „czym jest Stop-Loss”.",
    "Це навчальна демонстрація, а не фінансова порада.": "To jest demonstracja edukacyjna, a nie porada finansowa.",
    "Прибуток і збиток (P&L)": "Zyski i straty (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "Zyski i straty to różnica pomiędzy aktualną wartością monet a kwotą, za jaką je kupiłeś. Plus oznacza zysk, minus oznacza stratę. Dopóki nie sprzedasz, wynik będzie tylko na papierze.",
    "Зміна ціни за годину": "Godzinowa zmiana ceny",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Pokazuje, jak bardzo zmieniła się cena w ciągu ostatniej godziny. Gwałtowny spadek (z -5%) jest zaznaczony systemem na czerwono, gwałtowny wzrost (z +5%) na zielono.",
    "Усереднення": "Uśrednianie",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Dodatkowy zakup tej samej monety po niższej cenie. Średnia cena zakupu spada, zatem do osiągnięcia progu rentowności potrzebny jest mniejszy wzrost. Ryzyko: Inwestujesz więcej w aktywa, które nadal spadają.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Z góry określony procent straty, po osiągnięciu którego transakcja zostaje automatycznie zamknięta. To zabezpieczenie: ograniczasz swoje straty, nawet jeśli nie podążasz za rynkiem.",
    "Настрій новин": "Nastrój wiadomości",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "System odczytuje nagłówki światowych wiadomości o kryptowalutach i ocenia, czy tło jest pozytywne, neutralne czy negatywne, na podstawie słów kluczowych. To uproszczona analiza, a nie prognoza.",
    "Віртуальна торгівля": "Wirtualny handel",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Wszystkie zakupy tutaj są warunkowe: prawdziwe pieniądze nie są pobierane. Jest to bezpieczny sposób, aby dowiedzieć się, jak zmiany cen wpływają na portfel, i nie ryzykować własnych środków.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Jestem asystentem referencyjnym: wyjaśniam terminy i pokazuję aktualne dane zgodnie z zasadami, bez generatywnego modelu języka. Wybierz temat poniżej lub zapytaj o BTC, portfolio lub aktualności.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Pozdrowienia! Wyjaśniam pojęcia ze szkoły dla początkujących i pokazuję dane rynkowe. Odpowiedzi są generowane na podstawie reguł, a nie modelu generatywnego.",
    "Готую відповідь…": "Przygotowuję odpowiedź...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "W tym symulatorze Stop-Loss jest sprawdzany przez proces w tle co 10 sekund po otrzymanej cenie; wydajność na dokładnym poziomie nie jest gwarantowana.",
    "Зміна ціни за останню годину": "Zmiana ceny w ciągu ostatniej godziny",
    "Ціна за останні хвилини": "Cena z ostatniej chwili",
    "Додати віртуальну покупку": "Dodaj wirtualny zakup",
    "＋ До блокнота": "+ Do notatnika",
    "Докупити за нижчою ціною та перерахувати середню": "Kup więcej po niższej cenie i przelicz średnią",
    "⚖ Усереднити": "⚖ Średnio",
    "Автоматично закрити угоду при заданому відсотку збитку": "Automatycznie zamykaj transakcję przy określonym procencie straty",
    "Віртуально продати за поточною ціною": "Sprzedaję praktycznie po aktualnej cenie"
  },
  "zh": {
    "ШАПКА": "帽子",
    "Intelligence Tracker · навчальний симулятор": "智力追踪器·教育模拟器",
    "📈 Ринок": "📈 市场",
    "💼 Портфель": "💼 投资组合",
    "📊 Статистика": "📊 统计",
    "📚 Школа новачка": "📚 新手学堂",
    "Підключення…": "正在连接…",
    "БАНЕР РИЗИКУ": "风险旗帜",
    "ТАБЛО ПОРТФЕЛЯ": "投资组合板",
    "Загальна вартість портфеля": "投资组合的总价值",
    "віртуальний": "虚拟的",
    "результат відносно ціни покупки": "相对于购买价格的结果",
    "Вкладено (за цінами покупки)": "投资（按购买价格）",
    "Відкритих позицій": "未平仓头寸",
    "Скинути систему": "重置系统",
    "Очікуємо перші дані…": "我们正在等待第一个数据...",
    "оновлення через —": "更新通过——",
    "ОСНОВНА СІТКА": "主网格",
    "Ринок": "市场",
    "15 обраних монет · зміна за 1 годину": "15种精选硬币 · 1小时内兑换",
    "падіння ≥ 5% — сигнал «купити»": "跌幅≥5%——“买入”信号",
    "ріст ≥ 5% — сигнал «продати»": "增长 ≥ 5% - “卖出”信号",
    "Портфель": "投资组合",
    "Віртуальний блокнот покупок": "虚拟购物笔记本",
    "＋ Додати покупку": "＋ 添加购买",
    "Статистика": "统计数据",
    "Фінансовий підсумок місяця": "本月财务摘要",
    "Місяць:": "月份：",
    "Школа новачка": "新手学堂",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "解释、生活例子和风险。培训并不能保证收入。",
    "Новини": "新闻动态",
    "🤖 ШІ-моніторинг новин": "🤖 AI新闻监控",
    "Аналіз настрою світових заголовків про крипторинок": "全球加密货币市场头条新闻的情绪分析",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "“软件开发”课程的教育项目。所有交易都是虚拟的，不使用真实资金。",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "买入/卖出信号是逻辑演示，而不是财务建议。",
    "МОДАЛЬНЕ ВІКНО": "模态窗口",
    "🤖 Довідковий асистент": "🤖 参考助理",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "API规则和数据参考，而不是生成模型。不构成财务建议。",
    "Надіслати": "发送",
    "Стан зʼєднання та джерело цін": "连接状态和价格来源",
    "Звукові сповіщення: увімк./вимк.": "声音通知：开/关",
    "Мова інтерфейсу": "界面语言",
    "Перемкнути темну / світлу тему": "切换深色/浅色主题",
    "Пошук за назвою або символом": "按名称或符号搜索",
    "Оновити новини": "更新新闻",
    "Діалог": "对话",
    "Довідковий асистент": "参考助理",
    "Закрити": "关闭",
    "Ваше запитання": "你的问题",
    "Binance · наживо": "币安·直播",
    "CoinGecko · наживо": "CoinGecko · 直播",
    "Демо-режим (імітація цін)": "演示模式（模仿价格）",
    "Немає даних": "无可用数据",
    "Вручну": "手动",
    "Помилка сервера": "服务器错误",
    "Звукові сповіщення увімкнено": "声音通知已启用",
    "Звукові сповіщення вимкнено": "声音通知已关闭",
    "Історія ціни": "价格历史记录",
    "Аналітика": "分析",
    "у плюсі відносно ціни покупки": "相对于购买价格的加值",
    "у мінусі відносно ціни покупки": "相对于购买价格呈红色",
    "додайте першу покупку у вкладці «Портфель»": "在“投资组合”选项卡中添加您的第一次购买",
    "Оновлено о": "更新者",
    "/ 1 год": "/ 1 小时",
    "Блокнот порожній": "笔记本是空的",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "添加虚拟购买 - 顶部的记分板将开始实时计算利润。",
    "＋ Додати першу покупку": "＋ 添加首次购买",
    "% · спрацює на": "% · 将致力于",
    "Stop-Loss не задано": "未设置止损",
    "Відкрито": "已开放",
    "· докупівель:": "额外购买：",
    "Кількість": "数量",
    "Середня ціна покупки": "平均购买价格",
    "Поточна ціна": "现价",
    "Поточна вартість": "当前值",
    "Негативний фон": "负面背景",
    "Позитивний фон": "积极的背景",
    "Нейтральний фон": "中性背景",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "演示磁带（模拟）：目前无法获得真实新闻",
    "Джерело:": "来源：",
    "Оригінальні або перекладені заголовки": "原始或翻译标题",
    "Негативна": "阴性",
    "Позитивна": "积极",
    "Нейтральна": "中性",
    "індекс:": "索引：",
    "▼ негативних:": "▼ 负面：",
    "нейтральних:": "中性：",
    "▲ позитивних:": "▲ 正面：",
    "· оригінал англійською": "· 英文原版",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "情绪由标题的关键词自动决定。更新者",
    "Ще немає закритих угод.": "尚未完成交易。",
    "угод:": "协议：",
    "У цьому місяці угод немає.": "本月没有交易。",
    "Чистий результат ·": "最终结果·",
    "Закритих угод": "已成交交易",
    "Прибуткових": "有利可图",
    "з": "/",
    "Найкраща / найгірша": "最好/最差",
    "Результат за місяцями": "按月结果",
    "За монетами ·": "通过硬币",
    "Останні закриті угоди": "最后成交的交易",
    "Час": "时间",
    "Монета": "硬币",
    "К-сть": "先生",
    "Купівля": "购买",
    "Продаж": "销售",
    "Причина": "原因",
    "Результат": "结果",
    "Продайте першу позицію — і тут зʼявиться історія.": "卖出第一个头寸——故事就会在这里出现。",
    "Не вдалося завантажити статистику:": "无法加载统计信息：",
    "Віртуальна покупка": "虚拟购买",
    "Без обмеження стартовим капіталом": "启动资金无限制",
    "Ціна, за яку ви її віртуально купили ($)": "您实际购买的价格（$）",
    "Підставити ринкову ціну": "替代市场价",
    "Введіть кількість і ціну.": "输入数量和价格。",
    "Додати до блокнота": "添加到笔记本",
    "напр. 0,5": "例如0.5",
    "напр. 64 500": "例如64,500",
    "Підставити ринкову ціну:": "替代市场价：",
    "Сума покупки:": "购买金额：",
    "Зараз ця позиція була б у": "现在这个位置将是",
    "(ринок:": "（市场：",
    "Введіть додатні числа для кількості та ціни": "输入数量和价格的正数",
    "Додано:": "补充：",
    "за": "为了",
    "Усереднення ·": "平均·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "以较低价格追加购买并自动重新计算平均值",
    "Зараз:": "现在：",
    "· середня": "· 平均",
    "· ринок": "· 市场",
    "Скільки докуповуємо": "我们买多少钱？",
    "Ціна докупівлі ($) — має бути нижчою за": "额外购买价格（$）必须低于",
    "Усереднити": "平均",
    "Введіть додатні числа.": "输入正数。",
    "Ціна докупівлі має бути нижчою за поточну середню (": "回购价格必须低于当前平均价格（",
    "Нова кількість:": "新数量：",
    "Нова середня ціна:": "新均价：",
    "Додаткові вкладення:": "附加附件：",
    "Середня ціна": "平均价格",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "在给定的负数处自动虚拟关闭交易",
    "Середня ціна:": "平均价格：",
    "· зараз": "· 现在",
    "Закрити угоду, коли збиток досягне (%)": "当亏损达到(%)时平仓",
    "Зберегти": "保存",
    "Вимкнути": "关闭",
    "Вкажіть відсоток від 0,1 до 99.": "输入 0.1 到 99 之间的百分比。",
    "Спрацює при ціні ≤": "如果价格≤则有效",
    "Плановий збиток на порозі:": "阈值处的计划损失：",
    "Ціна вже нижча за поріг — угода закриється одразу!": "价格已经低于阈值 - 交易将立即结束！",
    "Stop-Loss для": "止损为",
    "встановлено: −": "成立： -",
    "вимкнено": "关闭",
    "Продати": "出售",
    "Віртуальний продаж за поточною ринковою ціною": "按当前市场价格进行虚拟销售",
    "Кількість:": "数量：",
    "Ціна продажу:": "销售价格：",
    "Результат угоди:": "协议结果：",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "结果将保存在数据库中，并纳入当月的统计中。",
    "Так, продати": "是的，卖",
    "Скасувати": "取消",
    "продано за": "售价为",
    "різко впала:": "大幅下跌：",
    "за годину": "一小时后",
    "Немає зв’язку з сервером": "没有连接到服务器",
    "Новини оновлено": "新闻更新",
    "Не вдалося оновити новини": "新闻更新失败",
    "оновлення через": "更新通过",
    "с": "秒",
    "повтор спроби підключення…": "重试连接...",
    "Видалити без фіксації ·": "删除而不修复·",
    "Виправлення випадково введеної позиції": "修正意外输入的位置",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "该职位将被永久删除。利润或亏损不计入月度统计。",
    "Видалити без фіксації": "删除且不计入统计",
    "Позицію видалено без запису в статистику": "该职位已删除，未记录在统计中",
    "Незворотна дія": "不可逆转的行动",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "所有活跃头寸和已平仓交易都将被删除。定价、新闻和主题设置将保留。",
    "Так, очистити всі угоди": "是的，清除所有协议",
    "Систему скинуто": "系统重置",
    "Аналітика монети": "硬币分析",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL：显示当前的 POL/USDT 对，而不是旧 MATIC 代币的价格。",
    "Максимум вікна": "最大窗口",
    "Мінімум вікна": "最小窗口",
    "Зміна у вікні": "窗口中的变化",
    "Волатильність дохідностей": "回报的波动性",
    "Історія ціни · до 60 точок": "价格历史 · 最多 60 点",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "分钟点；当前点每 10 秒更新一次。演示价格单独标明。",
    "Ще недостатньо спостережень для графіка.": "还没有足够的观察结果来绘制图表。",
    "Таблиця спостережень": "观察表",
    "Ціна": "价格",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "波动性是该窗口点之间百分比变化的标准差，而不是每天的最大值。",
    "КУПИТИ за вигідною ціною": "以优惠的价格购买",
    "НЕ КУПУВАТИ / ПРОДАТИ": "请勿购买/出售",
    "Утримуватись, ринок спокійний": "坚持住，市场平静",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️世界负面新闻导致市场下跌的风险很高！",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "止损起作用：{symbol} 收于 ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "未知硬币。可用：{coins}",
    "Кількість і ціна мають бути додатними числами": "数量和价格必须为正数",
    "Позицію не знайдено": "没有找到位置",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "仅当价格低于当前平均值 (${avg:,.4f}) 时才可以进行平均",
    "Stop-Loss — це відсоток від 0.1 до 99": "止损是从 0.1 到 99 的百分比",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "价格尚未加载，请稍后尝试",
    "Формат місяця: РРРР-ММ": "月份格式：YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "对于硬重置，发送 {\"confirm\": true}",
    "Повідомлення порожнє": "留言内容为空",
    "Повідомлення задовге (максимум {n} символів)": "消息太长（最多 {n} 个字符）",
    "висхідний": "上升",
    "низхідний": "下降",
    "боковий": "横向",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}：价格${price}，每小时{change:+.2f}%。 60分钟趋势：{trend}，波动{vol:.2f}%。系统信号：{reco}。",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "投资组合：成本 ${value:,.2f}，结果 {pnl:+,.2f}$ ({pct:+.2f}%)，未平仓头寸：{count}。",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "公文包是空的。将您的第一次虚拟购买添加到硬币卡上。",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "消息背景为负面（{index:+.2f}指数）：市场下跌风险加大。",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "无重大风险的新闻背景（指数{index:+.2f}）。",
    "Огляд ринку за годину: {items}.": "每小时市场概览：{items}。",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "问候！我是一名教育人工智能助理。询问有关硬币、投资组合、新闻、止损或平均的信息。",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "现在，我按照简单的规则（插件）工作。尝试：“BTC 价格”、“我的投资组合”、“新消息”、“什么是止损”。",
    "Це навчальна демонстрація, а не фінансова порада.": "这是一个教育演示，而不是财务建议。",
    "Прибуток і збиток (P&L)": "损益 (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "损益是代币的当前价值与您购买代币的金额之间的差额。加号表示盈利，减号表示损失。在你出售之前，结果只是纸面上的。",
    "Зміна ціни за годину": "每小时价格变化",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "显示过去一小时内价格的变化量。系统以红色突出显示急剧下降（从 -5%），以绿色突出显示急剧增加（从 +5%）。",
    "Усереднення": "平均",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "以较低的价格额外购买相同的硬币。平均购买价格正在下降，因此需要更少的增长才能达到收支平衡。风险：您对持续下跌的资产进行更多投资。",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "预定的损失百分比，达到该百分比后交易将自动关闭。这是一种对冲：即使您不跟随市场，您也可以限制损失。",
    "Настрій новин": "新闻的心情",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "该系统读取全球加密货币新闻头条，并根据关键词评估背景是正面、中性还是负面。这是一个简化的分析，而不是预测。",
    "Віртуальна торгівля": "虚拟贸易",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "这里的所有购买都是有条件的：真实货币不会被借记。这是了解价格变动如何影响投资组合的安全方法，而且不会让您自己的资金面临风险。",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "我是一名参考助理：我根据规则解释术语并显示当前数据，无需生成语言模型。选择下面的主题或询问有关 BTC、投资组合或新闻的问题。",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "问候！我解释了初学者学校的术语并展示了市场数据。答案是由规则生成的，而不是生成模型。",
    "Готую відповідь…": "我正在准备答案...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "在此模拟器中，后台进程每 10 秒按收到的价格检查一次止损；无法保证精确水平的性能。",
    "Зміна ціни за останню годину": "最近一小时的价格变化",
    "Ціна за останні хвилини": "最后一刻价格",
    "Додати віртуальну покупку": "添加虚拟购买",
    "＋ До блокнота": "＋ 到笔记本",
    "Докупити за нижчою ціною та перерахувати середню": "以更低的价格购买更多并重新计算平均值",
    "⚖ Усереднити": "⚖ 平均",
    "Автоматично закрити угоду при заданому відсотку збитку": "按指定损失百分比自动平仓",
    "Віртуально продати за поточною ціною": "几乎按当前价格出售"
  },
  "ja": {
    "ШАПКА": "帽子",
    "Intelligence Tracker · навчальний симулятор": "インテリジェンストラッカー・教育シミュレーター",
    "📈 Ринок": "📈 マーケット",
    "💼 Портфель": "💼ポートフォリオ",
    "📊 Статистика": "📊 統計",
    "📚 Школа новачка": "📚 初心者スクール",
    "Підключення…": "接続中…",
    "БАНЕР РИЗИКУ": "リスクバナー",
    "ТАБЛО ПОРТФЕЛЯ": "ポートフォリオボード",
    "Загальна вартість портфеля": "ポートフォリオの合計価値",
    "віртуальний": "仮想",
    "результат відносно ціни покупки": "購入価格に対する結果",
    "Вкладено (за цінами покупки)": "投資済み（購入価格）",
    "Відкритих позицій": "オープンポジション",
    "Скинути систему": "システムをリセットする",
    "Очікуємо перші дані…": "最初のデータを待っています...",
    "оновлення через —": "— 経由で更新します",
    "ОСНОВНА СІТКА": "メイングリッド",
    "Ринок": "市場",
    "15 обраних монет · зміна за 1 годину": "選択されたコイン 15 枚 · 1 時間で変化",
    "падіння ≥ 5% — сигнал «купити»": "5%以上の下落 - 「買い」シグナル",
    "ріст ≥ 5% — сигнал «продати»": "成長率 ≥ 5% - 「売り」シグナル",
    "Портфель": "ポートフォリオ",
    "Віртуальний блокнот покупок": "購入した仮想ノート",
    "＋ Додати покупку": "＋ 追加購入",
    "Статистика": "統計",
    "Фінансовий підсумок місяця": "今月の財務概要",
    "Місяць:": "月:",
    "Школа новачка": "初心者スクール",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "説明、生活例、リスク。研修は収入を保証するものではありません。",
    "Новини": "ニュース",
    "🤖 ШІ-моніторинг новин": "🤖 AIニュースモニタリング",
    "Аналіз настрою світових заголовків про крипторинок": "世界の仮想通貨市場のヘッドラインに関するセンチメント分析",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "「ソフトウェア開発」コースの教育プロジェクト。すべての取引は仮想であり、実際の資金は使用されません。",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "売買シグナルはロジックのデモンストレーションであり、財務上のアドバイスではありません。",
    "МОДАЛЬНЕ ВІКНО": "モーダルウィンドウ",
    "🤖 Довідковий асистент": "🤖 リファレンスアシスタント",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "生成モデルではなく、API ルールとデータ参照。財務上のアドバイスを構成するものではありません。",
    "Надіслати": "送信",
    "Стан зʼєднання та джерело цін": "接続状況と価格ソース",
    "Звукові сповіщення: увімк./вимк.": "音声通知: オン/オフ",
    "Мова інтерфейсу": "インターフェース言語",
    "Перемкнути темну / світлу тему": "暗いテーマと明るいテーマを切り替えます",
    "Пошук за назвою або символом": "名前または記号で検索",
    "Оновити новини": "ニュースを更新",
    "Діалог": "対話",
    "Довідковий асистент": "レファレンスアシスタント",
    "Закрити": "閉じる",
    "Ваше запитання": "あなたの質問",
    "Binance · наживо": "バイナンス・ライブ",
    "CoinGecko · наживо": "CoinGecko · ライブ",
    "Демо-режим (імітація цін)": "デモモード（価格の模倣）",
    "Немає даних": "利用可能なデータがありません",
    "Вручну": "手動で",
    "Помилка сервера": "サーバーエラー",
    "Звукові сповіщення увімкнено": "音声通知が有効になっています",
    "Звукові сповіщення вимкнено": "音声通知がオフになっています",
    "Історія ціни": "価格履歴",
    "Аналітика": "分析",
    "у плюсі відносно ціни покупки": "購入価格に比べてプラスになる",
    "у мінусі відносно ціни покупки": "購入価格に対して赤字",
    "додайте першу покупку у вкладці «Портфель»": "「ポートフォリオ」タブに最初の購入を追加します",
    "Оновлено о": "更新者",
    "/ 1 год": "/ 1時間",
    "Блокнот порожній": "ノートは空です",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "仮想購入を追加すると、上部のスコアボードがリアルタイムで利益のカウントを開始します。",
    "＋ Додати першу покупку": "＋ 初回購入分を追加",
    "% · спрацює на": "% · に取り組みます",
    "Stop-Loss не задано": "ストップロスが設定されていません",
    "Відкрито": "開いています",
    "· докупівель:": "追加購入:",
    "Кількість": "数量",
    "Середня ціна покупки": "平均購入価格",
    "Поточна ціна": "現在の価格",
    "Поточна вартість": "現在値",
    "Негативний фон": "ネガティブな背景",
    "Позитивний фон": "肯定的な背景",
    "Нейтральний фон": "ニュートラルな背景",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "デモテープ (モック): 現時点では実際のニュースはありません",
    "Джерело:": "出典:",
    "Оригінальні або перекладені заголовки": "オリジナルまたは翻訳されたタイトル",
    "Негативна": "ネガティブ",
    "Позитивна": "ポジティブ",
    "Нейтральна": "ニュートラル",
    "індекс:": "インデックス:",
    "▼ негативних:": "▼マイナス：",
    "нейтральних:": "中立:",
    "▲ позитивних:": "▲ポジティブ：",
    "· оригінал англійською": "・英語原文",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "タイトルのキーワードによって雰囲気が自動的に決まります。更新者",
    "Ще немає закритих угод.": "まだ成立した取引はありません。",
    "угод:": "協定:",
    "У цьому місяці угод немає.": "今月は取引がありません。",
    "Чистий результат ·": "最終結果 ·",
    "Закритих угод": "成立した取引",
    "Прибуткових": "儲かる",
    "з": "/",
    "Найкраща / найгірша": "最高/最悪",
    "Результат за місяцями": "月別の結果",
    "За монетами ·": "コインで",
    "Останні закриті угоди": "最後に成立した取引",
    "Час": "時間",
    "Монета": "コイン",
    "К-сть": "さん",
    "Купівля": "購入する",
    "Продаж": "セール",
    "Причина": "理由",
    "Результат": "結果",
    "Продайте першу позицію — і тут зʼявиться історія.": "最初のポジションを売る - そしてここに物語が現れます。",
    "Не вдалося завантажити статистику:": "統計のロードに失敗しました:",
    "Віртуальна покупка": "仮想購入",
    "Без обмеження стартовим капіталом": "開始資金に制限なし",
    "Ціна, за яку ви її віртуально купили ($)": "仮想的に購入した価格 ($)",
    "Підставити ринкову ціну": "市場価格を代入する",
    "Введіть кількість і ціну.": "数量と価格を入力します。",
    "Додати до блокнота": "ノートに追加",
    "напр. 0,5": "例: 0.5",
    "напр. 64 500": "例: 64,500",
    "Підставити ринкову ціну:": "市場価格を代入します。",
    "Сума покупки:": "購入金額：",
    "Зараз ця позиція була б у": "さて、この位置は次のようになります",
    "(ринок:": "(市場:",
    "Введіть додатні числа для кількості та ціни": "数量と価格には正の数値を入力してください",
    "Додано:": "追加:",
    "за": "のために",
    "Усереднення ·": "平均化 ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "平均値の自動再計算で安く追加購入可能",
    "Зараз:": "今:",
    "· середня": "・平均的",
    "· ринок": "· 市場",
    "Скільки докуповуємо": "いくらで買えますか？",
    "Ціна докупівлі ($) — має бути нижчою за": "追加購入価格 ($) は以下の値よりも低くなければなりません",
    "Усереднити": "平均",
    "Введіть додатні числа.": "正の数値を入力してください。",
    "Ціна докупівлі має бути нижчою за поточну середню (": "買戻し価格は現在の平均よりも低くなければなりません（",
    "Нова кількість:": "新しい数量:",
    "Нова середня ціна:": "新しい平均価格:",
    "Додаткові вкладення:": "追加の添付ファイル:",
    "Середня ціна": "平均価格",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "指定されたマイナスでのトランザクションの仮想自動クローズ",
    "Середня ціна:": "平均価格:",
    "· зараз": "· 今",
    "Закрити угоду, коли збиток досягне (%)": "損失が(%)に達したときに取引を終了する",
    "Зберегти": "保存する",
    "Вимкнути": "オフにする",
    "Вкажіть відсоток від 0,1 до 99.": "0.1 ～ 99 の割合を入力します。",
    "Спрацює при ціні ≤": "価格 ≤ の場合に機能します",
    "Плановий збиток на порозі:": "閾値での計画損失:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "価格はすでにしきい値を下回っています。取引はすぐに終了します。",
    "Stop-Loss для": "ストップロス",
    "встановлено: −": "確立: −",
    "вимкнено": "オフになった",
    "Продати": "売る",
    "Віртуальний продаж за поточною ринковою ціною": "現在の市場価格での仮想販売",
    "Кількість:": "数量:",
    "Ціна продажу:": "販売価格：",
    "Результат угоди:": "合意の結果:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "結果はデータベースに保存され、その月の統計に含まれます。",
    "Так, продати": "はい、売ります",
    "Скасувати": "キャンセル",
    "продано за": "のために売られた",
    "різко впала:": "急落しました:",
    "за годину": "1時間以内に",
    "Немає зв’язку з сервером": "サーバーに接続されていません",
    "Новини оновлено": "ニュースが更新されました",
    "Не вдалося оновити новини": "ニュースを更新できませんでした",
    "оновлення через": "経由で更新します",
    "с": "秒",
    "повтор спроби підключення…": "接続を再試行してください…",
    "Видалити без фіксації ·": "修正せずに削除・",
    "Виправлення випадково введеної позиції": "誤って入力した位置の修正",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "ポジションは完全に削除されます。損益は月次統計には含まれません。",
    "Видалити без фіксації": "記録せず削除",
    "Позицію видалено без запису в статистику": "統計に記録されずにポジションが削除されました",
    "Незворотна дія": "不可逆的なアクション",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "すべてのアクティブなポジションとクローズされた取引は削除されます。価格、ニュース、テーマ設定はそのまま残ります。",
    "Так, очистити всі угоди": "はい、すべての契約をクリアします",
    "Систему скинуто": "システムリセット",
    "Аналітика монети": "コイン分析",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: 古い MATIC トークンの価格ではなく、現在の POL/USDT ペアが表示されます。",
    "Максимум вікна": "最大ウィンドウ",
    "Мінімум вікна": "最小ウィンドウ",
    "Зміна у вікні": "窓の変化",
    "Волатильність дохідностей": "リターンのボラティリティ",
    "Історія ціни · до 60 точок": "価格履歴・最大60ポイント",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "ミニポイント;現在のポイントは 10 秒ごとに更新されます。デモ価格は別途表示されます。",
    "Ще недостатньо спостережень для графіка.": "グラフ化するにはまだ十分な観測値がありません。",
    "Таблиця спостережень": "観察結果の表",
    "Ціна": "価格",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "ボラティリティは、このウィンドウのポイント間の変化率の標準偏差であり、1 日あたりの最大値ではありません。",
    "КУПИТИ за вигідною ціною": "お得な価格で購入",
    "НЕ КУПУВАТИ / ПРОДАТИ": "売買しないでください",
    "Утримуватись, ринок спокійний": "ちょっと待ってください、市場は落ち着いています",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️世界のネガティブなニュースによる市場下落のリスクが高い!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "ストップロスが機能しました: {symbol} は ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$) で終了しました",
    "Невідома монета. Доступні: {coins}": "未知のコイン。利用可能: {coins}",
    "Кількість і ціна мають бути додатними числами": "数量と価格は正の数である必要があります",
    "Позицію не знайдено": "ポジションが見つかりません",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "平均化は現在の平均 (${avg:,.4f}) よりも低い価格でのみ可能です",
    "Stop-Loss — це відсоток від 0.1 до 99": "ストップロスは0.1から99のパーセンテージです",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "価格はまだ読み込まれていません。数秒後に試してください",
    "Формат місяця: РРРР-ММ": "月の形式: YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "ハードリセットの場合は、{\"confirm\": true}を送信してください",
    "Повідомлення порожнє": "メッセージは空です",
    "Повідомлення задовге (максимум {n} символів)": "メッセージが長すぎます (最大 {n} 文字)",
    "висхідний": "昇順",
    "низхідний": "降順",
    "боковий": "横方向",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: 料金 ${price}、1 時間あたり {change:+.2f}%。 60分間のトレンド：{trend}、変動率{vol:.2f}%。システム信号：{reco}。",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "ポートフォリオ: コスト ${value:,.2f}、結果 {pnl:+,.2f}$ ({pct:+.2f}%)、オープン ポジション: {count}。",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "ブリーフケースは空です。最初の仮想購入をコイン カードに追加します。",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "ニュースの背景はネガティブです ({index:+.2f} 指数): 市場下落のリスクが増大しています。",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "重大なリスクのないニュース背景 (インデックス {index:+.2f})。",
    "Огляд ринку за годину: {items}.": "時間ごとの市場概要: {items}。",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "こんにちは！私は教育AIアシスタントです。コイン、ポートフォリオ、ニュース、ストップロス、平均化について質問してください。",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "今のところ、私は簡単なルール（プラグ）に従って作業します。 「BTC 価格」、「私のポートフォリオ」、「最新情報」、「ストップロスとは」を試してください。",
    "Це навчальна демонстрація, а не фінансова порада.": "これは教育的なデモンストレーションであり、経済的なアドバイスではありません。",
    "Прибуток і збиток (P&L)": "損益 (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "損益は、コインの現在価値とコインを購入した金額の差です。プラスは利益、マイナスは損失を意味します。販売するまでは、結果は紙の上にあるだけです。",
    "Зміна ціни за годину": "時間ごとの料金変動",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "過去 1 時間に価格がどれだけ変化したかを示します。急激な減少 (-5% から) はシステムによって赤色で強調表示され、急激な増加 (+5% から) は緑色で強調表示されます。",
    "Усереднення": "平均化",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "同じコインをさらに安い価格で追加購入します。平均購入価格は低下しているため、損益分岐点までの成長はそれほど必要ありません。リスク: 下落し続ける資産にさらに投資することになります。",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "事前に設定された損失パーセンテージ。このパーセンテージに達すると、取引は自動的に終了します。これはヘッジです。市場に従っていない場合でも、損失を制限できます。",
    "Настрій новин": "ニュースの雰囲気",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "このシステムは世界の暗号通貨ニュースの見出しを読み取り、キーワードに基づいてその背景が肯定的か、中立的か、否定的かを評価します。これは単純化した分析であり、予測ではありません。",
    "Віртуальна торгівля": "バーチャルトレード",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "ここでの購入はすべて条件付きです。リアルマネーは引き落とされません。これは、自分の資金を危険にさらさずに、価格変動がポートフォリオにどのような影響を与えるかを学ぶ安全な方法です。",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "私はリファレンスアシスタントです。生成言語モデルを使用せずに、ルールに従って用語を説明し、現在のデータを表示します。以下のトピックを選択するか、BTC、ポートフォリオ、ニュースについて質問してください。",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "こんにちは！初心者の学校から用語を説明し、市場データを示します。答えは生成モデルではなくルールによって生成されます。",
    "Готую відповідь…": "答えを準備中です...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "このシミュレータでは、受信した価格でバックグラウンド プロセスによって 10 秒ごとにストップロスがチェックされます。正確なレベルでのパフォーマンスは保証されません。",
    "Зміна ціни за останню годину": "過去 1 時間の価格変動",
    "Ціна за останні хвилини": "直前価格",
    "Додати віртуальну покупку": "仮想購入を追加する",
    "＋ До блокнота": "＋ ノートへ",
    "Докупити за нижчою ціною та перерахувати середню": "より安い価格でより多く購入し、平均を再計算する",
    "⚖ Усереднити": "⚖ 平均",
    "Автоматично закрити угоду при заданому відсотку збитку": "指定した損失率で取引を自動的にクローズする",
    "Віртуально продати за поточною ціною": "実質的に現在の価格で販売する"
  },
  "ko": {
    "ШАПКА": "모자",
    "Intelligence Tracker · навчальний симулятор": "지능 추적기 · 교육용 시뮬레이터",
    "📈 Ринок": "📈 시장",
    "💼 Портфель": "💼 포트폴리오",
    "📊 Статистика": "📊 통계",
    "📚 Школа новачка": "📚 초보자 학교",
    "Підключення…": "연결 중…",
    "БАНЕР РИЗИКУ": "위험 배너",
    "ТАБЛО ПОРТФЕЛЯ": "포트폴리오 보드",
    "Загальна вартість портфеля": "포트폴리오의 총 가치",
    "віртуальний": "가상",
    "результат відносно ціни покупки": "구매 가격 대비 결과",
    "Вкладено (за цінами покупки)": "투자 (구매 가격)",
    "Відкритих позицій": "오픈 포지션",
    "Скинути систему": "시스템 재설정",
    "Очікуємо перші дані…": "우리는 첫 번째 데이터를 기다리고 있습니다 ...",
    "оновлення через —": "업데이트를 통해 —",
    "ОСНОВНА СІТКА": "메인 그리드",
    "Ринок": "시장",
    "15 обраних монет · зміна за 1 годину": "엄선된 15개 코인 · 1시간 내 변경",
    "падіння ≥ 5% — сигнал «купити»": "하락 ≥ 5% - \"매수\" 신호",
    "ріст ≥ 5% — сигнал «продати»": "성장률 ≥ 5% - \"매도\" 신호",
    "Портфель": "포트폴리오",
    "Віртуальний блокнот покупок": "구매에 대한 가상 노트북",
    "＋ Додати покупку": "＋ 구매 추가",
    "Статистика": "통계",
    "Фінансовий підсумок місяця": "이달의 재무 요약",
    "Місяць:": "월:",
    "Школа новачка": "초보자 학교",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "설명, 생활 사례 및 위험. 훈련은 수입을 보장하지 않습니다.",
    "Новини": "뉴스",
    "🤖 ШІ-моніторинг новин": "🤖 AI 뉴스 모니터링",
    "Аналіз настрою світових заголовків про крипторинок": "글로벌 암호화폐 시장 헤드라인에 대한 감정 분석",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "\"소프트웨어 개발\" 과정의 교육 프로젝트입니다. 모든 거래는 가상으로 이루어지며 실제 자금이 사용되지 않습니다.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "매수/매도 신호는 재무적 조언이 아닌 논리를 보여주는 것입니다.",
    "МОДАЛЬНЕ ВІКНО": "모달 창",
    "🤖 Довідковий асистент": "🤖 참고 도우미",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "생성 모델이 아닌 API 규칙 및 데이터 참조입니다. 재정적 조언을 구성하지 않습니다.",
    "Надіслати": "보내기",
    "Стан зʼєднання та джерело цін": "연결 상태 및 가격 소스",
    "Звукові сповіщення: увімк./вимк.": "소리 알림: 켜기/끄기",
    "Мова інтерфейсу": "인터페이스 언어",
    "Перемкнути темну / світлу тему": "어두운/밝은 테마 전환",
    "Пошук за назвою або символом": "이름이나 기호로 검색",
    "Оновити новини": "뉴스 업데이트",
    "Діалог": "대화",
    "Довідковий асистент": "참고 보조자",
    "Закрити": "닫기",
    "Ваше запитання": "귀하의 질문",
    "Binance · наживо": "바이낸스 · 라이브",
    "CoinGecko · наживо": "코인게코 · 라이브",
    "Демо-режим (імітація цін)": "데모 모드(가격 모방)",
    "Немає даних": "데이터가 없습니다",
    "Вручну": "수동으로",
    "Помилка сервера": "서버 오류",
    "Звукові сповіщення увімкнено": "소리 알림이 활성화되었습니다.",
    "Звукові сповіщення вимкнено": "소리 알림이 꺼졌습니다",
    "Історія ціни": "가격 내역",
    "Аналітика": "분석",
    "у плюсі відносно ціни покупки": "구매 가격 대비 플러스",
    "у мінусі відносно ціни покупки": "구매 가격 대비 빨간색으로 표시",
    "додайте першу покупку у вкладці «Портфель»": "\"포트폴리오\" 탭에 첫 번째 구매를 추가하세요.",
    "Оновлено о": "업데이트한 사람",
    "/ 1 год": "/ 1시간",
    "Блокнот порожній": "노트북이 비어 있습니다",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "가상 구매를 추가하면 상단의 점수판에서 실시간으로 수익 계산이 시작됩니다.",
    "＋ Додати першу покупку": "＋ 첫 구매 추가",
    "% · спрацює на": "% · 계속 노력할 것입니다",
    "Stop-Loss не задано": "손절매가 설정되지 않았습니다.",
    "Відкрито": "열려있습니다",
    "· докупівель:": "추가 구매:",
    "Кількість": "수량",
    "Середня ціна покупки": "평균 구매 가격",
    "Поточна ціна": "현재 가격",
    "Поточна вартість": "현재 가치",
    "Негативний фон": "부정적인 배경",
    "Позитивний фон": "긍정적인 배경",
    "Нейтральний фон": "중립 배경",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "데모 테이프(모의): 현재 실제 뉴스는 제공되지 않습니다.",
    "Джерело:": "출처:",
    "Оригінальні або перекладені заголовки": "원본 또는 번역된 제목",
    "Негативна": "네거티브",
    "Позитивна": "긍정적",
    "Нейтральна": "중립",
    "індекс:": "색인:",
    "▼ негативних:": "▼ 부정:",
    "нейтральних:": "중립:",
    "▲ позитивних:": "▲ 긍정적:",
    "· оригінал англійською": "· 영어 원본",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "제목의 키워드에 따라 분위기가 자동으로 결정됩니다. 업데이트한 사람",
    "Ще немає закритих угод.": "아직 종료된 거래가 없습니다.",
    "угод:": "계약:",
    "У цьому місяці угод немає.": "이번 달에는 거래가 없습니다.",
    "Чистий результат ·": "최종 결과 ·",
    "Закритих угод": "마감된 거래",
    "Прибуткових": "수익성이 있는",
    "з": "/",
    "Найкраща / найгірша": "최고 / 최악",
    "Результат за місяцями": "월별 결과",
    "За монетами ·": "동전으로",
    "Останні закриті угоди": "마지막으로 마감된 거래",
    "Час": "시간",
    "Монета": "코인",
    "К-сть": "미스터",
    "Купівля": "구매",
    "Продаж": "세일",
    "Причина": "이유",
    "Результат": "결과",
    "Продайте першу позицію — і тут зʼявиться історія.": "첫 번째 위치를 판매하면 여기에 이야기가 나타납니다.",
    "Не вдалося завантажити статистику:": "통계를 로드하지 못했습니다:",
    "Віртуальна покупка": "가상 구매",
    "Без обмеження стартовим капіталом": "초기 자본금 제한 없음",
    "Ціна, за яку ви її віртуально купили ($)": "실제로 구매한 가격($)",
    "Підставити ринкову ціну": "시장가격을 대체하다",
    "Введіть кількість і ціну.": "수량과 가격을 입력하세요.",
    "Додати до блокнота": "노트북에 추가",
    "напр. 0,5": "예를 들어 0.5",
    "напр. 64 500": "예를 들어 64,500",
    "Підставити ринкову ціну:": "시장 가격을 대체합니다:",
    "Сума покупки:": "구매 금액:",
    "Зараз ця позиція була б у": "이제 이 위치는",
    "(ринок:": "(시장:",
    "Введіть додатні числа для кількості та ціни": "수량 및 가격에 양수를 입력하세요.",
    "Додано:": "추가됨:",
    "за": "에 대한",
    "Усереднення ·": "평균 ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "평균 자동 재계산으로 더 저렴한 가격으로 추가 구매 가능",
    "Зараз:": "지금:",
    "· середня": "· 평균",
    "· ринок": "· 시장",
    "Скільки докуповуємо": "우리는 얼마나 사나요?",
    "Ціна докупівлі ($) — має бути нижчою за": "추가 구매 가격($)은 다음보다 낮아야 합니다.",
    "Усереднити": "평균",
    "Введіть додатні числа.": "양수를 입력하세요.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "환매 가격은 현재 평균보다 낮아야합니다 (",
    "Нова кількість:": "새로운 수량:",
    "Нова середня ціна:": "새로운 평균 가격:",
    "Додаткові вкладення:": "추가 첨부 파일:",
    "Середня ціна": "평균 가격",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "주어진 마이너스에서 거래의 자동 가상 마감",
    "Середня ціна:": "평균 가격:",
    "· зараз": "· 지금",
    "Закрити угоду, коли збиток досягне (%)": "손실이 (%)에 도달하면 거래를 종료합니다.",
    "Зберегти": "저장",
    "Вимкнути": "끄다",
    "Вкажіть відсоток від 0,1 до 99.": "0.1에서 99 사이의 백분율을 입력하세요.",
    "Спрацює при ціні ≤": "가격이 ≤이면 작동합니다.",
    "Плановий збиток на порозі:": "임계값에서의 계획된 손실:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "가격이 이미 임계값보다 낮습니다. 거래가 즉시 종료됩니다!",
    "Stop-Loss для": "손절매",
    "встановлено: −": "확립됨: -",
    "вимкнено": "꺼졌어",
    "Продати": "팔다",
    "Віртуальний продаж за поточною ринковою ціною": "현재 시장 가격으로 가상 판매",
    "Кількість:": "수량:",
    "Ціна продажу:": "판매 가격:",
    "Результат угоди:": "합의 결과:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "결과는 데이터베이스에 저장되며 이달의 통계에 포함됩니다.",
    "Так, продати": "응, 팔아",
    "Скасувати": "취소하다",
    "продано за": "에 팔렸다",
    "різко впала:": "급격히 떨어졌습니다.",
    "за годину": "한 시간 안에",
    "Немає зв’язку з сервером": "서버에 연결되지 않음",
    "Новини оновлено": "뉴스가 업데이트되었습니다.",
    "Не вдалося оновити новини": "뉴스를 업데이트하지 못했습니다.",
    "оновлення через": "업데이트를 통해",
    "с": "초",
    "повтор спроби підключення…": "연결 다시 시도…",
    "Видалити без фіксації ·": "수정하지 않고 삭제 ·",
    "Виправлення випадково введеної позиції": "실수로 입력된 위치 수정",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "해당 위치가 영구적으로 삭제됩니다. 월별 통계에는 손익이 포함되지 않습니다.",
    "Видалити без фіксації": "기록 없이 삭제",
    "Позицію видалено без запису в статистику": "통계에 기록되지 않고 해당 위치가 삭제되었습니다.",
    "Незворотна дія": "되돌릴 수 없는 행동",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "모든 활성 위치와 마감된 거래가 삭제됩니다. 가격, 뉴스, 테마 설정은 그대로 유지됩니다.",
    "Так, очистити всі угоди": "예, 모든 계약을 취소합니다",
    "Систему скинуто": "시스템 재설정",
    "Аналітика монети": "코인 분석",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: 이전 MATIC 토큰의 가격이 아닌 현재 POL/USDT 쌍이 표시됩니다.",
    "Максимум вікна": "최대 창",
    "Мінімум вікна": "최소 창",
    "Зміна у вікні": "창에서 변화",
    "Волатильність дохідностей": "수익률의 변동성",
    "Історія ціни · до 60 точок": "가격 내역 · 최대 60포인트",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "분 포인트; 현재 지점은 10초마다 업데이트됩니다. 데모 가격은 별도로 표시됩니다.",
    "Ще недостатньо спостережень для графіка.": "아직 그래프로 표시할 관측치가 충분하지 않습니다.",
    "Таблиця спостережень": "관찰표",
    "Ціна": "가격",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "변동성은 일일 최대값이 아니라 이 창의 지점 간 변화율의 표준 편차입니다.",
    "КУПИТИ за вигідною ціною": "좋은 가격에 구매하세요",
    "НЕ КУПУВАТИ / ПРОДАТИ": "구매/판매하지 마세요",
    "Утримуватись, ринок спокійний": "잠깐만요, 시장은 조용해요",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ 부정적인 세계 뉴스로 인한 시장 하락 위험 높음!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "손절매 작동: {symbol}가 ${price:,.4f}({pct:+.2f}%, {pnl:+,.2f}$)에 마감되었습니다.",
    "Невідома монета. Доступні: {coins}": "알 수 없는 동전. 사용 가능: {coins}",
    "Кількість і ціна мають бути додатними числами": "수량과 가격은 양수여야 합니다.",
    "Позицію не знайдено": "직위를 찾을 수 없습니다.",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "평균화는 현재 평균(${avg:,.4f})보다 낮은 가격에서만 가능합니다.",
    "Stop-Loss — це відсоток від 0.1 до 99": "정지 손실은 0.1에서 99까지의 백분율입니다.",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "가격이 아직 로드되지 않았습니다. 몇 초 후에 시도해 보세요.",
    "Формат місяця: РРРР-ММ": "월 형식: YYYY-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "하드 리셋하려면 {\"confirm\": true}를 보내세요.",
    "Повідомлення порожнє": "메시지가 비어 있습니다.",
    "Повідомлення задовге (максимум {n} символів)": "메시지가 너무 깁니다(최대 {n}자).",
    "висхідний": "오름차순",
    "низхідний": "내림차순",
    "боковий": "측면",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: 시간 {change:+.2f}%당 가격 ${price}. 60분 동안의 추세: {trend}, 변동폭 {vol:.2f}%. 시스템 신호: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "포트폴리오: 비용 ${value:,.2f}, 결과 {pnl:+,.2f}$({pct:+.2f}%), 오픈 포지션: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "서류 가방이 비어 있습니다. 코인 카드에 첫 번째 가상 구매를 추가하세요.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "뉴스 배경은 부정적({index:+.2f} 지수): 시장 하락 위험이 높아진다.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "심각한 위험이 없는 뉴스 배경(색인 {index:+.2f})",
    "Огляд ринку за годину: {items}.": "시간별 시장 개요: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "인사말! 저는 교육용 AI 보조원입니다. 코인, 포트폴리오, 뉴스, 손절매 또는 평균화에 대해 문의하세요.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "지금은 간단한 규칙(플러그)에 따라 작업합니다. 시도해 보세요: \"BTC 가격\", \"내 포트폴리오\", \"새로운 기능\", \"손절매란 무엇입니까?\"",
    "Це навчальна демонстрація, а не фінансова порада.": "이것은 재정적 조언이 아닌 교육적 시연입니다.",
    "Прибуток і збиток (P&L)": "손익(P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L은 코인의 현재 가치와 코인을 구매한 금액의 차이입니다. 플러스는 이익을 의미하고 마이너스는 손실을 의미합니다. 팔 때까지 결과는 종이에만 있습니다.",
    "Зміна ціни за годину": "시간별 가격 변동",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "지난 한 시간 동안 가격이 얼마나 변했는지 표시합니다. 급격한 감소(-5%에서)는 시스템에서 빨간색으로 강조 표시되고 급격한 증가(+5%에서)는 녹색으로 강조 표시됩니다.",
    "Усереднення": "평균화",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "동일한 코인을 더 저렴한 가격에 추가 구매하실 수 있습니다. 평균 구매 가격이 감소하고 있으므로 손익분기점에 도달하려면 더 적은 성장이 필요합니다. 위험: 계속 하락하는 자산에 더 많이 투자합니다.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "미리 결정된 손실 비율에 도달하면 거래가 자동으로 종료됩니다. 이는 헤지입니다. 시장을 따르지 않더라도 손실을 제한할 수 있습니다.",
    "Настрій новин": "뉴스의 분위기",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "시스템은 글로벌 암호화폐 뉴스 헤드라인을 읽고 키워드를 기반으로 배경이 긍정적인지, 중립적인지, 부정적인지 평가합니다. 이는 예측이 아닌 단순화된 분석입니다.",
    "Віртуальна торгівля": "가상 무역",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "여기서의 모든 구매는 조건부입니다. 실제 돈은 인출되지 않습니다. 이는 가격 변동이 포트폴리오에 어떻게 영향을 미치는지 알아보고 자신의 자금을 위험에 빠뜨리지 않는 안전한 방법입니다.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "나는 참조 보조자입니다. 생성 언어 모델 없이 규칙에 따라 용어를 설명하고 현재 데이터를 표시합니다. 아래에서 주제를 선택하거나 BTC, 포트폴리오 또는 뉴스에 대해 문의하세요.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "인사말! 초급부터 용어를 설명하고 시장 데이터를 보여줍니다. 답변은 생성 모델이 아닌 규칙에 의해 생성됩니다.",
    "Готую відповідь…": "답변을 준비 중입니다..",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "이 시뮬레이터에서는 수신된 가격으로 10초마다 백그라운드 프로세스에 의해 손절매가 확인됩니다. 정확한 수준의 성능은 보장되지 않습니다.",
    "Зміна ціни за останню годину": "지난 1시간 동안의 가격 변동",
    "Ціна за останні хвилини": "막바지 가격",
    "Додати віртуальну покупку": "가상 구매 추가",
    "＋ До блокнота": "＋ 노트에",
    "Докупити за нижчою ціною та перерахувати середню": "더 낮은 가격에 더 많이 구매하고 평균을 다시 계산하세요.",
    "⚖ Усереднити": "⚖ 평균",
    "Автоматично закрити угоду при заданому відсотку збитку": "지정된 손실 비율로 거래를 자동으로 종료합니다.",
    "Віртуально продати за поточною ціною": "사실상 현재 가격으로 판매"
  },
  "pt": {
    "ШАПКА": "CHAPÉU",
    "Intelligence Tracker · навчальний симулятор": "Intelligence Tracker · simulador educacional",
    "📈 Ринок": "📈 Mercado",
    "💼 Портфель": "💼 Portfólio",
    "📊 Статистика": "📊 Estatísticas",
    "📚 Школа новачка": "📚 Escola para iniciantes",
    "Підключення…": "Conectando…",
    "БАНЕР РИЗИКУ": "BANDEIRA DE RISCO",
    "ТАБЛО ПОРТФЕЛЯ": "QUADRO DE PORTFÓLIO",
    "Загальна вартість портфеля": "O valor total da carteira",
    "віртуальний": "virtuais",
    "результат відносно ціни покупки": "o resultado em relação ao preço de compra",
    "Вкладено (за цінами покупки)": "Investido (a preços de compra)",
    "Відкритих позицій": "Posições abertas",
    "Скинути систему": "Reinicialize o sistema",
    "Очікуємо перші дані…": "Estamos aguardando os primeiros dados...",
    "оновлення через —": "atualizar via -",
    "ОСНОВНА СІТКА": "GRADE PRINCIPAL",
    "Ринок": "o mercado",
    "15 обраних монет · зміна за 1 годину": "15 moedas selecionadas · troca em 1 hora",
    "падіння ≥ 5% — сигнал «купити»": "queda ≥ 5% - sinal de \"compra\"",
    "ріст ≥ 5% — сигнал «продати»": "crescimento ≥ 5% - sinal de “venda”",
    "Портфель": "Portfólio",
    "Віртуальний блокнот покупок": "Caderno virtual de compras",
    "＋ Додати покупку": "＋ Adicionar compra",
    "Статистика": "Estatísticas",
    "Фінансовий підсумок місяця": "Resumo financeiro do mês",
    "Місяць:": "Mês:",
    "Школа новачка": "Escola para iniciantes",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Explicações, exemplos de vida e riscos. Treinamento não garante renda.",
    "Новини": "Notícias",
    "🤖 ШІ-моніторинг новин": "🤖 Monitoramento de notícias de IA",
    "Аналіз настрою світових заголовків про крипторинок": "Análise de sentimento das manchetes do mercado global de criptografia",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "Projeto educativo do curso “Desenvolvimento de Software”. Todas as transações são virtuais, nenhum dinheiro real é utilizado.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Os sinais de compra/venda são uma demonstração de lógica, não de aconselhamento financeiro.",
    "МОДАЛЬНЕ ВІКНО": "JANELA MODAL",
    "🤖 Довідковий асистент": "🤖 Assistente de referência",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Regras de API e referência de dados, não modelo generativo. Não constitui aconselhamento financeiro.",
    "Надіслати": "Enviar",
    "Стан зʼєднання та джерело цін": "Status da conexão e fonte de preço",
    "Звукові сповіщення: увімк./вимк.": "Notificações sonoras: ligar/desligar",
    "Мова інтерфейсу": "Idioma da interface",
    "Перемкнути темну / світлу тему": "Alternar tema claro/escuro",
    "Пошук за назвою або символом": "Pesquise por nome ou símbolo",
    "Оновити новини": "Atualizar notícias",
    "Діалог": "Diálogo",
    "Довідковий асистент": "Assistente de referência",
    "Закрити": "fechar",
    "Ваше запитання": "Sua pergunta",
    "Binance · наживо": "Binance · ao vivo",
    "CoinGecko · наживо": "CoinGecko · ao vivo",
    "Демо-режим (імітація цін)": "Modo demo (imitação de preços)",
    "Немає даних": "Não há dados disponíveis",
    "Вручну": "Manualmente",
    "Помилка сервера": "Erro no servidor",
    "Звукові сповіщення увімкнено": "As notificações sonoras estão ativadas",
    "Звукові сповіщення вимкнено": "As notificações sonoras estão desativadas",
    "Історія ціни": "Histórico de preços",
    "Аналітика": "Análise",
    "у плюсі відносно ціни покупки": "no positivo em relação ao preço de compra",
    "у мінусі відносно ціни покупки": "no vermelho em relação ao preço de compra",
    "додайте першу покупку у вкладці «Портфель»": "adicione sua primeira compra na aba \"Portfólio\"",
    "Оновлено о": "Atualizado por",
    "/ 1 год": "/ 1 hora",
    "Блокнот порожній": "O caderno está vazio",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Adicione uma compra virtual – e o placar no topo começará a contar os lucros em tempo real.",
    "＋ Додати першу покупку": "＋ Adicionar primeira compra",
    "% · спрацює на": "% · trabalhará em",
    "Stop-Loss не задано": "Stop-Loss não está definido",
    "Відкрито": "Está aberto",
    "· докупівель:": "Compra adicional:",
    "Кількість": "Quantidade",
    "Середня ціна покупки": "Preço médio de compra",
    "Поточна ціна": "Preço atual",
    "Поточна вартість": "Valor atual",
    "Негативний фон": "Fundo negativo",
    "Позитивний фон": "Contexto positivo",
    "Нейтральний фон": "Fundo neutro",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Fita demo (simulada): notícias reais não estão disponíveis no momento",
    "Джерело:": "Fonte:",
    "Оригінальні або перекладені заголовки": "Títulos originais ou traduzidos",
    "Негативна": "Negativo",
    "Позитивна": "Positivo",
    "Нейтральна": "Neutro",
    "індекс:": "índice:",
    "▼ негативних:": "▼ negativo:",
    "нейтральних:": "neutro:",
    "▲ позитивних:": "▲ positivo:",
    "· оригінал англійською": "· original em inglês",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "O clima é determinado automaticamente pelas palavras-chave dos títulos. Atualizado por",
    "Ще немає закритих угод.": "Ainda não há negócios fechados.",
    "угод:": "acordos:",
    "У цьому місяці угод немає.": "Não há ofertas este mês.",
    "Чистий результат ·": "Resultado líquido ·",
    "Закритих угод": "Negócios fechados",
    "Прибуткових": "Rentável",
    "з": "de",
    "Найкраща / найгірша": "O melhor/o pior",
    "Результат за місяцями": "Resultado por mês",
    "За монетами ·": "Por moedas",
    "Останні закриті угоди": "Últimos negócios fechados",
    "Час": "hora",
    "Монета": "Moeda",
    "К-сть": "Senhor",
    "Купівля": "Comprar",
    "Продаж": "Venda",
    "Причина": "A razão",
    "Результат": "O resultado",
    "Продайте першу позицію — і тут зʼявиться історія.": "Venda a primeira posição - e aqui a história aparecerá.",
    "Не вдалося завантажити статистику:": "Falha ao carregar estatísticas:",
    "Віртуальна покупка": "Compra virtual",
    "Без обмеження стартовим капіталом": "Sem limite de capital inicial",
    "Ціна, за яку ви її віртуально купили ($)": "O preço pelo qual você virtualmente comprou ($)",
    "Підставити ринкову ціну": "Substitua o preço de mercado",
    "Введіть кількість і ціну.": "Insira a quantidade e o preço.",
    "Додати до блокнота": "Adicionar ao bloco de notas",
    "напр. 0,5": "por exemplo 0,5",
    "напр. 64 500": "por exemplo 64.500",
    "Підставити ринкову ціну:": "Substitua o preço de mercado:",
    "Сума покупки:": "Valor da compra:",
    "Зараз ця позиція була б у": "Agora esta posição estaria em",
    "(ринок:": "(mercado:",
    "Введіть додатні числа для кількості та ціни": "Insira números positivos para quantidade e preço",
    "Додано:": "Adicionado:",
    "за": "para",
    "Усереднення ·": "Média ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Compra adicional a um preço menor com recálculo automático da média",
    "Зараз:": "Agora:",
    "· середня": "· média",
    "· ринок": "· o mercado",
    "Скільки докуповуємо": "Quanto compramos?",
    "Ціна докупівлі ($) — має бути нижчою за": "O preço de compra adicional ($) deve ser inferior ao",
    "Усереднити": "Média",
    "Введіть додатні числа.": "Insira números positivos.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "O preço de recompra deve ser inferior à média atual (",
    "Нова кількість:": "Nova quantidade:",
    "Нова середня ціна:": "Novo preço médio:",
    "Додаткові вкладення:": "Anexos adicionais:",
    "Середня ціна": "Preço médio",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Fechamento virtual automático da transação com um determinado valor negativo",
    "Середня ціна:": "Preço médio:",
    "· зараз": "· agora",
    "Закрити угоду, коли збиток досягне (%)": "Feche o negócio quando a perda atingir (%)",
    "Зберегти": "salvar",
    "Вимкнути": "Desligue",
    "Вкажіть відсоток від 0,1 до 99.": "Insira uma porcentagem entre 0,1 e 99.",
    "Спрацює при ціні ≤": "Funcionará se o preço ≤",
    "Плановий збиток на порозі:": "Perda planejada no limite:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "O preço já está abaixo do limite - o negócio será fechado imediatamente!",
    "Stop-Loss для": "Stop Loss para",
    "встановлено: −": "estabelecido: -",
    "вимкнено": "desligado",
    "Продати": "vender",
    "Віртуальний продаж за поточною ринковою ціною": "Venda virtual ao preço de mercado atual",
    "Кількість:": "Quantidade:",
    "Ціна продажу:": "Preço de venda:",
    "Результат угоди:": "O resultado do acordo:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "O resultado será salvo no banco de dados e constará nas estatísticas do mês.",
    "Так, продати": "Sim, vender",
    "Скасувати": "cancelar",
    "продано за": "vendido por",
    "різко впала:": "caiu drasticamente:",
    "за годину": "em uma hora",
    "Немає зв’язку з сервером": "Sem conexão com o servidor",
    "Новини оновлено": "Notícias atualizadas",
    "Не вдалося оновити новини": "Falha ao atualizar notícias",
    "оновлення через": "atualizar via",
    "с": "s",
    "повтор спроби підключення…": "tente novamente a conexão…",
    "Видалити без фіксації ·": "Excluir sem corrigir ·",
    "Виправлення випадково введеної позиції": "Correção de posição inserida acidentalmente",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "A posição será excluída permanentemente. Lucros ou perdas não serão incluídos nas estatísticas mensais.",
    "Видалити без фіксації": "Eliminar sem registar",
    "Позицію видалено без запису в статистику": "A posição foi excluída sem registro nas estatísticas",
    "Незворотна дія": "Ação irreversível",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Todas as posições ativas e negócios fechados serão excluídos. As configurações de preços, notícias e temas permanecerão.",
    "Так, очистити всі угоди": "Sim, limpe todos os acordos",
    "Систему скинуто": "Reinicialização do sistema",
    "Аналітика монети": "Análise de moedas",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: O par POL/USDT atual é mostrado, não o preço do antigo token MATIC.",
    "Максимум вікна": "Janela máxima",
    "Мінімум вікна": "Janela mínima",
    "Зміна у вікні": "Mudança na janela",
    "Волатильність дохідностей": "Volatilidade dos retornos",
    "Історія ціни · до 60 точок": "Histórico de preços · até 60 pontos",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Pontos minuto; o ponto atual é atualizado a cada 10 segundos. Os preços de demonstração são indicados separadamente.",
    "Ще недостатньо спостережень для графіка.": "Ainda não há observações suficientes para representar graficamente.",
    "Таблиця спостережень": "Tabela de observações",
    "Ціна": "Preço",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "A volatilidade é o desvio padrão das variações percentuais entre os pontos desta janela, e não um máximo por dia.",
    "КУПИТИ за вигідною ціною": "COMPRE por um bom preço",
    "НЕ КУПУВАТИ / ПРОДАТИ": "NÃO COMPRE/VENDA",
    "Утримуватись, ринок спокійний": "Espere, o mercado está calmo",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Alto risco de queda do mercado devido a notícias mundiais negativas!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Stop-Loss funcionou: {symbol} fechou em ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Moeda desconhecida. Disponível: {coins}",
    "Кількість і ціна мають бути додатними числами": "Quantidade e preço devem ser números positivos",
    "Позицію не знайдено": "Nenhuma posição encontrada",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "A média só é possível a um preço inferior à média atual (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Stop-Loss é uma porcentagem de 0,1 a 99",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Os preços ainda não foram carregados, tente em alguns segundos",
    "Формат місяця: РРРР-ММ": "Formato do mês: AAAA-MM",
    "Для повного скидання надішліть {\"confirm\": true}": "Para reinicialização total, envie {\"confirm\": true}",
    "Повідомлення порожнє": "A mensagem está vazia",
    "Повідомлення задовге (максимум {n} символів)": "A mensagem é muito longa (máximo de caracteres {n})",
    "висхідний": "ascendente",
    "низхідний": "descendente",
    "боковий": "laterais",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: preço ${price}, por hora {change:+.2f}%. Tendência para 60 min: {trend}, flutuação {vol:.2f}%. Sinal do sistema: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Carteira: custo ${value:,.2f}, resultado {pnl:+,.2f}$ ({pct:+.2f}%), posições abertas: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "A pasta está vazia. Adicione sua primeira compra virtual em um cartão moeda.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "O cenário noticioso é negativo (índice {index:+.2f}): o risco de queda do mercado aumenta.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Histórico de notícias sem risco crítico (índice {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Visão geral do mercado por hora: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Saudações! Sou um assistente educacional de IA. Pergunte sobre Moeda, Portfólio, Notícias, Stop-Loss ou Média.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Por enquanto trabalho de acordo com regras simples (plug). Experimente: “Preço BTC”, “meu portfólio”, “novidades”, “o que é Stop-Loss”.",
    "Це навчальна демонстрація, а не фінансова порада.": "Esta é uma demonstração educacional, não um conselho financeiro.",
    "Прибуток і збиток (P&L)": "Lucros e perdas (P&L)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "P&L é a diferença entre o valor atual das moedas e o valor pelo qual você as comprou. Mais significa lucro, menos significa perda. Até você vender, o resultado fica apenas no papel.",
    "Зміна ціни за годину": "Alteração de preço por hora",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Mostra quanto o preço mudou na última hora. Uma queda acentuada (de -5%) é destacada pelo sistema em vermelho, um aumento acentuado (de +5%) em verde.",
    "Усереднення": "Média",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Compra adicional da mesma moeda a um preço inferior. O preço médio de compra está diminuindo, portanto, é necessário menos crescimento para atingir o ponto de equilíbrio. Risco: você investe mais em um ativo que continua caindo.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Um percentual de perda pré-determinado, ao atingir o qual o negócio é fechado automaticamente. É uma proteção: você está limitando suas perdas mesmo que não esteja acompanhando o mercado.",
    "Настрій новин": "O clima das notícias",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "O sistema lê manchetes de notícias criptográficas globais e avalia se o histórico é positivo, neutro ou negativo com base em palavras-chave. Esta é uma análise simplificada, não uma previsão.",
    "Віртуальна торгівля": "Comércio virtual",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Todas as compras aqui são condicionais: dinheiro real não é debitado. Esta é uma forma segura de aprender como os movimentos de preços afetam a carteira e não arriscar seus próprios fundos.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Sou assistente de referência: explico termos e mostro dados atuais de acordo com regras, sem modelo de linguagem generativa. Escolha um tema abaixo ou pergunte sobre BTC, portfólio ou novidades.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Saudações! Explico os termos da escola para iniciantes e mostro os dados do mercado. As respostas são geradas por regras, não por um modelo generativo.",
    "Готую відповідь…": "Estou preparando uma resposta...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "Neste simulador, o Stop-Loss é verificado pelo processo em segundo plano a cada 10 segundos pelo preço recebido; o desempenho em um nível exato não é garantido.",
    "Зміна ціни за останню годину": "Alteração de preço na última hora",
    "Ціна за останні хвилини": "Preço de última hora",
    "Додати віртуальну покупку": "Adicione uma compra virtual",
    "＋ До блокнота": "＋ Para o caderno",
    "Докупити за нижчою ціною та перерахувати середню": "Compre mais por um preço menor e recalcule a média",
    "⚖ Усереднити": "⚖ Média",
    "Автоматично закрити угоду при заданому відсотку збитку": "Fechar automaticamente o negócio com uma determinada porcentagem de perda",
    "Віртуально продати за поточною ціною": "Venda virtualmente pelo preço atual"
  },
  "tr": {
    "ШАПКА": "ŞAPKA",
    "Intelligence Tracker · навчальний симулятор": "Zeka Takipçisi · eğitim simülatörü",
    "📈 Ринок": "📈 Pazar",
    "💼 Портфель": "💼 Portföy",
    "📊 Статистика": "📊 İstatistikler",
    "📚 Школа новачка": "📚 Başlangıç okulu",
    "Підключення…": "Bağlanıyor…",
    "БАНЕР РИЗИКУ": "RİSK AFİŞİ",
    "ТАБЛО ПОРТФЕЛЯ": "PORTFÖY PANOSU",
    "Загальна вартість портфеля": "Portföyün toplam değeri",
    "віртуальний": "sanal",
    "результат відносно ціни покупки": "sonuç satın alma fiyatına göre",
    "Вкладено (за цінами покупки)": "Yatırım yapıldı (satın alma fiyatlarıyla)",
    "Відкритих позицій": "Açık pozisyonlar",
    "Скинути систему": "Sistemi sıfırla",
    "Очікуємо перші дані…": "İlk verileri bekliyoruz...",
    "оновлення через —": "aracılığıyla güncelleme —",
    "ОСНОВНА СІТКА": "ANA IZGARA",
    "Ринок": "pazar",
    "15 обраних монет · зміна за 1 годину": "15 seçilmiş jeton · 1 saatte değişim",
    "падіння ≥ 5% — сигнал «купити»": "düşüş ≥ %5 - \"satın alma\" sinyali",
    "ріст ≥ 5% — сигнал «продати»": "büyüme ≥ %5 - \"satış\" sinyali",
    "Портфель": "Portföy",
    "Віртуальний блокнот покупок": "Satın alma işlemlerinin sanal not defteri",
    "＋ Додати покупку": "＋ Satın alma ekle",
    "Статистика": "İstatistikler",
    "Фінансовий підсумок місяця": "Ayın finansal özeti",
    "Місяць:": "Ay:",
    "Школа новачка": "Başlangıç okulu",
    "Пояснення, життєві приклади та ризики. Навчання не гарантує прибутку.": "Açıklamalar, hayattan örnekler ve riskler. Eğitim gelir garantisi vermez.",
    "Новини": "Haberler",
    "🤖 ШІ-моніторинг новин": "🤖 Yapay zeka haber izleme",
    "Аналіз настрою світових заголовків про крипторинок": "Küresel kripto piyasası manşetlerinin duyarlılık analizi",
    "Навчальний проєкт з курсу «Розробка програмного забезпечення». Усі угоди віртуальні, реальні кошти не використовуються.": "\"Yazılım Geliştirme\" kursundan eğitim projesi. Tüm işlemler sanaldır, gerçek para kullanılmaz.",
    "Сигнали «купити / продати» — демонстрація логіки, а не фінансова порада.": "Alış/satış sinyalleri finansal tavsiye değil, mantığın göstergesidir.",
    "МОДАЛЬНЕ ВІКНО": "MODAL PENCERE",
    "🤖 Довідковий асистент": "🤖 Referans asistanı",
    "Довідка за правилами та даними API, не генеративна модель. Не є фінансовою порадою.": "Üretken model değil, API kuralları ve veri referansı. Finansal tavsiye niteliğinde değildir.",
    "Надіслати": "Gönder",
    "Стан зʼєднання та джерело цін": "Bağlantı durumu ve fiyat kaynağı",
    "Звукові сповіщення: увімк./вимк.": "Ses bildirimleri: açık/kapalı",
    "Мова інтерфейсу": "Arayüz dili",
    "Перемкнути темну / світлу тему": "Koyu / açık temayı değiştir",
    "Пошук за назвою або символом": "İsme veya sembole göre arayın",
    "Оновити новини": "Haberleri güncelle",
    "Діалог": "Diyalog",
    "Довідковий асистент": "Referans asistanı",
    "Закрити": "kapat",
    "Ваше запитання": "Sorunuz",
    "Binance · наживо": "Binance · canlı",
    "CoinGecko · наживо": "CoinGecko · canlı",
    "Демо-режим (імітація цін)": "Demo modu (fiyatların taklidi)",
    "Немає даних": "Veri yok",
    "Вручну": "Manuel olarak",
    "Помилка сервера": "Sunucu hatası",
    "Звукові сповіщення увімкнено": "Ses bildirimleri etkinleştirildi",
    "Звукові сповіщення вимкнено": "Ses bildirimleri kapatıldı",
    "Історія ціни": "Fiyat geçmişi",
    "Аналітика": "Analitik",
    "у плюсі відносно ціни покупки": "satın alma fiyatına göre artı",
    "у мінусі відносно ціни покупки": "satın alma fiyatına göre kırmızı renkte",
    "додайте першу покупку у вкладці «Портфель»": "ilk satın alma işleminizi \"Portföy\" sekmesine ekleyin",
    "Оновлено о": "Tarafından güncellendi",
    "/ 1 год": "/ 1 saat",
    "Блокнот порожній": "Defter boş",
    "Додайте віртуальну покупку — і табло вгорі почне рахувати прибуток у реальному часі.": "Sanal bir satın alma ekleyin; üstteki puan tablosu karları gerçek zamanlı olarak saymaya başlayacaktır.",
    "＋ Додати першу покупку": "＋ İlk satın alma işlemini ekle",
    "% · спрацює на": "% · üzerinde çalışacak",
    "Stop-Loss не задано": "Zararı Durdur ayarlanmadı",
    "Відкрито": "açık",
    "· докупівель:": "Ek satın alma:",
    "Кількість": "miktar",
    "Середня ціна покупки": "Ortalama satın alma fiyatı",
    "Поточна ціна": "Güncel fiyat",
    "Поточна вартість": "Mevcut değer",
    "Негативний фон": "Negatif arka plan",
    "Позитивний фон": "Olumlu arka plan",
    "Нейтральний фон": "Nötr arka plan",
    "Демо-стрічка (імітація): реальні новини зараз недоступні": "Demo kaseti (sahte): Şu anda gerçek haberler mevcut değil",
    "Джерело:": "Kaynak:",
    "Оригінальні або перекладені заголовки": "Orijinal veya çevrilmiş başlıklar",
    "Негативна": "Negatif",
    "Позитивна": "Olumlu",
    "Нейтральна": "Nötr",
    "індекс:": "dizin:",
    "▼ негативних:": "▼ negatif:",
    "нейтральних:": "nötr:",
    "▲ позитивних:": "▲ olumlu:",
    "· оригінал англійською": "· İngilizce orijinali",
    "Настрій визначається автоматично за ключовими словами заголовків. Оновлено о": "Ruh hali, başlıkların anahtar kelimelerine göre otomatik olarak belirlenir. Tarafından güncellendi",
    "Ще немає закритих угод.": "Henüz kapatılmış bir anlaşma yok.",
    "угод:": "anlaşmalar:",
    "У цьому місяці угод немає.": "Bu ay hiçbir anlaşma yok.",
    "Чистий результат ·": "Net sonuç ·",
    "Закритих угод": "Kapalı fırsatlar",
    "Прибуткових": "karlı",
    "з": "/",
    "Найкраща / найгірша": "En iyi / en kötü",
    "Результат за місяцями": "Aya göre sonuç",
    "За монетами ·": "Madeni paralara göre",
    "Останні закриті угоди": "Son kapatılan fırsatlar",
    "Час": "zaman",
    "Монета": "Madeni para",
    "К-сть": "Bay",
    "Купівля": "Satın alma",
    "Продаж": "Satış",
    "Причина": "Sebep",
    "Результат": "Sonuç",
    "Продайте першу позицію — і тут зʼявиться історія.": "İlk pozisyonu sat - ve hikaye burada görünecek.",
    "Не вдалося завантажити статистику:": "İstatistikler yüklenemedi:",
    "Віртуальна покупка": "Sanal satın alma",
    "Без обмеження стартовим капіталом": "Başlangıç sermayesinde sınır yok",
    "Ціна, за яку ви її віртуально купили ($)": "Sanal olarak satın aldığınız fiyat ($)",
    "Підставити ринкову ціну": "Piyasa fiyatını değiştirin",
    "Введіть кількість і ціну.": "Miktarı ve fiyatı girin.",
    "Додати до блокнота": "Not defterine ekle",
    "напр. 0,5": "örneğin 0,5",
    "напр. 64 500": "örneğin 64.500",
    "Підставити ринкову ціну:": "Piyasa fiyatını değiştirin:",
    "Сума покупки:": "Satın alma tutarı:",
    "Зараз ця позиція була б у": "Şimdi bu pozisyon",
    "(ринок:": "(piyasa:",
    "Введіть додатні числа для кількості та ціни": "Miktar ve fiyat için pozitif sayılar girin",
    "Додано:": "Eklendi:",
    "за": "için",
    "Усереднення ·": "Ortalama ·",
    "Докупівля за нижчою ціною з автоматичним перерахунком середньої": "Ortalamanın otomatik olarak yeniden hesaplanmasıyla daha düşük fiyata ek satın alma",
    "Зараз:": "Şimdi:",
    "· середня": "· ortalama",
    "· ринок": "· pazar",
    "Скільки докуповуємо": "Ne kadar satın alıyoruz?",
    "Ціна докупівлі ($) — має бути нижчою за": "Ek satın alma fiyatı ($) şundan düşük olmalıdır:",
    "Усереднити": "Ortalama",
    "Введіть додатні числа.": "Pozitif sayıları girin.",
    "Ціна докупівлі має бути нижчою за поточну середню (": "Geri alım fiyatı mevcut ortalamanın altında olmalıdır (",
    "Нова кількість:": "Yeni miktar:",
    "Нова середня ціна:": "Yeni ortalama fiyat:",
    "Додаткові вкладення:": "Ek ekler:",
    "Середня ціна": "Ortalama fiyat",
    "Автоматичне віртуальне закриття угоди при заданому мінусі": "Belirli bir ekside işlemin otomatik sanal kapatılması",
    "Середня ціна:": "Ortalama fiyat:",
    "· зараз": "· şimdi",
    "Закрити угоду, коли збиток досягне (%)": "Zarar (%) değerine ulaştığında işlemi kapatın",
    "Зберегти": "kaydet",
    "Вимкнути": "Kapat",
    "Вкажіть відсоток від 0,1 до 99.": "0,1 ile 99 arasında bir yüzde girin.",
    "Спрацює при ціні ≤": "Fiyat ≤ ise işe yarayacaktır",
    "Плановий збиток на порозі:": "Eşikte planlanan kayıp:",
    "Ціна вже нижча за поріг — угода закриється одразу!": "Fiyat zaten eşiğin altında - anlaşma hemen sonuçlanacak!",
    "Stop-Loss для": "Zararı Durdur",
    "встановлено: −": "kurulmuş: −",
    "вимкнено": "kapalı",
    "Продати": "satmak",
    "Віртуальний продаж за поточною ринковою ціною": "Güncel piyasa fiyatından sanal satış",
    "Кількість:": "miktar:",
    "Ціна продажу:": "Satış fiyatı:",
    "Результат угоди:": "Anlaşmanın sonucu:",
    "Результат буде збережено в базі даних і потрапить у статистику місяця.": "Sonuç veri tabanına kaydedilecek ve ayın istatistiklerine dahil edilecektir.",
    "Так, продати": "Evet sat",
    "Скасувати": "iptal etmek",
    "продано за": "için satıldı",
    "різко впала:": "hızla düştü:",
    "за годину": "bir saat içinde",
    "Немає зв’язку з сервером": "Sunucuya bağlantı yok",
    "Новини оновлено": "Haberler güncellendi",
    "Не вдалося оновити новини": "Haber güncellenemedi",
    "оновлення через": "aracılığıyla güncelleme",
    "с": "sn",
    "повтор спроби підключення…": "bağlantıyı yeniden dene…",
    "Видалити без фіксації ·": "Düzeltmeden sil ·",
    "Виправлення випадково введеної позиції": "Yanlışlıkla girilen konumun düzeltilmesi",
    "Позицію буде видалено назавжди. Прибуток або збиток не потрапить у місячну статистику.": "Pozisyon kalıcı olarak silinecek. Aylık istatistiklere kar veya zarar dahil edilmeyecektir.",
    "Видалити без фіксації": "Kaydetmeden sil",
    "Позицію видалено без запису в статистику": "Pozisyon istatistiklere kaydedilmeden silindi",
    "Незворотна дія": "Geri dönüşü olmayan eylem",
    "Усі активні позиції та закриті угоди буде видалено. Ціни, новини й налаштування теми залишаться.": "Tüm aktif pozisyonlar ve kapatılan işlemler silinecektir. Fiyatlandırma, haberler ve tema ayarları aynı kalacak.",
    "Так, очистити всі угоди": "Evet, tüm anlaşmaları temizle",
    "Систему скинуто": "Sistem sıfırlama",
    "Аналітика монети": "Madeni para analitiği",
    "MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC.": "MATIC → POL: Eski MATIC tokeninin fiyatı değil, mevcut POL/USDT çifti gösterilir.",
    "Максимум вікна": "Maksimum pencere",
    "Мінімум вікна": "Minimum pencere",
    "Зміна у вікні": "Pencerede değişiklik",
    "Волатильність дохідностей": "Getirilerin oynaklığı",
    "Історія ціни · до 60 точок": "Fiyat geçmişi · 60 puana kadar",
    "Хвилинні точки; поточна точка оновлюється кожні 10 секунд. Демо-ціни позначаються окремо.": "Dakika puanları; geçerli nokta her 10 saniyede bir güncellenir. Demo fiyatları ayrı olarak belirtilmektedir.",
    "Ще недостатньо спостережень для графіка.": "Henüz grafik oluşturmak için yeterli gözlem yok.",
    "Таблиця спостережень": "Gözlem tablosu",
    "Ціна": "Fiyat",
    "Волатильність — стандартне відхилення відсоткових змін між точками цього вікна, не максимум за добу.": "Volatilite, bu pencerenin noktaları arasındaki yüzdesel değişimin standart sapmasıdır, günlük maksimum değil.",
    "КУПИТИ за вигідною ціною": "İyi bir fiyata SATIN ALIN",
    "НЕ КУПУВАТИ / ПРОДАТИ": "ALMAYIN / SATMAYIN",
    "Утримуватись, ринок спокійний": "Durun piyasa sakin",
    "⚠️ Високий ризик падіння ринку через негативні світові новини!": "⚠️ Olumsuz dünya haberleri nedeniyle piyasanın düşme riski yüksek!",
    "Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)": "Zarar Durdurma işe yaradı: {symbol} ${price:,.4f} seviyesinden kapandı ({pct:+.2f}%, {pnl:+,.2f}$)",
    "Невідома монета. Доступні: {coins}": "Bilinmeyen para. Mevcut: {coins}",
    "Кількість і ціна мають бути додатними числами": "Miktar ve fiyat pozitif sayılar olmalıdır",
    "Позицію не знайдено": "Pozisyon bulunamadı",
    "Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})": "Ortalama alma yalnızca mevcut ortalamadan daha düşük bir fiyatla mümkündür (${avg:,.4f})",
    "Stop-Loss — це відсоток від 0.1 до 99": "Zararı Durdur 0,1'den 99'a kadar bir yüzdedir",
    "Ціни ще не завантажені, спробуйте за кілька секунд": "Fiyatlar henüz yüklenmedi, birkaç saniye sonra deneyin",
    "Формат місяця: РРРР-ММ": "Ay biçimi: YYYY-AA",
    "Для повного скидання надішліть {\"confirm\": true}": "Donanımdan sıfırlama için {\"confirm\": true} gönderin",
    "Повідомлення порожнє": "Mesaj boş",
    "Повідомлення задовге (максимум {n} символів)": "Mesaj çok uzun (maksimum {n} karakter)",
    "висхідний": "artan",
    "низхідний": "alçalan",
    "боковий": "yanal",
    "{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал системи: {reco}.": "{symbol}: fiyat ${price}, saat başına {change:+.2f}%. 60 dakikalık trend: {trend}, dalgalanma {vol:.2f}%. Sistem sinyali: {reco}.",
    "Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.": "Portföy: maliyet ${value:,.2f}, sonuç {pnl:+,.2f}$ (%{pct:+.2f}), açık pozisyonlar: {count}.",
    "Портфель порожній. Додайте першу віртуальну покупку на картці монети.": "Evrak çantası boş. İlk sanal satın alımınızı jeton kartına ekleyin.",
    "Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.": "Haberin arka planı olumsuz ({index:+.2f} endeksi): Piyasanın düşme riski artıyor.",
    "Новинний фон без критичного ризику (індекс {index:+.2f}).": "Kritik risk içermeyen haber geçmişi (indeks {index:+.2f}).",
    "Огляд ринку за годину: {items}.": "Saatlik piyasaya genel bakış: {items}.",
    "Привіт! Я навчальний ШІ-помічник. Запитайте про монету, портфель, новини, Stop-Loss чи усереднення.": "Selamlar! Ben eğitici bir yapay zeka asistanıyım. Coin, Portföy, Haberler, Zarar Durdurma veya Ortalama Alma hakkında bilgi alın.",
    "Я поки що працюю за простими правилами (заглушка). Спробуйте: «ціна BTC», «мій портфель», «що з новинами», «що таке Stop-Loss».": "Şimdilik basit kurallara (fiş) göre çalışıyorum. Deneyin: \"BTC fiyatı\", \"portföyüm\", \"yenilikler\", \"Zarar Durdurma nedir\".",
    "Це навчальна демонстрація, а не фінансова порада.": "Bu eğitici bir gösteri, mali tavsiye değil.",
    "Прибуток і збиток (P&L)": "Kâr ve Zarar (K&Z)",
    "P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. Поки ви не продали, результат лише на папері.": "K&Z, coinin mevcut değeri ile satın aldığınız tutar arasındaki farktır. Artı kar, eksi ise zarar anlamına gelir. Satış yapana kadar sonuç sadece kağıt üzerindedir.",
    "Зміна ціни за годину": "Saatlik fiyat değişimi",
    "Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує червоним, різке зростання (від +5%) — зеленим.": "Fiyatın son bir saatte ne kadar değiştiğini gösterir. Sistem tarafından keskin bir düşüş (-%5'ten) kırmızıyla, keskin bir artış (+%5'ten) yeşille vurgulanır.",
    "Усереднення": "Ortalama",
    "Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.": "Aynı madalyonun daha düşük bir fiyata ek olarak satın alınması. Ortalama satın alma fiyatı düşüyor, dolayısıyla başabaş için daha az büyümeye ihtiyaç var. Risk: Düşmeye devam eden bir varlığa daha fazla yatırım yaparsınız.",
    "Заздалегідь заданий відсоток збитку, при досягненні якого угода закривається автоматично. Це запобіжник: ви обмежуєте втрати, навіть якщо не стежите за ринком.": "Anlaşmanın otomatik olarak kapatıldığı, önceden belirlenmiş bir kayıp yüzdesi. Bu bir riskten korunmadır: piyasayı takip etmeseniz bile kayıplarınızı sınırlandırıyorsunuz.",
    "Настрій новин": "Haberin ruh hali",
    "Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи негативний. Це спрощений аналіз, а не прогноз.": "Sistem, küresel kripto haber başlıklarını okuyor ve anahtar kelimelere göre arka planın olumlu, nötr veya olumsuz olup olmadığını değerlendiriyor. Bu basitleştirilmiş bir analizdir, bir tahmin değildir.",
    "Віртуальна торгівля": "Sanal ticaret",
    "Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на портфель, і не ризикувати власними коштами.": "Buradaki tüm satın alımlar koşulludur: gerçek para tahsil edilmez. Bu, fiyat hareketlerinin portföyü nasıl etkilediğini öğrenmenin ve kendi fonlarınızı riske atmanın güvenli bir yoludur.",
    "Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.": "Ben bir referans asistanıyım: Üretken bir dil modeli olmadan, kurallara göre terimleri açıklıyor ve güncel verileri gösteriyorum. Aşağıdan bir konu seçin veya BTC, portföy veya haberler hakkında soru sorun.",
    "Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не генеративною моделлю.": "Selamlar! Başlangıç ​​okulunun şartlarını açıklayıp piyasa verilerini gösteriyorum. Yanıtlar üretken bir modelle değil, kurallarla oluşturulur.",
    "Готую відповідь…": "Bir cevap hazırlıyorum...",
    "У цьому симуляторі Stop-Loss перевіряється фоновим процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.": "Bu simülatörde, Stop-Loss, arka plan işlemi tarafından her 10 saniyede bir alınan fiyat üzerinden kontrol edilir; kesin bir seviyede performans garanti edilmez.",
    "Зміна ціни за останню годину": "Son saatte fiyat değişimi",
    "Ціна за останні хвилини": "Son dakika fiyatı",
    "Додати віртуальну покупку": "Sanal satın alma ekle",
    "＋ До блокнота": "＋ Not defterine",
    "Докупити за нижчою ціною та перерахувати середню": "Daha düşük fiyata daha fazlasını satın alın ve ortalamayı yeniden hesaplayın",
    "⚖ Усереднити": "⚖ Ortalama",
    "Автоматично закрити угоду при заданому відсотку збитку": "Belirli bir kayıp yüzdesinde anlaşmayı otomatik olarak kapat",
    "Віртуально продати за поточною ціною": "Hemen hemen mevcut fiyattan satış yapın"
  }
}

SCHOOL = [{'id': 'long',
  'core': True,
  'term': {'ua': 'Лонг (Long)',
           'en': 'Long',
           'ru': 'Лонг (Long)',
           'es': 'Largo (Long)',
           'hi': 'लॉन्ग (Long)',
           'vi': 'Mua lên (Long)',
           'de': 'Long',
           'pl': 'Long',
           'zh': '做多 (Long)',
           'ja': 'ロング (Long)',
           'ko': '롱 (Long)',
           'pt': 'Long',
           'tr': 'Uzun (Long)'},
  'text': {'ua': 'Позиція з очікуванням зростання: P&L = (поточна ціна − ціна входу) × кількість. Купили 2 монети по 100 USDT, '
                 'ціна стала 110 — результат +20; падіння до 90 дає −20. Це як купити товар для подальшого продажу дорожче: '
                 'очікування не гарантує попиту. У цьому тренажері немає кредитного плеча.',
           'en': 'A long benefits from rising prices: P&L = (current − entry) × quantity. Two coins bought at 100 and valued at '
                 '110 gain 20 USDT; at 90 they lose 20. Like buying inventory to resell, demand is uncertain. No leverage is '
                 'modeled.',
           'ru': 'Позиция на рост: P&L = (текущая цена − вход) × количество. Две монеты по 100 при цене 110 дают +20 USDT, при '
                 '90 — −20. Как товар для перепродажи, актив может не найти спроса. Плечо здесь не моделируется.',
           'es': 'Gana con subidas: P&L = (precio actual − entrada) × cantidad. Dos monedas de 100 a 110 ganan 20 USDT; a 90 '
                 'pierden 20. Como comprar mercancía para revender, la demanda es incierta. Sin apalancamiento aquí.',
           'hi': 'बढ़ती कीमत से लाभ: P&L = (वर्तमान − प्रवेश) × मात्रा। 100 पर खरीदे दो कॉइन 110 पर 20 USDT लाभ और 90 पर 20 हानि '
                 'देते हैं। पुनर्विक्रय के सामान की तरह माँग निश्चित नहीं। यहाँ लीवरेज नहीं।',
           'vi': 'Có lợi khi giá tăng: P&L = (giá hiện tại − giá vào) × số lượng. Hai coin mua 100, lên 110 lãi 20 USDT; xuống '
                 '90 lỗ 20. Như mua hàng bán lại, nhu cầu không chắc chắn. Không mô phỏng đòn bẩy.',
           'de': 'Profitiert von steigenden Preisen: P&L = (aktuell − Einstieg) × Menge. Zwei Coins von 100 auf 110 bringen 20 '
                 'USDT, auf 90 verlieren sie 20. Wie Waren zum Weiterverkauf: Nachfrage ist unsicher. Kein Hebel wird '
                 'modelliert.',
           'pl': 'Zarabia na wzroście: P&L = (cena obecna − wejście) × ilość. Dwie monety kupione po 100 przy 110 dają +20 USDT, '
                 'przy 90 −20. Jak towar do odsprzedaży, popyt nie jest pewny. Bez modelowania dźwigni.',
           'zh': '价格上涨时获利：盈亏=(现价−入场价)×数量。以100买两枚币，涨至110赚20 USDT，跌至90亏20。像购入商品准备转卖，需求并不确定。此处不模拟杠杆。',
           'ja': '値上がりで利益：損益=(現在値−取得価格)×数量。100で2枚買い110なら+20 USDT、90なら−20。転売用の商品と同様、需要は不確実です。レバレッジは計算しません。',
           'ko': '가격 상승에 유리합니다. 손익=(현재가−진입가)×수량. 100에 두 개를 사서 110이면 +20 USDT, 90이면 −20입니다. 되팔 상품처럼 수요는 불확실합니다. 레버리지는 계산하지 않습니다.',
           'pt': 'Ganha com alta: P&L = (atual − entrada) × quantidade. Duas moedas de 100 a 110 ganham 20 USDT; a 90 perdem 20. '
                 'Como mercadoria para revender, a demanda é incerta. Sem alavancagem modelada.',
           'tr': "Yükselişten yararlanır: P&L = (güncel − giriş) × miktar. 100'den alınan iki coin 110'da 20 USDT kazandırır, "
                 "90'da 20 kaybettirir. Yeniden satılacak mal gibi talep belirsizdir. Kaldıraç modellenmez."}},
 {'id': 'short',
  'core': True,
  'term': {'ua': 'Шорт (Short)',
           'en': 'Short',
           'ru': 'Шорт (Short)',
           'es': 'Corto (Short)',
           'hi': 'शॉर्ट (Short)',
           'vi': 'Bán khống (Short)',
           'de': 'Short',
           'pl': 'Short',
           'zh': '做空 (Short)',
           'ja': 'ショート (Short)',
           'ko': '숏 (Short)',
           'pt': 'Short',
           'tr': 'Kısa (Short)'},
  'text': {'ua': 'Позиція виграє від падіння: P&L = (ціна входу − поточна ціна) × кількість. Продали умовну монету по 100, '
                 'викупили по 90 — +10 USDT; зростання до 120 означає −20. На реальному ринку потрібні позика або похідний '
                 'інструмент, можливі комісії та ліквідація. Збиток від зростання ціни теоретично необмежений; тут це лише '
                 'облікова симуляція.',
           'en': 'A short benefits from falling prices: P&L = (entry − current) × quantity. One coin sold at 100 and covered at '
                 '90 gains 10; a rise to 120 loses 20. Real shorts involve borrowing or derivatives, fees and potentially '
                 'liquidation. Rising-price losses can be unlimited; this is a simulation.',
           'ru': 'Позиция на падение: P&L = (вход − текущая цена) × количество. Вход 100, выход 90 дают +10 на монету; выход 120 '
                 'даёт −20. Реально нужны заём или деривативы, возможны комиссии и ликвидация. Убыток от роста теоретически не '
                 'ограничен; здесь симуляция.',
           'es': 'Gana con bajadas: P&L = (entrada − precio actual) × cantidad. De 100 a 90 gana 10 por moneda; a 120 pierde 20. '
                 'En realidad exige préstamo o derivados y puede haber liquidación. Las pérdidas por subidas no tienen límite '
                 'teórico; aquí es simulado.',
           'hi': 'गिरती कीमत से लाभ: P&L = (प्रवेश − वर्तमान) × मात्रा। 100 से 90 पर प्रति कॉइन 10 लाभ; 120 पर 20 हानि। वास्तविक '
                 'शॉर्ट में उधार या डेरिवेटिव और परिसमापन जोखिम होते हैं। बढ़ती कीमत से हानि असीमित हो सकती है; यहाँ सिमुलेशन '
                 'है।',
           'vi': 'Có lợi khi giá giảm: P&L = (giá vào − hiện tại) × số lượng. Từ 100 xuống 90 lãi 10; lên 120 lỗ 20. Thực tế cần '
                 'vay hoặc phái sinh, có nguy cơ thanh lý. Lỗ khi giá tăng có thể vô hạn; đây là mô phỏng.',
           'de': 'Profitiert von fallenden Preisen: P&L = (Einstieg − aktuell) × Menge. Von 100 auf 90 gewinnt ein Coin 10, auf '
                 '120 verliert er 20. Reale Shorts benötigen Leihe oder Derivate und können liquidiert werden. Verluste bei '
                 'steigenden Kursen sind theoretisch unbegrenzt; hier Simulation.',
           'pl': 'Zarabia na spadku: P&L = (wejście − obecna cena) × ilość. Ze 100 do 90 zysk 10 na monetę, do 120 strata 20. W '
                 'praktyce wymaga pożyczki lub instrumentów pochodnych i grozi likwidacją. Strata przy wzroście teoretycznie '
                 'nieograniczona; tu symulacja.',
           'zh': '价格下跌时获利：盈亏=(入场价−现价)×数量。100入场、90退出每枚赚10；涨至120亏20。现实需要借币或衍生品，存在费用与强平。上涨导致的损失理论上无限；此处仅为模拟。',
           'ja': '値下がりで利益：損益=(取得価格−現在値)×数量。100から90なら1枚あたり+10、120なら−20。実際は借入やデリバティブと清算リスクがあります。値上がりによる損失は理論上無限です。ここでは模擬取引です。',
           'ko': '하락에 유리합니다. 손익=(진입가−현재가)×수량. 100에서 90이면 개당 +10, 120이면 −20입니다. 실제로는 차입 또는 파생상품과 청산 위험이 있습니다. 상승 손실은 이론적으로 무한하며 '
                 '여기서는 모의 계산입니다.',
           'pt': 'Ganha com queda: P&L = (entrada − atual) × quantidade. De 100 a 90 ganha 10 por moeda; a 120 perde 20. Na '
                 'prática envolve empréstimo ou derivativos e risco de liquidação. Perdas por altas podem ser ilimitadas; aqui é '
                 'simulação.',
           'tr': "Düşüşten yararlanır: P&L = (giriş − güncel) × miktar. 100'den 90'a coin başına +10, 120'ye −20. Gerçekte borç "
                 'veya türev ve tasfiye riski vardır. Yükselişte zarar teorik olarak sınırsızdır; burada simülasyondur.'}},
 {'id': 'volatility',
  'core': True,
  'term': {'ua': 'Волатильність',
           'en': 'Volatility',
           'ru': 'Волатильность',
           'es': 'Volatilidad',
           'hi': 'अस्थिरता',
           'vi': 'Biến động',
           'de': 'Volatilität',
           'pl': 'Zmienność',
           'zh': '波动性',
           'ja': 'ボラティリティ',
           'ko': '변동성',
           'pt': 'Volatilidade',
           'tr': 'Oynaklık'},
  'text': {'ua': 'Мінливість ціни не є напрямом руху чи обіцянкою прибутку. Якщо добовий мінімум 90, а максимум 110, діапазон '
                 'відносно мінімуму дорівнює (110−90)/90×100 = 22,22%. Це як перепади температури: велика амплітуда не каже, що '
                 'завтра буде тепліше. Діапазон — не статистична волатильність і не максимальний збиток від піку; для них '
                 'потрібні інші розрахунки.',
           'en': 'Volatility describes variability, not direction. With a daily low of 90 and high of 110, low-relative range is '
                 '(110−90)/90×100 = 22.22%. Like temperature swings, amplitude does not predict tomorrow. This range is neither '
                 'statistical volatility nor maximum drawdown.',
           'ru': 'Изменчивость, а не направление цены. При минимуме 90 и максимуме 110 диапазон относительно минимума равен '
                 '22,22%. Как перепады температуры, амплитуда не предсказывает завтра. Это не статистическая волатильность и не '
                 'максимальная просадка.',
           'es': 'Es variabilidad, no dirección. Con mínimo 90 y máximo 110, el rango relativo al mínimo es 22,22%. Como cambios '
                 'de temperatura, no predice mañana. No equivale a volatilidad estadística ni caída máxima desde un pico.',
           'hi': 'यह कीमत की परिवर्तनशीलता है, दिशा नहीं। न्यूनतम 90 और अधिकतम 110 का न्यूनतम-सापेक्ष दायरा 22.22% है। तापमान के '
                 'उतार-चढ़ाव की तरह यह कल नहीं बताता। यह सांख्यिकीय अस्थिरता या अधिकतम गिरावट नहीं है।',
           'vi': 'Độ thay đổi giá, không phải hướng. Thấp 90, cao 110 cho biên độ theo mức thấp 22,22%. Như nhiệt độ dao động, '
                 'không dự báo ngày mai. Đây không phải biến động thống kê hay mức sụt giảm tối đa từ đỉnh.',
           'de': 'Schwankung, nicht Richtung. Tief 90 und Hoch 110 ergeben eine Spanne von 22,22% relativ zum Tief. Wie '
                 'Temperaturschwankungen sagt das nichts über morgen. Keine statistische Volatilität und kein maximaler Rückgang '
                 'vom Höchststand.',
           'pl': 'To wahania, nie kierunek. Minimum 90 i maksimum 110 dają zakres 22,22% względem minimum. Jak zmiany '
                 'temperatury nie przewiduje jutra. Nie jest to zmienność statystyczna ani maksymalne obsunięcie od szczytu.',
           'zh': '描述价格变化程度，而非方向。最低90、最高110，相对低点区间为22.22%。像气温变化，幅度不能预测明天。这不是统计波动率，也不是从峰值计算的最大回撤。',
           'ja': '方向ではなく価格の変動性です。安値90、高値110なら安値比の値幅は22.22%。気温の変動のように明日を予測しません。統計的変動率や最大ドローダウンとは異なります。',
           'ko': '방향이 아닌 가격의 변화 정도입니다. 저가 90, 고가 110이면 저가 대비 범위는 22.22%입니다. 기온 변동처럼 내일을 예측하지 못합니다. 통계적 변동성이나 고점 대비 최대 낙폭과 다릅니다.',
           'pt': 'É variabilidade, não direção. Mínima 90 e máxima 110 dão faixa de 22,22% da mínima. Como oscilações de '
                 'temperatura, não prevê amanhã. Não é volatilidade estatística nem queda máxima desde o pico.',
           'tr': "Yön değil değişkenliktir. Dip 90 ve tepe 110 ise dibe göre aralık %22,22'dir. Sıcaklık dalgalanması gibi "
                 'yarını öngörmez. İstatistiksel oynaklık veya tepeden maksimum düşüş değildir.'}},
 {'id': 'dca',
  'core': True,
  'term': {'ua': 'Усереднення (DCA)',
           'en': 'Dollar-cost averaging (DCA)',
           'ru': 'Усреднение (DCA)',
           'es': 'DCA',
           'hi': 'DCA',
           'vi': 'DCA',
           'de': 'DCA',
           'pl': 'DCA',
           'zh': '定投 (DCA)',
           'ja': '積立 (DCA)',
           'ko': '분할 매수 (DCA)',
           'pt': 'DCA',
           'tr': 'DCA'},
  'text': {'ua': 'Регулярне придбання на однакову грошову суму, а не однакової кількості монет. Витратили 100 USDT за ціни 10 і '
                 'ще 100 за ціни 5: отримали 10 + 20 = 30 монет, середня ціна 200/30 = 6,67, а не 7,50. Як щомісячне поповнення '
                 'запасів, стратегія розподіляє момент входу, але не рятує актив, який назавжди втрачає цінність.',
           'en': 'Invest equal amounts regularly, not equal coin quantities. Spending 100 at price 10 and 100 at price 5 buys 30 '
                 'coins; average cost is 200/30 = 6.67, not 7.50. Like regular household purchases, it spreads entry timing but '
                 'cannot rescue a permanently failing asset.',
           'ru': 'Регулярная покупка на одинаковую сумму. По 100 USDT при ценах 10 и 5 покупают 30 монет; средняя цена 200/30 = '
                 '6,67, не 7,50. Как регулярные закупки, это распределяет момент входа, но не спасает обесценивающийся актив.',
           'es': 'Comprar regularmente con igual dinero. Invertir 100 a precio 10 y 100 a precio 5 compra 30 monedas; coste '
                 'medio 200/30 = 6,67, no 7,50. Como compras periódicas, distribuye el momento de entrada, pero no salva un '
                 'activo fallido.',
           'hi': 'नियमित रूप से समान धन निवेश करें। कीमत 10 पर 100 और कीमत 5 पर 100 लगाने से 30 कॉइन मिलते हैं; औसत 200/30 = '
                 '6.67, न कि 7.50। नियमित घरेलू खरीद जैसा समय-वितरण है; खराब संपत्ति को नहीं बचाता।',
           'vi': 'Mua định kỳ với cùng số tiền. Chi 100 ở giá 10 và 100 ở giá 5 được 30 coin; giá vốn 200/30 = 6,67, không phải '
                 '7,50. Như mua nhu yếu phẩm định kỳ, phân bổ thời điểm nhưng không cứu tài sản thất bại.',
           'de': 'Regelmäßig gleiche Geldbeträge investieren. Je 100 bei Preisen 10 und 5 kaufen 30 Coins; Durchschnittskosten '
                 '200/30 = 6,67, nicht 7,50. Wie regelmäßige Haushaltseinkäufe verteilt es den Einstiegszeitpunkt, rettet aber '
                 'keinen dauerhaft wertlosen Vermögenswert.',
           'pl': 'Regularny zakup za tę samą kwotę. Po 100 przy cenach 10 i 5 daje 30 monet; średnia cena 200/30 = 6,67, nie '
                 '7,50. Jak okresowe zakupy domowe rozkłada moment wejścia, lecz nie ratuje tracącego wartość aktywa.',
           'zh': '定期投入相同金额而非相同币数。价格10和5时各投100，共得30枚，平均成本200/30=6.67，而非7.50。像定期采购，分散入场时点，但无法挽救永久失去价值的资产。',
           'ja': '同じ枚数でなく同じ金額を定期購入します。価格10と5で各100使うと合計30枚、平均200/30=6.67で7.50ではありません。定期的な買い物と同様に時期を分散しますが、価値を失う資産を救えません。',
           'ko': '같은 수량이 아닌 같은 금액을 정기 투자합니다. 가격 10과 5에서 각각 100을 쓰면 30개, 평균 200/30=6.67이며 7.50이 아닙니다. 정기 장보기처럼 시점을 나누지만 영구적 가치 '
                 '하락을 해결하지는 못합니다.',
           'pt': 'Comprar regularmente com a mesma quantia. Aplicar 100 a preço 10 e 100 a preço 5 compra 30 moedas; custo médio '
                 '200/30 = 6,67, não 7,50. Como compras periódicas, distribui a entrada, mas não salva um ativo falido.',
           'tr': 'Düzenli olarak aynı tutarla alım yapmaktır. Fiyat 10 ve 5 iken ayrı ayrı 100 harcamak 30 coin alır; ortalama '
                 'maliyet 200/30 = 6,67, 7,50 değil. Düzenli alışveriş gibi zamanı dağıtır ama başarısız varlığı kurtarmaz.'}},
 {'id': 'fomo',
  'core': True,
  'term': {'ua': 'FOMO',
           'en': 'FOMO',
           'ru': 'FOMO',
           'es': 'FOMO',
           'hi': 'FOMO',
           'vi': 'FOMO',
           'de': 'FOMO',
           'pl': 'FOMO',
           'zh': 'FOMO',
           'ja': 'FOMO',
           'ko': 'FOMO',
           'pt': 'FOMO',
           'tr': 'FOMO'},
  'text': {'ua': 'Страх втраченої вигоди штовхає купувати через чужий успіх і поспіх. Після зростання зі 100 до 150 людина '
                 'купує, а падіння до 100 дає −33,33%, не −50%. Це схоже на купівлю модної речі лише через чергу. Перевіряйте '
                 'власний план, бюджет ризику та джерела; популярність не замінює аналіз.',
           'en': 'Fear of missing out encourages rushed purchases after others profit. Buying at 150 after a rise from 100 and '
                 'then falling back to 100 loses 33.33%, not 50%. Like joining a shopping queue because others do, excitement is '
                 'not analysis. Check your plan and risk budget.',
           'ru': 'Страх упустить выгоду вызывает поспешные покупки. Купив по 150 после роста со 100 и увидев возврат к 100, '
                 'теряют 33,33%, не 50%. Как покупка из-за очереди, ажиотаж не заменяет анализ и бюджет риска.',
           'es': 'El miedo a perder una oportunidad provoca compras apresuradas. Comprar a 150 y volver a 100 pierde 33,33%, no '
                 '50%. Como entrar en una fila por imitación, el entusiasmo no sustituye un plan ni un presupuesto de riesgo.',
           'hi': 'अवसर छूटने का डर जल्दबाज़ी कराता है। 150 पर खरीदकर 100 तक गिरने पर 33.33% हानि होती है, 50% नहीं। भीड़ देखकर '
                 'दुकान में जाने जैसा उत्साह विश्लेषण नहीं। अपनी योजना और जोखिम सीमा जाँचें।',
           'vi': 'Sợ bỏ lỡ làm mua vội. Mua 150 rồi giảm về 100 mất 33,33%, không phải 50%. Như xếp hàng chỉ vì người khác, hưng '
                 'phấn không thay phân tích. Kiểm tra kế hoạch và giới hạn rủi ro.',
           'de': 'Angst, etwas zu verpassen, verleitet zu Eile. Kauf bei 150 und Rückgang auf 100 verlieren 33,33%, nicht 50%. '
                 'Wie Anstehen wegen einer Menschenmenge ersetzt Begeisterung keine Analyse. Plan und Risikobudget prüfen.',
           'pl': 'Strach przed pominięciem okazji skłania do pośpiechu. Zakup po 150 i spadek do 100 oznacza −33,33%, nie −50%. '
                 'Jak kolejka z naśladownictwa, emocje nie zastępują analizy. Sprawdź plan i budżet ryzyka.',
           'zh': '害怕错过机会会促成冲动购买。价格从100涨至150后买入，再跌至100会亏33.33%，不是50%。像因为排队人多而购物，热情不能代替分析。先核对计划与风险预算。',
           'ja': '取り残される恐怖は衝動買いを招きます。100から150への上昇後に買い100へ戻ると33.33%損失で50%ではありません。行列につられる買い物同様、熱気は分析ではありません。計画とリスク予算を確認しましょう。',
           'ko': '기회를 놓칠 두려움은 충동 매수를 부릅니다. 100에서 150 상승 후 사서 100으로 떨어지면 손실은 33.33%이지 50%가 아닙니다. 줄이 길어 따라 사는 것처럼 열기는 분석을 대신하지 '
                 '못합니다. 계획과 위험 예산을 확인하세요.',
           'pt': 'Medo de perder oportunidades provoca pressa. Comprar a 150 após alta de 100 e voltar a 100 perde 33,33%, não '
                 '50%. Como entrar numa fila por imitação, entusiasmo não substitui análise. Confira plano e limite de risco.',
           'tr': "Fırsatı kaçırma korkusu acele alıma yol açar. 100'den 150'ye yükselişten sonra alıp 100'e dönmek %33,33 kayıp "
                 'verir, %50 değil. Kalabalık yüzünden sıraya girmek gibi heyecan analizin yerini tutmaz. Plan ve risk bütçesini '
                 'kontrol edin.'}},
 {'id': 'hodl',
  'core': True,
  'term': {'ua': 'HODL',
           'en': 'HODL',
           'ru': 'HODL',
           'es': 'HODL',
           'hi': 'HODL',
           'vi': 'HODL',
           'de': 'HODL',
           'pl': 'HODL',
           'zh': 'HODL',
           'ja': 'HODL',
           'ko': 'HODL',
           'pt': 'HODL',
           'tr': 'HODL'},
  'text': {'ua': 'Тривале утримання активу попри короткі коливання. Купівля по 100, падіння до 40 і повернення до 100 означають '
                 'спочатку −60%, потім +150% від дна, але нульовий результат від входу до комісій. Це як довго зберігати '
                 'колекційну річ: відновлення вартості не гарантоване. Утримання не скасовує перевірки фундаментальних ризиків.',
           'en': 'Holding through fluctuations is not a recovery guarantee. A purchase at 100 falling to 40 loses 60%; rising '
                 'from 40 back to 100 requires 150%, leaving zero entry-to-exit profit before costs. Like storing a collectible, '
                 'reassess whether its underlying value still exists.',
           'ru': 'Длительное удержание не гарантирует восстановление. Покупка по 100 и падение до 40 дают −60%; возврат к 100 '
                 'требует +150% от дна и даёт нулевой итог до затрат. Как хранение коллекционной вещи, требует проверки её '
                 'реальной ценности.',
           'es': 'Mantener no garantiza recuperación. Comprar a 100 y caer a 40 pierde 60%; volver a 100 exige subir 150% desde '
                 'el mínimo y deja beneficio cero antes de costes. Como guardar un objeto de colección, exige revisar su valor.',
           'hi': 'लंबे समय तक रखना वापसी की गारंटी नहीं। 100 से 40 पर 60% हानि; 40 से 100 के लिए 150% बढ़त चाहिए और लागत से पहले '
                 'कुल लाभ शून्य है। संग्रहणीय वस्तु की तरह मूल मूल्य की जाँच आवश्यक है।',
           'vi': 'Nắm giữ dài hạn không bảo đảm hồi phục. Giá 100 xuống 40 mất 60%; từ 40 lên 100 cần tăng 150%, tổng lãi trước '
                 'phí bằng không. Như giữ đồ sưu tầm, phải đánh giá lại giá trị thật.',
           'de': 'Langes Halten garantiert keine Erholung. Von 100 auf 40 sind −60%; von 40 zurück auf 100 braucht +150% und '
                 'ergibt vor Kosten null Gewinn. Wie bei Sammlerstücken muss der zugrunde liegende Wert weiter geprüft werden.',
           'pl': 'Długie trzymanie nie gwarantuje odbicia. Ze 100 do 40 strata 60%; z 40 do 100 potrzeba wzrostu 150%, a zysk od '
                 'wejścia przed kosztami wynosi zero. Jak przedmiot kolekcjonerski wymaga ponownej oceny wartości.',
           'zh': '长期持有不保证价格恢复。100跌至40亏60%；40回到100需涨150%，入场至退出的费用前利润仍为零。像保存收藏品，应持续审视其真实价值。',
           'ja': '長期保有は回復を保証しません。100から40で60%下落、40から100には150%上昇が必要で、当初からの利益は費用前でゼロです。収集品の保管と同様、根本的な価値を再評価します。',
           'ko': '장기 보유는 회복을 보장하지 않습니다. 100에서 40이면 −60%, 40에서 100은 +150%가 필요하며 진입 대비 비용 전 수익은 0입니다. 수집품 보관처럼 기초 가치를 다시 평가해야 합니다.',
           'pt': 'Manter por muito tempo não garante recuperação. De 100 a 40 perde 60%; de 40 a 100 exige alta de 150%, com '
                 'lucro total zero antes de custos. Como guardar uma peça de coleção, exige reavaliar o valor real.',
           'tr': "Uzun tutmak toparlanma garantisi değildir. 100'den 40'a %60 kayıp; 40'tan 100'e %150 yükseliş gerekir ve "
                 'masraflardan önce toplam kâr sıfırdır. Koleksiyon eşyası gibi gerçek değeri yeniden değerlendirilmelidir.'}},
 {'id': 'stoploss',
  'core': True,
  'term': {'ua': 'Stop-Loss',
           'en': 'Stop-Loss',
           'ru': 'Stop-Loss',
           'es': 'Stop-Loss',
           'hi': 'Stop-Loss',
           'vi': 'Stop-Loss',
           'de': 'Stop-Loss',
           'pl': 'Stop-Loss',
           'zh': '止损 (Stop-Loss)',
           'ja': 'ストップロス',
           'ko': '손절 (Stop-Loss)',
           'pt': 'Stop-Loss',
           'tr': 'Stop-Loss'},
  'text': {'ua': 'Умова обмеження збитку: для лонгу з входом 100 рівень 95 задає план виходу поблизу −5% до витрат. Ринковий '
                 'стоп після спрацювання може виконатися по 93 через ціновий розрив; стоп-ліміт може не виконатися взагалі. Як '
                 'аварійне гальмо, це інструмент контролю, а не гарантія. У цьому симуляторі Stop-Loss перевіряється фоновим '
                 'процесом кожні 10 секунд за отриманою ціною; виконання на точному рівні не гарантується.',
           'en': 'For a long entered at 100, a stop at 95 plans about a 5% loss before costs. A gap can fill a market stop at '
                 '93; a stop-limit may never fill. Like an emergency brake, it controls risk but cannot guarantee an exit price. '
                 'In this simulator, the Stop-Loss is checked by the background process every 10 seconds at the received price; '
                 'performance at an exact level is not guaranteed.',
           'ru': 'При лонге от 100 стоп 95 планирует около −5% до затрат. Из-за разрыва рыночный стоп может исполниться по 93; '
                 'стоп-лимит может не исполниться. Как аварийный тормоз, это не гарантия цены. В этом симуляторе Stop-Loss '
                 'проверяется фоновым процессом каждые 10 секунд по полученной цене; исполнение на точном уровне не '
                 'гарантируется.',
           'es': 'Entrada larga 100 y stop 95 buscan limitar la pérdida al 5% antes de costes. Un salto puede ejecutar un stop '
                 'de mercado a 93; un stop-limit puede no ejecutarse. Como un freno de emergencia, no garantiza precio. En este '
                 'simulador, el proceso en segundo plano verifica el Stop-Loss cada 10 segundos al precio recibido; No se '
                 'garantiza un rendimiento a un nivel exacto.',
           'hi': ' इस सिम्युलेटर में, प्राप्त मूल्य पर हर 10 सेकंड में पृष्ठभूमि प्रक्रिया द्वारा स्टॉप-लॉस की जाँच की जाती है; '
                 'सटीक स्तर पर प्रदर्शन की गारंटी नहीं है.',
           'vi': 'Long từ 100, dừng 95 dự kiến lỗ 5% trước phí. Khoảng trống giá có thể khớp lệnh thị trường ở 93; stop-limit có '
                 'thể không khớp. Như phanh khẩn cấp, không bảo đảm giá. Trong trình mô phỏng này, lệnh Cắt lỗ được kiểm tra '
                 'bằng quy trình nền cứ sau 10 giây ở mức giá nhận được; hiệu suất ở mức chính xác không được đảm bảo.',
           'de': 'Long-Einstieg 100 und Stop 95 planen etwa 5% Verlust vor Kosten. Eine Kurslücke kann einen Marktstop bei 93 '
                 'ausführen; ein Stop-Limit bleibt eventuell ungefüllt. Wie eine Notbremse, ohne Preisgarantie. In diesem '
                 'Simulator wird der Stop-Loss durch den Hintergrundprozess alle 10 Sekunden zum erhaltenen Preis überprüft; Die '
                 'Leistung auf einem exakten Niveau kann nicht garantiert werden.',
           'pl': 'Long od 100 ze stopem 95 planuje około 5% straty przed kosztami. Luka może wykonać zlecenie rynkowe po 93; '
                 'stop-limit może nie zostać wykonany. Jak hamulec awaryjny nie gwarantuje ceny. W tym symulatorze Stop-Loss '
                 'jest sprawdzany przez proces w tle co 10 sekund po otrzymanej cenie; wydajność na dokładnym poziomie nie jest '
                 'gwarantowana.',
           'zh': ' 在此模拟器中，后台进程每 10 秒按收到的价格检查一次止损；无法保证精确水平的性能。',
           'ja': ' このシミュレータでは、受信した価格でバックグラウンド プロセスによって 10 秒ごとにストップロスがチェックされます。正確なレベルでのパフォーマンスは保証されません。',
           'ko': '롱 100에 손절 95는 비용 전 약 5% 손실 계획입니다. 갭으로 시장가 손절이 93에 체결되거나 스톱리밋이 미체결될 수 있습니다. 비상 브레이크처럼 가격을 보장하지 않습니다. 이 시뮬레이터에서는 '
                 '수신된 가격으로 10초마다 백그라운드 프로세스에 의해 손절매가 확인됩니다. 정확한 수준의 성능은 보장되지 않습니다.',
           'pt': 'Long em 100 e stop 95 planejam perda de 5% antes de custos. Um salto pode executar stop a mercado em 93; '
                 'stop-limit pode não executar. Como freio de emergência, não garante preço. Neste simulador, o Stop-Loss é '
                 'verificado pelo processo em segundo plano a cada 10 segundos pelo preço recebido; o desempenho em um nível '
                 'exato não é garantido.',
           'tr': "100 uzun giriş ve 95 stop, masraf öncesi yaklaşık %5 kayıp planlar. Fiyat boşluğu piyasa stopunu 93'te "
                 'doldurabilir; stop-limit hiç dolmayabilir. Acil fren gibi fiyat garantisi değildir. Bu simülatörde, Stop-Loss, '
                 'arka plan işlemi tarafından her 10 saniyede bir alınan fiyat üzerinden kontrol edilir; kesin bir seviyede '
                 'performans garanti edilmez.'}},
 {'id': 'takeprofit',
  'core': True,
  'term': {'ua': 'Take-Profit',
           'en': 'Take-Profit',
           'ru': 'Take-Profit',
           'es': 'Take-Profit',
           'hi': 'Take-Profit',
           'vi': 'Take-Profit',
           'de': 'Take-Profit',
           'pl': 'Take-Profit',
           'zh': '止盈 (Take-Profit)',
           'ja': 'テイクプロフィット',
           'ko': '익절 (Take-Profit)',
           'pt': 'Take-Profit',
           'tr': 'Take-Profit'},
  'text': {'ua': 'Умова фіксації прибутку: для лонгу з входом 100 рівень 110 означає плановий прибуток 10% до витрат. Для шорту '
                 'прибутковий рівень розташований нижче входу. Досягнення ціни не завжди гарантує виконання лімітного наказу '
                 'через ліквідність і чергу. Як заздалегідь визначена ціна продажу речі, план зменшує емоційність; тут закриття '
                 'лише ручне.',
           'en': 'A long entered at 100 with a target of 110 plans a 10% gain before costs; a short target lies below entry. '
                 'Touching the price does not guarantee a limit fill. Like setting a sale price in advance, it reduces emotion. '
                 'This release supports manual closing only.',
           'ru': 'Лонг от 100 с целью 110 планирует +10% до затрат; цель шорта ниже входа. Касание уровня не гарантирует '
                 'исполнения лимитной заявки. Как заранее заданная цена продажи, снижает эмоции. В этом релизе закрытие только '
                 'ручное.',
           'es': 'Entrada larga 100 y objetivo 110 planean ganar 10% antes de costes; en cortos el objetivo va debajo. Tocar un '
                 'precio no garantiza ejecución de una orden limitada. Como fijar precio de venta, reduce emociones. Aquí solo '
                 'cierre manual.',
           'hi': '100 पर लॉन्ग और 110 का लक्ष्य लागत से पहले 10% लाभ की योजना है; शॉर्ट का लक्ष्य नीचे होता है। कीमत छूना लिमिट '
                 'ऑर्डर भरने की गारंटी नहीं। पहले से बिक्री मूल्य तय करने जैसा है। यहाँ केवल मैन्युअल बंद करना है।',
           'vi': 'Long 100 với mục tiêu 110 dự kiến lãi 10% trước phí; mục tiêu short thấp hơn giá vào. Chạm giá không bảo đảm '
                 'khớp lệnh giới hạn. Như định giá bán trước, giúp giảm cảm xúc. Chỉ đóng thủ công ở phiên bản này.',
           'de': 'Long bei 100 mit Ziel 110 plant 10% Gewinn vor Kosten; ein Short-Ziel liegt darunter. Berühren garantiert '
                 'keine Ausführung einer Limitorder. Wie ein vorab gesetzter Verkaufspreis verringert es Emotionen. Hier nur '
                 'manuelles Schließen.',
           'pl': 'Long od 100 z celem 110 planuje 10% zysku przed kosztami; cel shorta poniżej wejścia. Dotknięcie ceny nie '
                 'gwarantuje wykonania limitu. Jak ustalona wcześniej cena sprzedaży ogranicza emocje. Tu zamknięcie wyłącznie '
                 'ręczne.',
           'zh': '做多100、目标110，计划费用前收益10%；做空目标低于入场价。触及价格不保证限价单成交。像预先设定转卖价格，可减少情绪。本版本仅支持手动平仓。',
           'ja': 'ロング100で目標110なら費用前10%利益、ショートの目標は取得価格以下です。価格に触れても指値約定は保証されません。売値を事前に決めるように感情を抑えます。この版は手動決済のみです。',
           'ko': '롱 100에 목표 110은 비용 전 10% 수익 계획이며 숏 목표는 진입가 아래입니다. 가격 도달이 지정가 체결을 보장하지 않습니다. 판매가를 미리 정하듯 감정을 줄입니다. 이 버전은 수동 종료만 '
                 '지원합니다.',
           'pt': 'Long 100 e alvo 110 planejam ganho de 10% antes de custos; alvo short fica abaixo da entrada. Tocar o preço '
                 'não garante executar uma ordem limitada. Como fixar preço de venda antes, reduz emoções. Aqui apenas '
                 'fechamento manual.',
           'tr': '100 uzun giriş ve 110 hedef, masraf öncesi %10 kazanç planlar; kısa hedef girişin altındadır. Fiyata temas '
                 'limit emrinin gerçekleşmesini garanti etmez. Satış fiyatını önceden belirlemek gibi duyguyu azaltır. Bu '
                 'sürümde yalnızca elle kapatma vardır.'}},
 {'id': 'pnl',
  'term': {'ua': 'Прибуток і збиток (P&L)',
           'en': 'Profit and loss (P&L)',
           'ru': 'Прибыль и убыток (P&L)',
           'es': 'Ganancias y pérdidas (P&L)',
           'hi': 'लाभ और हानि (पी एंड एल)',
           'vi': 'Lãi và Lỗ (P&L)',
           'de': 'Gewinn und Verlust (GuV)',
           'pl': 'Zyski i straty (P&L)',
           'zh': '损益 (P&L)',
           'ja': '損益 (P&L)',
           'ko': '손익(P&L)',
           'pt': 'Lucros e perdas (P&L)',
           'tr': 'Kâr ve Zarar (K&Z)'},
  'text': {'ua': 'P&L — різниця між поточною вартістю монет і сумою, за яку ви їх купили. Плюс означає прибуток, мінус — збиток. '
                 'Поки ви не продали, результат лише на папері.',
           'en': 'P&L is the difference between the current value of your coins and what you paid. Plus means profit, minus '
                 'means loss. Until you sell, the result exists only on paper.',
           'ru': 'P&L — разница между текущей стоимостью монет и суммой покупки. Плюс — прибыль, минус — убыток. Пока вы не '
                 'продали, результат только на бумаге.',
           'es': 'P&L es la diferencia entre el valor actual de las monedas y el monto por el que las compraste. Más significa '
                 'ganancia, menos significa pérdida. Hasta que lo vendas, el resultado sólo está en el papel.',
           'hi': 'P&L सिक्कों के वर्तमान मूल्य और आपके द्वारा उन्हें खरीदी गई राशि के बीच का अंतर है। प्लस का अर्थ है लाभ, माइनस '
                 'का अर्थ है हानि। जब तक आप बेचते नहीं, परिणाम केवल कागज़ पर ही होता है।',
           'vi': 'P&L là chênh lệch giữa giá trị hiện tại của đồng tiền và số tiền bạn mua chúng. Cộng là lãi, trừ là lỗ. Cho '
                 'đến khi bạn bán, kết quả chỉ có trên giấy.',
           'de': 'GuV ist die Differenz zwischen dem aktuellen Wert der Münzen und dem Betrag, für den Sie sie gekauft haben. '
                 'Plus bedeutet Gewinn, Minus bedeutet Verlust. Bis zum Verkauf steht das Ergebnis nur auf dem Papier.',
           'pl': 'Zyski i straty to różnica pomiędzy aktualną wartością monet a kwotą, za jaką je kupiłeś. Plus oznacza zysk, '
                 'minus oznacza stratę. Dopóki nie sprzedasz, wynik będzie tylko na papierze.',
           'zh': '损益是代币的当前价值与您购买代币的金额之间的差额。加号表示盈利，减号表示损失。在你出售之前，结果只是纸面上的。',
           'ja': '損益は、コインの現在価値とコインを購入した金額の差です。プラスは利益、マイナスは損失を意味します。販売するまでは、結果は紙の上にあるだけです。',
           'ko': 'P&L은 코인의 현재 가치와 코인을 구매한 금액의 차이입니다. 플러스는 이익을 의미하고 마이너스는 손실을 의미합니다. 팔 때까지 결과는 종이에만 있습니다.',
           'pt': 'P&L é a diferença entre o valor atual das moedas e o valor pelo qual você as comprou. Mais significa lucro, '
                 'menos significa perda. Até você vender, o resultado fica apenas no papel.',
           'tr': 'K&Z, coinin mevcut değeri ile satın aldığınız tutar arasındaki farktır. Artı kar, eksi ise zarar anlamına '
                 'gelir. Satış yapana kadar sonuç sadece kağıt üzerindedir.'},
  'core': False},
 {'id': 'change',
  'term': {'ua': 'Зміна ціни за годину',
           'en': 'One-hour price change',
           'ru': 'Изменение цены за час',
           'es': 'Cambio de precio por hora',
           'hi': 'प्रति घंटा मूल्य परिवर्तन',
           'vi': 'Thay đổi giá hàng giờ',
           'de': 'Stündliche Preisänderung',
           'pl': 'Godzinowa zmiana ceny',
           'zh': '每小时价格变化',
           'ja': '時間ごとの料金変動',
           'ko': '시간별 가격 변동',
           'pt': 'Alteração de preço por hora',
           'tr': 'Saatlik fiyat değişimi'},
  'text': {'ua': 'Показує, на скільки відсотків ціна змінилась за останню годину. Різке падіння (від −5%) система підсвічує '
                 'червоним, різке зростання (від +5%) — зеленим.',
           'en': 'Shows how many percent the price changed in the last hour. A sharp drop (−5% or more) is highlighted red, a '
                 'sharp rise (+5% or more) is highlighted green.',
           'ru': 'Показывает, на сколько процентов изменилась цена за последний час. Резкое падение (от −5%) подсвечивается '
                 'красным, резкий рост (от +5%) — зелёным.',
           'es': 'Muestra cuánto ha cambiado el precio en la última hora. El sistema resalta en rojo una fuerte caída (desde '
                 '-5%) y un fuerte aumento (desde +5%) en verde.',
           'hi': 'दिखाता है कि पिछले घंटे में कीमत में कितना बदलाव आया है। सिस्टम द्वारा एक तेज गिरावट (-5% से) को लाल रंग में, '
                 'एक तेज वृद्धि (+5% से) को हरे रंग में हाइलाइट किया जाता है।',
           'vi': 'Cho biết giá đã thay đổi bao nhiêu trong giờ qua. Mức giảm mạnh (từ −5%) được hệ thống đánh dấu bằng màu đỏ, '
                 'mức tăng mạnh (từ +5%) được đánh dấu bằng màu xanh lục.',
           'de': 'Zeigt an, wie stark sich der Preis in der letzten Stunde verändert hat. Ein starker Abfall (von −5 %) wird vom '
                 'System rot hervorgehoben, ein starker Anstieg (von +5 %) grün.',
           'pl': 'Pokazuje, jak bardzo zmieniła się cena w ciągu ostatniej godziny. Gwałtowny spadek (z -5%) jest zaznaczony '
                 'systemem na czerwono, gwałtowny wzrost (z +5%) na zielono.',
           'zh': '显示过去一小时内价格的变化量。系统以红色突出显示急剧下降（从 -5%），以绿色突出显示急剧增加（从 +5%）。',
           'ja': '過去 1 時間に価格がどれだけ変化したかを示します。急激な減少 (-5% から) はシステムによって赤色で強調表示され、急激な増加 (+5% から) は緑色で強調表示されます。',
           'ko': '지난 한 시간 동안 가격이 얼마나 변했는지 표시합니다. 급격한 감소(-5%에서)는 시스템에서 빨간색으로 강조 표시되고 급격한 증가(+5%에서)는 녹색으로 강조 표시됩니다.',
           'pt': 'Mostra quanto o preço mudou na última hora. Uma queda acentuada (de -5%) é destacada pelo sistema em vermelho, '
                 'um aumento acentuado (de +5%) em verde.',
           'tr': "Fiyatın son bir saatte ne kadar değiştiğini gösterir. Sistem tarafından keskin bir düşüş (-%5'ten) kırmızıyla, "
                 "keskin bir artış (+%5'ten) yeşille vurgulanır."},
  'core': False},
 {'id': 'averaging',
  'term': {'ua': 'Усереднення',
           'en': 'Averaging down',
           'ru': 'Усреднение',
           'es': 'promediando',
           'hi': 'औसत',
           'vi': 'Tính trung bình',
           'de': 'Mittelung',
           'pl': 'Uśrednianie',
           'zh': '平均',
           'ja': '平均化',
           'ko': '평균화',
           'pt': 'Média',
           'tr': 'Ortalama'},
  'text': {'ua': 'Докупівля тієї ж монети за нижчою ціною. Середня ціна покупки зменшується, тож для виходу в плюс потрібне '
                 'менше зростання. Ризик: ви вкладаєте більше в актив, який продовжує падати.',
           'en': 'Buying more of the same coin at a lower price. Your average purchase price drops, so a smaller rise is needed '
                 'to break even. Risk: you put more money into an asset that may keep falling.',
           'ru': 'Докупка той же монеты по более низкой цене. Средняя цена покупки снижается, и для выхода в плюс нужен меньший '
                 'рост. Риск: вы вкладываете больше в актив, который может продолжить падать.',
           'es': 'Compra adicional de la misma moneda a un precio menor. El precio de compra promedio está disminuyendo, por lo '
                 'que se necesita menos crecimiento para alcanzar el punto de equilibrio. Riesgo: Inviertes más en un activo que '
                 'sigue cayendo.',
           'hi': 'कम कीमत पर उसी सिक्के की अतिरिक्त खरीदारी। औसत खरीद मूल्य घट रहा है, इसलिए संतुलन के लिए कम वृद्धि की आवश्यकता '
                 'है। जोखिम: आप ऐसी परिसंपत्ति में अधिक निवेश करते हैं जिसमें गिरावट जारी रहती है।',
           'vi': 'Mua thêm cùng một loại tiền với giá thấp hơn. Giá mua trung bình đang giảm, do đó cần tăng trưởng ít hơn để '
                 'hòa vốn. Rủi ro: Bạn đầu tư nhiều hơn vào một tài sản tiếp tục giảm.',
           'de': 'Zusätzlicher Kauf derselben Münze zu einem günstigeren Preis. Der durchschnittliche Kaufpreis sinkt, sodass '
                 'weniger Wachstum erforderlich ist, um die Gewinnschwelle zu erreichen. Risiko: Sie investieren mehr in einen '
                 'Vermögenswert, der weiter fällt.',
           'pl': 'Dodatkowy zakup tej samej monety po niższej cenie. Średnia cena zakupu spada, zatem do osiągnięcia progu '
                 'rentowności potrzebny jest mniejszy wzrost. Ryzyko: Inwestujesz więcej w aktywa, które nadal spadają.',
           'zh': '以较低的价格额外购买相同的硬币。平均购买价格正在下降，因此需要更少的增长才能达到收支平衡。风险：您对持续下跌的资产进行更多投资。',
           'ja': '同じコインをさらに安い価格で追加購入します。平均購入価格は低下しているため、損益分岐点までの成長はそれほど必要ありません。リスク: 下落し続ける資産にさらに投資することになります。',
           'ko': '동일한 코인을 더 저렴한 가격에 추가 구매하실 수 있습니다. 평균 구매 가격이 감소하고 있으므로 손익분기점에 도달하려면 더 적은 성장이 필요합니다. 위험: 계속 하락하는 자산에 더 많이 투자합니다.',
           'pt': 'Compra adicional da mesma moeda a um preço inferior. O preço médio de compra está diminuindo, portanto, é '
                 'necessário menos crescimento para atingir o ponto de equilíbrio. Risco: você investe mais em um ativo que '
                 'continua caindo.',
           'tr': 'Aynı madalyonun daha düşük bir fiyata ek olarak satın alınması. Ortalama satın alma fiyatı düşüyor, '
                 'dolayısıyla başabaş için daha az büyümeye ihtiyaç var. Risk: Düşmeye devam eden bir varlığa daha fazla yatırım '
                 'yaparsınız.'},
  'core': False},
 {'id': 'news',
  'term': {'ua': 'Настрій новин',
           'en': 'News sentiment',
           'ru': 'Настроение новостей',
           'es': 'El estado de ánimo de las noticias',
           'hi': 'खबर का मिजाज',
           'vi': 'Tâm trạng của tin tức',
           'de': 'Die Stimmung der Nachrichten',
           'pl': 'Nastrój wiadomości',
           'zh': '新闻的心情',
           'ja': 'ニュースの雰囲気',
           'ko': '뉴스의 분위기',
           'pt': 'O clima das notícias',
           'tr': 'Haberin ruh hali'},
  'text': {'ua': 'Система читає заголовки світових крипто-новин і за ключовими словами оцінює, чи фон позитивний, нейтральний чи '
                 'негативний. Це спрощений аналіз, а не прогноз.',
           'en': 'The system reads world crypto headlines and, using keywords, judges whether the background is positive, '
                 "neutral or negative. It's a simplified analysis, not a forecast.",
           'ru': 'Система читает заголовки мировых крипто-новостей и по ключевым словам оценивает фон: позитивный, нейтральный '
                 'или негативный. Это упрощённый анализ, а не прогноз.',
           'es': 'El sistema lee los titulares de noticias criptográficas globales y evalúa si el fondo es positivo, neutral o '
                 'negativo en función de las palabras clave. Este es un análisis simplificado, no un pronóstico.',
           'hi': 'सिस्टम वैश्विक क्रिप्टो समाचार सुर्खियों को पढ़ता है और कीवर्ड के आधार पर मूल्यांकन करता है कि पृष्ठभूमि '
                 'सकारात्मक, तटस्थ या नकारात्मक है या नहीं। यह एक सरलीकृत विश्लेषण है, पूर्वानुमान नहीं।',
           'vi': 'Hệ thống đọc các tiêu đề tin tức về tiền điện tử toàn cầu và đánh giá xem nền tảng đó là tích cực, trung lập '
                 'hay tiêu cực dựa trên các từ khóa. Đây là một phân tích đơn giản, không phải là một dự báo.',
           'de': 'Das System liest globale Schlagzeilen zu Krypto-Nachrichten und bewertet anhand von Schlüsselwörtern, ob der '
                 'Hintergrund positiv, neutral oder negativ ist. Dies ist eine vereinfachte Analyse, keine Prognose.',
           'pl': 'System odczytuje nagłówki światowych wiadomości o kryptowalutach i ocenia, czy tło jest pozytywne, neutralne '
                 'czy negatywne, na podstawie słów kluczowych. To uproszczona analiza, a nie prognoza.',
           'zh': '该系统读取全球加密货币新闻头条，并根据关键词评估背景是正面、中性还是负面。这是一个简化的分析，而不是预测。',
           'ja': 'このシステムは世界の暗号通貨ニュースの見出しを読み取り、キーワードに基づいてその背景が肯定的か、中立的か、否定的かを評価します。これは単純化した分析であり、予測ではありません。',
           'ko': '시스템은 글로벌 암호화폐 뉴스 헤드라인을 읽고 키워드를 기반으로 배경이 긍정적인지, 중립적인지, 부정적인지 평가합니다. 이는 예측이 아닌 단순화된 분석입니다.',
           'pt': 'O sistema lê manchetes de notícias criptográficas globais e avalia se o histórico é positivo, neutro ou '
                 'negativo com base em palavras-chave. Esta é uma análise simplificada, não uma previsão.',
           'tr': 'Sistem, küresel kripto haber başlıklarını okuyor ve anahtar kelimelere göre arka planın olumlu, nötr veya '
                 'olumsuz olup olmadığını değerlendiriyor. Bu basitleştirilmiş bir analizdir, bir tahmin değildir.'},
  'core': False},
 {'id': 'virtual',
  'term': {'ua': 'Віртуальна торгівля',
           'en': 'Virtual trading',
           'ru': 'Виртуальная торговля',
           'es': 'comercio virtual',
           'hi': 'आभासी व्यापार',
           'vi': 'Giao dịch ảo',
           'de': 'Virtueller Handel',
           'pl': 'Wirtualny handel',
           'zh': '虚拟贸易',
           'ja': 'バーチャルトレード',
           'ko': '가상 무역',
           'pt': 'Comércio virtual',
           'tr': 'Sanal ticaret'},
  'text': {'ua': 'Усі покупки тут умовні: реальні гроші не списуються. Це безпечний спосіб вчитись, як рух ціни впливає на '
                 'портфель, і не ризикувати власними коштами.',
           'en': "All purchases here are simulated: no real money is spent. It's a safe way to learn how price moves affect a "
                 'portfolio without risking your own funds.',
           'ru': 'Все покупки здесь условные: реальные деньги не списываются. Это безопасный способ научиться понимать, как '
                 'движение цены влияет на портфель, не рискуя своими средствами.',
           'es': 'Todas las compras aquí son condicionales: no se carga dinero real. Esta es una forma segura de aprender cómo '
                 'los movimientos de precios afectan la cartera y no arriesgar sus propios fondos.',
           'hi': 'यहां सभी खरीदारी सशर्त हैं: वास्तविक पैसा डेबिट नहीं किया जाता है। यह यह जानने का एक सुरक्षित तरीका है कि '
                 'मूल्य परिवर्तन पोर्टफोलियो को कैसे प्रभावित करते हैं और अपने स्वयं के फंड को जोखिम में नहीं डालते हैं।',
           'vi': 'Tất cả các giao dịch mua ở đây đều có điều kiện: tiền thật không bị ghi nợ. Đây là một cách an toàn để tìm '
                 'hiểu biến động giá ảnh hưởng đến danh mục đầu tư như thế nào và không gây rủi ro cho quỹ của chính bạn.',
           'de': 'Alle Käufe hier erfolgen unter Vorbehalt: Es wird kein echtes Geld abgebucht. Dies ist eine sichere '
                 'Möglichkeit, zu erfahren, wie sich Preisbewegungen auf das Portfolio auswirken, ohne Ihr eigenes Geld zu '
                 'riskieren.',
           'pl': 'Wszystkie zakupy tutaj są warunkowe: prawdziwe pieniądze nie są pobierane. Jest to bezpieczny sposób, aby '
                 'dowiedzieć się, jak zmiany cen wpływają na portfel, i nie ryzykować własnych środków.',
           'zh': '这里的所有购买都是有条件的：真实货币不会被借记。这是了解价格变动如何影响投资组合的安全方法，而且不会让您自己的资金面临风险。',
           'ja': 'ここでの購入はすべて条件付きです。リアルマネーは引き落とされません。これは、自分の資金を危険にさらさずに、価格変動がポートフォリオにどのような影響を与えるかを学ぶ安全な方法です。',
           'ko': '여기서의 모든 구매는 조건부입니다. 실제 돈은 인출되지 않습니다. 이는 가격 변동이 포트폴리오에 어떻게 영향을 미치는지 알아보고 자신의 자금을 위험에 빠뜨리지 않는 안전한 방법입니다.',
           'pt': 'Todas as compras aqui são condicionais: dinheiro real não é debitado. Esta é uma forma segura de aprender como '
                 'os movimentos de preços afetam a carteira e não arriscar seus próprios fundos.',
           'tr': 'Buradaki tüm satın alımlar koşulludur: gerçek para tahsil edilmez. Bu, fiyat hareketlerinin portföyü nasıl '
                 'etkilediğini öğrenmenin ve kendi fonlarınızı riske atmanın güvenli bir yoludur.'},
  'core': False}]

CHAT_LABELS = {'ua': {'thinking': 'Готую відповідь…',
        'rec_buy': 'КУПИТИ за вигідною ціною',
        'rec_sell': 'НЕ КУПУВАТИ / ПРОДАТИ',
        'rec_neutral': 'Утримуватись, ринок спокійний'},
 'en': {'thinking': 'I am preparing an answer...',
        'rec_buy': 'BUY at a discount',
        'rec_sell': "DON'T BUY / SELL",
        'rec_neutral': 'Hold, the market is calm'},
 'ru': {'thinking': 'Готовлю ответ…',
        'rec_buy': 'КУПИТЬ по выгодной цене',
        'rec_sell': 'НЕ ПОКУПАТЬ / ПРОДАТЬ',
        'rec_neutral': 'Воздержаться, рынок спокоен'},
 'es': {'thinking': 'Estoy preparando una respuesta...',
        'rec_buy': 'COMPRAR a buen precio',
        'rec_sell': 'NO COMPRAR/VENDER',
        'rec_neutral': 'Espera, el mercado está tranquilo.'},
 'hi': {'thinking': 'मैं एक उत्तर तैयार कर रहा हूँ...',
        'rec_buy': 'अच्छी कीमत पर खरीदें',
        'rec_sell': 'खरीदें/बेचें नहीं',
        'rec_neutral': 'रुकिए, बाजार शांत है'},
 'vi': {'thinking': 'Tôi đang chuẩn bị câu trả lời...',
        'rec_buy': 'MUA với giá tốt',
        'rec_sell': 'KHÔNG MUA / BÁN',
        'rec_neutral': 'Cố lên, thị trường bình yên'},
 'de': {'thinking': 'Ich bereite eine Antwort vor ...',
        'rec_buy': 'Kaufen Sie zu einem guten Preis',
        'rec_sell': 'NICHT KAUFEN/VERKAUFEN',
        'rec_neutral': 'Moment, der Markt ist ruhig'},
 'pl': {'thinking': 'Przygotowuję odpowiedź...',
        'rec_buy': 'KUPIĘ w dobrej cenie',
        'rec_sell': 'NIE KUPUJ/SPRZEDAJ',
        'rec_neutral': 'Poczekaj, rynek jest spokojny'},
 'zh': {'thinking': '我正在准备答案...', 'rec_buy': '以优惠的价格购买', 'rec_sell': '请勿购买/出售', 'rec_neutral': '坚持住，市场平静'},
 'ja': {'thinking': '答えを準備中です...', 'rec_buy': 'お得な価格で購入', 'rec_sell': '売買しないでください', 'rec_neutral': 'ちょっと待ってください、市場は落ち着いています'},
 'ko': {'thinking': '답변을 준비 중입니다..', 'rec_buy': '좋은 가격에 구매하세요', 'rec_sell': '구매/판매하지 마세요', 'rec_neutral': '잠깐만요, 시장은 조용해요'},
 'pt': {'thinking': 'Estou preparando uma resposta...',
        'rec_buy': 'COMPRE por um bom preço',
        'rec_sell': 'NÃO COMPRE/VENDA',
        'rec_neutral': 'Espere, o mercado está calmo'},
 'tr': {'thinking': 'Bir cevap hazırlıyorum...',
        'rec_buy': 'İyi bir fiyata SATIN ALIN',
        'rec_sell': 'ALMAYIN / SATMAYIN',
        'rec_neutral': 'Durun piyasa sakin'}}


_SCHOOL_LABELS = {'ua': 'Школа новачка', 'en': 'Beginner school', 'ru': 'Школа новичка', 'es': 'Escuela para principiantes', 'hi': 'शुरुआती पाठशाला', 'vi': 'Trường học cho người mới', 'de': 'Einsteigerschule', 'pl': 'Szkoła dla początkujących', 'zh': '新手学堂', 'ja': '初心者スクール', 'ko': '초보자 학교', 'pt': 'Escola para iniciantes', 'tr': 'Başlangıç okulu'}
for _lang, _label in _SCHOOL_LABELS.items():
    UI_TRANSLATIONS[_lang]["Школа новачка"] = _label
    UI_TRANSLATIONS[_lang]["📚 Школа новачка"] = "📚 " + _label

LANG_ALIASES.update({lang: lang for lang in LANGS})

I18N = {'rec_buy': {'ua': 'КУПИТИ за вигідною ціною',
             'en': 'BUY at a discount',
             'ru': 'КУПИТЬ по выгодной цене',
             'es': 'COMPRAR a buen precio',
             'hi': 'अच्छी कीमत पर खरीदें',
             'vi': 'MUA với giá tốt',
             'de': 'Kaufen Sie zu einem guten Preis',
             'pl': 'KUPIĘ w dobrej cenie',
             'zh': '以优惠的价格购买',
             'ja': 'お得な価格で購入',
             'ko': '좋은 가격에 구매하세요',
             'pt': 'COMPRE por um bom preço',
             'tr': 'İyi bir fiyata SATIN ALIN'},
 'rec_sell': {'ua': 'НЕ КУПУВАТИ / ПРОДАТИ',
              'en': "DON'T BUY / SELL",
              'ru': 'НЕ ПОКУПАТЬ / ПРОДАТЬ',
              'es': 'NO COMPRAR/VENDER',
              'hi': 'खरीदें/बेचें नहीं',
              'vi': 'KHÔNG MUA / BÁN',
              'de': 'NICHT KAUFEN/VERKAUFEN',
              'pl': 'NIE KUPUJ/SPRZEDAJ',
              'zh': '请勿购买/出售',
              'ja': '売買しないでください',
              'ko': '구매/판매하지 마세요',
              'pt': 'NÃO COMPRE/VENDA',
              'tr': 'ALMAYIN / SATMAYIN'},
 'rec_neutral': {'ua': 'Утримуватись, ринок спокійний',
                 'en': 'Hold, the market is calm',
                 'ru': 'Воздержаться, рынок спокоен',
                 'es': 'Espera, el mercado está tranquilo.',
                 'hi': 'रुकिए, बाजार शांत है',
                 'vi': 'Cố lên, thị trường bình yên',
                 'de': 'Moment, der Markt ist ruhig',
                 'pl': 'Poczekaj, rynek jest spokojny',
                 'zh': '坚持住，市场平静',
                 'ja': 'ちょっと待ってください、市場は落ち着いています',
                 'ko': '잠깐만요, 시장은 조용해요',
                 'pt': 'Espere, o mercado está calmo',
                 'tr': 'Durun piyasa sakin'},
 'banner': {'ua': '⚠️ Високий ризик падіння ринку через негативні світові новини!',
            'en': '⚠️ High risk of a market drop due to negative world news!',
            'ru': '⚠️ Высокий риск падения рынка из-за негативных мировых новостей!',
            'es': '⚠️ ¡Alto riesgo de caída del mercado debido a noticias mundiales negativas!',
            'hi': '⚠️ दुनिया की नकारात्मक खबरों से बाजार में गिरावट का खतरा ज्यादा!',
            'vi': '⚠️ Nguy cơ thị trường sụt giảm cao do tin tức tiêu cực trên thế giới!',
            'de': '⚠️ Hohes Risiko eines Marktrückgangs aufgrund negativer Weltnachrichten!',
            'pl': '⚠️ Wysokie ryzyko spadków rynku w związku z negatywnymi wiadomościami ze świata!',
            'zh': '⚠️世界负面新闻导致市场下跌的风险很高！',
            'ja': '⚠️世界のネガティブなニュースによる市場下落のリスクが高い!',
            'ko': '⚠️ 부정적인 세계 뉴스로 인한 시장 하락 위험 높음!',
            'pt': '⚠️ Alto risco de queda do mercado devido a notícias mundiais negativas!',
            'tr': '⚠️ Olumsuz dünya haberleri nedeniyle piyasanın düşme riski yüksek!'},
 'sl_event': {'ua': 'Stop-Loss спрацював: {symbol} закрито за ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'en': 'Stop-Loss triggered: {symbol} closed at ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'ru': 'Сработал Stop-Loss: {symbol} закрыта по ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'es': 'Stop-Loss funcionó: {symbol} cerró en ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'hi': 'स्टॉप-लॉस काम किया: {symbol} ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$) पर बंद हुआ',
              'vi': 'Lệnh dừng lỗ đã hoạt động: {symbol} đóng ở mức ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'de': 'Stop-Loss funktionierte: {symbol} schloss bei ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'pl': 'Stop-Loss zadziałał: {symbol} zamknął się na poziomie ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'zh': '止损起作用：{symbol} 收于 ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'ja': 'ストップロスが機能しました: {symbol} は ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$) で終了しました',
              'ko': '손절매 작동: {symbol}가 ${price:,.4f}({pct:+.2f}%, {pnl:+,.2f}$)에 마감되었습니다.',
              'pt': 'Stop-Loss funcionou: {symbol} fechou em ${price:,.4f} ({pct:+.2f}%, {pnl:+,.2f}$)',
              'tr': 'Zarar Durdurma işe yaradı: {symbol} ${price:,.4f} seviyesinden kapandı ({pct:+.2f}%, {pnl:+,.2f}$)'},
 'err_unknown_coin': {'ua': 'Невідома монета. Доступні: {coins}',
                      'en': 'Unknown coin. Available: {coins}',
                      'ru': 'Неизвестная монета. Доступны: {coins}',
                      'es': 'Moneda desconocida. Disponible: {coins}',
                      'hi': 'अज्ञात सिक्का. उपलब्ध: {coins}',
                      'vi': 'Đồng xu không xác định. Có sẵn: {coins}',
                      'de': 'Unbekannte Münze. Verfügbar: {coins}',
                      'pl': 'Nieznana moneta. Dostępne: {coins}',
                      'zh': '未知硬币。可用：{coins}',
                      'ja': '未知のコイン。利用可能: {coins}',
                      'ko': '알 수 없는 동전. 사용 가능: {coins}',
                      'pt': 'Moeda desconhecida. Disponível: {coins}',
                      'tr': 'Bilinmeyen para. Mevcut: {coins}'},
 'err_bad_numbers': {'ua': 'Кількість і ціна мають бути додатними числами',
                     'en': 'Quantity and price must be positive numbers',
                     'ru': 'Количество и цена должны быть положительными числами',
                     'es': 'La cantidad y el precio deben ser números positivos.',
                     'hi': 'मात्रा और कीमत धनात्मक संख्या होनी चाहिए',
                     'vi': 'Số lượng và giá phải là số dương',
                     'de': 'Menge und Preis müssen positive Zahlen sein',
                     'pl': 'Ilość i cena muszą być liczbami dodatnimi',
                     'zh': '数量和价格必须为正数',
                     'ja': '数量と価格は正の数である必要があります',
                     'ko': '수량과 가격은 양수여야 합니다.',
                     'pt': 'Quantidade e preço devem ser números positivos',
                     'tr': 'Miktar ve fiyat pozitif sayılar olmalıdır'},
 'err_not_found': {'ua': 'Позицію не знайдено',
                   'en': 'Position not found',
                   'ru': 'Позиция не найдена',
                   'es': 'No se encontró ninguna posición',
                   'hi': 'कोई पद नहीं मिला',
                   'vi': 'Không tìm thấy vị trí nào',
                   'de': 'Keine Position gefunden',
                   'pl': 'Nie znaleziono pozycji',
                   'zh': '没有找到位置',
                   'ja': 'ポジションが見つかりません',
                   'ko': '직위를 찾을 수 없습니다.',
                   'pt': 'Nenhuma posição encontrada',
                   'tr': 'Pozisyon bulunamadı'},
 'err_avg_high': {'ua': 'Усереднення можливе лише за ціною, нижчою за поточну середню (${avg:,.4f})',
                  'en': 'Averaging is only possible at a price below the current average (${avg:,.4f})',
                  'ru': 'Усреднение возможно только по цене ниже текущей средней (${avg:,.4f})',
                  'es': 'El promedio sólo es posible a un precio inferior al promedio actual (${avg:,.4f})',
                  'hi': 'औसतीकरण केवल वर्तमान औसत (${avg:,.4f}) से कम कीमत पर ही संभव है',
                  'vi': 'Chỉ có thể tính trung bình ở mức giá thấp hơn mức trung bình hiện tại (${avg:,.4f})',
                  'de': 'Eine Mittelwertbildung ist nur zu einem Preis möglich, der unter dem aktuellen Durchschnitt '
                        '(${avg:,.4f}) liegt.',
                  'pl': 'Uśrednianie jest możliwe tylko po cenie niższej niż bieżąca średnia (${avg:,.4f})',
                  'zh': '仅当价格低于当前平均值 (${avg:,.4f}) 时才可以进行平均',
                  'ja': '平均化は現在の平均 (${avg:,.4f}) よりも低い価格でのみ可能です',
                  'ko': '평균화는 현재 평균(${avg:,.4f})보다 낮은 가격에서만 가능합니다.',
                  'pt': 'A média só é possível a um preço inferior à média atual (${avg:,.4f})',
                  'tr': 'Ortalama alma yalnızca mevcut ortalamadan daha düşük bir fiyatla mümkündür (${avg:,.4f})'},
 'err_sl_range': {'ua': 'Stop-Loss — це відсоток від 0.1 до 99',
                  'en': 'Stop-Loss is a percentage from 0.1 to 99',
                  'ru': 'Stop-Loss — это процент от 0.1 до 99',
                  'es': 'Stop-Loss es un porcentaje de 0,1 a 99',
                  'hi': 'स्टॉप-लॉस 0.1 से 99 तक का प्रतिशत है',
                  'vi': 'Dừng lỗ là tỷ lệ phần trăm từ 0,1 đến 99',
                  'de': 'Stop-Loss ist ein Prozentsatz von 0,1 bis 99',
                  'pl': 'Stop-Loss to wartość procentowa od 0,1 do 99',
                  'zh': '止损是从 0.1 到 99 的百分比',
                  'ja': 'ストップロスは0.1から99のパーセンテージです',
                  'ko': '정지 손실은 0.1에서 99까지의 백분율입니다.',
                  'pt': 'Stop-Loss é uma porcentagem de 0,1 a 99',
                  'tr': "Zararı Durdur 0,1'den 99'a kadar bir yüzdedir"},
 'err_prices_wait': {'ua': 'Ціни ще не завантажені, спробуйте за кілька секунд',
                     'en': 'Prices are not loaded yet, try again in a few seconds',
                     'ru': 'Цены ещё не загружены, повторите через несколько секунд',
                     'es': 'Los precios aún no están cargados, inténtalo en unos segundos.',
                     'hi': 'कीमतें अभी तक लोड नहीं की गई हैं, कुछ सेकंड में प्रयास करें',
                     'vi': 'Giá chưa được tải, hãy thử sau vài giây',
                     'de': 'Die Preise sind noch nicht geladen. Versuchen Sie es in ein paar Sekunden',
                     'pl': 'Ceny nie są jeszcze załadowane, spróbuj za kilka sekund',
                     'zh': '价格尚未加载，请稍后尝试',
                     'ja': '価格はまだ読み込まれていません。数秒後に試してください',
                     'ko': '가격이 아직 로드되지 않았습니다. 몇 초 후에 시도해 보세요.',
                     'pt': 'Os preços ainda não foram carregados, tente em alguns segundos',
                     'tr': 'Fiyatlar henüz yüklenmedi, birkaç saniye sonra deneyin'},
 'err_bad_month': {'ua': 'Формат місяця: РРРР-ММ',
                   'en': 'Month format: YYYY-MM',
                   'ru': 'Формат месяца: ГГГГ-ММ',
                   'es': 'Formato de mes: AAAA-MM',
                   'hi': 'माह प्रारूप: YYYY-MM',
                   'vi': 'Định dạng tháng: YYYY-MM',
                   'de': 'Monatsformat: JJJJ-MM',
                   'pl': 'Format miesiąca: RRRR-MM',
                   'zh': '月份格式：YYYY-MM',
                   'ja': '月の形式: YYYY-MM',
                   'ko': '월 형식: YYYY-MM',
                   'pt': 'Formato do mês: AAAA-MM',
                   'tr': 'Ay biçimi: YYYY-AA'},
 'err_confirm': {'ua': 'Для повного скидання надішліть {"confirm": true}',
                 'en': 'To reset everything send {"confirm": true}',
                 'ru': 'Для полного сброса отправьте {"confirm": true}',
                 'es': 'Para restablecimiento completo envíe {"confirm": true}',
                 'hi': 'हार्ड रीसेट के लिए {"confirm": true} भेजें',
                 'vi': 'Để thiết lập lại cứng, hãy gửi {"confirm": true}',
                 'de': 'Für einen Hard-Reset senden Sie {"confirm": true}',
                 'pl': 'W celu twardego resetu wyślij {"confirm": true}',
                 'zh': '对于硬重置，发送 {"confirm": true}',
                 'ja': 'ハードリセットの場合は、{"confirm": true}を送信してください',
                 'ko': '하드 리셋하려면 {"confirm": true}를 보내세요.',
                 'pt': 'Para reinicialização total, envie {"confirm": true}',
                 'tr': 'Donanımdan sıfırlama için {"confirm": true} gönderin'},
 'err_empty_msg': {'ua': 'Повідомлення порожнє',
                   'en': 'The message is empty',
                   'ru': 'Сообщение пустое',
                   'es': 'El mensaje esta vacio',
                   'hi': 'संदेश खाली है',
                   'vi': 'Tin nhắn trống',
                   'de': 'Die Nachricht ist leer',
                   'pl': 'Wiadomość jest pusta',
                   'zh': '留言内容为空',
                   'ja': 'メッセージは空です',
                   'ko': '메시지가 비어 있습니다.',
                   'pt': 'A mensagem está vazia',
                   'tr': 'Mesaj boş'},
 'err_long_msg': {'ua': 'Повідомлення задовге (максимум {n} символів)',
                  'en': 'The message is too long (max {n} characters)',
                  'ru': 'Сообщение слишком длинное (максимум {n} символов)',
                  'es': 'El mensaje es demasiado largo (máximo de caracteres {n})',
                  'hi': 'संदेश बहुत लंबा है (अधिकतम {n} वर्ण)',
                  'vi': 'Tin nhắn quá dài (tối đa ký tự {n})',
                  'de': 'Nachricht ist zu lang (maximal {n} Zeichen)',
                  'pl': 'Wiadomość jest za długa (maksymalnie {n} znaków)',
                  'zh': '消息太长（最多 {n} 个字符）',
                  'ja': 'メッセージが長すぎます (最大 {n} 文字)',
                  'ko': '메시지가 너무 깁니다(최대 {n}자).',
                  'pt': 'A mensagem é muito longa (máximo de caracteres {n})',
                  'tr': 'Mesaj çok uzun (maksimum {n} karakter)'},
 'trend_up': {'ua': 'висхідний',
              'en': 'upward',
              'ru': 'восходящий',
              'es': 'ascendiendo',
              'hi': 'आरोही',
              'vi': 'tăng dần',
              'de': 'aufsteigend',
              'pl': 'rosnąco',
              'zh': '上升',
              'ja': '昇順',
              'ko': '오름차순',
              'pt': 'ascendente',
              'tr': 'artan'},
 'trend_down': {'ua': 'низхідний',
                'en': 'downward',
                'ru': 'нисходящий',
                'es': 'descendiendo',
                'hi': 'अवरोही',
                'vi': 'giảm dần',
                'de': 'absteigend',
                'pl': 'malejąco',
                'zh': '下降',
                'ja': '降順',
                'ko': '내림차순',
                'pt': 'descendente',
                'tr': 'alçalan'},
 'trend_flat': {'ua': 'боковий',
                'en': 'sideways',
                'ru': 'боковой',
                'es': 'laterales',
                'hi': 'पार्श्व',
                'vi': 'bên',
                'de': 'seitlich',
                'pl': 'boczny',
                'zh': '横向',
                'ja': '横方向',
                'ko': '측면',
                'pt': 'laterais',
                'tr': 'yanal'},
 'chat_coin': {'ua': '{symbol}: ціна ${price}, за годину {change:+.2f}%. Тренд за 60 хв: {trend}, коливання {vol:.2f}%. Сигнал '
                     'системи: {reco}.',
               'en': '{symbol}: price ${price}, {change:+.2f}% over the last hour. 60-min trend: {trend}, volatility {vol:.2f}%. '
                     'System signal: {reco}.',
               'ru': '{symbol}: цена ${price}, за час {change:+.2f}%. Тренд за 60 мин: {trend}, колебания {vol:.2f}%. Сигнал '
                     'системы: {reco}.',
               'es': '{symbol}: precio ${price}, por hora {change:+.2f}%. Tendencia durante 60 min: {trend}, fluctuación '
                     '{vol:.2f}%. Señal del sistema: {reco}.',
               'hi': '{symbol}: मूल्य ${price}, प्रति घंटा {change:+.2f}%। 60 मिनट के लिए रुझान: {trend}, उतार-चढ़ाव {vol:.2f}%। '
                     'सिस्टम सिग्नल: {reco}.',
               'vi': '{symbol}: giá ${price}, mỗi giờ {change:+.2f}%. Xu hướng trong 60 phút: {trend}, biến động {vol:.2f}%. Tín '
                     'hiệu hệ thống: {reco}.',
               'de': '{symbol}: Preis ${price}, pro Stunde {change:+.2f}%. Trend für 60 Min.: {trend}, Schwankung {vol:.2f} %. '
                     'Systemsignal: {reco}.',
               'pl': '{symbol}: cena ${price}, za godzinę {change:+.2f}%. Trend przez 60 min: {trend}, wahania {vol:.2f}%. '
                     'Sygnał systemowy: {reco}.',
               'zh': '{symbol}：价格${price}，每小时{change:+.2f}%。 60分钟趋势：{trend}，波动{vol:.2f}%。系统信号：{reco}。',
               'ja': '{symbol}: 料金 ${price}、1 時間あたり {change:+.2f}%。 60分間のトレンド：{trend}、変動率{vol:.2f}%。システム信号：{reco}。',
               'ko': '{symbol}: 시간 {change:+.2f}%당 가격 ${price}. 60분 동안의 추세: {trend}, 변동폭 {vol:.2f}%. 시스템 신호: {reco}.',
               'pt': '{symbol}: preço ${price}, por hora {change:+.2f}%. Tendência para 60 min: {trend}, flutuação {vol:.2f}%. '
                     'Sinal do sistema: {reco}.',
               'tr': '{symbol}: fiyat ${price}, saat başına {change:+.2f}%. 60 dakikalık trend: {trend}, dalgalanma {vol:.2f}%. '
                     'Sistem sinyali: {reco}.'},
 'chat_portfolio': {'ua': 'Портфель: вартість ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), відкритих позицій: {count}.',
                    'en': 'Portfolio: value ${value:,.2f}, result {pnl:+,.2f}$ ({pct:+.2f}%), open positions: {count}.',
                    'ru': 'Портфель: стоимость ${value:,.2f}, результат {pnl:+,.2f}$ ({pct:+.2f}%), открытых позиций: {count}.',
                    'es': 'Cartera: costo ${value:,.2f}, resultado {pnl:+,.2f}$ ({pct:+.2f}%), posiciones abiertas: {count}.',
                    'hi': 'पोर्टफोलियो: लागत ${value:,.2f}, परिणाम {pnl:+,.2f}$ ({pct:+.2f}%), खुली स्थिति: {count}।',
                    'vi': 'Danh mục đầu tư: chi phí ${value:,.2f}, kết quả {pnl:+,.2f}$ ({pct:+.2f}%), vị trí mở: {count}.',
                    'de': 'Portfolio: Kosten ${value:,.2f}, Ergebnis {pnl:+,.2f}$ ({pct:+.2f}%), offene Positionen: {count}.',
                    'pl': 'Portfel: koszt ${value:,.2f}, wynik {pnl:+,.2f}$ ({pct:+.2f}%), otwarte pozycje: {count}.',
                    'zh': '投资组合：成本 ${value:,.2f}，结果 {pnl:+,.2f}$ ({pct:+.2f}%)，未平仓头寸：{count}。',
                    'ja': 'ポートフォリオ: コスト ${value:,.2f}、結果 {pnl:+,.2f}$ ({pct:+.2f}%)、オープン ポジション: {count}。',
                    'ko': '포트폴리오: 비용 ${value:,.2f}, 결과 {pnl:+,.2f}$({pct:+.2f}%), 오픈 포지션: {count}.',
                    'pt': 'Carteira: custo ${value:,.2f}, resultado {pnl:+,.2f}$ ({pct:+.2f}%), posições abertas: {count}.',
                    'tr': 'Portföy: maliyet ${value:,.2f}, sonuç {pnl:+,.2f}$ (%{pct:+.2f}), açık pozisyonlar: {count}.'},
 'chat_portfolio_empty': {'ua': 'Портфель порожній. Додайте першу віртуальну покупку на картці монети.',
                          'en': 'Your portfolio is empty. Add your first virtual purchase on a coin card.',
                          'ru': 'Портфель пуст. Добавьте первую виртуальную покупку на карточке монеты.',
                          'es': 'El maletín está vacío. Agrega tu primera compra virtual en una tarjeta de monedas.',
                          'hi': 'ब्रीफकेस खाली है. कॉइन कार्ड पर अपनी पहली आभासी खरीदारी जोड़ें।',
                          'vi': 'Chiếc cặp trống rỗng. Thêm giao dịch mua ảo đầu tiên của bạn trên thẻ xu.',
                          'de': 'Die Aktentasche ist leer. Fügen Sie Ihren ersten virtuellen Einkauf einer Münzkarte hinzu.',
                          'pl': 'Teczka jest pusta. Dodaj swój pierwszy wirtualny zakup na karcie monety.',
                          'zh': '公文包是空的。将您的第一次虚拟购买添加到硬币卡上。',
                          'ja': 'ブリーフケースは空です。最初の仮想購入をコイン カードに追加します。',
                          'ko': '서류 가방이 비어 있습니다. 코인 카드에 첫 번째 가상 구매를 추가하세요.',
                          'pt': 'A pasta está vazia. Adicione sua primeira compra virtual em um cartão moeda.',
                          'tr': 'Evrak çantası boş. İlk sanal satın alımınızı jeton kartına ekleyin.'},
 'chat_news_risk': {'ua': 'Новинний фон негативний (індекс {index:+.2f}): ризик падіння ринку підвищений.',
                    'en': 'The news background is negative (index {index:+.2f}): the risk of a market drop is elevated.',
                    'ru': 'Новостной фон негативный (индекс {index:+.2f}): риск падения рынка повышен.',
                    'es': 'El trasfondo de las noticias es negativo (índice {index:+.2f}): aumenta el riesgo de caída del '
                          'mercado.',
                    'hi': 'समाचार पृष्ठभूमि नकारात्मक है ({index:+.2f} सूचकांक): बाजार में गिरावट का जोखिम बढ़ गया है।',
                    'vi': 'Nền tin tức tiêu cực (chỉ số {index:+.2f}): nguy cơ thị trường sụt giảm tăng lên.',
                    'de': 'Der Nachrichtenhintergrund ist negativ ({index:+.2f}-Index): Das Risiko eines Marktrückgangs ist '
                          'erhöht.',
                    'pl': 'Tło wiadomości jest negatywne (indeks {index:+.2f}): ryzyko spadku rynku wzrasta.',
                    'zh': '消息背景为负面（{index:+.2f}指数）：市场下跌风险加大。',
                    'ja': 'ニュースの背景はネガティブです ({index:+.2f} 指数): 市場下落のリスクが増大しています。',
                    'ko': '뉴스 배경은 부정적({index:+.2f} 지수): 시장 하락 위험이 높아진다.',
                    'pt': 'O cenário noticioso é negativo (índice {index:+.2f}): o risco de queda do mercado aumenta.',
                    'tr': 'Haberin arka planı olumsuz ({index:+.2f} endeksi): Piyasanın düşme riski artıyor.'},
 'chat_news_ok': {'ua': 'Новинний фон без критичного ризику (індекс {index:+.2f}).',
                  'en': 'The news background shows no critical risk (index {index:+.2f}).',
                  'ru': 'Новостной фон без критического риска (индекс {index:+.2f}).',
                  'es': 'Antecedentes de noticias sin riesgo crítico (índice {index:+.2f}).',
                  'hi': 'गंभीर जोखिम के बिना समाचार पृष्ठभूमि (सूचकांक {index:+.2f})।',
                  'vi': 'Nền tin tức không có rủi ro nghiêm trọng (chỉ số {index:+.2f}).',
                  'de': 'Nachrichtenhintergrund ohne kritisches Risiko (Index {index:+.2f}).',
                  'pl': 'Tło wiadomości bez ryzyka krytycznego (indeks {index:+.2f}).',
                  'zh': '无重大风险的新闻背景（指数{index:+.2f}）。',
                  'ja': '重大なリスクのないニュース背景 (インデックス {index:+.2f})。',
                  'ko': '심각한 위험이 없는 뉴스 배경(색인 {index:+.2f})',
                  'pt': 'Histórico de notícias sem risco crítico (índice {index:+.2f}).',
                  'tr': 'Kritik risk içermeyen haber geçmişi (indeks {index:+.2f}).'},
 'chat_market': {'ua': 'Огляд ринку за годину: {items}.',
                 'en': 'Market overview over the last hour: {items}.',
                 'ru': 'Обзор рынка за час: {items}.',
                 'es': 'Resumen del mercado horario: {items}.',
                 'hi': 'प्रति घंटा बाज़ार अवलोकन: {items}।',
                 'vi': 'Tổng quan về thị trường hàng giờ: {items}.',
                 'de': 'Stündliche Marktübersicht: {items}.',
                 'pl': 'Przegląd rynku godzinowego: {items}.',
                 'zh': '每小时市场概览：{items}。',
                 'ja': '時間ごとの市場概要: {items}。',
                 'ko': '시간별 시장 개요: {items}.',
                 'pt': 'Visão geral do mercado por hora: {items}.',
                 'tr': 'Saatlik piyasaya genel bakış: {items}.'},
 'chat_greet': {'ua': 'Привіт! Пояснюю терміни зі школи новачка та показую дані ринку. Відповіді формуються за правилами, а не '
                      'генеративною моделлю.',
                'en': "Greetings! I explain the terms from the beginner's school and show the market data. Answers are generated "
                      'by rules, not a generative model.',
                'ru': 'Привет! Объясняю сроки школы новичка и показываю данные рынка. Ответы формируются по правилам, а не по '
                      'генеративной модели.',
                'es': '¡Saludos! Explico los términos de la escuela para principiantes y muestro los datos del mercado. Las '
                      'respuestas se generan mediante reglas, no mediante un modelo generativo.',
                'hi': 'अभिवादन! मैं शुरुआती स्कूल की शर्तों को समझाता हूं और बाजार डेटा दिखाता हूं। उत्तर नियमों द्वारा उत्पन्न '
                      'होते हैं, जनरेटिव मॉडल से नहीं।',
                'vi': 'Xin chào! Tôi giải thích các thuật ngữ từ trường dành cho người mới bắt đầu và hiển thị dữ liệu thị '
                      'trường. Câu trả lời được tạo ra bởi các quy tắc, không phải là một mô hình tổng quát.',
                'de': 'Grüße! Ich erkläre die Begriffe aus der Einsteigerschule und zeige die Marktdaten. Antworten werden durch '
                      'Regeln generiert, nicht durch ein generatives Modell.',
                'pl': 'Pozdrowienia! Wyjaśniam pojęcia ze szkoły dla początkujących i pokazuję dane rynkowe. Odpowiedzi są '
                      'generowane na podstawie reguł, a nie modelu generatywnego.',
                'zh': '问候！我解释了初学者学校的术语并展示了市场数据。答案是由规则生成的，而不是生成模型。',
                'ja': 'こんにちは！初心者の学校から用語を説明し、市場データを示します。答えは生成モデルではなくルールによって生成されます。',
                'ko': '인사말! 초급부터 용어를 설명하고 시장 데이터를 보여줍니다. 답변은 생성 모델이 아닌 규칙에 의해 생성됩니다.',
                'pt': 'Saudações! Explico os termos da escola para iniciantes e mostro os dados do mercado. As respostas são '
                      'geradas por regras, não por um modelo generativo.',
                'tr': 'Selamlar! Başlangıç \u200b\u200bokulunun şartlarını açıklayıp piyasa verilerini gösteriyorum. Yanıtlar '
                      'üretken bir modelle değil, kurallarla oluşturulur.'},
 'chat_help': {'ua': 'Я довідковий асистент: пояснюю терміни та показую поточні дані за правилами, без генеративної мовної '
                     'моделі. Оберіть тему нижче або запитайте про BTC, портфель чи новини.',
               'en': 'I am a reference assistant: I explain terms and show current data according to rules, without a generative '
                     'language model. Choose a topic below or ask about BTC, portfolio or news.',
               'ru': 'Я справочный ассистент: объясняю сроки и показываю текущие данные по правилам без генеративной языковой '
                     'модели. Выберите тему ниже или попросите BTC, портфель или новости.',
               'es': 'Soy un asistente de referencia: explico términos y muestro datos actuales según reglas, sin un modelo de '
                     'lenguaje generativo. Elija un tema a continuación o pregunte sobre BTC, cartera o noticias.',
               'hi': 'मैं एक संदर्भ सहायक हूं: मैं नियमों के अनुसार शब्दों की व्याख्या करता हूं और वर्तमान डेटा दिखाता हूं, बिना '
                     'किसी जनरेटिव भाषा मॉडल के। नीचे कोई विषय चुनें या बीटीसी, पोर्टफोलियो या समाचार के बारे में पूछें।',
               'vi': 'Tôi là trợ lý tham khảo: Tôi giải thích các thuật ngữ và hiển thị dữ liệu hiện tại theo các quy tắc mà '
                     'không cần mô hình ngôn ngữ khái quát. Chọn một chủ đề bên dưới hoặc hỏi về BTC, danh mục đầu tư hoặc tin '
                     'tức.',
               'de': 'Ich bin Nachschlagewerker: Ich erkläre Begriffe und zeige aktuelle Daten nach Regeln, ohne generatives '
                     'Sprachmodell. Wählen Sie unten ein Thema oder fragen Sie nach BTC, Portfolio oder Neuigkeiten.',
               'pl': 'Jestem asystentem referencyjnym: wyjaśniam terminy i pokazuję aktualne dane zgodnie z zasadami, bez '
                     'generatywnego modelu języka. Wybierz temat poniżej lub zapytaj o BTC, portfolio lub aktualności.',
               'zh': '我是一名参考助理：我根据规则解释术语并显示当前数据，无需生成语言模型。选择下面的主题或询问有关 BTC、投资组合或新闻的问题。',
               'ja': '私はリファレンスアシスタントです。生成言語モデルを使用せずに、ルールに従って用語を説明し、現在のデータを表示します。以下のトピックを選択するか、BTC、ポートフォリオ、ニュースについて質問してください。',
               'ko': '나는 참조 보조자입니다. 생성 언어 모델 없이 규칙에 따라 용어를 설명하고 현재 데이터를 표시합니다. 아래에서 주제를 선택하거나 BTC, 포트폴리오 또는 뉴스에 대해 문의하세요.',
               'pt': 'Sou assistente de referência: explico termos e mostro dados atuais de acordo com regras, sem modelo de '
                     'linguagem generativa. Escolha um tema abaixo ou pergunte sobre BTC, portfólio ou novidades.',
               'tr': 'Ben bir referans asistanıyım: Üretken bir dil modeli olmadan, kurallara göre terimleri açıklıyor ve güncel '
                     'verileri gösteriyorum. Aşağıdan bir konu seçin veya BTC, portföy veya haberler hakkında soru sorun.'},
 'disclaimer': {'ua': 'Це навчальна демонстрація, а не фінансова порада.',
                'en': 'This is an educational demo, not financial advice.',
                'ru': 'Это учебная демонстрация, а не финансовый совет.',
                'es': 'Esta es una demostración educativa, no un consejo financiero.',
                'hi': 'यह एक शैक्षिक प्रदर्शन है, वित्तीय सलाह नहीं।',
                'vi': 'Đây là một minh chứng giáo dục, không phải lời khuyên tài chính.',
                'de': 'Dies ist eine pädagogische Demonstration, keine Finanzberatung.',
                'pl': 'To jest demonstracja edukacyjna, a nie porada finansowa.',
                'zh': '这是一个教育演示，而不是财务建议。',
                'ja': 'これは教育的なデモンストレーションであり、経済的なアドバイスではありません。',
                'ko': '이것은 재정적 조언이 아닌 교육적 시연입니다.',
                'pt': 'Esta é uma demonstração educacional, não um conselho financeiro.',
                'tr': 'Bu eğitici bir gösteri, mali tavsiye değil.'}}

SUGGESTIONS = {lang: [l["term"][lang] for l in SCHOOL if l["core"]] for lang in LANGS}



# ───────────────────────── Маршрути: сторінка та службові ─────────────────────────
@app.before_request
def validate_json_object():
    if request.method in ("POST", "PUT", "PATCH") and request.is_json:
        if not isinstance(request.get_json(silent=True), dict):
            return err("err_bad_numbers")


@app.route("/")
def index():
    try:
        return render_template("index.html", coins=COINS, refresh_seconds=PRICE_REFRESH_SECONDS, ui_translations=UI_TRANSLATIONS, school_lessons=SCHOOL, chat_labels=CHAT_LABELS, research_i18n=RESEARCH_I18N, language_flags=LANGUAGE_FLAGS)
    except TemplateNotFound:
        return ("<h2>Сервер працює ✅</h2><p>Файл <code>templates/index.html</code> не знайдено.</p>"
                "<p>Перевірка API: <a href='/api/prices'>/api/prices</a>, "
                "<a href='/api/health'>/api/health</a></p>")


@app.get("/api/health")
def health():
    with prices_lock:
        return jsonify({"status": "ok", "prices_updated_at": prices_state["updated_at"],
                        "price_source": prices_state["source"]})


@app.get("/api/meta")
def api_meta():
    """Налаштування для фронтенду: мови, монети, період оновлення, пороги, джерела новин."""
    return jsonify({"lang": get_lang(), "languages": list(LANGS), "default_lang": DEFAULT_LANG,
                    "refresh_seconds": PRICE_REFRESH_SECONDS, "history_points": HISTORY_LEN,
                    "history_step_seconds": HISTORY_STEP_SECONDS,
                    "coins": {s: m["name"] for s, m in COINS.items()},
                    "thresholds": {"drop": DROP_THRESHOLD, "rise": RISE_THRESHOLD},
                    "news_sources": OFFICIAL_SOURCES})


# ───────────────────────── Маршрути: ринок ─────────────────────────
@app.get("/api/prices")
def api_prices():
    lang = get_lang()
    with prices_lock:
        coins = list(prices_state["coins"].values())
        updated_at, source = prices_state["updated_at"], prices_state["source"]
    now = time.time()
    try:
        received = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        if received.tzinfo is None:
            raise ValueError("Quote time must include timezone")
        age = now - received.timestamp()
        valid_time = math.isfinite(age) and age >= -5
    except (AttributeError, TypeError, ValueError, OverflowError):
        age, valid_time = None, False
    stale = not coins or not valid_time or age > MARKET_MAX_AGE
    return jsonify({"coins": [serialize_coin(c, lang) for c in coins], "updated_at": updated_at,
                    "source": source, "lang": lang, "age_seconds": max(0, age) if valid_time else None,
                    "stale": stale, "stale_after_seconds": MARKET_MAX_AGE,
                    "thresholds": {"drop": DROP_THRESHOLD, "rise": RISE_THRESHOLD}})


@app.get("/api/coins/<symbol>")
def api_coin(symbol):
    """Аналітика монети для модального вікна: ціна, 60 точок історії, статистика, моя позиція."""
    sym = symbol.upper()
    if sym not in COINS:
        return err("err_unknown_coin", 404, coins=", ".join(COINS))
    data = coin_analysis(sym, get_lang())
    if data is None:
        return err("err_prices_wait", 503)
    return jsonify(data)


# ───────────────────────── Маршрути: портфель ─────────────────────────
@app.get("/api/portfolio")
def api_portfolio():
    return jsonify(portfolio_snapshot())


@app.post("/api/positions")
def add_position():
    data = request.get_json(silent=True) or {}
    symbol = str(data.get("symbol", "")).upper()
    qty, price = parse_positive(data, "quantity"), parse_positive(data, "buy_price")
    if symbol not in COINS:
        return err("err_unknown_coin", coins=", ".join(COINS))
    if qty is None or price is None:
        return err("err_bad_numbers")
    with db_write_lock, get_db() as db:
        cur = db.execute("INSERT INTO positions (symbol, quantity, avg_price, opened_at) VALUES (?,?,?,?)",
                         (symbol, qty, price, now_iso()))
    return jsonify({"id": cur.lastrowid}), 201


@app.post("/api/positions/<int:pos_id>/average")
def average_position(pos_id):
    """Усереднення: докупівля за нижчою ціною, середня ціна перераховується."""
    data = request.get_json(silent=True) or {}
    qty, price = parse_positive(data, "quantity"), parse_positive(data, "price")
    if qty is None or price is None:
        return err("err_bad_numbers")
    with db_write_lock, get_db() as db:
        pos = db.execute("SELECT * FROM positions WHERE id = ?", (pos_id,)).fetchone()
        if not pos:
            return err("err_not_found", 404)
        if price >= pos["avg_price"]:
            return err("err_avg_high", avg=pos["avg_price"])
        new_qty = pos["quantity"] + qty
        new_avg = (pos["quantity"] * pos["avg_price"] + qty * price) / new_qty
        db.execute("UPDATE positions SET quantity=?, avg_price=?, buys_count=buys_count+1 WHERE id=?",
                   (new_qty, new_avg, pos_id))
    return jsonify({"id": pos_id, "quantity": new_qty, "avg_price": new_avg,
                    "old_avg_price": pos["avg_price"]})


@app.post("/api/positions/<int:pos_id>/stop-loss")
def set_stop_loss(pos_id):
    """percent: 0.1–99 — увімкнути; null або 0 — вимкнути."""
    data = request.get_json(silent=True) or {}
    raw = data.get("percent")
    pct = None
    if raw not in (None, 0, "0", ""):
        pct = parse_positive(data, "percent")
        if pct is None or not 0.1 <= pct <= 99:
            return err("err_sl_range")
    with db_write_lock, get_db() as db:
        cur = db.execute("UPDATE positions SET stop_loss_pct=? WHERE id=?", (pct, pos_id))
        if cur.rowcount == 0:
            return err("err_not_found", 404)
    return jsonify({"id": pos_id, "stop_loss_pct": pct})


@app.post("/api/positions/<int:pos_id>/sell")
def sell_position(pos_id):
    """Віртуальний продаж за поточною ринковою ціною; результат іде в статистику."""
    with db_write_lock, get_db() as db:
        pos = db.execute("SELECT * FROM positions WHERE id = ?", (pos_id,)).fetchone()
        if not pos:
            return err("err_not_found", 404)
        price = current_price(pos["symbol"])
        if price is None:
            return err("err_prices_wait", 503)
        pnl, pct = close_position(db, pos, price, "manual")
    return jsonify({"symbol": pos["symbol"], "sell_price": price, "pnl": pnl, "pnl_pct": pct})


@app.delete("/api/positions/<int:pos_id>")
def delete_position(pos_id):
    """Видалити активну позицію БЕЗ фіксації результату (виправлення помилки введення)."""
    with db_write_lock, get_db() as db:
        pos = db.execute("SELECT symbol FROM positions WHERE id = ?", (pos_id,)).fetchone()
        if not pos:
            return err("err_not_found", 404)
        db.execute("DELETE FROM positions WHERE id = ?", (pos_id,))
    return jsonify({"deleted": pos_id, "symbol": pos["symbol"], "recorded_in_stats": False})


@app.post("/api/reset")
def reset_all():
    """Повне очищення positions і closed_trades. Потрібне явне підтвердження: {"confirm": true}."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or data.get("confirm") is not True:
        return err("err_confirm")
    with db_write_lock, get_db() as db:
        positions = db.execute("DELETE FROM positions").rowcount
        trades = db.execute("DELETE FROM closed_trades").rowcount
        db.execute("DELETE FROM sqlite_sequence WHERE name IN ('positions', 'closed_trades')")
    return jsonify({"reset": True, "deleted_positions": positions, "deleted_trades": trades})


# ───────────────────────── Маршрути: новини, сповіщення, статистика ─────────────────────────
@app.get("/api/news")
def api_news():
    return jsonify(build_news(get_lang()))


@app.get("/api/notifications")
def api_notifications():
    """Події (напр. спрацював Stop-Loss) з id більшим за since, текст — мовою запиту."""
    lang, since = get_lang(), request.args.get("since", default=0, type=int)
    with get_db() as db:
        rows = db.execute("SELECT * FROM events WHERE id > ? ORDER BY id LIMIT 50", (since,)).fetchall()
    out = []
    for r in rows:
        msg = r["message"]
        if r["kind"] == "stop_loss" and r["payload"]:
            try:
                msg = t("sl_event", lang, **json.loads(r["payload"]))
            except Exception:
                pass
        out.append({"id": r["id"], "kind": r["kind"], "message": msg, "created_at": r["created_at"]})
    return jsonify(out)


@app.get("/api/trades")
def api_trades():
    with get_db() as db:
        rows = db.execute("SELECT * FROM closed_trades ORDER BY id DESC LIMIT 200").fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/stats")
def api_stats():
    """Чистий фінансовий підсумок за місяць (?month=YYYY-MM, за замовчуванням поточний)."""
    month = request.args.get("month") or datetime.now().strftime("%Y-%m")
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        return err("err_bad_month")
    with get_db() as db:
        s = db.execute("""SELECT COUNT(*) AS trades, COALESCE(SUM(pnl),0) AS net_pnl,
                                 COALESCE(SUM(pnl > 0),0) AS wins, COALESCE(SUM(pnl <= 0),0) AS losses,
                                 COALESCE(MAX(pnl),0) AS best, COALESCE(MIN(pnl),0) AS worst
                          FROM closed_trades WHERE strftime('%Y-%m', closed_at) = ?""", (month,)).fetchone()
        by_symbol = db.execute("""SELECT symbol, COUNT(*) AS trades, SUM(pnl) AS net_pnl
                                  FROM closed_trades WHERE strftime('%Y-%m', closed_at) = ?
                                  GROUP BY symbol ORDER BY net_pnl DESC""", (month,)).fetchall()
        history = db.execute("""SELECT strftime('%Y-%m', closed_at) AS month, SUM(pnl) AS net_pnl,
                                       COUNT(*) AS trades
                                FROM closed_trades GROUP BY month ORDER BY month DESC LIMIT 12""").fetchall()
    summary = dict(s)
    summary["win_rate"] = round(summary["wins"] / summary["trades"] * 100, 1) if summary["trades"] else 0.0
    return jsonify({"month": month, "summary": summary,
                    "by_symbol": [dict(r) for r in by_symbol], "history": [dict(r) for r in history]})


# ───────────────────────── Маршрути: Школа новачка та ШІ-чат ─────────────────────────
@app.get("/api/school")
def api_school():
    lang = get_lang()
    return jsonify({"lang": lang, "lessons": [{"id": l["id"], "term": l["term"][lang], "text": l["text"][lang]}
                                               for l in SCHOOL]})


def lesson(lesson_id, lang):
    l = next(x for x in SCHOOL if x["id"] == lesson_id)
    return f"{l['term'][lang]}: {l['text'][lang]}"


def _has(text, words):
    return any(w in text for w in words)


def detect_symbol(text):
    for sym in COINS:
        if re.search(r"\b" + sym.lower() + r"\b", text) or any(a in text for a in COIN_ALIASES.get(sym, [COINS[sym]["name"].lower()])):
            return sym
    return None


@app.post("/api/ai-chat")
def ai_chat():
    """Довідковий асистент: перевірені уроки та поточні дані, без вигаданої LLM."""
    data = request.get_json(silent=True) or {}
    lang = get_lang()
    msg = str(data.get("message", "")).strip()
    if not msg:
        return err("err_empty_msg")
    if len(msg) > CHAT_MAX_LEN:
        return err("err_long_msg", n=CHAT_MAX_LEN)
    text = msg.lower()
    explicit = detect_symbol(text)
    ctx = str(data.get("symbol", "")).upper()
    ctx = ctx if ctx in COINS else None                  # монета, відкрита у вікні аналітики

    def coin_reply(sym):
        a = coin_analysis(sym, lang)
        if not a:
            return t("err_prices_wait", lang)
        s = a["stats"] or {}
        answer = t("chat_coin", lang, symbol=sym, price=f"{a['price']:,.8f}" if a["price"] < .01 else f"{a['price']:,.4f}" if a["price"] < 1 else f"{a['price']:,.2f}",
                 change=a["change_1h"], trend=t("trend_" + s.get("trend", "flat"), lang),
                 vol=s.get("volatility_pct", 0.0), reco=a["recommendation"])
        with prices_lock:
            source = prices_state["source"]
        if source == "simulation":
            answer += "\n" + UI_TRANSLATIONS[lang]["Демо-режим (імітація цін)"]
        if sym == "MATIC":
            answer += "\n" + UI_TRANSLATIONS[lang]["MATIC → POL: показана актуальна пара POL/USDT, не ціна старого токена MATIC."]
        with analysis_lock:
            setup = analysis_state["items"].get(sym)
            age = time.time() - analysis_state["updated_at"]
        if setup:
            labels = RESEARCH_I18N[lang]
            kind = setup["kind"] if age <= 120 and source == "binance" else "insufficient"
            answer += "\n\n" + labels[kind]
            for field, title in (("pros", "pros"), ("risks", "risks"), ("missing", "missing")):
                if setup[field]:
                    answer += "\n" + labels[title] + ": " + "; ".join(labels["reason_" + code] for code in setup[field])
            answer += "\n" + labels["screening_note"]
        return answer

    def market_reply():
        with prices_lock:
            coins = list(prices_state["coins"].values())
        items = "; ".join(f"{c['symbol']} {c['change_1h']:+.1f}% ({t('rec_' + c['signal'], lang)})" for c in coins)
        return t("chat_market", lang, items=items)

    selected = str(data.get("topic", ""))
    aliases = {
        "long": ["long", "лонг", "длинная позиция", "做多", "ロング", "롱", "लॉन्ग"],
        "short": ["short", "шорт", "做空", "ショート", "숏", "शॉर्ट"],
        "volatility": ["volatil", "волат", "波动", "変動", "변동", "biến động", "oynak", "zmienność", "अस्थिर"],
        "dca": ["dca", "усеред", "усред", "averag", "promedio", "coste", "定投", "積立", "적립", "trung bình"],
        "fomo": ["fomo"], "hodl": ["hodl", "холд"],
        "takeprofit": ["take-profit", "take profit", "тейк", "止盈", "利確", "익절"],
        "stoploss": ["stop-loss", "stop loss", "стоп", "止损", "損切", "손절"]}
    topic = next((l["id"] for l in SCHOOL if l["id"] == selected), None)
    if not topic:
        topic = next((k for k, words in aliases.items() if _has(text, words)), None)
    if not topic:
        topic = next((l["id"] for l in SCHOOL if l["term"][lang].lower() in text), None)
    if topic:
        intent, reply = "school_" + topic, lesson(topic, lang)
    elif _has(text, ["stop", "стоп"]):
        intent, reply = "school_stoploss", lesson("stoploss", lang)
    elif _has(text, ["усеред", "averag", "усредн"]):
        intent, reply = "school_averaging", lesson("averaging", lang)
    elif _has(text, ["pnl", "p&l", "прибут", "profit", "прибыл"]) and not explicit:
        intent, reply = "school_pnl", lesson("pnl", lang)
    elif explicit:
        intent, reply = "coin", coin_reply(explicit)
    elif _has(text, ["портфел", "баланс", "portfolio", "balance"]):
        snap = portfolio_snapshot()
        tot = snap["totals"]
        intent = "portfolio"
        reply = (t("chat_portfolio", lang, value=tot["value"], pnl=tot["pnl"], pct=tot["pnl_pct"],
                   count=len(snap["positions"])) if snap["positions"] else t("chat_portfolio_empty", lang))
    elif _has(text, ["новин", "news", "новост", "ризик", "риск", "risk"]):
        n = build_news(lang)
        intent = "news"
        reply = t("chat_news_risk" if n["high_risk"] else "chat_news_ok", lang, index=n["sentiment_index"])
    elif _has(text, ["куп", "buy", "прод", "sell", "що робити", "what should", "что делать"]):
        intent, reply = ("coin", coin_reply(ctx)) if ctx else ("market", market_reply())
    elif _has(text, ["привіт", "вітаю", "hello", "hi ", "hey", "привет", "здравств"]) or text in ("hi", "hey"):
        intent, reply = "greeting", t("chat_greet", lang)
    elif ctx:
        intent, reply = "coin", coin_reply(ctx)
    else:
        intent, reply = "help", t("chat_help", lang)

    return jsonify({"reply": reply, "intent": intent, "lang": lang, "engine": "reference-assistant",
                    "disclaimer": t("disclaimer", lang), "suggestions": SUGGESTIONS[lang]})


RESEARCH_I18N = {
  "ua": {
    "signals_nav": "🔔 Сигнали",
    "chart_nav": "Графік",
    "assistant_title": "Помічник для аналізу покупки",
    "assistant_note": "Ринкові ознаки, джерела новин і результати сигналів — без обіцянок зростання.",
    "signals_journal": "Сигнали та журнал",
    "candidate": "Кандидат для аналізу покупки",
    "watch": "Спостерігати",
    "risk": "Підвищений ризик",
    "calm": "Без значних сигналів",
    "insufficient": "Недостатньо даних",
    "pros": "Аргументи за",
    "risks": "Ризики",
    "missing": "Чого бракує",
    "none": "Ознак не виявлено",
    "live_missing": "Збираємо свіжі дані. Без актуальних котирувань торговий висновок недоступний.",
    "live_only": "Лише справжні дані Binance; правила оновлюються приблизно раз на хвилину",
    "hour": "год",
    "hours": "год",
    "open_chart": "Відкрити графік",
    "refresh": "Оновити",
    "screening_note": "Це фільтр ситуацій для дослідження, не наказ купувати. Сигнали не є перевіреною прибутковою стратегією.",
    "journal": "Журнал результатів сигналів",
    "coin": "Монета",
    "all_coins": "Усі монети",
    "outcome_note": "Показано зміну ціни, не прибуток угоди. Комісії та прослизання не враховані. Результат береться з ціни відкриття першої справжньої хвилини на або після горизонту; відхилення часу — менш як 60 секунд.",
    "more": "Показати ще",
    "methodology": "Як утворюється сигнал?",
    "methodology_text": "Версія market-context-v1. Кандидат: свіжі котирування Binance, щонайменше 40 послідовних закритих хвилинних свічок, EMA9 вище EMA21 і ціна вище EMA9, RSI14 від 45 до 68, зміна за годину від +0,5% до менш як +5%, обсяг останніх 5 завершених хвилин не менше 1,2 середнього обсягу п’ятихвилинного вікна за попередні 30 хвилин, годинний оборот від 1 млн USDT, незнижуваний Bitcoin і свіжі новини саме про монету. Негативні пов’язані заголовки блокують кандидата. Пороги є неперевіреними евристиками, а не ймовірністю зростання. Однаковий тип сигналу для монети записується не частіше разу на годину, будь-який новий — не частіше разу на 5 хвилин. Демо-котирування не створюють записи. Зміст новин не проходить фактчек.",
    "time_coin": "Час / монета",
    "status": "Статус",
    "signal_price": "Ціна сигналу",
    "details": "Деталі",
    "waiting": "Ще не настав час",
    "pending_data": "Очікуємо справжні дані",
    "measured": "Виміряно",
    "journal_empty": "Журнал поки порожній. Записи з’являться після справжніх сигналів, без вигаданої історії. Результати через 1, 4 і 24 години заповняться з часом.",
    "no_setups": "Зараз виразних ситуацій за правилами немає. Це нормальний результат, а не помилка.",
    "target_time": "Запланований час",
    "observed_time": "Фактичний час ціни",
    "coin_chart": "Графік криптовалюти",
    "chart_note": "Справжні ціни закриття свічок. Остання незавершена свічка може змінюватися; прогнозних точок немає.",
    "market": "Ринок",
    "window_1h": "1 година",
    "window_4h": "4 години",
    "window_1d": "1 доба",
    "window_7d": "7 діб",
    "paper_purchase": "Віртуальна покупка",
    "loading_real": "Завантажуємо справжні свічки…",
    "no_fake_chart": "Штучний графік замість справжнього не підставляється.",
    "no_data": "Дані недоступні",
    "shown_window": "у показаному вікні",
    "updated": "Оновлено",
    "interval": "Крок свічки",
    "high": "Максимум",
    "low": "Мінімум",
    "time": "Час",
    "price": "Ціна",
    "observations": "Таблиця спостережень",
    "chart_library_error": "Бібліотека графіка не завантажилася. Справжні значення доступні в таблиці нижче.",
    "news_title": "Новини · джерела",
    "publisher_check_note": "Перевіряємо HTTPS-домен видання та час публікації; аналіз настрою — за словами заголовка.",
    "available": "Доступне",
    "unavailable": "Недоступне",
    "not_factcheck": "Перевірка домену підтверджує походження посилання, а не правдивість новини. Це не фактчек.",
    "rss_missing": "Справжні RSS-новини зараз недоступні. Вигадані заголовки не показуються.",
    "time_unknown": "Час публікації невідомий",
    "domain_checked": "Домен перевірено",
    "fresh_article": "Публікація до 24 год",
    "old_article": "Старе або невідоме датування",
    "sentiment_negative": "Негативна лексика",
    "sentiment_positive": "Позитивна лексика",
    "sentiment_neutral": "Нейтральна лексика",
    "similar_titles": "Схожі заголовки також є у",
    "not_independent_proof": "Це не доказ незалежного підтвердження.",
    "original_title": "Оригінальний заголовок",
    "source_links": "Джерела та посилання",
    "source_links_note": "Читаємо RSS CoinTelegraph і CoinDesk. Bloomberg та Binance наведені лише як посилання; їхній вміст не аналізується.",
    "reason_fresh_binance": "Немає достатньо свіжих котирувань Binance; демо та резервні USD-ціни не використовуються для сигналів.",
    "reason_candles": "Недостатньо свіжих послідовних хвилинних свічок.",
    "reason_trend_up": "EMA9 вище EMA21, а ціна — вище EMA9: короткий напрям висхідний.",
    "reason_trend_weak": "Ціна або коротка середня не підтверджує висхідний напрям.",
    "reason_volume_up": "Оборот останніх 5 хвилин підвищений відносно попередніх 30 хвилин.",
    "reason_volume_weak": "Обсяг не підтверджує посилення руху.",
    "reason_btc_up": "Bitcoin за останню годину не знижується.",
    "reason_btc_down": "Bitcoin знижується; це ризик для руху монети.",
    "reason_btc_data": "Бракує свіжих даних Bitcoin.",
    "reason_rsi_hot": "RSI14 вище 75: рух може бути перегрітим, але це не гарантує розвороту.",
    "reason_large_move": "Зміна за годину щонайменше 5%: підвищений ризик різкого руху.",
    "reason_negative_headlines": "У пов’язаних або макроекономічних заголовках є негативна лексика. Це не встановлена причина руху ціни.",
    "reason_coin_news": "Немає свіжих заголовків саме про цю монету.",
    "reason_fresh_news": "Немає свіжих новин із перевіреним доменом і часом публікації.",
    "reason_turnover": "Годинний оборот недоступний.",
    "reason_low_turnover": "Годинний оборот нижче порога 1 млн USDT. Це грубий фільтр активності, не вимір глибини ринку.",
    "api_invalid": "Невідома монета або період графіка.",
    "api_chart_unavailable": "Справжні дані графіка недоступні. Спробуйте пізніше.",
    "movement_down": "Різке падіння — перевірте причину",
    "movement_up": "Різке зростання — перевірте ризики",
    "movement_calm": "Значних змін не виявлено",
    "footer_note": "Аналіз допомагає досліджувати покупку, але не прогнозує зростання та не є фінансовою порадою.",
    "reset_note": "Усі активні позиції та закриті угоди буде видалено. Журнал сигналів, ціни та налаштування залишаться.",
    "legend_down": "падіння ≥ 5% — перевірити причину",
    "legend_up": "ріст ≥ 5% — перевірити ризики"
  },
  "en": {
    "signals_nav": "🔔 Signals",
    "chart_nav": "Chart",
    "assistant_title": "Purchase analysis assistant",
    "assistant_note": "Market signs, news sources, and signal results — without the promise of growth.",
    "signals_journal": "Signals and log",
    "candidate": "Candidate for purchase research",
    "watch": "Watch",
    "risk": "Elevated risk",
    "calm": "No significant setup",
    "insufficient": "Insufficient data",
    "pros": "Supporting factors",
    "risks": "Risks",
    "missing": "Missing context",
    "none": "No signs were found",
    "live_missing": "We collect fresh data. Without current quotations, the trading conclusion is not available.",
    "live_only": "Only genuine Binance data; rules are updated approximately once per minute",
    "hour": "h",
    "hours": "h",
    "open_chart": "Open schedule",
    "refresh": "Update",
    "screening_note": "This is a filter of situations to research, not a buy order. Signals are not a proven profitable strategy.",
    "journal": "Log of signal results",
    "coin": "Coin",
    "all_coins": "All coins",
    "outcome_note": "The price change is shown, not the profit of the deal. Commissions and slippage are not taken into account. The result is taken from the opening price of the first real minute on or after the horizon; time deviation is less than 60 seconds.",
    "more": "Show more",
    "methodology": "How is the signal generated?",
    "methodology_text": "Version market-context-v1. Candidate: Binance fresh quotes, at least 40 consecutive closed minute candles, EMA9 above EMA21 and price above EMA9, RSI14 from 45 to 68, hourly change from +0.5% to less than +5%, volume of the last 5 completed minutes at least 1.2 of the average volume of the five-minute window of the previous 30 minutes, hourly volume of 1 million USDT, non-declining Bitcoin and fresh news about the coin itself. Negative related headlines block the candidate. Thresholds are untested heuristics, not growth probabilities. The same type of signal for a coin is recorded no more than once an hour, any new one - no more than once every 5 minutes. Demo quotes do not create records. The content of the news does not pass the fact check.",
    "time_coin": "Time / coin",
    "status": "Status",
    "signal_price": "Signal price",
    "details": "Details",
    "waiting": "It's not time yet",
    "pending_data": "We are waiting for real data",
    "measured": "Measured",
    "journal_empty": "The magazine is still empty. Entries will appear after real signals, without a fictional story. Results after 1, 4 and 24 hours will populate over time.",
    "no_setups": "Now there are no specific situations according to the rules. This is a normal result and not an error.",
    "target_time": "Scheduled time",
    "observed_time": "Actual price time",
    "coin_chart": "Cryptocurrency chart",
    "chart_note": "Actual candle closing prices. The last unfinished candle can change; there are no predictive points.",
    "market": "the market",
    "window_1h": "1 hour",
    "window_4h": "4 hours",
    "window_1d": "1 day",
    "window_7d": "7 days",
    "paper_purchase": "Virtual purchase",
    "loading_real": "Loading real candles...",
    "no_fake_chart": "An artificial schedule is not substituted for the real one.",
    "no_data": "Data not available",
    "shown_window": "in the displayed window",
    "updated": "Updated",
    "interval": "Step of the candle",
    "high": "Maximum",
    "low": "Minimum",
    "time": "time",
    "price": "Price",
    "observations": "Table of observations",
    "chart_library_error": "Graphics library failed to load. Actual values ​​are available in the table below.",
    "news_title": "News · sources",
    "publisher_check_note": "We check the HTTPS domain of the publication and the time of publication; sentiment analysis - as the title says.",
    "available": "Available",
    "unavailable": "Not available",
    "not_factcheck": "Domain verification verifies the origin of the link, not the veracity of the news. This is not a fact check.",
    "rss_missing": "Real RSS news is currently unavailable. Fictional titles are not displayed.",
    "time_unknown": "The time of publication is unknown",
    "domain_checked": "Domain verified",
    "fresh_article": "Publication up to 24 hours",
    "old_article": "Old or unknown dating",
    "sentiment_negative": "Negative vocabulary",
    "sentiment_positive": "Positive vocabulary",
    "sentiment_neutral": "Neutral vocabulary",
    "similar_titles": "Similar headings are also found in",
    "not_independent_proof": "This is not proof of independent confirmation.",
    "original_title": "Original title",
    "source_links": "Sources and links",
    "source_links_note": "We read CoinTelegraph and CoinDesk RSS. Bloomberg and Binance are provided as references only; their content is not analyzed.",
    "reason_fresh_binance": "Not enough fresh Binance quotes; demo and reserve USD prices are not used for signals.",
    "reason_candles": "Not enough fresh consecutive minute candles.",
    "reason_trend_up": "EMA9 is above EMA21 and the price is above EMA9: the short direction is up.",
    "reason_trend_weak": "The price or the short average does not confirm the uptrend.",
    "reason_volume_up": "The turnover of the last 5 minutes is increased compared to the previous 30 minutes.",
    "reason_volume_weak": "The volume does not confirm the strengthening of the movement.",
    "reason_btc_up": "Bitcoin has not decreased in the last hour.",
    "reason_btc_down": "Bitcoin is down; it is a risk to the movement of the coin.",
    "reason_btc_data": "No fresh Bitcoin data.",
    "reason_rsi_hot": "RSI14 above 75: the movement may be overheated, but this does not guarantee a reversal.",
    "reason_large_move": "Hourly change of at least 5%: increased risk of sudden movement.",
    "reason_negative_headlines": "Related or macroeconomic headlines contain negative language. This is not an established reason for the price movement.",
    "reason_coin_news": "There are no recent headlines about this particular coin.",
    "reason_fresh_news": "No breaking news with verified domain and publication time.",
    "reason_turnover": "Hourly turnover is not available.",
    "reason_low_turnover": "Hourly turnover below the threshold of 1 million USDT. This is a crude activity filter, not a measure of market depth.",
    "api_invalid": "Unknown coin or chart period.",
    "api_chart_unavailable": "Actual chart data is not available. Try again later.",
    "movement_down": "Sharp drop - check the reason",
    "movement_up": "Sharp growth - check the risks",
    "movement_calm": "No significant changes were found",
    "footer_note": "The analysis helps to research a purchase, but does not predict growth and does not constitute financial advice.",
    "reset_note": "All active positions and closed deals will be deleted. The signal log, prices and settings will remain.",
    "legend_down": "drop ≥ 5% — check the cause",
    "legend_up": "growth ≥ 5% — check the risks"
  },
  "ru": {
    "signals_nav": "🔔 Сигналы",
    "chart_nav": "График",
    "assistant_title": "Помощник для анализа покупки",
    "assistant_note": "Рыночные признаки, источники новостей и результаты сигналов без обещаний роста.",
    "signals_journal": "Сигналы и журнал",
    "candidate": "Кандидат для анализа покупки",
    "watch": "Наблюдать",
    "risk": "Повышенный риск",
    "calm": "Без значительных сигналов",
    "insufficient": "Недостаточно данных",
    "pros": "Аргументы по",
    "risks": "Риски",
    "missing": "Чего не хватает",
    "none": "Признаков не обнаружено",
    "live_missing": "Собираем свежие данные. Без актуальных котировок торговый вывод недоступен.",
    "live_only": "Только подлинные данные Binance; правила обновляются примерно раз в минуту",
    "hour": "год",
    "hours": "год",
    "open_chart": "Открыть график",
    "refresh": "Обновить",
    "screening_note": "Это фильтр ситуаций для исследования, не приказ покупать. Сигналы не являются проверенной прибыльной стратегией.",
    "journal": "Журнал результатов сигналов",
    "coin": "Монета",
    "all_coins": "Все монеты",
    "outcome_note": "Показано изменение цены, не прибыль сделки. Комиссии и проскальзывания не учтены. Результат берется из цены открытия первой настоящей минуты или после горизонта; отклонение времени - менее 60 секунд.",
    "more": "Показать еще",
    "methodology": "Как появляется сигнал?",
    "methodology_text": "Версия market-context-v1. Кандидат: свежие котировки Binance, по меньшей мере 40 последовательных закрытых минутных свечей, EMA9 выше EMA21 и цена выше EMA9, RSI14 от 45 до 68, изменение за час от +0,5% до менее +5%, объем последних 5 завершенных минут от менее 1,2 среднего объема п' 1 млн USDT, неснижаемый Bitcoin и свежие новости именно о монете. Негативные связанные заголовки блокируют кандидата. Пороги являются непроверенными эвристиками, а не вероятностью роста. Одинаковый тип сигнала для монеты записывается не чаще раза в час, любой новый – не чаще раза в 5 минут. Демо-котировки не создают записи. Содержание новостей не проходит фактчек.",
    "time_coin": "Время/монета",
    "status": "Статус",
    "signal_price": "Цена сигнала",
    "details": "Подробности",
    "waiting": "Еще не пришло время",
    "pending_data": "Ожидаем подлинные данные",
    "measured": "Измерено",
    "journal_empty": "Журнал пока пуст. Записи появятся после настоящих сигналов без вымышленной истории. Результаты через 1, 4 и 24 часа заполнятся со временем.",
    "no_setups": "Сейчас внятных ситуаций по правилам нет. Это обычный итог, а не ошибка.",
    "target_time": "Планируемое время",
    "observed_time": "Фактическое время цены",
    "coin_chart": "График криптовалюты",
    "chart_note": "Настоящие цены закрытия свечей. Последняя незавершенная свеча может изменяться; прогнозных точек нет.",
    "market": "Рынок",
    "window_1h": "1 час",
    "window_4h": "4 часа",
    "window_1d": "1 сутки",
    "window_7d": "7 суток",
    "paper_purchase": "Виртуальная покупка",
    "loading_real": "Загружаем настоящие свечи…",
    "no_fake_chart": "Искусственный график вместо подлинного не подставляется.",
    "no_data": "Данные недоступны",
    "shown_window": "в показанном окне",
    "updated": "Обновлено",
    "interval": "Шаг свечи",
    "high": "Максимум",
    "low": "Минимум",
    "time": "Время",
    "price": "Цена",
    "observations": "Таблица наблюдений",
    "chart_library_error": "Библиотека графика не загрузилась. Подлинные значения доступны в таблице ниже.",
    "news_title": "Новости · источники",
    "publisher_check_note": "Проверяем HTTPS-домен издания и время публикации; анализ настроения – по словам заголовка.",
    "available": "Доступное",
    "unavailable": "Недоступно",
    "not_factcheck": "Проверка домена подтверждает происхождение ссылки, а не достоверность новости. Это не фактчек.",
    "rss_missing": "Настоящие RSS-новости сейчас недоступны. Вымышленные заголовки не показываются.",
    "time_unknown": "Время публикации неизвестно",
    "domain_checked": "Домен проверено",
    "fresh_article": "Публикация до 24 часов",
    "old_article": "Старая или неизвестная датировка",
    "sentiment_negative": "Отрицательная лексика",
    "sentiment_positive": "Положительная лексика",
    "sentiment_neutral": "Нейтральная лексика",
    "similar_titles": "Похожие заголовки также есть у",
    "not_independent_proof": "Это не доказательство независимого подтверждения.",
    "original_title": "Оригинальное название",
    "source_links": "Источники и ссылки",
    "source_links_note": "Читаем RSS CoinTelegraph и CoinDesk. Bloomberg и Binance приведены только в качестве ссылки; их содержание не анализируется.",
    "reason_fresh_binance": "Нет достаточно свежих котировок Binance; демо и резервные цены USD не используются для сигналов.",
    "reason_candles": "Недостаточно свежих последовательных минутных свечей.",
    "reason_trend_up": "EMA9 выше EMA21, а цена – выше EMA9: короткое направление восходящее.",
    "reason_trend_weak": "Цена или короткая средняя не подтверждает восходящее направление.",
    "reason_volume_up": "Оборот последних 5 минут повышен относительно предыдущих 30 минут.",
    "reason_volume_weak": "Объем не подтверждает усиление движения.",
    "reason_btc_up": "Bitcoin за последнее время не снижается.",
    "reason_btc_down": "Bitcoin снижается; это риск для движения монеты.",
    "reason_btc_data": "Недостает новых данных Bitcoin.",
    "reason_rsi_hot": "RSI14 выше 75: движение может быть перегретым, но это не гарантирует разворота.",
    "reason_large_move": "Изменение в час не менее 5%: повышен риск резкого движения.",
    "reason_negative_headlines": "В связанных или макроэкономических заголовках есть отрицательная лексика. Это не установленная причина движения цены.",
    "reason_coin_news": "Нет свежих заголовков именно об этой монете.",
    "reason_fresh_news": "Нет свежих новостей с проверенным доменом и временем публикации.",
    "reason_turnover": "Часовой оборот недоступен.",
    "reason_low_turnover": "Часовой оборот ниже порога 1 млн. USDT. Это грубый фильтр активности, не измерение глубины рынка.",
    "api_invalid": "Неизвестная монета или период графика.",
    "api_chart_unavailable": "Настоящие графики недоступны. Попытайтесь позже.",
    "movement_down": "Резкое падение – проверьте причину",
    "movement_up": "Резкий рост – проверьте риски",
    "movement_calm": "Значительных изменений не обнаружено",
    "footer_note": "Анализ помогает исследовать покупку, но не прогнозирует роста и не является финансовым советом.",
    "reset_note": "Все активные позиции и закрытые сделки будут удалены. Журнал сигналов, цены и настройки останутся.",
    "legend_down": "падение ≥ 5% - проверить причину",
    "legend_up": "рост ≥ 5% - проверить риски"
  },
  "es": {
    "signals_nav": "🔔 Señales",
    "chart_nav": "Horario",
    "assistant_title": "Asistente de análisis de compras",
    "assistant_note": "Señales de mercado, fuentes de noticias y resultados de señales, sin la promesa de crecimiento.",
    "signals_journal": "Señales y registro",
    "candidate": "Candidato para análisis de compra.",
    "watch": "observar",
    "risk": "Mayor riesgo",
    "calm": "Sin señales significativas",
    "insufficient": "Datos insuficientes",
    "pros": "Argumentos a favor",
    "risks": "Riesgos",
    "missing": "¿Qué falta?",
    "none": "No se encontraron señales",
    "live_missing": "Recopilamos datos nuevos. Sin cotizaciones actuales no se puede llegar a una conclusión comercial.",
    "live_only": "Solo datos genuinos de Binance; las reglas se actualizan aproximadamente una vez por minuto",
    "hour": "horas",
    "hours": "horas",
    "open_chart": "Horario abierto",
    "refresh": "Actualizar",
    "screening_note": "Este es un filtro de situaciones a investigar, no una orden de compra. Las señales no son una estrategia rentable comprobada.",
    "journal": "Registro de resultados de señales",
    "coin": "moneda",
    "all_coins": "Todas las monedas",
    "outcome_note": "Se muestra el cambio de precio, no el beneficio del trato. No se tienen en cuenta las comisiones ni los deslizamientos. El resultado se toma del precio de apertura del primer minuto real en o después del horizonte; la desviación de tiempo es inferior a 60 segundos.",
    "more": "Mostrar más",
    "methodology": "¿Cómo se genera la señal?",
    "methodology_text": "Versión mercado-contexto-v1. Candidato: cotizaciones nuevas de Binance, al menos 40 velas de minutos cerradas consecutivas, EMA9 por encima de EMA21 y precio por encima de EMA9, RSI14 de 45 a 68, cambio horario de +0,5% a menos de +5%, volumen de los últimos 5 minutos completados al menos 1,2 del volumen promedio de la ventana de cinco minutos de los 30 minutos anteriores, volumen por hora de 1 millón de USDT, Bitcoin sin declinar y nuevas noticias sobre el moneda misma. Los titulares negativos relacionados bloquean al candidato. Los umbrales son heurísticas no probadas, no probabilidades de crecimiento. El mismo tipo de señal para una moneda se registra no más de una vez por hora, cualquier nueva, no más de una vez cada 5 minutos. Las cotizaciones de demostración no crean registros. El contenido de la noticia no pasa la verificación de hechos.",
    "time_coin": "Tiempo/moneda",
    "status": "Estado",
    "signal_price": "Precio de la señal",
    "details": "Detalles",
    "waiting": "aún no es el momento",
    "pending_data": "Estamos esperando datos reales.",
    "measured": "medido",
    "journal_empty": "La revista todavía está vacía. Las entradas aparecerán después de señales reales, sin historia ficticia. Los resultados después de 1, 4 y 24 horas se completarán con el tiempo.",
    "no_setups": "Ahora no existen situaciones específicas según las reglas. Este es un resultado normal y no un error.",
    "target_time": "hora programada",
    "observed_time": "Precio real tiempo",
    "coin_chart": "gráfico de criptomonedas",
    "chart_note": "Precios reales de cierre de velas. La última vela sin terminar puede cambiar; no hay puntos predictivos.",
    "market": "el mercado",
    "window_1h": "1 hora",
    "window_4h": "4 horas",
    "window_1d": "1 dia",
    "window_7d": "7 dias",
    "paper_purchase": "Compra virtual",
    "loading_real": "Cargando velas reales...",
    "no_fake_chart": "Un horario artificial no sustituye al real.",
    "no_data": "Datos no disponibles",
    "shown_window": "en la ventana mostrada",
    "updated": "Actualizado",
    "interval": "paso de la vela",
    "high": "Máximo",
    "low": "Mínimo",
    "time": "tiempo",
    "price": "Precio",
    "observations": "Tabla de observaciones",
    "chart_library_error": "La biblioteca de gráficos no se pudo cargar. Los valores reales están disponibles en la siguiente tabla.",
    "news_title": "Noticias · fuentes",
    "publisher_check_note": "Comprobamos el dominio HTTPS de la publicación y la hora de publicación; análisis de sentimientos, como dice el título.",
    "available": "Disponible",
    "unavailable": "No disponible",
    "not_factcheck": "La verificación de dominio verifica el origen del enlace, no la veracidad de la noticia. Esto no es una verificación de hechos.",
    "rss_missing": "Las noticias RSS reales no están disponibles actualmente. No se muestran títulos de ficción.",
    "time_unknown": "Se desconoce la hora de publicación.",
    "domain_checked": "Dominio verificado",
    "fresh_article": "Publicación hasta 24 horas",
    "old_article": "Citas antiguas o desconocidas.",
    "sentiment_negative": "Vocabulario negativo",
    "sentiment_positive": "Vocabulario positivo",
    "sentiment_neutral": "Vocabulario neutro",
    "similar_titles": "Títulos similares también se encuentran en",
    "not_independent_proof": "Esta no es una prueba de confirmación independiente.",
    "original_title": "Título original",
    "source_links": "Fuentes y enlaces",
    "source_links_note": "Leemos CoinTelegraph y CoinDesk RSS. Bloomberg y Binance se proporcionan únicamente como referencia; su contenido no se analiza.",
    "reason_fresh_binance": "No hay suficientes cotizaciones nuevas de Binance; Los precios de demostración y reserva en USD no se utilizan para señales.",
    "reason_candles": "No hay suficientes velas de minutos consecutivas y frescas.",
    "reason_trend_up": "EMA9 está por encima de EMA21 y el precio está por encima de EMA9: la dirección corta es alcista.",
    "reason_trend_weak": "El precio o la media corta no confirman la tendencia alcista.",
    "reason_volume_up": "El volumen de negocios de los últimos 5 minutos aumenta respecto a los 30 minutos anteriores.",
    "reason_volume_weak": "El volumen no confirma el fortalecimiento del movimiento.",
    "reason_btc_up": "Bitcoin no ha bajado en la última hora.",
    "reason_btc_down": "Bitcoin ha caído; es un riesgo para el movimiento de la moneda.",
    "reason_btc_data": "No hay datos nuevos de Bitcoin.",
    "reason_rsi_hot": "RSI14 por encima de 75: el movimiento puede estar sobrecalentado, pero esto no garantiza una reversión.",
    "reason_large_move": "Cambio horario de al menos un 5%: mayor riesgo de movimiento brusco.",
    "reason_negative_headlines": "Los titulares relacionados o macroeconómicos contienen lenguaje negativo. Ésta no es una razón establecida para el movimiento de precios.",
    "reason_coin_news": "No hay titulares recientes sobre esta moneda en particular.",
    "reason_fresh_news": "Sin noticias de última hora con dominio verificado y hora de publicación.",
    "reason_turnover": "La facturación horaria no está disponible.",
    "reason_low_turnover": "Volumen de negocios por hora por debajo del umbral de 1 millón de USDT. Se trata de un burdo filtro de actividad, no de una medida de la profundidad del mercado.",
    "api_invalid": "Moneda o período de gráfico desconocido.",
    "api_chart_unavailable": "Los datos reales del gráfico no están disponibles. Vuelve a intentarlo más tarde.",
    "movement_down": "Caída brusca: compruebe el motivo",
    "movement_up": "Fuerte crecimiento: compruebe los riesgos",
    "movement_calm": "No se encontraron cambios significativos.",
    "footer_note": "El análisis ayuda a investigar una compra, pero no predice el crecimiento y no constituye un asesoramiento financiero.",
    "reset_note": "Se eliminarán todas las posiciones activas y acuerdos cerrados. El registro de señales, los precios y la configuración permanecerán.",
    "legend_down": "caída ≥ 5%: verifique la causa",
    "legend_up": "crecimiento ≥ 5% — verifique los riesgos"
  },
  "hi": {
    "signals_nav": "🔔संकेत",
    "chart_nav": "अनुसूची",
    "assistant_title": "खरीद विश्लेषण सहायक",
    "assistant_note": "बाज़ार संकेत, समाचार स्रोत, और संकेत परिणाम - विकास के वादे के बिना।",
    "signals_journal": "सिग्नल और लॉग",
    "candidate": "खरीद विश्लेषण के लिए उम्मीदवार",
    "watch": "निरीक्षण करना",
    "risk": "खतरा बढ़ गया",
    "calm": "कोई महत्वपूर्ण संकेत नहीं",
    "insufficient": "अपर्याप्त डेटा",
    "pros": "के लिए तर्क",
    "risks": "जोखिम",
    "missing": "क्या कमी है?",
    "none": "कोई लक्षण नहीं मिले",
    "live_missing": "हम ताजा डेटा एकत्र करते हैं। वर्तमान कोटेशन के बिना, ट्रेडिंग निष्कर्ष उपलब्ध नहीं है।",
    "live_only": "केवल वास्तविक बायनेन्स डेटा; नियम प्रति मिनट लगभग एक बार अपडेट किये जाते हैं",
    "hour": "घंटे",
    "hours": "घंटे",
    "open_chart": "शेड्यूल खोलें",
    "refresh": "अद्यतन करें",
    "screening_note": "यह शोध के लिए स्थितियों का फ़िल्टर है, खरीदने का ऑर्डर नहीं। सिग्नल कोई सिद्ध लाभदायक रणनीति नहीं हैं।",
    "journal": "सिग्नल परिणामों का लॉग",
    "coin": "सिक्का",
    "all_coins": "सभी सिक्के",
    "outcome_note": "मूल्य परिवर्तन दिखाया गया है, सौदे का लाभ नहीं। कमीशन और फिसलन पर ध्यान नहीं दिया जाता है। परिणाम क्षितिज पर या उसके बाद पहले वास्तविक मिनट के शुरुआती मूल्य से लिया जाता है; समय विचलन 60 सेकंड से कम है.",
    "more": "और दिखाएँ",
    "methodology": "सिग्नल कैसे उत्पन्न होता है?",
    "methodology_text": "संस्करण बाज़ार-संदर्भ-v1. उम्मीदवार: बिनेंस ताजा उद्धरण, कम से कम 40 लगातार बंद मिनट मोमबत्तियाँ, ईएमए9 ईएमए21 से ऊपर और कीमत ईएमए9 से ऊपर, आरएसआई14 45 से 68, प्रति घंटा परिवर्तन +0.5% से +5% से कम, पिछले 5 पूर्ण मिनटों की मात्रा पिछले 30 मिनट की पांच मिनट की विंडो की औसत मात्रा का कम से कम 1.2, 1 मिलियन यूएसडीटी की प्रति घंटा मात्रा, गैर-घटती बिटकॉइन और इसके बारे में ताजा खबर सिक्का ही. नकारात्मक संबंधित सुर्खियाँ उम्मीदवार को रोक देती हैं। सीमाएँ अपरीक्षित अनुमान हैं, विकास की संभावनाएँ नहीं। एक सिक्के के लिए एक ही प्रकार का संकेत प्रति घंटे में एक बार से अधिक दर्ज नहीं किया जाता है, किसी भी नए सिक्के के लिए - हर 5 मिनट में एक बार से अधिक नहीं। डेमो उद्धरण रिकॉर्ड नहीं बनाते हैं. समाचार की सामग्री तथ्यात्मक जांच से खरी नहीं उतरती।",
    "time_coin": "समय / सिक्का",
    "status": "स्थिति",
    "signal_price": "सिग्नल की कीमत",
    "details": "विवरण",
    "waiting": "अभी समय नहीं हुआ है",
    "pending_data": "हम वास्तविक आंकड़ों का इंतजार कर रहे हैं",
    "measured": "नापा गया",
    "journal_empty": "पत्रिका अभी भी खाली है. प्रविष्टियाँ किसी काल्पनिक कहानी के बिना, वास्तविक संकेतों के बाद दिखाई देंगी। 1, 4 और 24 घंटों के बाद के परिणाम समय के साथ सामने आ जाएंगे।",
    "no_setups": "अब नियमानुसार कोई विशेष स्थिति नहीं है। यह एक सामान्य परिणाम है और कोई त्रुटि नहीं है.",
    "target_time": "निर्धारित समय",
    "observed_time": "वास्तविक मूल्य समय",
    "coin_chart": "क्रिप्टोक्यूरेंसी चार्ट",
    "chart_note": "वास्तविक मोमबत्ती समापन मूल्य। आखिरी अधूरी मोमबत्ती बदल सकती है; कोई पूर्वानुमानित बिंदु नहीं हैं.",
    "market": "बाजार",
    "window_1h": "1 घंटा",
    "window_4h": "4 घंटे",
    "window_1d": "1 दिन",
    "window_7d": "7 दिन",
    "paper_purchase": "आभासी खरीदारी",
    "loading_real": "असली मोमबत्तियाँ लोड हो रही हैं...",
    "no_fake_chart": "कृत्रिम शेड्यूल को वास्तविक शेड्यूल से प्रतिस्थापित नहीं किया जा सकता।",
    "no_data": "डेटा उपलब्ध नहीं है",
    "shown_window": "प्रदर्शित विंडो में",
    "updated": "अद्यतन किया गया",
    "interval": "मोमबत्ती का चरण",
    "high": "अधिकतम",
    "low": "न्यूनतम",
    "time": "समय",
    "price": "कीमत",
    "observations": "प्रेक्षणों की तालिका",
    "chart_library_error": "ग्राफ़िक्स लाइब्रेरी लोड होने में विफल रही. वास्तविक मान नीचे दी गई तालिका में उपलब्ध हैं।",
    "news_title": "समाचार · स्रोत",
    "publisher_check_note": "हम प्रकाशन के HTTPS डोमेन और प्रकाशन के समय की जाँच करते हैं; भावना विश्लेषण - जैसा कि शीर्षक से पता चलता है।",
    "available": "उपलब्ध",
    "unavailable": "उपलब्ध नहीं है",
    "not_factcheck": "डोमेन सत्यापन लिंक की उत्पत्ति की पुष्टि करता है, न कि समाचार की सत्यता की। यह कोई तथ्य जांच नहीं है.",
    "rss_missing": "वास्तविक आरएसएस समाचार फिलहाल अनुपलब्ध है। काल्पनिक शीर्षक प्रदर्शित नहीं किए जाते.",
    "time_unknown": "प्रकाशन का समय अज्ञात है",
    "domain_checked": "डोमेन सत्यापित",
    "fresh_article": "24 घंटे तक प्रकाशन",
    "old_article": "पुरानी या अज्ञात डेटिंग",
    "sentiment_negative": "नकारात्मक शब्दावली",
    "sentiment_positive": "सकारात्मक शब्दावली",
    "sentiment_neutral": "तटस्थ शब्दावली",
    "similar_titles": "इसी प्रकार के शीर्षक भी मिलते हैं",
    "not_independent_proof": "यह स्वतंत्र पुष्टि का प्रमाण नहीं है.",
    "original_title": "मूल शीर्षक",
    "source_links": "स्रोत और लिंक",
    "source_links_note": "हम कॉइनटेलीग्राफ और कॉइनडेस्क आरएसएस पढ़ते हैं। ब्लूमबर्ग और बिनेंस को केवल संदर्भ के रूप में प्रदान किया गया है; उनकी सामग्री का विश्लेषण नहीं किया गया है.",
    "reason_fresh_binance": "पर्याप्त ताज़ा बायनेन्स उद्धरण नहीं; सिग्नल के लिए डेमो और रिज़र्व USD कीमतों का उपयोग नहीं किया जाता है।",
    "reason_candles": "पर्याप्त ताजा लगातार मिनट मोमबत्तियाँ नहीं।",
    "reason_trend_up": "EMA9 EMA21 से ऊपर है और कीमत EMA9 से ऊपर है: छोटी दिशा ऊपर है।",
    "reason_trend_weak": "कीमत या संक्षिप्त औसत तेजी की प्रवृत्ति की पुष्टि नहीं करता है।",
    "reason_volume_up": "अंतिम 5 मिनट का टर्नओवर पिछले 30 मिनट की तुलना में बढ़ा हुआ है।",
    "reason_volume_weak": "यह वॉल्यूम आंदोलन के मजबूत होने की पुष्टि नहीं करता है।",
    "reason_btc_up": "पिछले एक घंटे में बिटकॉइन में कोई कमी नहीं आई है.",
    "reason_btc_down": "बिटकॉइन नीचे है; यह सिक्के की चाल के लिए जोखिम है।",
    "reason_btc_data": "कोई ताज़ा बिटकॉइन डेटा नहीं.",
    "reason_rsi_hot": "आरएसआई14 75 से ऊपर: गति ज़्यादा गरम हो सकती है, लेकिन यह उलटने की गारंटी नहीं देता है।",
    "reason_large_move": "प्रति घंटा कम से कम 5% परिवर्तन: अचानक गति का खतरा बढ़ जाता है।",
    "reason_negative_headlines": "संबंधित या व्यापक आर्थिक शीर्षकों में नकारात्मक भाषा होती है। यह कीमत में उतार-चढ़ाव का कोई स्थापित कारण नहीं है।",
    "reason_coin_news": "इस विशेष सिक्के के बारे में हाल ही में कोई सुर्खियाँ नहीं हैं।",
    "reason_fresh_news": "सत्यापित डोमेन और प्रकाशन समय के साथ कोई ब्रेकिंग न्यूज़ नहीं।",
    "reason_turnover": "प्रति घंटा टर्नओवर उपलब्ध नहीं है.",
    "reason_low_turnover": "प्रति घंटा कारोबार 1 मिलियन यूएसडीटी की सीमा से नीचे। यह एक अपरिष्कृत गतिविधि फ़िल्टर है, बाज़ार की गहराई का माप नहीं।",
    "api_invalid": "अज्ञात सिक्का या चार्ट अवधि.",
    "api_chart_unavailable": "वास्तविक चार्ट डेटा उपलब्ध नहीं है. बाद में पुन: प्रयास।",
    "movement_down": "तीव्र गिरावट - कारण की जाँच करें",
    "movement_up": "तीव्र वृद्धि - जोखिमों की जाँच करें",
    "movement_calm": "कोई महत्वपूर्ण परिवर्तन नहीं पाया गया",
    "footer_note": "विश्लेषण किसी खरीदारी पर शोध करने में मदद करता है, लेकिन विकास की भविष्यवाणी नहीं करता है और वित्तीय सलाह नहीं देता है।",
    "reset_note": "सभी सक्रिय पद और बंद सौदे हटा दिए जाएंगे। सिग्नल लॉग, कीमतें और सेटिंग्स बनी रहेंगी।",
    "legend_down": "गिरावट ≥ 5% - कारण की जाँच करें",
    "legend_up": "वृद्धि ≥ 5% - जोखिमों की जाँच करें"
  },
  "vi": {
    "signals_nav": "🔔 Tín hiệu",
    "chart_nav": "lịch trình",
    "assistant_title": "Trợ lý phân tích mua hàng",
    "assistant_note": "Dấu hiệu thị trường, nguồn tin tức và kết quả tín hiệu - không có hứa hẹn về sự tăng trưởng.",
    "signals_journal": "Tín hiệu và nhật ký",
    "candidate": "Ứng viên phân tích mua hàng",
    "watch": "quan sát",
    "risk": "Nguy cơ gia tăng",
    "calm": "Không có tín hiệu đáng kể",
    "insufficient": "Dữ liệu không đầy đủ",
    "pros": "Lập luận cho",
    "risks": "Rủi ro",
    "missing": "Cái gì còn thiếu?",
    "none": "Không có dấu hiệu nào được tìm thấy",
    "live_missing": "Chúng tôi thu thập dữ liệu mới. Nếu không có báo giá hiện tại thì không thể có kết luận giao dịch.",
    "live_only": "Chỉ có dữ liệu Binance chính hãng; các quy tắc được cập nhật khoảng một lần mỗi phút",
    "hour": "giờ",
    "hours": "giờ",
    "open_chart": "Lịch mở",
    "refresh": "cập nhật",
    "screening_note": "Đây là một bộ lọc các tình huống để nghiên cứu, không phải là một lệnh mua. Tín hiệu không phải là một chiến lược có lợi nhuận đã được chứng minh.",
    "journal": "Nhật ký kết quả tín hiệu",
    "coin": "đồng xu",
    "all_coins": "Tất cả tiền xu",
    "outcome_note": "Sự thay đổi giá được hiển thị, không phải lợi nhuận của giao dịch. Hoa hồng và trượt giá không được tính đến. Kết quả được lấy từ giá mở cửa của phút thực đầu tiên trên hoặc sau đường chân trời; độ lệch thời gian nhỏ hơn 60 giây.",
    "more": "Hiển thị thêm",
    "methodology": "Tín hiệu được tạo ra như thế nào?",
    "methodology_text": "Phiên bản thị trường-bối cảnh-v1. Ứng cử viên: Báo giá mới của Binance, ít nhất 40 nến phút đóng liên tiếp, EMA9 trên EMA21 và giá trên EMA9, RSI14 từ 45 đến 68, thay đổi hàng giờ từ +0,5% đến dưới +5%, khối lượng trong 5 phút hoàn thành gần nhất ít nhất bằng 1,2 khối lượng trung bình trong khoảng thời gian 5 phút trong 30 phút trước đó, khối lượng hàng giờ là 1 triệu USDT, Bitcoin không giảm và tin tức mới về bản thân đồng tiền này. Các tiêu đề liên quan tiêu cực sẽ chặn ứng viên. Ngưỡng là những phương pháp phỏng đoán chưa được kiểm chứng, không phải là xác suất tăng trưởng. Loại tín hiệu tương tự cho một đồng xu được ghi lại không quá một lần một giờ, bất kỳ tín hiệu mới nào - không quá 5 phút một lần. Báo giá demo không tạo ra bản ghi. Nội dung của tin tức không vượt qua được việc kiểm tra thực tế.",
    "time_coin": "Thời gian/đồng tiền",
    "status": "Trạng thái",
    "signal_price": "Giá tín hiệu",
    "details": "Chi tiết",
    "waiting": "Vẫn chưa đến lúc",
    "pending_data": "Chúng tôi đang chờ đợi dữ liệu thực",
    "measured": "Đã đo",
    "journal_empty": "Tạp chí vẫn trống. Các bài viết sẽ xuất hiện sau những tín hiệu có thật, không có câu chuyện hư cấu. Kết quả sau 1, 4 và 24 giờ sẽ xuất hiện theo thời gian.",
    "no_setups": "Bây giờ không có tình huống cụ thể theo quy định. Đây là kết quả bình thường và không phải lỗi.",
    "target_time": "Thời gian dự kiến",
    "observed_time": "Thời điểm giá thực tế",
    "coin_chart": "Biểu đồ tiền điện tử",
    "chart_note": "Giá đóng nến thực tế. Cây nến dở dang cuối cùng có thể thay đổi; không có điểm dự đoán.",
    "market": "thị trường",
    "window_1h": "1 giờ",
    "window_4h": "4 giờ",
    "window_1d": "1 ngày",
    "window_7d": "7 ngày",
    "paper_purchase": "Mua hàng ảo",
    "loading_real": "Đang tải nến thật...",
    "no_fake_chart": "Một lịch trình nhân tạo không thể thay thế được lịch trình thực tế.",
    "no_data": "Dữ liệu không có sẵn",
    "shown_window": "trong cửa sổ hiển thị",
    "updated": "Đã cập nhật",
    "interval": "Bước của ngọn nến",
    "high": "Tối đa",
    "low": "tối thiểu",
    "time": "thời gian",
    "price": "Giá",
    "observations": "Bảng quan sát",
    "chart_library_error": "Thư viện đồ họa không tải được. Giá trị thực tế có sẵn trong bảng dưới đây.",
    "news_title": "Tin tức · nguồn",
    "publisher_check_note": "Chúng tôi kiểm tra miền HTTPS của ấn phẩm và thời gian xuất bản; phân tích tình cảm - như tiêu đề đã nói.",
    "available": "Có sẵn",
    "unavailable": "Không có sẵn",
    "not_factcheck": "Xác minh tên miền xác minh nguồn gốc của liên kết chứ không phải tính xác thực của tin tức. Đây không phải là một kiểm tra thực tế.",
    "rss_missing": "Tin tức RSS thực sự hiện không có sẵn. Tiêu đề hư cấu không được hiển thị.",
    "time_unknown": "Thời điểm xuất bản chưa rõ",
    "domain_checked": "Đã xác minh tên miền",
    "fresh_article": "Xuất bản lên đến 24 giờ",
    "old_article": "Hẹn hò cũ hoặc chưa biết",
    "sentiment_negative": "Từ vựng tiêu cực",
    "sentiment_positive": "Từ vựng tích cực",
    "sentiment_neutral": "Từ vựng trung tính",
    "similar_titles": "Các tiêu đề tương tự cũng được tìm thấy trong",
    "not_independent_proof": "Đây không phải là bằng chứng xác nhận độc lập.",
    "original_title": "Tiêu đề gốc",
    "source_links": "Nguồn và liên kết",
    "source_links_note": "Chúng tôi đọc RSS của CoinTelegraph và CoinDesk. Bloomberg và Binance chỉ được cung cấp dưới dạng tài liệu tham khảo; nội dung của chúng không được phân tích.",
    "reason_fresh_binance": "Không có đủ báo giá Binance mới; giá demo và dự trữ USD không được sử dụng cho tín hiệu.",
    "reason_candles": "Không đủ nến tươi phút liên tiếp.",
    "reason_trend_up": "EMA9 nằm trên EMA21 và giá nằm trên EMA9: xu hướng bán là tăng.",
    "reason_trend_weak": "Giá hoặc đường trung bình ngắn không xác nhận xu hướng tăng.",
    "reason_volume_up": "Doanh thu của 5 phút cuối tăng lên so với 30 phút trước đó.",
    "reason_volume_weak": "Khối lượng không xác nhận sự tăng cường của chuyển động.",
    "reason_btc_up": "Bitcoin đã không giảm trong giờ qua.",
    "reason_btc_down": "Bitcoin giảm giá; đó là một rủi ro đối với sự chuyển động của đồng xu.",
    "reason_btc_data": "Không có dữ liệu Bitcoin mới.",
    "reason_rsi_hot": "RSI14 trên 75: chuyển động có thể quá nóng, nhưng điều này không đảm bảo sẽ đảo chiều.",
    "reason_large_move": "Thay đổi hàng giờ ít nhất 5%: tăng nguy cơ chuyển động đột ngột.",
    "reason_negative_headlines": "Các tiêu đề liên quan hoặc kinh tế vĩ mô chứa ngôn ngữ tiêu cực. Đây không phải là lý do chính đáng cho sự biến động giá cả.",
    "reason_coin_news": "Không có tiêu đề gần đây về đồng tiền đặc biệt này.",
    "reason_fresh_news": "Không có tin tức nóng hổi với tên miền và thời gian xuất bản đã được xác minh.",
    "reason_turnover": "Doanh thu hàng giờ không có sẵn.",
    "reason_low_turnover": "Doanh thu hàng giờ dưới ngưỡng 1 triệu USDT. Đây là bộ lọc hoạt động thô, không phải thước đo độ sâu thị trường.",
    "api_invalid": "Đồng xu hoặc thời gian biểu đồ không xác định.",
    "api_chart_unavailable": "Dữ liệu biểu đồ thực tế không có sẵn. Hãy thử lại sau.",
    "movement_down": "Giảm mạnh - kiểm tra lý do",
    "movement_up": "Tăng trưởng mạnh - kiểm soát rủi ro",
    "movement_calm": "Không có thay đổi đáng kể nào được tìm thấy",
    "footer_note": "Phân tích giúp nghiên cứu việc mua hàng nhưng không dự đoán mức tăng trưởng và không cấu thành tư vấn tài chính.",
    "reset_note": "Tất cả các vị trí đang hoạt động và giao dịch đã đóng sẽ bị xóa. Nhật ký tín hiệu, giá cả và cài đặt sẽ vẫn còn.",
    "legend_down": "giảm ≥ 5% - kiểm tra nguyên nhân",
    "legend_up": "tăng trưởng ≥ 5% - kiểm tra rủi ro"
  },
  "de": {
    "signals_nav": "🔔 Signale",
    "chart_nav": "Zeitplan",
    "assistant_title": "Assistent für die Kaufanalyse",
    "assistant_note": "Marktzeichen, Nachrichtenquellen und Signalergebnisse – ohne Wachstumsversprechen.",
    "signals_journal": "Signale und Protokoll",
    "candidate": "Kandidat für Kaufanalyse",
    "watch": "zu beobachten",
    "risk": "Erhöhtes Risiko",
    "calm": "Keine nennenswerten Signale",
    "insufficient": "Unzureichende Daten",
    "pros": "Argumente dafür",
    "risks": "Risiken",
    "missing": "Was fehlt?",
    "none": "Es wurden keine Anzeichen gefunden",
    "live_missing": "Wir sammeln frische Daten. Ohne aktuelle Notierungen ist der Handelsabschluss nicht verfügbar.",
    "live_only": "Nur echte Binance-Daten; Die Regeln werden etwa einmal pro Minute aktualisiert",
    "hour": "Stunden",
    "hours": "Stunden",
    "open_chart": "Offener Zeitplan",
    "refresh": "Aktualisieren",
    "screening_note": "Dabei handelt es sich um einen Filter von Situationen, die es zu recherchieren gilt, nicht um einen Kaufauftrag. Signale sind keine bewährte profitable Strategie.",
    "journal": "Protokoll der Signalergebnisse",
    "coin": "Münze",
    "all_coins": "Alle Münzen",
    "outcome_note": "Es wird die Preisänderung angezeigt, nicht der Gewinn des Deals. Provisionen und Slippage werden nicht berücksichtigt. Das Ergebnis ergibt sich aus dem Eröffnungskurs der ersten realen Minute am oder nach dem Horizont; Die Zeitabweichung beträgt weniger als 60 Sekunden.",
    "more": "Mehr anzeigen",
    "methodology": "Wie wird das Signal erzeugt?",
    "methodology_text": "Version Market-Context-v1. Kandidat: Aktuelle Binance-Kurse, mindestens 40 aufeinanderfolgende geschlossene Minutenkerzen, EMA9 über EMA21 und Preis über EMA9, RSI14 von 45 auf 68, stündliche Änderung von +0,5 % auf weniger als +5 %, Volumen der letzten 5 abgeschlossenen Minuten mindestens 1,2 des durchschnittlichen Volumens des Fünf-Minuten-Fensters der vorherigen 30 Minuten, stündliches Volumen von 1 Million USDT, nicht rückläufiger Bitcoin und neue Nachrichten darüber Münze selbst. Negativbezogene Schlagzeilen blockieren den Kandidaten. Schwellenwerte sind ungetestete Heuristiken, keine Wachstumswahrscheinlichkeiten. Das gleiche Signal für eine Münze wird höchstens einmal pro Stunde aufgezeichnet, jedes neue Signal höchstens einmal alle 5 Minuten. Demo-Angebote erzeugen keine Datensätze. Der Inhalt der Nachrichten besteht den Faktencheck nicht.",
    "time_coin": "Zeit / Münze",
    "status": "Status",
    "signal_price": "Signalpreis",
    "details": "Details",
    "waiting": "Es ist noch nicht so weit",
    "pending_data": "Wir warten auf echte Daten",
    "measured": "Gemessen",
    "journal_empty": "Das Magazin ist noch leer. Einträge erscheinen nach echten Signalen, ohne eine fiktive Geschichte. Die Ergebnisse nach 1, 4 und 24 Stunden werden im Laufe der Zeit angezeigt.",
    "no_setups": "Jetzt gibt es keine besonderen Situationen gemäß den Regeln. Dies ist ein normales Ergebnis und kein Fehler.",
    "target_time": "Geplante Zeit",
    "observed_time": "Tatsächliche Preiszeit",
    "coin_chart": "Kryptowährungsdiagramm",
    "chart_note": "Tatsächliche Schlusskurse der Kerze. Die letzte unvollendete Kerze kann sich ändern; Es gibt keine Vorhersagepunkte.",
    "market": "Der Markt",
    "window_1h": "1 Stunde",
    "window_4h": "4 Stunden",
    "window_1d": "1 Tag",
    "window_7d": "7 Tage",
    "paper_purchase": "Virtueller Kauf",
    "loading_real": "Echte Kerzen werden geladen...",
    "no_fake_chart": "Ein künstlicher Zeitplan ersetzt den echten nicht.",
    "no_data": "Daten nicht verfügbar",
    "shown_window": "im angezeigten Fenster",
    "updated": "Aktualisiert",
    "interval": "Schritt der Kerze",
    "high": "Maximal",
    "low": "Mindestens",
    "time": "Zeit",
    "price": "Preis",
    "observations": "Beobachtungstabelle",
    "chart_library_error": "Die Grafikbibliothek konnte nicht geladen werden. Die tatsächlichen Werte finden Sie in der folgenden Tabelle.",
    "news_title": "Nachrichten · Quellen",
    "publisher_check_note": "Wir überprüfen die HTTPS-Domäne der Veröffentlichung und den Zeitpunkt der Veröffentlichung; Sentimentanalyse – wie der Titel schon sagt.",
    "available": "Verfügbar",
    "unavailable": "Nicht verfügbar",
    "not_factcheck": "Bei der Domainverifizierung wird die Herkunft des Links überprüft, nicht der Wahrheitsgehalt der Nachricht. Dies ist kein Faktencheck.",
    "rss_missing": "Echte RSS-Nachrichten sind derzeit nicht verfügbar. Fiktionale Titel werden nicht angezeigt.",
    "time_unknown": "Der Zeitpunkt der Veröffentlichung ist unbekannt",
    "domain_checked": "Domain verifiziert",
    "fresh_article": "Veröffentlichung bis zu 24 Stunden",
    "old_article": "Alte oder unbekannte Datierung",
    "sentiment_negative": "Negatives Vokabular",
    "sentiment_positive": "Positiver Wortschatz",
    "sentiment_neutral": "Neutraler Wortschatz",
    "similar_titles": "Ähnliche Überschriften finden sich auch in",
    "not_independent_proof": "Dies ist kein Beweis einer unabhängigen Bestätigung.",
    "original_title": "Originaltitel",
    "source_links": "Quellen und Links",
    "source_links_note": "Wir lesen CoinTelegraph und CoinDesk RSS. Bloomberg und Binance dienen lediglich als Referenz; Ihr Inhalt wird nicht analysiert.",
    "reason_fresh_binance": "Nicht genügend aktuelle Binance-Kurse; Demo- und Reserve-USD-Preise werden nicht für Signale verwendet.",
    "reason_candles": "Nicht genügend frische aufeinanderfolgende Minutenkerzen.",
    "reason_trend_up": "EMA9 liegt über EMA21 und der Preis liegt über EMA9: Die Short-Richtung ist nach oben.",
    "reason_trend_weak": "Der Preis oder der Short-Durchschnitt bestätigen den Aufwärtstrend nicht.",
    "reason_volume_up": "Der Umsatz der letzten 5 Minuten ist im Vergleich zu den vorherigen 30 Minuten erhöht.",
    "reason_volume_weak": "Die Lautstärke bestätigt nicht die Verstärkung der Bewegung.",
    "reason_btc_up": "Bitcoin ist in der letzten Stunde nicht zurückgegangen.",
    "reason_btc_down": "Bitcoin ist unten; Es besteht ein Risiko für die Bewegung der Münze.",
    "reason_btc_data": "Keine neuen Bitcoin-Daten.",
    "reason_rsi_hot": "RSI14 über 75: Die Bewegung könnte überhitzt sein, aber das garantiert keine Umkehr.",
    "reason_large_move": "Stündliche Änderung von mindestens 5 %: erhöhtes Risiko plötzlicher Bewegungen.",
    "reason_negative_headlines": "Ähnliche oder makroökonomische Schlagzeilen enthalten negative Ausdrücke. Dies ist kein nachgewiesener Grund für die Preisbewegung.",
    "reason_coin_news": "Es gibt keine aktuellen Schlagzeilen zu dieser speziellen Münze.",
    "reason_fresh_news": "Keine Eilmeldungen mit verifizierter Domain und Veröffentlichungszeitpunkt.",
    "reason_turnover": "Stundenumsatz ist nicht verfügbar.",
    "reason_low_turnover": "Stundenumsatz unter der Schwelle von 1 Million USDT. Dies ist ein grober Aktivitätsfilter, kein Maß für die Markttiefe.",
    "api_invalid": "Unbekannter Münz- oder Chartzeitraum.",
    "api_chart_unavailable": "Tatsächliche Diagrammdaten sind nicht verfügbar. Versuchen Sie es später noch einmal.",
    "movement_down": "Starker Abfall – prüfen Sie die Ursache",
    "movement_up": "Starkes Wachstum – prüfen Sie die Risiken",
    "movement_calm": "Es wurden keine wesentlichen Änderungen festgestellt",
    "footer_note": "Die Analyse hilft bei der Recherche eines Kaufs, sagt jedoch kein Wachstum voraus und stellt keine Finanzberatung dar.",
    "reset_note": "Alle aktiven Positionen und abgeschlossenen Geschäfte werden gelöscht. Das Signalprotokoll, die Preise und die Einstellungen bleiben erhalten.",
    "legend_down": "Abfall ≥ 5 % – Ursache prüfen",
    "legend_up": "Wachstum ≥ 5 % – prüfen Sie die Risiken"
  },
  "pl": {
    "signals_nav": "🔔 Sygnały",
    "chart_nav": "Harmonogram",
    "assistant_title": "Asystent analizy zakupów",
    "assistant_note": "Znaki rynkowe, źródła wiadomości i wyniki sygnałów – bez obietnicy wzrostu.",
    "signals_journal": "Sygnały i dziennik",
    "candidate": "Kandydat do analizy zakupowej",
    "watch": "obserwować",
    "risk": "Zwiększone ryzyko",
    "calm": "Brak znaczących sygnałów",
    "insufficient": "Niewystarczające dane",
    "pros": "Argumenty za",
    "risks": "Ryzyko",
    "missing": "Czego brakuje?",
    "none": "Nie znaleziono żadnych znaków",
    "live_missing": "Zbieramy świeże dane. Bez aktualnych notowań wnioski handlowe nie są dostępne.",
    "live_only": "Tylko oryginalne dane Binance; zasady są aktualizowane mniej więcej raz na minutę",
    "hour": "godziny",
    "hours": "godziny",
    "open_chart": "Otwórz harmonogram",
    "refresh": "Aktualizacja",
    "screening_note": "Jest to filtr sytuacji do zbadania, a nie zlecenie zakupu. Sygnały nie są sprawdzoną zyskowną strategią.",
    "journal": "Dziennik wyników sygnału",
    "coin": "Moneta",
    "all_coins": "Wszystkie monety",
    "outcome_note": "Pokazana jest zmiana ceny, a nie zysk z transakcji. Prowizje i poślizgi nie są brane pod uwagę. Wynik jest brany z ceny otwarcia pierwszej prawdziwej minuty na horyzoncie lub po nim; odchylenie czasu jest mniejsze niż 60 sekund.",
    "more": "Pokaż więcej",
    "methodology": "Jak generowany jest sygnał?",
    "methodology_text": "Wersja market-context-v1. Kandydat: Świeże notowania Binance, co najmniej 40 kolejnych zamkniętych świec minutowych, EMA9 powyżej EMA21 i cena powyżej EMA9, RSI14 od 45 do 68, godzinna zmiana z +0,5% do mniej niż +5%, wolumen z ostatnich 5 ukończonych minut co najmniej 1,2 średniego wolumenu pięciominutowego okna z poprzednich 30 minut, wolumen godzinowy 1 milion USDT, niespadający Bitcoin i świeże wiadomości nt. samą monetę. Negatywne nagłówki blokują kandydata. Progi to niesprawdzona heurystyka, a nie prawdopodobieństwa wzrostu. Ten sam rodzaj sygnału dla monety rejestrowany jest nie częściej niż raz na godzinę, każdy nowy - nie częściej niż raz na 5 minut. Cytaty demonstracyjne nie tworzą rekordów. Treść wiadomości nie przechodzi weryfikacji faktów.",
    "time_coin": "Czas / moneta",
    "status": "Stan",
    "signal_price": "Cena sygnału",
    "details": "Szczegóły",
    "waiting": "To jeszcze nie czas",
    "pending_data": "Czekamy na prawdziwe dane",
    "measured": "Zmierzone",
    "journal_empty": "Magazyn jest nadal pusty. Wpisy będą pojawiać się po prawdziwych sygnałach, bez fikcyjnej historii. Wyniki po 1, 4 i 24 godzinach będą pojawiać się z czasem.",
    "no_setups": "Teraz nie ma żadnych szczególnych sytuacji zgodnie z przepisami. Jest to normalny wynik, a nie błąd.",
    "target_time": "Zaplanowany czas",
    "observed_time": "Rzeczywisty czas cenowy",
    "coin_chart": "Wykres kryptowaluty",
    "chart_note": "Aktualne ceny zamknięcia świec. Ostatnia niedokończona świeca może się zmienić; nie ma punktów prognostycznych.",
    "market": "rynek",
    "window_1h": "1 godzina",
    "window_4h": "4 godziny",
    "window_1d": "1 dzień",
    "window_7d": "7 dni",
    "paper_purchase": "Wirtualny zakup",
    "loading_real": "Ładowanie prawdziwych świec...",
    "no_fake_chart": "Sztuczny harmonogram nie zastępuje prawdziwego.",
    "no_data": "Dane niedostępne",
    "shown_window": "w wyświetlonym oknie",
    "updated": "Zaktualizowano",
    "interval": "Krok świecy",
    "high": "Maksymalnie",
    "low": "Minimalne",
    "time": "czas",
    "price": "Cena",
    "observations": "Tabela obserwacji",
    "chart_library_error": "Nie udało się załadować biblioteki graficznej. Rzeczywiste wartości dostępne są w poniższej tabeli.",
    "news_title": "Aktualności · źródła",
    "publisher_check_note": "Sprawdzamy domenę HTTPS publikacji i czas publikacji; analiza nastrojów - jak mówi tytuł.",
    "available": "Dostępne",
    "unavailable": "Niedostępne",
    "not_factcheck": "Weryfikacja domeny sprawdza pochodzenie linku, a nie prawdziwość wiadomości. To nie jest weryfikacja faktów.",
    "rss_missing": "Prawdziwe wiadomości RSS są obecnie niedostępne. Tytuły fikcyjne nie są wyświetlane.",
    "time_unknown": "Czas publikacji nie jest znany",
    "domain_checked": "Domena zweryfikowana",
    "fresh_article": "Publikacja do 24 godzin",
    "old_article": "Stare lub nieznane randki",
    "sentiment_negative": "Negatywne słownictwo",
    "sentiment_positive": "Pozytywne słownictwo",
    "sentiment_neutral": "Neutralne słownictwo",
    "similar_titles": "Podobne nagłówki znajdują się także w",
    "not_independent_proof": "Nie jest to dowód niezależnego potwierdzenia.",
    "original_title": "Tytuł oryginalny",
    "source_links": "Źródła i linki",
    "source_links_note": "Czytamy CoinTelegraph i CoinDesk RSS. Bloomberg i Binance służą wyłącznie jako referencje; ich treść nie jest analizowana.",
    "reason_fresh_binance": "Za mało świeżych notowań Binance; Ceny demonstracyjne i rezerwowe w USD nie są wykorzystywane do sygnałów.",
    "reason_candles": "Za mało świeżych kolejnych świec minutowych.",
    "reason_trend_up": "EMA9 jest powyżej EMA21, a cena jest powyżej EMA9: krótki kierunek jest w górę.",
    "reason_trend_weak": "Cena czy krótka średnia nie potwierdzają trendu wzrostowego.",
    "reason_volume_up": "Obroty z ostatnich 5 minut są zwiększone w porównaniu z poprzednimi 30 minutami.",
    "reason_volume_weak": "Objętość nie potwierdza wzmocnienia ruchu.",
    "reason_btc_up": "Bitcoin nie spadł w ciągu ostatniej godziny.",
    "reason_btc_down": "Bitcoin nie działa; stanowi to ryzyko dla ruchu monety.",
    "reason_btc_data": "Brak świeżych danych Bitcoin.",
    "reason_rsi_hot": "RSI14 powyżej 75: mechanizm może się przegrzać, ale nie gwarantuje to odwrócenia.",
    "reason_large_move": "Zmiana godzinowa co najmniej 5%: zwiększone ryzyko nagłego ruchu.",
    "reason_negative_headlines": "Nagłówki o tematyce pokrewnej lub makroekonomicznej zawierają sformułowania negatywne. Nie jest to ustalony powód ruchu cen.",
    "reason_coin_news": "Brak aktualnych nagłówków na temat tej konkretnej monety.",
    "reason_fresh_news": "Brak najświeższych wiadomości ze zweryfikowaną domeną i czasem publikacji.",
    "reason_turnover": "Obrót godzinowy nie jest dostępny.",
    "reason_low_turnover": "Obrót godzinowy poniżej progu 1 miliona USDT. Jest to przybliżony filtr aktywności, a nie miara głębokości rynku.",
    "api_invalid": "Nieznany okres monety lub wykresu.",
    "api_chart_unavailable": "Rzeczywiste dane wykresu nie są dostępne. Spróbuj ponownie później.",
    "movement_down": "Ostry spadek - sprawdź przyczynę",
    "movement_up": "Ostry wzrost – sprawdź ryzyko",
    "movement_calm": "Nie stwierdzono żadnych istotnych zmian",
    "footer_note": "Analiza pomaga zbadać zakup, ale nie przewiduje wzrostu i nie stanowi porady finansowej.",
    "reset_note": "Wszystkie aktywne pozycje i zamknięte transakcje zostaną usunięte. Dziennik sygnałów, ceny i ustawienia pozostaną.",
    "legend_down": "spadek ≥ 5% – sprawdź przyczynę",
    "legend_up": "wzrost ≥ 5% — sprawdź ryzyko"
  },
  "zh": {
    "signals_nav": "🔔 信号",
    "chart_nav": "时间表",
    "assistant_title": "采购分析助理",
    "assistant_note": "市场迹象、新闻来源和信号结果——没有增长的承诺。",
    "signals_journal": "信号和日志",
    "candidate": "候选购买分析",
    "watch": "观察",
    "risk": "风险增加",
    "calm": "无明显信号",
    "insufficient": "数据不足",
    "pros": "论点",
    "risks": "风险",
    "missing": "缺少什么？",
    "none": "没有发现任何迹象",
    "live_missing": "我们收集新数据。没有当前报价，就无法得出交易结论。",
    "live_only": "只有真实的币安数据；规则大约每分钟更新一次",
    "hour": "小时",
    "hours": "小时",
    "open_chart": "开放日程",
    "refresh": "更新",
    "screening_note": "这是对需要研究的情况进行筛选，而不是购买订单。信号并不是一种经过验证的盈利策略。",
    "journal": "信号结果日志",
    "coin": "硬币",
    "all_coins": "所有硬币",
    "outcome_note": "显示的是价格变化，而不是交易利润。不考虑佣金和滑点。结果取自地平线上或之后第一个真实分钟的开盘价；时间偏差小于60秒。",
    "more": "显示更多",
    "methodology": "信号是如何产生的？",
    "methodology_text": "版本 market-context-v1。候选者：币安最新报价，至少 40 个连续收盘分钟蜡烛，EMA9 高于 EMA21，价格高于 EMA9，RSI14 从 45 到 68，每小时变化从 +0.5% 到小于 +5%，最后 5 分钟的交易量至少是前 30 分钟五分钟窗口平均交易量的 1.2，每小时交易量 100 万 USDT，比特币不下跌，有关该币的最新消息本身。负面相关的标题会阻碍候选人。阈值是未经测试的启发法，而不是增长概率。一枚硬币的同一类型信号每小时记录不超过一次，任何新信号记录不超过每 5 分钟一次。演示报价不会创建记录。新闻内容未通过事实核查。",
    "time_coin": "时间/硬币",
    "status": "状态",
    "signal_price": "信号价格",
    "details": "详情",
    "waiting": "时间还没到",
    "pending_data": "我们正在等待真实数据",
    "measured": "测量的",
    "journal_empty": "杂志还是空的。条目将出现在真实信号之后，没有虚构的故事。 1、4 和 24 小时后的结果将随着时间的推移而填充。",
    "no_setups": "现在根据规则还没有具体的情况。这是正常结果而不是错误。",
    "target_time": "预定时间",
    "observed_time": "实际价格时间",
    "coin_chart": "加密货币图表",
    "chart_note": "实际蜡烛收盘价。最后一根未完成的蜡烛可以改变；没有预测点。",
    "market": "市场",
    "window_1h": "1小时",
    "window_4h": "4小时",
    "window_1d": "1天",
    "window_7d": "7天",
    "paper_purchase": "虚拟购买",
    "loading_real": "正在加载真正的蜡烛...",
    "no_fake_chart": "人为的时间表不能代替真实的时间表。",
    "no_data": "数据不可用",
    "shown_window": "在显示的窗口中",
    "updated": "已更新",
    "interval": "蜡烛的脚步",
    "high": "最大",
    "low": "最低",
    "time": "时间",
    "price": "价格",
    "observations": "观察表",
    "chart_library_error": "图形库加载失败。实际值可参见下表。",
    "news_title": "新闻·来源",
    "publisher_check_note": "我们检查发布的HTTPS域名和发布时间；情感分析 - 正如标题所说。",
    "available": "可用",
    "unavailable": "不可用",
    "not_factcheck": "域名验证验证链接的来源，而不是新闻的真实性。这不是事实核查。",
    "rss_missing": "目前无法获取真正的 RSS 新闻。不显示虚构标题。",
    "time_unknown": "发表时间未知",
    "domain_checked": "域名已验证",
    "fresh_article": "最长24小时发布",
    "old_article": "旧的或未知的约会",
    "sentiment_negative": "负面词汇",
    "sentiment_positive": "积极词汇",
    "sentiment_neutral": "中性词汇",
    "similar_titles": "类似的标题也可以在",
    "not_independent_proof": "这不是独立确认的证据。",
    "original_title": "原标题",
    "source_links": "来源和链接",
    "source_links_note": "我们阅读 CoinTelegraph 和 CoinDesk RSS。彭博社和币安网仅供参考；他们的内容没有被分析。",
    "reason_fresh_binance": "没有足够的新鲜币安报价；演示和储备美元价格不用于信号。",
    "reason_candles": "没有足够的新鲜连续分钟蜡烛。",
    "reason_trend_up": "EMA9位于EMA21上方且价格位于EMA9上方：空头方向向上。",
    "reason_trend_weak": "价格或短期均线并未确认上升趋势。",
    "reason_volume_up": "最后5分钟的成交量较前30分钟有所增加。",
    "reason_volume_weak": "成交量并没有证实走势的加强。",
    "reason_btc_up": "比特币在过去一个小时内没有减少。",
    "reason_btc_down": "比特币下跌；这对代币的流动构成风险。",
    "reason_btc_data": "没有新的比特币数据。",
    "reason_rsi_hot": "RSI14高于75：走势可能过热，但这并不能保证反转。",
    "reason_large_move": "每小时变化至少 5%：突然移动的风险增加。",
    "reason_negative_headlines": "相关或宏观经济头条新闻包含负面语言。这并不是价格变动的既定原因。",
    "reason_coin_news": "最近没有关于这种特殊硬币的头条新闻。",
    "reason_fresh_news": "没有经过验证的域名和发布时间的突发新闻。",
    "reason_turnover": "每小时营业额不可用。",
    "reason_low_turnover": "每小时交易额低于 100 万 USDT。这是一个粗略的活动过滤器，而不是市场深度的衡量标准。",
    "api_invalid": "未知的硬币或图表时期。",
    "api_chart_unavailable": "实际图表数据不可用。稍后再试。",
    "movement_down": "急剧下降 - 检查原因",
    "movement_up": "快速增长——检查风险",
    "movement_calm": "没有发现明显变化",
    "footer_note": "该分析有助于研究购买行为，但不能预测增长，也不构成财务建议。",
    "reset_note": "所有活跃头寸和已平仓交易都将被删除。信号日志、价格和设置将保留。",
    "legend_down": "下降≥5%——检查原因",
    "legend_up": "增长≥5%——检查风险"
  },
  "ja": {
    "signals_nav": "🔔信号",
    "chart_nav": "スケジュール",
    "assistant_title": "購入分析アシスタント",
    "assistant_note": "市場の兆候、ニュースソース、シグナルの結果 - 成長の約束なし。",
    "signals_journal": "シグナルとログ",
    "candidate": "購入分析の候補者",
    "watch": "観察する",
    "risk": "リスクの増加",
    "calm": "重要な信号なし",
    "insufficient": "データが不十分です",
    "pros": "の引数",
    "risks": "リスク",
    "missing": "何が足りないのでしょうか？",
    "none": "兆候は見つかりませんでした",
    "live_missing": "新鮮なデータを収集します。現在の相場がなければ、取引の結論は得られません。",
    "live_only": "本物のBinanceデータのみ。ルールは約 1 分に 1 回更新されます",
    "hour": "時間",
    "hours": "時間",
    "open_chart": "オープンスケジュール",
    "refresh": "アップデート",
    "screening_note": "これは調査すべき状況のフィルターであり、購入の注文ではありません。シグナルは収益性が証明されている戦略ではありません。",
    "journal": "信号結果のログ",
    "coin": "コイン",
    "all_coins": "すべてのコイン",
    "outcome_note": "取引の利益ではなく、価格の変化が表示されます。コミッションとスリッページは考慮されません。結果は、水平線以降の最初の実際の始値から取得されます。時間のずれは60秒未満です。",
    "more": "もっと見る",
    "methodology": "信号はどのように生成されるのでしょうか?",
    "methodology_text": "バージョンマーケットコンテキスト-v1。候補: Binance の新鮮な相場、少なくとも 40 連続のクローズ分ローソク足、EMA9 が EMA21 を超え、価格が EMA9 を超え、RSI14 が 45 から 68、時間当たりの変化が +0.5% から +5% 未満、過去 5 分間の完了した取引量が過去 30 分間の 5 分間ウィンドウの平均取引量の少なくとも 1.2、時間取引量が 100 万 USDT、下落していないビットコインと新鮮取引コイン自体に関するニュース。関連するネガティブな見出しは候補者をブロックします。しきい値はテストされていないヒューリスティックであり、成長確率ではありません。コインの同じ種類のシグナルは 1 時間に 1 回、新しいシグナルは 5 分に 1 回だけ記録されます。デモ見積もりでは記録は作成されません。ニュースの内容はファクトチェックに合格しません。",
    "time_coin": "時間/コイン",
    "status": "ステータス",
    "signal_price": "シグナル価格",
    "details": "詳細",
    "waiting": "まだその時ではない",
    "pending_data": "実際のデータをお待ちしています",
    "measured": "測定した",
    "journal_empty": "マガジンはまだ空です。エントリーは架空のストーリーではなく、実際の信号の後に表示されます。 1、4、24 時間後の結果は時間の経過とともに表示されます。",
    "no_setups": "現在、ルールに従って特定の状況はありません。これは正常な結果であり、エラーではありません。",
    "target_time": "予定時刻",
    "observed_time": "実際の価格の時間",
    "coin_chart": "仮想通貨チャート",
    "chart_note": "実際のローソク足の終値。最後の未完成のキャンドルは変更される可能性があります。予測ポイントはありません。",
    "market": "市場",
    "window_1h": "1時間",
    "window_4h": "4時間",
    "window_1d": "1日",
    "window_7d": "7日間",
    "paper_purchase": "仮想購入",
    "loading_real": "本物のキャンドルを読み込み中...",
    "no_fake_chart": "人為的なスケジュールは実際のスケジュールの代わりにはなりません。",
    "no_data": "データが利用できません",
    "shown_window": "表示されたウィンドウ内で",
    "updated": "更新されました",
    "interval": "キャンドルのステップ",
    "high": "最大値",
    "low": "最小値",
    "time": "時間",
    "price": "価格",
    "observations": "観察結果の表",
    "chart_library_error": "グラフィック ライブラリのロードに失敗しました。実際の値は以下の表にあります。",
    "news_title": "ニュース・ソース",
    "publisher_check_note": "出版物の HTTPS ドメインと出版時刻を確認します。感情分析 - タイトルの通りです。",
    "available": "利用可能",
    "unavailable": "利用できません",
    "not_factcheck": "ドメイン検証は、ニュースの真実性ではなく、リンクの発信元を検証します。これは事実確認ではありません。",
    "rss_missing": "リアル RSS ニュースは現在利用できません。架空のタイトルは表示されません。",
    "time_unknown": "出版時期は不明",
    "domain_checked": "ドメイン認証済み",
    "fresh_article": "公開は24時間まで",
    "old_article": "古いまたは不明な日付",
    "sentiment_negative": "否定的な語彙",
    "sentiment_positive": "ポジティブな語彙",
    "sentiment_neutral": "中立的な語彙",
    "similar_titles": "同様の見出しは次の場所にもあります。",
    "not_independent_proof": "これは独立した確認を証明するものではありません。",
    "original_title": "原題",
    "source_links": "ソースとリンク",
    "source_links_note": "CoinTelegraph と CoinDesk RSS を読みます。ブルームバーグとバイナンスは参考としてのみ提供されています。その内容は分析されません。",
    "reason_fresh_binance": "十分な新鮮なバイナンス相場がありません。デモ価格とリザーブ米ドル価格はシグナルには使用されません。",
    "reason_candles": "新鮮な連続分キャンドルが十分ではありません。",
    "reason_trend_up": "EMA9 は EMA21 を上回っており、価格は EMA9 を上回っています。つまり、短期方向は上昇しています。",
    "reason_trend_weak": "価格や短期平均は上昇トレンドを裏付けるものではありません。",
    "reason_volume_up": "最後の 5 分間の売上高は、前の 30 分間に比べて増加します。",
    "reason_volume_weak": "音量は動きの強化を確認するものではありません。",
    "reason_btc_up": "過去1時間でビットコインは減っていません。",
    "reason_btc_down": "ビットコインは下落している。それはコインの動きに対するリスクです。",
    "reason_btc_data": "新しいビットコインデータはありません。",
    "reason_rsi_hot": "RSI14 が 75 を超える場合: ムーブメントが過熱している可能性がありますが、これは反転を保証するものではありません。",
    "reason_large_move": "時間ごとの変化が少なくとも 5%: 突然の動きのリスクが増加します。",
    "reason_negative_headlines": "関連またはマクロ経済の見出しには否定的な表現が含まれています。これは価格変動の確立された理由ではありません。",
    "reason_coin_news": "この特定のコインに関する最近の見出しはありません。",
    "reason_fresh_news": "ドメインと公開時間が確認された最新ニュースはありません。",
    "reason_turnover": "時間当たりの売上高は利用できません。",
    "reason_low_turnover": "時間当たり売上高が 100 万 USDT の基準を下回る。これは大まかなアクティビティフィルターであり、市場の厚みを測るものではありません。",
    "api_invalid": "不明なコインまたはチャートの期間。",
    "api_chart_unavailable": "実際のチャートデータは入手できません。後でもう一度試してください。",
    "movement_down": "急激な下落 - 理由を確認してください",
    "movement_up": "急激な成長 – リスクを確認する",
    "movement_calm": "大きな変化は見つかりませんでした",
    "footer_note": "この分析は購入の調査には役立ちますが、成長を予測するものではなく、財務上のアドバイスを構成するものでもありません。",
    "reset_note": "すべてのアクティブなポジションとクローズされた取引は削除されます。信号ログ、価格、設定は残ります。",
    "legend_down": "5%以上低下 — 原因を確認してください",
    "legend_up": "成長率 ≥ 5% — リスクを確認する"
  },
  "ko": {
    "signals_nav": "🔔 신호",
    "chart_nav": "일정",
    "assistant_title": "구매 분석 도우미",
    "assistant_note": "성장을 약속하지 않는 시장 징후, 뉴스 소스 및 신호 결과.",
    "signals_journal": "신호 및 로그",
    "candidate": "구매분석 대상자",
    "watch": "관찰하다",
    "risk": "위험 증가",
    "calm": "중요한 신호 없음",
    "insufficient": "데이터가 부족함",
    "pros": "인수",
    "risks": "위험",
    "missing": "무엇이 빠졌나요?",
    "none": "흔적이 발견되지 않았습니다",
    "live_missing": "우리는 새로운 데이터를 수집합니다. 현재 호가가 없으면 거래 결론을 내릴 수 없습니다.",
    "live_only": "정품 바이낸스 데이터만; 규칙은 대략 1분에 한 번씩 업데이트됩니다.",
    "hour": "시간",
    "hours": "시간",
    "open_chart": "일정 공개",
    "refresh": "업데이트",
    "screening_note": "이는 구매 주문이 아닌 조사할 상황의 필터입니다. 신호는 입증된 수익성 있는 전략이 아닙니다.",
    "journal": "신호 결과 로그",
    "coin": "코인",
    "all_coins": "모든 코인",
    "outcome_note": "거래의 이익이 아닌 가격 변동이 표시됩니다. 수수료와 미끄러짐은 고려되지 않습니다. 결과는 수평선 또는 그 이후의 첫 번째 실제 분의 시가에서 가져옵니다. 시간 편차는 60초 미만입니다.",
    "more": "더 보기",
    "methodology": "신호는 어떻게 생성되나요?",
    "methodology_text": "버전 market-context-v1. 후보자: 바이낸스의 최신 시세, 최소 40개의 연속 마감 분 캔들, EMA21보다 높은 EMA9, EMA9보다 높은 가격, 45에서 68까지의 RSI14, 시간당 변동률 +0.5%에서 +5% 미만, 지난 5분 동안의 거래량은 이전 30분의 5분 창 평균 거래량의 최소 1.2 이상, 시간당 거래량은 100만 USDT, 하락하지 않는 비트코인 및 비트코인에 대한 새로운 뉴스 동전 그 자체. 부정적인 관련 헤드라인은 후보자를 차단합니다. 임계값은 성장 확률이 아니라 테스트되지 않은 경험적 방법입니다. 동전에 대한 동일한 유형의 신호는 한 시간에 한 번만 기록되며 새로운 신호는 5분에 한 번만 기록됩니다. 데모 견적은 기록을 생성하지 않습니다. 뉴스 내용은 팩트체크를 통과하지 못했습니다.",
    "time_coin": "시간 / 코인",
    "status": "상태",
    "signal_price": "신호 가격",
    "details": "세부정보",
    "waiting": "아직은 때가 아니다",
    "pending_data": "우리는 실제 데이터를 기다리고 있습니다",
    "measured": "측정됨",
    "journal_empty": "잡지는 아직 비어있습니다. 허구의 이야기 없이 실제 신호 후에 항목이 표시됩니다. 1시간, 4시간, 24시간 후의 결과는 시간이 지남에 따라 채워집니다.",
    "no_setups": "이제 규칙에 따라 특정 상황이 없습니다. 이는 정상적인 결과이며 오류가 아닙니다.",
    "target_time": "예정된 시간",
    "observed_time": "실제 가격 시간",
    "coin_chart": "암호화폐 차트",
    "chart_note": "실제 캔들 종가. 마지막 미완성 양초는 바뀔 수 있습니다. 예측 포인트가 없습니다.",
    "market": "시장",
    "window_1h": "1시간",
    "window_4h": "4시간",
    "window_1d": "1일",
    "window_7d": "7일",
    "paper_purchase": "가상 구매",
    "loading_real": "실제 양초 로드 중...",
    "no_fake_chart": "인위적인 일정은 실제 일정을 대체하지 않습니다.",
    "no_data": "데이터를 사용할 수 없음",
    "shown_window": "표시된 창에서",
    "updated": "업데이트됨",
    "interval": "촛불의 발걸음",
    "high": "최대",
    "low": "최소",
    "time": "시간",
    "price": "가격",
    "observations": "관찰표",
    "chart_library_error": "그래픽 라이브러리를 로드하지 못했습니다. 실제 값은 아래 표에서 확인할 수 있습니다.",
    "news_title": "뉴스 · 출처",
    "publisher_check_note": "우리는 출판의 HTTPS 도메인과 출판 시간을 확인합니다. 감정 분석 - 제목에서 알 수 있듯이.",
    "available": "가능",
    "unavailable": "사용할 수 없음",
    "not_factcheck": "도메인 확인은 뉴스의 진실성이 아닌 링크의 출처를 확인합니다. 이것은 사실 확인이 아닙니다.",
    "rss_missing": "현재 RSS 뉴스를 이용할 수 없습니다. 가상의 제목은 표시되지 않습니다.",
    "time_unknown": "출판 시기는 알려지지 않았다",
    "domain_checked": "도메인이 확인되었습니다.",
    "fresh_article": "최대 24시간 게시",
    "old_article": "오래되었거나 알려지지 않은 데이트",
    "sentiment_negative": "부정적인 어휘",
    "sentiment_positive": "긍정적인 어휘",
    "sentiment_neutral": "중립 어휘",
    "similar_titles": "비슷한 제목이 다음에서도 발견됩니다.",
    "not_independent_proof": "이는 독립적인 확인을 증명하는 것이 아닙니다.",
    "original_title": "원래 제목",
    "source_links": "출처 및 링크",
    "source_links_note": "우리는 CoinTelegraph와 CoinDesk RSS를 읽습니다. Bloomberg와 Binance는 참고용으로만 제공됩니다. 그 내용은 분석되지 않습니다.",
    "reason_fresh_binance": "새로운 바이낸스 인용문이 충분하지 않습니다. 데모 및 예비 USD 가격은 신호에 사용되지 않습니다.",
    "reason_candles": "신선한 연속 분 양초가 충분하지 않습니다.",
    "reason_trend_up": "EMA9가 EMA21 위에 있고 가격이 EMA9 위에 있습니다. 단기 방향은 상승입니다.",
    "reason_trend_weak": "가격이나 짧은 평균은 상승 추세를 확인하지 않습니다.",
    "reason_volume_up": "지난 5분의 회전율은 이전 30분에 비해 증가했습니다.",
    "reason_volume_weak": "볼륨은 움직임의 강화를 확인하지 않습니다.",
    "reason_btc_up": "비트코인은 지난 한 시간 동안 하락하지 않았습니다.",
    "reason_btc_down": "비트코인이 다운되었습니다. 이는 동전의 움직임에 대한 위험입니다.",
    "reason_btc_data": "새로운 비트코인 ​​데이터가 없습니다.",
    "reason_rsi_hot": "RSI14가 75 이상: 무브먼트가 과열되었을 수 있지만 이것이 반전을 보장하지는 않습니다.",
    "reason_large_move": "최소 5%의 시간당 변화: 갑작스러운 움직임의 위험이 증가합니다.",
    "reason_negative_headlines": "관련 또는 거시경제 헤드라인에 부정적인 언어가 포함되어 있습니다. 이는 가격 변동에 대한 확립된 이유가 아닙니다.",
    "reason_coin_news": "이 특정 동전에 대한 최근 헤드라인이 없습니다.",
    "reason_fresh_news": "확인된 도메인과 게시 시간이 포함된 속보가 없습니다.",
    "reason_turnover": "시간별 회전율은 제공되지 않습니다.",
    "reason_low_turnover": "시간당 매출액이 100만 USDT 미만입니다. 이는 시장 심도를 측정하는 것이 아니라 대략적인 활동 필터입니다.",
    "api_invalid": "코인이나 차트 기간을 알 수 없습니다.",
    "api_chart_unavailable": "실제 차트 데이터를 사용할 수 없습니다. 나중에 다시 시도하세요.",
    "movement_down": "급락 - 이유를 확인하세요",
    "movement_up": "급격한 성장 - 위험을 확인하십시오",
    "movement_calm": "중요한 변화가 발견되지 않았습니다",
    "footer_note": "분석은 구매 조사에 도움이 되지만 성장을 예측하거나 재정적 조언을 구성하지는 않습니다.",
    "reset_note": "모든 활성 위치와 마감된 거래가 삭제됩니다. 신호 로그, 가격 및 설정은 그대로 유지됩니다.",
    "legend_down": "하락 ≥ 5% - 원인 확인",
    "legend_up": "성장률 ≥ 5% — 위험 확인"
  },
  "pt": {
    "signals_nav": "🔔 Sinais",
    "chart_nav": "Cronograma",
    "assistant_title": "Assistente de análise de compras",
    "assistant_note": "Sinais de mercado, fontes de notícias e resultados de sinais – sem promessa de crescimento.",
    "signals_journal": "Sinais e registro",
    "candidate": "Candidato para análise de compra",
    "watch": "observar",
    "risk": "Risco aumentado",
    "calm": "Sem sinais significativos",
    "insufficient": "Dados insuficientes",
    "pros": "Argumentos para",
    "risks": "Riscos",
    "missing": "O que está faltando?",
    "none": "Nenhum sinal foi encontrado",
    "live_missing": "Coletamos dados novos. Sem as cotações atuais, a conclusão da negociação não está disponível.",
    "live_only": "Apenas dados genuínos da Binance; as regras são atualizadas aproximadamente uma vez por minuto",
    "hour": "horas",
    "hours": "horas",
    "open_chart": "Agenda aberta",
    "refresh": "Atualizar",
    "screening_note": "Este é um filtro de situações para pesquisar, não uma ordem de compra. Os sinais não são uma estratégia comprovadamente lucrativa.",
    "journal": "Registro de resultados de sinal",
    "coin": "Moeda",
    "all_coins": "Todas as moedas",
    "outcome_note": "A mudança de preço é mostrada, não o lucro do negócio. Comissões e derrapagens não são levadas em consideração. O resultado é obtido a partir do preço de abertura do primeiro minuto real no horizonte ou após ele; o desvio de tempo é inferior a 60 segundos.",
    "more": "Mostrar mais",
    "methodology": "Como o sinal é gerado?",
    "methodology_text": "Versão market-context-v1. Candidato: Cotações recentes da Binance, pelo menos 40 velas de minuto fechadas consecutivas, EMA9 acima de EMA21 e preço acima de EMA9, RSI14 de 45 a 68, variação horária de +0,5% para menos de +5%, volume dos últimos 5 minutos concluídos de pelo menos 1,2 do volume médio da janela de cinco minutos dos 30 minutos anteriores, volume horário de 1 milhão de USDT, Bitcoin não decrescente e notícias frescas sobre a moeda em si. Manchetes relacionadas negativas bloqueiam o candidato. Os limites são heurísticas não testadas, não probabilidades de crescimento. O mesmo tipo de sinal para uma moeda é registrado no máximo uma vez por hora, qualquer novo - não mais do que uma vez a cada 5 minutos. Cotações de demonstração não criam registros. O conteúdo da notícia não passa na verificação dos fatos.",
    "time_coin": "Tempo / moeda",
    "status": "Estado",
    "signal_price": "Preço do sinal",
    "details": "Detalhes",
    "waiting": "Ainda não é hora",
    "pending_data": "Estamos aguardando dados reais",
    "measured": "Medido",
    "journal_empty": "A revista ainda está vazia. As inscrições aparecerão após sinais reais, sem história fictícia. Os resultados após 1, 4 e 24 horas serão preenchidos com o tempo.",
    "no_setups": "Agora não há situações específicas de acordo com as regras. Este é um resultado normal e não um erro.",
    "target_time": "Horário agendado",
    "observed_time": "Hora do preço real",
    "coin_chart": "Gráfico de criptomoeda",
    "chart_note": "Preços reais de fechamento das velas. A última vela inacabada pode mudar; não há pontos preditivos.",
    "market": "o mercado",
    "window_1h": "1 hora",
    "window_4h": "4 horas",
    "window_1d": "1 dia",
    "window_7d": "7 dias",
    "paper_purchase": "Compra virtual",
    "loading_real": "Carregando velas reais...",
    "no_fake_chart": "Um cronograma artificial não substitui o real.",
    "no_data": "Dados não disponíveis",
    "shown_window": "na janela exibida",
    "updated": "Atualizado",
    "interval": "Passo da vela",
    "high": "Máximo",
    "low": "Mínimo",
    "time": "hora",
    "price": "Preço",
    "observations": "Tabela de observações",
    "chart_library_error": "A biblioteca gráfica não foi carregada. Os valores reais estão disponíveis na tabela abaixo.",
    "news_title": "Notícias · fontes",
    "publisher_check_note": "Verificamos o domínio HTTPS da publicação e o horário da publicação; análise de sentimento - como diz o título.",
    "available": "Disponível",
    "unavailable": "Não disponível",
    "not_factcheck": "A verificação de domínio verifica a origem do link, não a veracidade da notícia. Esta não é uma verificação de fatos.",
    "rss_missing": "Notícias RSS reais não estão disponíveis no momento. Títulos fictícios não são exibidos.",
    "time_unknown": "A hora da publicação é desconhecida",
    "domain_checked": "Domínio verificado",
    "fresh_article": "Publicação em até 24 horas",
    "old_article": "Namoro antigo ou desconhecido",
    "sentiment_negative": "Vocabulário negativo",
    "sentiment_positive": "Vocabulário positivo",
    "sentiment_neutral": "Vocabulário neutro",
    "similar_titles": "Títulos semelhantes também são encontrados em",
    "not_independent_proof": "Isto não é prova de confirmação independente.",
    "original_title": "Título original",
    "source_links": "Fontes e links",
    "source_links_note": "Lemos CoinTelegraph e CoinDesk RSS. Bloomberg e Binance são fornecidos apenas como referências; seu conteúdo não é analisado.",
    "reason_fresh_binance": "Não há cotações recentes suficientes da Binance; Os preços de demonstração e reserva em dólares americanos não são usados ​​para sinais.",
    "reason_candles": "Não há velas frescas de minutos consecutivos suficientes.",
    "reason_trend_up": "A EMA9 está acima da EMA21 e o preço está acima da EMA9: a direção curta é de alta.",
    "reason_trend_weak": "O preço ou a média curta não confirmam a tendência de alta.",
    "reason_volume_up": "O volume de negócios dos últimos 5 minutos é aumentado em comparação com os 30 minutos anteriores.",
    "reason_volume_weak": "O volume não confirma o fortalecimento do movimento.",
    "reason_btc_up": "O Bitcoin não diminuiu na última hora.",
    "reason_btc_down": "Bitcoin caiu; é um risco para o movimento da moeda.",
    "reason_btc_data": "Não há dados recentes sobre Bitcoin.",
    "reason_rsi_hot": "RSI14 acima de 75: o movimento pode estar superaquecido, mas isso não garante uma reversão.",
    "reason_large_move": "Mudança horária de pelo menos 5%: aumento do risco de movimentos bruscos.",
    "reason_negative_headlines": "As manchetes relacionadas ou macroeconómicas contêm linguagem negativa. Esta não é uma razão estabelecida para o movimento dos preços.",
    "reason_coin_news": "Não há manchetes recentes sobre esta moeda em particular.",
    "reason_fresh_news": "Nenhuma notícia de última hora com domínio verificado e horário de publicação.",
    "reason_turnover": "A rotatividade por hora não está disponível.",
    "reason_low_turnover": "Faturamento por hora abaixo do limite de 1 milhão de USDT. Este é um filtro bruto de atividade, não uma medida da profundidade do mercado.",
    "api_invalid": "Moeda ou período gráfico desconhecido.",
    "api_chart_unavailable": "Os dados reais do gráfico não estão disponíveis. Tente novamente mais tarde.",
    "movement_down": "Queda acentuada - verifique o motivo",
    "movement_up": "Crescimento acentuado – verifique os riscos",
    "movement_calm": "Nenhuma mudança significativa foi encontrada",
    "footer_note": "A análise ajuda a pesquisar uma compra, mas não prevê crescimento e não constitui aconselhamento financeiro.",
    "reset_note": "Todas as posições ativas e negócios fechados serão excluídos. O registro de sinal, preços e configurações permanecerão.",
    "legend_down": "queda ≥ 5% — verifique a causa",
    "legend_up": "crescimento ≥ 5% — verifique os riscos"
  },
  "tr": {
    "signals_nav": "🔔 Sinyaller",
    "chart_nav": "Program",
    "assistant_title": "Satın alma analizi asistanı",
    "assistant_note": "Büyüme vaadi olmadan pazar işaretleri, haber kaynakları ve sinyal sonuçları.",
    "signals_journal": "Sinyaller ve günlük",
    "candidate": "Satın alma analizi adayı",
    "watch": "gözlemlemek",
    "risk": "Artan risk",
    "calm": "Önemli sinyal yok",
    "insufficient": "Yetersiz veri",
    "pros": "için argümanlar",
    "risks": "Riskler",
    "missing": "Ne eksik?",
    "none": "Hiçbir işaret bulunamadı",
    "live_missing": "Taze veriler topluyoruz. Mevcut kotasyonlar olmadan alım satım sonucu elde edilemez.",
    "live_only": "Yalnızca orijinal Binance verileri; kurallar yaklaşık dakikada bir güncellenir",
    "hour": "saat",
    "hours": "saat",
    "open_chart": "Programı aç",
    "refresh": "Güncelleme",
    "screening_note": "Bu, bir satın alma emri değil, araştırılacak durumların bir filtresidir. Sinyaller kanıtlanmış karlı bir strateji değildir.",
    "journal": "Sinyal sonuçlarının günlüğü",
    "coin": "Madeni para",
    "all_coins": "Tüm paralar",
    "outcome_note": "Anlaşmanın karı değil, fiyat değişimi gösterilir. Komisyonlar ve kaymalar dikkate alınmaz. Sonuç, ufuktaki veya sonraki ilk gerçek dakikanın açılış fiyatından alınır; zaman sapması 60 saniyeden azdır.",
    "more": "Daha fazlasını göster",
    "methodology": "Sinyal nasıl üretilir?",
    "methodology_text": "Sürüm pazar bağlamı-v1. Aday: Binance'in yeni fiyatları, en az 40 ardışık kapalı dakika mumu, EMA9 EMA21'in üzerinde ve fiyatı EMA9'un üzerinde, RSI14 45'ten 68'e, saatlik değişim +%0,5'ten +%5'in altına, tamamlanan son 5 dakikanın hacmi önceki 30 dakikanın beş dakikalık penceresinin ortalama hacminin en az 1,2'si, saatlik hacim 1 milyon USDT, düşmeyen Bitcoin ve koin hakkında yeni haberler kendisi. İlgili olumsuz başlıklar adayı engeller. Eşikler, büyüme olasılıkları değil, test edilmemiş buluşsal yöntemlerdir. Bir madeni para için aynı tür sinyal, saatte bir defadan fazla, yeni bir sinyal ise her 5 dakikada bir defadan fazla kaydedilmez. Demo teklifleri kayıt oluşturmaz. Haberin içeriği doğruluk kontrolünden geçmiyor.",
    "time_coin": "Zaman / madeni para",
    "status": "Durum",
    "signal_price": "Sinyal fiyatı",
    "details": "Ayrıntılar",
    "waiting": "henüz zamanı gelmedi",
    "pending_data": "Gerçek verileri bekliyoruz",
    "measured": "Ölçülen",
    "journal_empty": "Dergi hâlâ boş. Girişler, kurgusal bir hikaye olmadan, gerçek sinyallerden sonra görünecektir. 1, 4 ve 24 saat sonraki sonuçlar zamanla doldurulacaktır.",
    "no_setups": "Artık kurallara göre belirli bir durum yok. Bu normal bir sonuçtur ve bir hata değildir.",
    "target_time": "Planlanan zaman",
    "observed_time": "Gerçek fiyat zamanı",
    "coin_chart": "Kripto para birimi grafiği",
    "chart_note": "Gerçek mum kapanış fiyatları. Son tamamlanmamış mum değişebilir; öngörücü noktalar yoktur.",
    "market": "pazar",
    "window_1h": "1 saat",
    "window_4h": "4 saat",
    "window_1d": "1 gün",
    "window_7d": "7 gün",
    "paper_purchase": "Sanal satın alma",
    "loading_real": "Gerçek mumlar yükleniyor...",
    "no_fake_chart": "Yapay bir program gerçek programın yerini almaz.",
    "no_data": "Veri mevcut değil",
    "shown_window": "görüntülenen pencerede",
    "updated": "Güncellendi",
    "interval": "Mumun adımı",
    "high": "Maksimum",
    "low": "Asgari",
    "time": "zaman",
    "price": "Fiyat",
    "observations": "Gözlem tablosu",
    "chart_library_error": "Grafik kitaplığı yüklenemedi. Gerçek değerler aşağıdaki tabloda mevcuttur.",
    "news_title": "Haberler · kaynaklar",
    "publisher_check_note": "Yayının HTTPS alanını ve yayınlanma zamanını kontrol ediyoruz; başlıkta da belirtildiği gibi duyarlılık analizi.",
    "available": "Mevcut",
    "unavailable": "Mevcut değil",
    "not_factcheck": "Alan adı doğrulaması haberin doğruluğunu değil bağlantının kaynağını doğrular. Bu bir doğruluk kontrolü değil.",
    "rss_missing": "Gerçek RSS haberleri şu anda kullanılamıyor. Kurgusal başlıklar görüntülenmiyor.",
    "time_unknown": "Yayınlanma zamanı bilinmiyor",
    "domain_checked": "Alan adı doğrulandı",
    "fresh_article": "24 saate kadar yayın",
    "old_article": "Eski veya bilinmeyen flört",
    "sentiment_negative": "Olumsuz kelime bilgisi",
    "sentiment_positive": "Olumlu kelime bilgisi",
    "sentiment_neutral": "Tarafsız kelime bilgisi",
    "similar_titles": "Benzer başlıklar şuralarda da mevcut:",
    "not_independent_proof": "Bu bağımsız onayın kanıtı değildir.",
    "original_title": "Orijinal başlık",
    "source_links": "Kaynaklar ve bağlantılar",
    "source_links_note": "CoinTelegraph ve CoinDesk RSS'yi okuyoruz. Bloomberg ve Binance yalnızca referans olarak verilmiştir; içerikleri analiz edilmez.",
    "reason_fresh_binance": "Yeterince yeni Binance kotasyonu yok; Sinyaller için demo ve rezerv USD fiyatları kullanılmaz.",
    "reason_candles": "Yeterli sayıda taze ardışık dakika mumu yok.",
    "reason_trend_up": "EMA9, EMA21'in üzerinde ve fiyat EMA9'un üzerinde: kısa yön yukarı.",
    "reason_trend_weak": "Fiyat veya kısa ortalama yükseliş trendini teyit etmiyor.",
    "reason_volume_up": "Son 5 dakikadaki ciro önceki 30 dakikaya göre arttı.",
    "reason_volume_weak": "Hacim, hareketin güçlendiğini teyit etmiyor.",
    "reason_btc_up": "Bitcoin son bir saattir düşmedi.",
    "reason_btc_down": "Bitcoin düştü; madalyonun hareketi için bir risktir.",
    "reason_btc_data": "Yeni Bitcoin verisi yok.",
    "reason_rsi_hot": "RSI14 75'in üzerinde: hareket aşırı ısınmış olabilir ancak bu bir geri dönüşü garanti etmez.",
    "reason_large_move": "Saatlik en az %5 değişim: ani hareket riskinin artması.",
    "reason_negative_headlines": "İlgili veya makroekonomik başlıklar olumsuz bir dil içeriyor. Bu, fiyat hareketinin yerleşik bir nedeni değildir.",
    "reason_coin_news": "Bu özel madalyonun hakkında yeni bir manşet yok.",
    "reason_fresh_news": "Doğrulanmış alan adı ve yayınlanma zamanı ile son dakika haberi yok.",
    "reason_turnover": "Saatlik ciro mevcut değildir.",
    "reason_low_turnover": "Saatlik ciro 1 milyon USDT eşiğinin altında. Bu, piyasa derinliğinin bir ölçüsü değil, kaba bir faaliyet filtresidir.",
    "api_invalid": "Bilinmeyen para veya grafik dönemi.",
    "api_chart_unavailable": "Gerçek grafik verileri mevcut değil. Daha sonra tekrar deneyin.",
    "movement_down": "Keskin düşüş - nedenini kontrol edin",
    "movement_up": "Keskin büyüme – riskleri kontrol edin",
    "movement_calm": "Önemli bir değişiklik bulunamadı",
    "footer_note": "Analiz, bir satın alma işleminin araştırılmasına yardımcı olur ancak büyümeyi öngörmez ve mali tavsiye teşkil etmez.",
    "reset_note": "Tüm aktif pozisyonlar ve kapatılan işlemler silinecektir. Sinyal günlüğü, fiyatlar ve ayarlar kalacaktır.",
    "legend_down": "≥ %5 düşüş — nedenini kontrol edin",
    "legend_up": "büyüme ≥ %5 — riskleri kontrol edin"
  }
}

LANGUAGE_FLAGS = {
  "ua": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCI+PHBhdGggZmlsbD0iIzAwNUJCQiIgZD0iTTAgMGgxMjAwdjgwMEgweiIvPjxwYXRoIGZpbGw9IiNGRkQ1MDAiIGQ9Ik0wIDQwMGgxMjAwdjQwMEgweiIvPjwvc3ZnPg==",
  "en": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA2MCAzMCIgd2lkdGg9IjEyMDAiIGhlaWdodD0iNjAwIj48Y2xpcFBhdGggaWQ9ImEiPjxwYXRoIGQ9Ik0wIDB2MzBoNjBWMHoiLz48L2NsaXBQYXRoPjxjbGlwUGF0aCBpZD0iYiI+PHBhdGggZD0iTTMwIDE1aDMwdjE1enYxNUgwekgwVjB6VjBoMzB6Ii8+PC9jbGlwUGF0aD48ZyBjbGlwLXBhdGg9InVybCgjYSkiPjxwYXRoIGQ9Ik0wIDB2MzBoNjBWMHoiIGZpbGw9IiMwMTIxNjkiLz48cGF0aCBkPSJtMCAwIDYwIDMwbTAtMzBMMCAzMCIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjYiLz48cGF0aCBkPSJtMCAwIDYwIDMwbTAtMzBMMCAzMCIgY2xpcC1wYXRoPSJ1cmwoI2IpIiBzdHJva2U9IiNDODEwMkUiIHN0cm9rZS13aWR0aD0iNCIvPjxwYXRoIGQ9Ik0zMCAwdjMwTTAgMTVoNjAiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSIxMCIvPjxwYXRoIGQ9Ik0zMCAwdjMwTTAgMTVoNjAiIHN0cm9rZT0iI0M4MTAyRSIgc3Ryb2tlLXdpZHRoPSI2Ii8+PC9nPjwvc3ZnPg==",
  "ru": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5IDYiIHdpZHRoPSI5MDAiIGhlaWdodD0iNjAwIj48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMCAwaDl2M0gweiIvPjxwYXRoIGZpbGw9IiNkNTJiMWUiIGQ9Ik0wIDNoOXYzSDB6Ii8+PHBhdGggZmlsbD0iIzAwMzlhNiIgZD0iTTAgMmg5djJIMHoiLz48L3N2Zz4=",
  "es": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI3NTAiIGhlaWdodD0iNTAwIj48cGF0aCBmaWxsPSIjYWQxNTE5IiBkPSJNMCAwaDc1MHY1MDBIMHoiLz48cGF0aCBmaWxsPSIjZmFiZDAwIiBkPSJNMCAxMjVoNzUwdjI1MEgweiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0yNDkuODQzIDIyMy4wNTVjLTEwLjcyNi0uMDE1LTIwLjQyLTEuMzY0LTI3LjgtMy40NDMgNy4zOC0yLjA4IDE3LjA3NC0zLjM1MyAyNy44LTMuMzc1IDEwLjcyMy4wMjIgMjAuNDcgMS4yOTQgMjcuODQ5IDMuMzc1LTcuMzggMi4wNzktMTcuMTI2IDMuNDI4LTI3Ljg1IDMuNDQzIi8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSJub25lIiBzdHJva2Utd2lkdGg9Ii4yNDMiIGQ9Ik0zMzUuNjQ5IDIxOS4yNzRjMC01LjQwOCA0LjYyMi05Ljc4MSAxMC4zMTMtOS43ODEgNS42NjcgMCAxMC4zMDggNC4zNzMgMTAuMzA4IDkuNzggMCA1LjM5LTQuNjIyIDkuNzYzLTEwLjMwOCA5Ljc2My01LjY5IDAtMTAuMzEzLTQuMzczLTEwLjMxMy05Ljc2MnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgc3Ryb2tlLXdpZHRoPSIxLjIzMiIgZD0iTTQ1MS45NjcgMTM0Ljk0NWMzMS42MSAwIDU5LjczNyA0LjY4IDc4LjA2IDExLjk0MiAxMC40ODUgNC43MzIgMjQuNTYzIDguMjI5IDM5Ljk3MyAxMC4yODkgMTEuNzM1IDEuNTcgMjIuODg3IDEuODkyIDMyLjU4NyAxLjE1IDEyLjk3MS0uMjU1IDMxLjczNCAzLjU0NCA1MC41MDIgMTEuODA3IDE1LjUzNCA2Ljg5MyAyOC41IDE1LjI3IDM3LjExMyAyMy4zOGwtNy40NTMgNi42MzktMi4xNTUgMTguODQ5LTIwLjQ1IDIzLjQxNC0xMC4yMTcgOC42Ny0yNC4yMDQgMTkuMzc1LTEyLjM2MyAxLjAxMS0zLjc2IDEwLjY5Nkw0NTMgMjYzLjgyMWwtMTU3LjA3NyAxOC4zNDYtMy43NjUtMTAuNjk2LTEyLjM4Mi0xLjAxLTI0LjItMTkuMzc2LTEwLjIyMi04LjY3TDIyNC45MTUgMjE5bC0yLjEyNi0xOC44NDktNy40OTItNi42MzljOC42NTEtOC4xMSAyMS42MjMtMTYuNDg3IDM3LjExOS0yMy4zOCAxOC43NjgtOC4yNjMgMzcuNTM1LTEyLjA2MiA1MC40OTctMTEuODA4IDkuNy43NDMgMjAuODU2LjQyMiAzMi41OTItMS4xNSAxNS40MTUtMi4wNiAyOS41MDctNS41NTYgMzkuOTczLTEwLjI4OCAxOC4zNDItNy4yNjIgNDQuODk4LTExLjk0MiA3Ni40ODktMTEuOTQyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIiBzdHJva2Utd2lkdGg9IjEuODU3Ij48cGF0aCBkPSJtNTY0LjUzOSAxODEuNjA1LTkuODk2LTE2LjE2N2MxMC43MzQtNi41NzEgMTguMTAxLTE3Ljk5MSAxOC4xMDEtMzEgMC0xLjQ3MS0uMDg2LTIuOTA0LS4yNjMtNC4zMjYtMS4wMi0yMC42MjYtMjYuMTg4LTM3LjY3LTU4LjA2Ni0zNy42Ny0xNi41ODggMC0zMS41MjMgNC41MjctNDIuMDU3IDExLjc5NC0uMjg3LTMuMTk1LS41MzYtNS45My0xLjAyLTguODM4IDExLjU5Ny02Ljc1OCAyNi42MzMtMTAuODI1IDQzLjA3Ny0xMC44MjUgMzYuNjc4IDAgNjUuMzc2IDIwLjg0MSA2Ni43ODQgNDUuNTI0YTUwIDUwIDAgMCAxIC4xOTYgNC4zNGMwIDEzLjE2My02LjAwNiAyNS4wMTktMTUuNTE1IDMzLjI2Mmw1LjI2IDguNjE4em0tMjIxLjYzNiAwIDkuODk3LTE2LjE2N2MtMTAuNzM1LTYuNTcxLTE4LjEwMi0xNy45OTEtMTguMTAyLTMxIDAtMS40NzEuMDg2LTIuOTA0LjI2My00LjMyNiAxLjAyLTIwLjYyNiAyNi4xODgtMzcuNjcgNTguMDY2LTM3LjY3IDE2LjU4OCAwIDMxLjUyNCA0LjUyNyA0Mi4wNTcgMTEuNzk0LjI4OC0zLjE5NS41MzctNS45MyAxLjAyLTguODM4LTExLjU5Ni02Ljc1OC0yNi42MzMtMTAuODI1LTQzLjA3Ny0xMC44MjUtMzYuNjc4IDAtNjUuMzc1IDIwLjg0MS02Ni43ODQgNDUuNTI0YTUwIDUwIDAgMCAwLS4xOTYgNC4zNGMwIDEzLjE2MyA2LjAwNyAyNS4wMTkgMTUuNTE1IDMzLjI2MmwtNS4yNiA4LjYxOHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTU5MS4wMTQgMTQwLjQ2OGMwLTE2LjExNC0xMC41NDgtMzAuNDg5LTI2LjU0Mi00MC4wMTYgOS44NjMgNy45MzcgMTUuODUgMTguMTkyIDE2LjcyNyAyOS42NDUuMTI0IDEuNDM3LjE5NiAyLjg4OS4xOTYgNC4zNCAwIDEzLjE2My02LjAwNiAyNS4wMTktMTUuNTE1IDMzLjI2Mmw0LjgzMyA4LjhjMTIuNTIyLTkuMzQgMjAuMy0yMi4wNDQgMjAuMy0zNi4wMzF6TTIyNi4yNzIgMTkyLjgxOGMtNy4wMTMtNy44NTUtMTEuMzEtMTguMDA1LTExLjMxLTI5LjEwNGE0Mi42IDQyLjYgMCAwIDEgNC4zNS0xOC44YzEwLjEzLTIwLjg0NyA0MS45MTgtMzYuMDE3IDc5LjY5Ny0zNi4wMTcgMTAuMjk0IDAgMjAuMTQzIDEuMTE2IDI5LjIzOSAzLjE5LTIuMDE3IDIuMTk5LTMuNjAyIDQuNjEzLTUuMTQ1IDcuMDQ2LTcuNTU4LTEuNDctMTUuNjU0LTIuMjY2LTI0LjA5NC0yLjI2Ni0zNC41ODQgMC02My41MTcgMTMuNDUtNzEuOSAzMS42MjRhMzUgMzUgMCAwIDAtMy40ODIgMTUuMjIzYzAgMTEuMDQ2IDUuMTc0IDIwLjk0NyAxMy4yNzQgMjcuNzA2bC0xMi41MjIgMjAuNDUzLTYuNzA2LTUuMzM2IDguNTk5LTEzLjd6TTQ1My44MiA4MC40NDljOC4zODMgMCAxNS41OTIgNS41NDIgMTcuMzA3IDEyLjk3NiAxLjEyMSA2LjU3MiAxLjgyIDE0LjA1NCAxLjk3OSAyMi4wMjQuMDE1LjgzLS4wNTggMS42MzktLjA1OCAyLjQ1My4wMjUuOTQ0LjIwMSAxLjk2LjIxNSAyLjkyMi4yODggMTYuNzIyIDIuNjc4IDMxLjQ4NSA2LjA4NCA0MC41MjRsLTI1LjU0IDI0LjQyOS0yNS44MTUtMjQuNDNjMy40MjUtOS4wMzggNS43OTYtMjMuODAxIDYuMTE3LTQwLjUyMy4wMi0uOTYzLjIwMS0xLjk3OC4yMDEtMi45MjIgMC0uODE0LS4wNTctMS42MjQtLjAzOC0yLjQ1My4xMjQtNy45Ny44MzgtMTUuNDUyIDEuOTY0LTIyLjAyNCAxLjY5Ni03LjQzNCA5LjIwMi0xMi45NzYgMTcuNTctMTIuOTc2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxLjA4MiI+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMTA4IiBkPSJNMTkzLjM4NCAyMjkuNTcxdi02LjUyMm0tMS43NzIgNi41MjJ2LTYuNTIyIiB0cmFuc2Zvcm09Im1hdHJpeCgxLjA5MzYgMCAwIDEuMjQxNzMgNDMuMDE3IC02MS4zODgpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMjciIGQ9Ik0xODkuOTQgMjI5LjU3MXYtNi41MjJtLTEuNjU4IDYuNTIydi02LjUyMm0tMS40NzcgNi41MjJ2LTYuNTIybS0yLjgxOCA2LjE3MS0uMDM5LTUuOTM3bTEuMzc1IDYuMDE1di02LjIxIiB0cmFuc2Zvcm09Im1hdHJpeCgxLjA5MzYgMCAwIDEuMjQxNzMgNDMuMDE3IC02MS4zODgpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuNTQxIiBkPSJNMTgxLjM4NiAyMjguOTUzdi01LjQ3bTEuMzE4IDUuNjI2LS4wMzktNS44MjFtLTQuNzY4IDUuMzUydi00LjgwNW0xLjE0NSA0Ljg4M3YtNS4wMzltMS4xNzkgNS4xOTZ2LTUuMjM2IiB0cmFuc2Zvcm09Im1hdHJpeCgxLjA5MzYgMCAwIDEuMjQxNzMgNDMuMDE3IC02MS4zODgpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuODExIiBkPSJNMTc2LjY3MyAyMjguNjAxdi00LjY0OW0tMS4xNCA0Ljc0NXYtNS4wODdtLTEuMjIzIDQuOTM5di00Ljc0NG0tMi41MDQgNC4zMzMtLjAzOS00LjAxNG0xLjMyMiA0LjI2di00LjQzNCIgdHJhbnNmb3JtPSJtYXRyaXgoMS4wOTM2IDAgMCAxLjI0MTczIDQzLjAxNyAtNjEuMzg4KSIvPjxwYXRoIGQ9Ik0xNzAuNTIyIDIyOC4wNDV2LTMuNjI0bS0xLjE3NSAzLjY2NXYtMy40ODJtLTEuMjgzIDIuODF2LTIuNjE1bS0xLjMxOSAyLjYzOXYtMi4zODdtLTEuMzk2IDIuMDc1di0xLjc3NCIgdHJhbnNmb3JtPSJtYXRyaXgoMS4wOTM2IDAgMCAxLjI0MTczIDQzLjAxNyAtNjEuMzg4KSIvPjxwYXRoIHN0cm9rZS13aWR0aD0iLjEwOCIgZD0iTTIwMC40MzIgMjI5LjIydi01Ljk3Nm0tMy4wMDEgNi4xNzEuMDM5LTYuMzI3bS0yLjIyNiA2LjQwNXYtNi40NDQiIHRyYW5zZm9ybT0ibWF0cml4KDEuMDkzNiAwIDAgMS4yNDE3MyA0My4wMTcgLTYxLjM4OCkiLz48L2c+PGcgc3Ryb2tlLXdpZHRoPSIxLjg1OSI+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggZD0iTTQ1NC4zNyAyOTMuNzM0Yy01OC4zNDIuMDg3LTExMC42MDggNi45OTUtMTQ3LjkwMyAxOC4yMTMtMi42NC43OTUtNC4wNDYgMy4wNzUtMy45OTggNS41OS0uMTU4IDIuNTg3IDEuMjY3IDUuMDg3IDMuOTk4IDUuOTE2IDM3LjI5NSAxMS4yMzMgODkuNTYgMTguMTQgMTQ3LjkwNCAxOC4yMjcgNTguMzM0LS4wODcgMTEwLjU2LTYuOTk0IDE0Ny44NjEtMTguMjI3IDIuNzExLS44MjkgNC4xMi0zLjMzIDMuOTc3LTUuOTE2LjA0OC0yLjUxNS0xLjMzNy00Ljc5NS0zLjk3Ny01LjU5LTM3LjMtMTEuMjE4LTg5LjUyNy0xOC4xMjYtMTQ3Ljg2MS0xOC4yMTN6bS0uMTQyIDkuNThjNTIuNjQ0LjEwMSAxMDAuNDg2IDUuODMxIDEzNi43MTMgMTUuMjA2LTM2LjIyNyA5LjM2LTg0LjA3IDE1LjQzNi0xMzYuNzEzIDE1LjUwMy01Mi42NTItLjA2Ny0xMDAuMjQzLTYuMTQ0LTEzNi40Ny0xNS41MDMgMzYuMjI3LTkuMzc1IDgzLjgxOC0xNS4xMDUgMTM2LjQ3LTE1LjIwNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTQ1My45NjQgMjkzLjY4N2MtNTkuMDQzLjExNS0xMTIuMDM1IDcuNTE2LTE0OS4zMzYgMTkuMDAyIDMuMS0xLjQ3IDIuODIxLTUuMjg4LTEuMDM1LTE1LjIxOC00LjY1Ni0xMi4wMTMtMTEuOTEzLTExLjQ4Ni0xMS45MTMtMTEuNDg2IDQxLjIzOC0xMi4xODEgOTguNjQzLTE5LjgwMiAxNjIuNTMzLTE5Ljg4NCA2My45MTUuMDgyIDEyMS43OCA3LjcwMyAxNjMuMDIyIDE5Ljg4NCAwIDAtNy4yNjItLjUyNy0xMS45MTggMTEuNDg2LTMuODUxIDkuOTMtNC4xMzkgMTMuNzQ4LTEuMDM1IDE1LjIxOC0zNy4yOTUtMTEuNDg2LTkxLjI4LTE4Ljg4Ny0xNTAuMzE4LTE5LjAwMiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNNDU0LjIxMyAyNjYuMTE2Yy02My44OS4xLTEyMS4yOTUgNy43MDItMTYyLjUzMyAxOS45MDItMi43NS44MjQtNS42NTctLjI1My02LjU0OC0yLjg1NC0uODktMi42MDYuNTktNS41OTUgMy4zMzktNi40MzggNDEuNDE1LTEyLjcwMyAxMDAuMy0yMC42NzkgMTY1Ljc1Ny0yMC44MTMgNjUuNDcuMTIgMTI0LjU4IDguMTEgMTY2IDIwLjgxMyAyLjc1Ljg0MyA0LjIzIDMuODMyIDMuMzQgNi40MzgtLjg5NiAyLjYtMy44MDQgMy42NzgtNi41NDkgMi44NTQtNDEuMjQyLTEyLjItOTguODkxLTE5LjgwMi0xNjIuODA2LTE5LjkwMiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTQwOC42NCAyODAuNjNjMC0yLjcyMSAyLjMzMy00LjkzNCA1LjIwNy00LjkzNCAyLjg5MyAwIDUuMjMgMi4yMTMgNS4yMyA0LjkzNCAwIDIuNzE2LTIuMzM3IDQuOTQ4LTUuMjMgNC45NDgtMi44NzQgMC01LjIwNy0yLjIzMi01LjIwNy00Ljk0OCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNDU0LjM0MyAyODQuNTE0aC0xNS42MzVjLTIuODg0IDAtNS4yNzQtMi4xOTgtNS4yNzQtNC45MzMgMC0yLjcyMSAyLjMzNy00Ljk0OSA1LjIxMi00Ljk0OWgzMS42YzIuODc0IDAgNS4yMTYgMi4yMjggNS4yMTYgNC45NDkgMCAyLjczNS0yLjM5IDQuOTMzLTUuMjg4IDQuOTMzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA2ZjQ2IiBkPSJtMzc1LjgwNCAyODguODItMTEuMjQ3IDEuMzA0Yy0yLjg3LjMzNS01LjUyOC0xLjU5LTUuODg3LTQuMjc4LS4zNS0yLjcxNiAxLjY4Ni01LjE4MyA0LjU1NS01LjUwNGwxMS4zMS0xLjMxNyAxMS41MDYtMS4zMjJjMi44NS0uMzM1IDUuNDU2IDEuNTU3IDUuODE1IDQuMjc3LjMzNSAyLjcwMi0xLjc0OSA1LjE4My00LjYwMyA1LjUwNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTMzMC4xMDIgMjg5LjgwM2MwLTIuNzIxIDIuMzM3LTQuOTM0IDUuMjA3LTQuOTM0IDIuODkzIDAgNS4yMjYgMi4yMTMgNS4yMjYgNC45MzQgMCAyLjczNS0yLjMzMyA0Ljk0OC01LjIyNiA0Ljk0OC0yLjg3IDAtNS4yMDctMi4yMTMtNS4yMDctNC45NDgiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0ibTI5Ni4zOCAyOTcuMjkgNC43NTYtNi4wODkgMTYuMDE4IDIuMDI2LTEyLjgwOSA5LjM0Ni03LjA5NC0yLjczLTIuMDMtLjkyM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzAwNmY0NiIgZD0ibTUzMi44OTYgMjg4LjgyIDExLjIzNyAxLjMwNGMyLjg1LjMzNSA1LjUzMy0xLjU5IDUuODg3LTQuMjc4LjMyMS0yLjcxNi0xLjY5Ni01LjE4My00LjU1LTUuNTA0bC0xMS4zMDUtMS4zMTctMTEuNTA2LTEuMzIyYy0yLjg3NC0uMzM1LTUuNDc1IDEuNTU3LTUuODE1IDQuMjc3LS4zNiAyLjcwMiAxLjc0OCA1LjE4MyA0LjU5OCA1LjUwNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTQ4OS42MjIgMjgwLjYzYzAtMi43MjEgMi4zMzctNC45MzQgNS4yMTEtNC45MzQgMi44ODkgMCA1LjIyNiAyLjIxMyA1LjIyNiA0LjkzNCAwIDIuNzE2LTIuMzM3IDQuOTQ4LTUuMjI2IDQuOTQ4LTIuODc0IDAtNS4yMTEtMi4yMzItNS4yMTEtNC45NDhtNzguNTM4IDkuMTczYzAtMi43MjEgMi4zMzgtNC45MzQgNS4yMTItNC45MzQgMi44ODggMCA1LjIyNiAyLjIxMyA1LjIyNiA0LjkzNCAwIDIuNzM1LTIuMzM4IDQuOTQ4LTUuMjI2IDQuOTQ4LTIuODc0IDAtNS4yMTItMi4yMTMtNS4yMTItNC45NDgiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0ibTYxMy4zNiAyOTguNzg5LTUuNzk2LTcuNTg4LTE2LjAxOCAyLjAyNiAxMi44MDggOS4zNDYgOC42MjMtMi43NzQuOTAzLS4yOTR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNDUzLjgyIDg4LjQwNWM0LjM1NSAwIDguMDI0IDIuNzczIDguOTIgNi42MiAxLjA1NCA2LjIxNyAxLjcyOSAxMy4zMTYgMS44NzMgMjAuODEyIDAgLjc4MS0uMDQgMS41NTctLjA0IDIuMzE0IDAgLjkzLjE2MyAxLjg1OS4xODIgMi44MDcuMjY4IDE1Ljc5MyAyLjUzNCAyOS43MTMgNS43NzcgMzguMjc3bC0xNi44MzggMTUuOTQ2LTE2Ljg1Ni0xNS45NDZjMy4yMTQtOC41NDUgNS40OC0yMi40ODQgNS43NjItMzguMjc3LjAyLS45NDguMTgyLTEuODc4LjE5Ny0yLjgwNyAwLS43NTctLjA1My0xLjUzMy0uMDUzLTIuMzE0LjE0NC03LjQ5Ni44Mi0xNC41OTUgMS44ODctMjAuODEyLjg3Ny0zLjg0NyA0Ljg1My02LjYyIDkuMTg4LTYuNjJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjQ3LjkxIDE4NS40MTJjMC0xLjA1LjgzLTEuODk3IDEuODQ3LTEuODk3czEuODQ2Ljg0OCAxLjg0NiAxLjg5N2MwIDEuMDU0LS44MjggMS45MDYtMS44NDYgMS45MDZzLTEuODQ2LS44NTItMS44NDYtMS45MDYiLz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik00NDQuNzQzIDE2NC40OWMwLTQuNzI4IDQuMDY3LTguNTQ1IDkuMDYzLTguNTQ1czkuMDYzIDMuODE3IDkuMDYzIDguNTQ1YzAgNC43NDctNC4wNjcgOC41ODQtOS4wNjMgOC41ODRzLTkuMDYzLTMuODM3LTkuMDYzLTguNTg0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBzdHJva2Utd2lkdGg9IjEuODU5Ij48cGF0aCBmaWxsPSIjZmZmIiBkPSJNNDQ0Ljc0MyAxNDcuNjgyYzAtNC43MjggNC4wNjctOC41ODQgOS4wNjMtOC41ODRzOS4wNjMgMy44NTYgOS4wNjMgOC41ODRjMCA0LjczMi00LjA2NyA4LjU2NC05LjA2MyA4LjU2NHMtOS4wNjMtMy44MzItOS4wNjMtOC41NjRtMS44MjEtMTguMDc4YzAtMy43ODQgMy4yNDctNi44NCA3LjI0Mi02Ljg0IDMuOTc2IDAgNy4yMjQgMy4wNTYgNy4yMjQgNi44NHMtMy4yNDggNi44NDUtNy4yMjQgNi44NDVjLTMuOTk1IDAtNy4yNDItMy4wNi03LjI0Mi02Ljg0NW0yLjAzMS0xNi4zYzAtMi43MTYgMi4zMzctNC45MyA1LjIxMS00LjkzIDIuODg5IDAgNS4yMDcgMi4yMTQgNS4yMDcgNC45MyAwIDIuNzQtMi4zMTggNC45NTItNS4yMDcgNC45NTItMi44NzQgMC01LjIxMS0yLjIxMy01LjIxMS00Ljk1Mm0xLjAzNS0xNC4yNTZjMC0yLjE5OCAxLjg2Ny0zLjk1MSA0LjE3Ni0zLjk1MSAyLjMgMCA0LjE3MiAxLjc1MyA0LjE3MiAzLjk1MSAwIDIuMTgtMS44NzMgMy45NTItNC4xNzIgMy45NTItMi4zMDkgMC00LjE3Ny0xLjc3Mi00LjE3Ny0zLjk1MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJtNDU0LjU3MyAyMTYuMDc5IDUuODg3IDEuMDgyYy0uOTQ5IDIuMzgxLTEuMTQ1IDQuOTgyLTEuMTQ1IDcuNzIyIDAgMTIuMjEgMTAuNDkgMjIuMTQ0IDIzLjQwNCAyMi4xNDQgMTAuMzY2IDAgMTkuMTk0LTYuNDE4IDIyLjIyNi0xNS4yODUuMzQuMjM1IDIuMjMzLTguMDA5IDMuMjEtNy45MDguODE5LjA4Ni43MzMgOC41NjUgMS4wMzQgOC40MTEgMS41IDExLjE2NiAxMS43MDMgMTguNzIgMjMuMTkgMTguNzIgMTIuODk0IDAgMjMuMzUxLTkuODgyIDIzLjM1MS0yMi4xMTYgMC0uOTEtLjA1My0xLjgyLS4xNzctMi43MDFsNy4zMjktNy4yNjIgMy45MzcgOS4yNTRjLTEuNTY2IDIuOTA4LTIuMTg5IDYuMTctMi4xODkgOS42NjcgMCAxMS42NzMgOS45ODggMjEuMTE0IDIyLjMxNyAyMS4xMTQgNy43NTUgMCAxNC41NjctMy43MzEgMTguNTY3LTkuMzkzbDQuNjktNS45NjQtLjAzNiA3LjMxNWMwIDcuMzQ4IDMuMTA0IDEzLjkzOSAxMC4yNzUgMTUuMTAzIDAgMCA4LjIzNC41MDcgMTkuMTQxLTguMDU3IDEwLjkxNy04LjU2NSAxNi45MjktMTUuNjU5IDE2LjkyOS0xNS42NTlsLjkzOCA4LjU4cy05LjA1OCAxNC4wMDUtMTguOTIgMTkuNzE1Yy01LjM5IDMuMTQyLTEzLjU3NiA2LjQzMy0yMC4wODUgNS4zNy02Ljg4OS0xLjExNi0xMS43OTQtNi42NC0xNC4zMjMtMTMuMDA1LTQuOTEgMi44ODgtMTAuNzA2IDQuNTc0LTE2LjkxNCA0LjU3NC0xMy4zNCAwLTI1LjMzLTcuMzE0LTMwLjA3Mi0xOC4zMjctNi4xMzYgNi42Mi0xNC42ODIgMTAuNjkyLTI0LjcwMiAxMC42OTItMTAuNjU0IDAtMjAuNDExLTQuNzk1LTI2LjUyOC0xMi4xNjItNi4wMTIgNS40NzUtMTQuMTg0IDguODUyLTIzLjE4OSA4Ljg1Mi0xMS43OTMgMC0yMi4zMTItNS43NzctMjguMjc2LTE0LjQ5NS01Ljk1NCA4LjcxOC0xNi40NjQgMTQuNDk1LTI4LjIzOCAxNC40OTUtOSAwLTE3LjE5MS0zLjM3Ny0yMy4yMDgtOC44NTItNi4wOTMgNy4zNjctMTUuODcgMTIuMTYyLTI2LjUxOCAxMi4xNjItMTAuMDI1IDAtMTguNTctNC4wNzItMjQuNzEyLTEwLjY5Mi00LjczNyAxMS4wMTMtMTYuNzIyIDE4LjMyNy0zMC4wNjcgMTguMzI3LTYuMjEzIDAtMTEuOTg1LTEuNjg2LTE2Ljg5LTQuNTc0LTIuNTUzIDYuMzY2LTcuNDU4IDExLjg4OS0xNC4zMjcgMTMuMDA1LTYuNTEgMS4wNjMtMTQuNjk2LTIuMjI4LTIwLjEtNS4zNy05Ljg2Ny01LjcxLTE4LjkxNi0xOS43MTYtMTguOTE2LTE5LjcxNmwuOTQ5LTguNTc5czYuMDE2IDcuMDk0IDE2LjkxNCAxNS42NTljMTAuOTE2IDguNTc5IDE5LjE0IDguMDU3IDE5LjE0IDguMDU3IDcuMTcyLTEuMTY0IDEwLjI3LTcuNzU1IDEwLjI3LTE1LjEwM2wtLjAzMy03LjMxNSA0LjY5IDUuOTY0YzMuOTk1IDUuNjYyIDEwLjgzIDkuMzkzIDE4LjU3MSA5LjM5MyAxMi4zMjUgMCAyMi4zMTItOS40NDEgMjIuMzEyLTIxLjExNCAwLTMuNDk3LS42MjctNi43Ni0yLjE5NC05LjY2N2wzLjkzOC05LjI1NCA3LjMzOCA3LjI2MmMtLjExLjg4MS0uMTc3IDEuNzkxLS4xNzcgMi43MDEgMCAxMi4yMzQgMTAuNDQzIDIyLjExNiAyMy4zNDcgMjIuMTE2IDExLjUwNiAwIDIxLjY5LTcuNTU0IDIzLjE4OS0xOC43Mi4zMi4xNTQuMjM1LTguMzI1IDEuMDQ5LTguNDExLjk2OC0uMSAyLjg3NCA4LjE0MyAzLjE5NSA3LjkwOCAzLjA1MSA4Ljg2NyAxMS44NjUgMTUuMjg1IDIyLjI2NCAxNS4yODUgMTIuOTEgMCAyMy4zNjYtOS45MzQgMjMuMzY2LTIyLjE0NCAwLTIuNzQtLjE2Mi01LjM0LTEuMTI1LTcuNzIybDYuMTAyLTEuMDgyIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik02MTUuMTggMjQ1LjI3YzEuMzUtMy45NjcuMTQzLTcuODktMi43MTEtOC43NDctMi44NS0uODk2LTYuMjggMS42MDUtNy42MyA1LjU1Ni0xLjM2MSAzLjk1Mi0uMTQ0IDcuODU2IDIuNzEgOC43NTIgMi44NS44NTcgNi4yNzUtMS42MjQgNy42My01LjU2Mk01MTMuNDkgMjI1LjU3M2MuNTMzLTQuMTM5LTEuNDQ2LTcuNzUtNC40MjUtOC4wOS0yLjk4LS4zNTUtNS44MzUgMi43MDEtNi4zNjYgNi44MjUtLjUzNyA0LjEyIDEuNDQyIDcuNzU1IDQuNDIxIDguMTEgMi45OC4zMzUgNS44MzQtMi43MjEgNi4zNy02Ljg0NW0tMTE4LjA3IDBjLS41MzItNC4xMzkgMS40NjUtNy43NSA0LjQyNi04LjA5IDIuOTgtLjM1NSA1LjgzNCAyLjcwMSA2LjM3IDYuODI1LjUxMyA0LjEyLTEuNDQ2IDcuNzU1LTQuNDI2IDguMTEtMi45NzkuMzM1LTUuODM0LTIuNzIxLTYuMzctNi44NDVNMjkzLjc1IDI0NS4yN2MtMS4zNTYtMy45NjctLjE0NC03Ljg5IDIuNzEtOC43NDcgMi44NTYtLjg5NiA2LjI2MiAxLjYwNSA3LjYxNyA1LjU1NiAxLjMzNyAzLjk1Mi4xMjUgNy44NTYtMi43MTEgOC43NTItMi44NTUuODU3LTYuMjYtMS42MjQtNy42MTYtNS41NjIiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggZD0iTTM0MC4wNTYgMjI1Ljk4Yy0xLjYwNS0xLjI3LTIuODE3LTMuMDQyLTMuMjEtNS4xMzUtLjM5Ny0yLjA3OS4wNTMtNC4xMzkgMS4xMDctNS44MyAwIDAtNC4yMTYtMi4xMjYtOC43MjgtMy4zMS0zLjQyNS0uODk1LTkuNDUtLjkyOS0xMS4yNy0uOTYyLTEuODIxLS4wNTMtNS40NTctLjEzNC01LjQ1Ny0uMTM0cy4zMDIuODI4IDEuMzM3IDIuNjM0YzEuMjQ1IDIuMTggMi4zNTIgMy41NDUgMi4zNTIgMy41NDUtNi4wMzEgMS4zODktMTEuMTY2IDUuMzU1LTE0LjQxNCA5Ljk1NCA0LjcxNCAzLjI1NyAxMC45NzQgNS4yMzUgMTcuMTI1IDQuNjA4IDAgMC0uNTM3IDEuNjQzLS45MjUgNC4xMjQtLjMyIDIuMDQ1LS4zMDIgMi44ODgtLjMwMiAyLjg4OHMzLjM4Ny0xLjI1IDUuMDgzLTEuODczYzEuNjk1LS42MjcgNy4zNDgtMi41ODYgMTAuMjU1LTQuNTQ1IDMuNzk5LTIuNjAxIDcuMDQ3LTUuOTUgNy4wNDctNS45NW0xMy41MjItMi4yOGMxLjA1LTEuNjg2IDEuNTUyLTMuNzUgMS4xNi01Ljg0NC0uMzk0LTIuMDkzLTEuNTM4LTMuODY1LTMuMTQzLTUuMTM1IDAgMCAzLjE3Ni0zLjM2MiA2Ljk3NC01Ljk0NCAyLjg5NC0xLjk2IDguNTYtMy45MzcgMTAuMjU2LTQuNTQ2IDEuNjk2LS42MjIgNS4wODctMS44OTIgNS4wODctMS44OTJzLjAxNS44NjItLjMwNiAyLjkwOGMtLjM4OCAyLjQ2Ny0uOTMgNC4xMDUtLjkzIDQuMTA1IDYuMTYtLjY0MiAxMi40MyAxLjQxOCAxNy4xNDQgNC42OTQtMy4yNDMgNC41OC04LjQxNiA4LjQ3OC0xNC40MjggOS44NjggMCAwIDEuMDg4IDEuMzY1IDIuMzUyIDMuNTQ0IDEuMDM1IDEuODI1IDEuMzQxIDIuNjM1IDEuMzQxIDIuNjM1cy0zLjY0LS4wODItNS40Ni0uMTE1Yy0xLjgyLS4wMzQtNy44NDctLjA1My0xMS4yNzEtLjk2My00LjUxMy0xLjIwMi04Ljc3Ni0zLjI5Ni04Ljc3Ni0zLjI5NiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNMzQ4Ljg4MSAxOTEuODQxcy42MTMtMS4yMTYgMy4zODctMi44MjFjMi43ODMtMS41NzEgNS4xNzgtMS41MjMgNS4xNzgtMS41MjNzLS44MDUgNC42MTItMS4yMTcgNi4yN2MtLjQxMiAxLjYxOS0uNDI2IDYuNTcyLTEuNDk0IDExLjAzMS0xLjA3MyA0LjQ2LTMuMDEzIDguMDI0LTMuMDEzIDguMDI0YTkuNDggOS40OCAwIDAgMC03LjQ5Ny0xLjk3OWMtMi43NzguNDc1LTUuMDMgMi4xMTMtNi4zMzIgNC4yNzMgMCAwLTMuMTA0LTIuNzE2LTUuNzMtNi41NTMtMi42LTMuODM3LTQuNDAxLTguNDY0LTUuMzY0LTkuODY3LS45ODItMS40MTgtMy40MS01LjUwNC0zLjQxLTUuNTA0czIuMjMyLS44MjkgNS40MjItLjI0YzMuMTk1LjU5NSA0LjE5NiAxLjU1NyA0LjE5NiAxLjU1Ny0uNzE0LTYuMDk3IDEuMzIyLTEyLjQ2OCA0LjkwNS0xNy4wOTUgNS4wMyAzLjE5IDkuNDMyIDguNDk3IDEwLjk3IDE0LjQyN3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0zMzUuNjQ5IDIxOS4yNzRjMC01LjQwOCA0LjYyMi05Ljc4MSAxMC4zMTMtOS43ODEgNS42NjcgMCAxMC4zMDggNC4zNzMgMTAuMzA4IDkuNzggMCA1LjM5LTQuNjIyIDkuNzYzLTEwLjMwOCA5Ljc2My01LjY5IDAtMTAuMzEzLTQuMzczLTEwLjMxMy05Ljc2MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJNNDYzLjQ0IDE3OS45MTRzLjg5LTEuMjUgNC4zMzQtMi41YzMuNDQtMS4yNSA2LjA3OS0uNzYyIDYuMDc5LS43NjJzLTEuODM1IDUuMDItMi42NCA2Ljc3M2MtLjggMS43NTgtMS44MzQgNy4yNjctMy45OCAxMi4wMTQtMi4wODQgNC43OC00Ljk5MSA4LjM3Ny00Ljk5MSA4LjM3Ny0xLjg5My0yLjE2LTQuNzQzLTMuNTYzLTcuOTU3LTMuNTYzLTMuMTk1IDAtNi4wNDUgMS40MDMtNy45MzcgMy41NjMgMCAwLTIuOTA4LTMuNTk3LTUuMDEtOC4zNzctMi4xMjctNC43NDctMy4xNzYtMTAuMjU2LTMuOTYyLTEyLjAxNC0uOC0xLjc1My0yLjY1OC02Ljc3My0yLjY1OC02Ljc3M3MyLjY1OC0uNDg5IDYuMDgzLjc2MmMzLjQ0IDEuMjUgNC4zNTQgMi41IDQuMzU0IDIuNS40OC02LjkxMiA0LjA4Ni0xMy42MzIgOS4wMjUtMTguMTI2IDQuOTU4IDQuNDk0IDguNzc1IDExLjIxNCA5LjI2IDE4LjEyNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTQ0Ni40OTIgMjE2LjMzM2MtMS41MzMtMS43MDUtMi41MTUtMy45MTgtMi41MTUtNi4zMTggMC0yLjM4MS45MS00LjYwOCAyLjQ0My02LjI4NSAwIDAtNC4yNDQtMy4xNzYtOS4wMjUtNS4zMzYtMy42MjEtMS42NTctMTAuMzQ2LTIuODAyLTEyLjM2My0zLjE3Ni0yLjAzMS0uMzg4LTYuMDY0LTEuMTUtNi4wNjQtMS4xNXMuMTYzLjk2My45NDMgMy4xNzZjLjk0OSAyLjY4OCAxLjg5MyA0LjQxMiAxLjg5MyA0LjQxMi02Ljk5LjQyMi0xMy41NzYgMy45LTE4LjE0IDguNDExIDQuNTY0IDQuNDc0IDExLjEzMiA3Ljg3IDE4LjE0IDguMzMgMCAwLS45NDQgMS43MDYtMS44OTMgNC40MDctLjc4IDIuMTgtLjk0MyAzLjE1Ny0uOTQzIDMuMTU3czQuMDMzLS43NDMgNi4wNjQtMS4xMTJjMi4wMTctLjQwNyA4Ljc0Mi0xLjUzNyAxMi4zNjMtMy4yMDkgNC43OC0yLjE2NSA5LjA5Ny01LjI4OCA5LjA5Ny01LjI4OG0xNS41MzgtLjAxOWMxLjUzNC0xLjcwNSAyLjUxLTMuOTE4IDIuNTEtNi4zMThhOS4zIDkuMyAwIDAgMC0yLjQ0Mi02LjI4NXM0LjI0OS0zLjE3NiA5LjAzLTUuMzM2YzMuNjM1LTEuNjU3IDEwLjM2LTIuODAyIDEyLjM3Ny0zLjE3NiAxLjk5Ny0uMzg4IDYuMDI2LTEuMTUgNi4wMjYtMS4xNXMtLjE0Ljk2My0uOTQ0IDMuMTc2Yy0uOTQ4IDIuNjg4LTEuODczIDQuNDEyLTEuODczIDQuNDEyIDYuOTk0LjQyMiAxMy41NyAzLjkgMTguMTIxIDguNDExLTQuNTUgNC40NzQtMTEuMTEzIDcuODctMTguMTIgOC4zMyAwIDAgLjkyNCAxLjcwNiAxLjg3MiA0LjQwNy43ODYgMi4xOC45NDQgMy4xNTcuOTQ0IDMuMTU3cy00LjAxLS43NDMtNi4wMjYtMS4xMTJjLTIuMDE3LS40MDctOC43NDItMS41MzctMTIuMzc4LTMuMjA5LTQuNzgtMi4xNjUtOS4wOTYtNS4yODgtOS4wOTYtNS4yODhtOTcuOTk2LTI0LjUxMXMtLjYxMy0xLjIxNi0zLjM4Ny0yLjgyMWMtMi43ODMtMS41NzEtNS4xNzgtMS41MjMtNS4xNzgtMS41MjNzLjgwNSA0LjYxMiAxLjIxNyA2LjI3Yy40MTIgMS42MTkuNDI2IDYuNTcyIDEuNDk0IDExLjAzMSAxLjA3MyA0LjQ2IDMuMDEzIDguMDI0IDMuMDEzIDguMDI0YTkuNDggOS40OCAwIDAgMSA3LjQ5Ny0xLjk3OWMyLjc3OC40NzUgNS4wMyAyLjExMyA2LjMzMiA0LjI3MyAwIDAgMy4xMDQtMi43MTYgNS43My02LjU1MyAyLjYtMy44MzcgNC40MDEtOC40NjQgNS4zNjQtOS44NjcuOTgyLTEuNDE4IDMuNDEtNS41MDQgMy40MS01LjUwNHMtMi4yMzItLjgyOS01LjQyMi0uMjRjLTMuMTk1LjU5NS00LjE5NiAxLjU1Ny00LjE5NiAxLjU1Ny43MTQtNi4wOTctMS4zMjItMTIuNDY4LTQuOTA1LTE3LjA5NS01LjAzIDMuMTktOS40MzIgOC40OTctMTAuOTcgMTQuNDI3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNNTY4Ljg3NCAyMjUuOThjMS41OS0xLjI3IDIuODIxLTMuMDQyIDMuMTktNS4xMzVhOC4xMyA4LjEzIDAgMCAwLTEuMDgyLTUuODNzNC4xOTEtMi4xMjYgOC42OTgtMy4zMWMzLjQzLS44OTUgOS40NzUtLjkyOSAxMS4yNzItLjk2MiAxLjgyNS0uMDUzIDUuNDYtLjEzNCA1LjQ2LS4xMzRzLS4yODcuODI4LTEuMzMxIDIuNjM0Yy0xLjI1NSAyLjE4LTIuMzU3IDMuNTQ1LTIuMzU3IDMuNTQ1IDYuMDI2IDEuMzg5IDExLjE2IDUuMzU1IDE0LjQxMyA5Ljk1NC00LjY5NCAzLjI1Ny0xMC45NTUgNS4yMzUtMTcuMTI0IDQuNjA4IDAgMCAuNTUgMS42NDMuOTI5IDQuMTI0LjI5NyAyLjA0NS4yODMgMi44ODguMjgzIDIuODg4cy0zLjM5Mi0xLjI1LTUuMDY0LTEuODczYy0xLjY5NS0uNjI3LTcuMzUyLTIuNTg2LTEwLjI2LTQuNTQ1LTMuNzgtMi42MDEtNy4wMjctNS45NS03LjAyNy01Ljk1bS0xMy41MzctMi4yOGMtMS4wNTQtMS42ODYtMS41MzMtMy43NS0xLjE2NC01Ljg0NC4zOTgtMi4wOTMgMS41NTctMy44NjUgMy4xNTctNS4xMzUgMCAwLTMuMTktMy4zNjItNi45ODktNS45NDQtMi44ODgtMS45Ni04LjU2NS0zLjkzNy0xMC4yNTYtNC41NDYtMS42OTUtLjYyMi01LjA2Ny0xLjg5Mi01LjA2Ny0xLjg5MnMtLjAxNS44NjIuMzAxIDIuOTA4Yy4zNzkgMi40NjcuOTE1IDQuMTA1LjkxNSA0LjEwNS02LjE1NS0uNjQyLTEyLjQzNSAxLjQxOC0xNy4xMyA0LjY5NCAzLjI1MyA0LjU4IDguNDA3IDguNDc4IDE0LjQxOSA5Ljg2OCAwIDAtMS4wODggMS4zNjUtMi4zNDMgMy41NDQtMS4wNDkgMS44MjUtMS4zMzEgMi42MzUtMS4zMzEgMi42MzVzMy42MTYtLjA4MiA1LjQzNy0uMTE1YzEuOC0uMDM0IDcuODctLjA1MyAxMS4yNy0uOTYzIDQuNDk5LTEuMjAyIDguNzYyLTMuMjk2IDguNzYyLTMuMjk2IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTUyLjY0NSAyMTkuMjc0YzAtNS40MDggNC42MTMtOS43ODEgMTAuMzA4LTkuNzgxIDUuNzEgMCAxMC4zMjggNC4zNzMgMTAuMzI4IDkuNzggMCA1LjM5LTQuNjE4IDkuNzYzLTEwLjMyOCA5Ljc2My01LjY5NSAwLTEwLjMwOC00LjM3My0xMC4zMDgtOS43NjJtMTE1LjMxNyAyMS42ODljLTIuNDI5LTIuNTY3LTcuNDU4LTIuMDI2LTExLjIxOCAxLjE4My0zLjc2NSAzLjE5LTQuODU4IDcuODktMi40MjkgMTAuNDM4IDIuNDI5IDIuNTY3IDcuNDU4IDIuMDEyIDExLjIxOC0xLjE3OCAzLjc2NS0zLjIyOSA0Ljg1OC03LjkwOSAyLjQzLTEwLjQ0MyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNNjUzLjMxOSAyNDcuMThjLjUxNy0xLjc1NyAxLjY5NS0zLjU0OSAzLjQyNS01LjAzNCAzLjc2LTMuMjA5IDguNzktMy43NSAxMS4yMTgtMS4xODMuMzAyLjM0LjY0Mi43OTUuODM4IDEuMTk4IDAgMCA1LjIyNi05LjkxNiAxMS40MTUtMTMuMjA2IDYuMTk0LTMuMzMgMTYuNjY1LTIuNDg2IDE2LjY2NS0yLjQ4NiAwLTcuNjAyLTYuMjI3LTEzLjc0OC0xNC4yNTUtMTMuNzQ4LTQuNzEgMC05LjE2OSAxLjk2LTExLjc5NCA1LjI3bC0xLjA4Mi01LjEwMnMtNi40NTcgMS4yODMtOS40MjIgOC42NjVjLTIuOTQxIDcuNC4yNjggMTguMDkyLjI2OCAxOC4wOTJzLTEuNjA1LTQuNTk0LTQuMDI4LTcuNjU1Yy0yLjQxLTMuMDM2LTguNTk5LTYuMzY2LTExLjgyNy03Ljg4NC0zLjIyOS0xLjUwNC02LjUyOS0zLjc3LTYuNTI5LTMuNzdzLS4xNDQuODI5LS4yNjkgMi44NzRjLS4xMjQgMi40NDguMDcyIDMuOTUyLjA3MiAzLjk1Mi01LjkyLS43NzYtMTIuODI3LjE4Ny0xOC4yMTIgMi4yOCAyLjMgNC41MjcgNi42ODcgOC43ODUgMTIuNDMgMTAuOTY1IDAgMC0yLjA2OSAxLjcwNS0zLjk2IDMuNTc4LTEuNTY3IDEuNTktMi4wNjUgMi4zMzItMi4wNjUgMi4zMzJsNi4wODMuODYzYzIuMDEyLjI2OCA4LjczNyAxLjMzMSAxMi43NTIgMS4wNjMgMi45Ni0uMTg3IDYuMjgtLjY3NSA4LjI3Ny0xLjA2M20tMzk3LjcyMi0uMDAxYy0uNTE4LTEuNzU3LTEuNjg3LTMuNTQ5LTMuNDI1LTUuMDM0LTMuNzY1LTMuMjA5LTguNzgtMy43NS0xMS4yMjQtMS4xODNhNS4yIDUuMiAwIDAgMC0uODM4IDEuMTk4cy01LjI0NS05LjkxNi0xMS40MzQtMTMuMjA2Yy02LjE3LTMuMzMtMTYuNjQtMi40ODYtMTYuNjQtMi40ODYgMC03LjYwMiA2LjIyNi0xMy43NDggMTQuMjUtMTMuNzQ4IDQuNzI4IDAgOS4xNTQgMS45NiAxMS44MDggNS4yN2wxLjA3My01LjEwMnM2LjQ1NyAxLjI4MyA5LjQxNyA4LjY2NWMyLjk1NSA3LjQtLjI2OCAxOC4wOTItLjI2OCAxOC4wOTJzMS42MDQtNC41OTQgNC4wMzMtNy42NTVjMi40MjQtMy4wMzYgOC42MTItNi4zNjYgMTEuODM2LTcuODg0IDMuMjItMS41MDQgNi41MzQtMy43NyA2LjUzNC0zLjc3cy4xMjQuODI5LjI1NCAyLjg3NGMuMTI0IDIuNDQ4LS4wNzIgMy45NTItLjA3MiAzLjk1MiA1LjkwMS0uNzc2IDEyLjgyMy4xODcgMTguMjEyIDIuMjgtMi4zMDQgNC41MjctNi42NzcgOC43ODUtMTIuNDM1IDEwLjk2NSAwIDAgMi4wNyAxLjcwNSAzLjk1NiAzLjU3OCAxLjU3NiAxLjU5IDIuMDg5IDIuMzMyIDIuMDg5IDIuMzMycy00LjA2Ny41NzUtNi4wNzkuODYzYy0yLjA0LjI2OC04Ljc0MiAxLjMzMS0xMi43NTYgMS4wNjMtMi45Ni0uMTg3LTYuMjgtLjY3NS04LjI5MS0xLjA2MyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNMjQwLjk0OCAyNDAuOTYzYzIuNDQzLTIuNTY3IDcuNDU5LTIuMDI2IDExLjIyNCAxLjE4MyAzLjc3OSAzLjE5IDQuODQ3IDcuODkgMi40MjMgMTAuNDM4LTIuNDIzIDIuNTY3LTcuNDU4IDIuMDEyLTExLjIxOC0xLjE3OC0zLjc2NS0zLjIyOS00Ljg1Mi03LjkwOS0yLjQyOS0xMC40NDNtMjAzLjAyOS0zMC45NDhjMC01LjQwMyA0LjYxOC05Ljc2MiAxMC4zMDgtOS43NjJzMTAuMzI4IDQuMzU5IDEwLjMyOCA5Ljc2MmMwIDUuNDA4LTQuNjE4IDkuNzgxLTEwLjMyOCA5Ljc4MS01LjY5IDAtMTAuMzA4LTQuMzczLTEwLjMwOC05Ljc4MSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PGcgc3Ryb2tlLXdpZHRoPSIxLjIzMSI+PHBhdGggZmlsbD0iIzAwNDRhZCIgZD0iTTQzMi44MjYgNjEuNThjMC0xMS4wNSA5LjQ0LTE5Ljk3IDIxLjA2Ni0xOS45NyAxMS42MyAwIDIxLjA2NyA4LjkyIDIxLjA2NyAxOS45NyAwIDExLjAxMy05LjQzNiAxOS45MzItMjEuMDY3IDE5LjkzMi0xMS42MjUgMC0yMS4wNjYtOC45Mi0yMS4wNjYtMTkuOTMxIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik00NDguMzc1IDUuNjE2djEwLjc3N2gtMTEuNTI2VjI3LjMyaDExLjUyNnYzMS40MzVoLTE0LjUyYy0uMTcxIDEuMDI1LTEuMDQ4IDEuNzczLTEuMDQ4IDIuODQ0IDAgMi43NTMuNTggNS40IDEuNjQ3IDcuNzg0LjAyOS4wNjQuMTIuMDg2LjE1LjE1aDM4LjYyYy4wMy0uMDY0LjEyLS4wODYuMTUtLjE1YTE5LjA1IDE5LjA1IDAgMCAwIDEuNjQ2LTcuNzg0YzAtMS4wNjctLjg4LTEuODIxLTEuMDQ4LTIuODQ0SDQ1OS45VjI3LjMyaDExLjUyNlYxNi4zOTNINDU5LjlWNS42MTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48L2c+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI5OC4xODEgMTk1LjcwMWMwLS42MDguNDc2LTEuMDkyIDEuMDYyLTEuMDkyLjU4OCAwIDEuMDYuNDg0IDEuMDYgMS4wOTJzLS40NzIgMS4wOTUtMS4wNiAxLjA5NWMtLjU4NiAwLTEuMDYyLS40ODctMS4wNjItMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02ODUuMzI2IDIxMC44MjljMC0yLjc0IDIuMjc2LTQuOTIgNS4wNzUtNC45MiAyLjgxMyAwIDUuMDcgMi4xOCA1LjA3IDQuOTIgMCAyLjczNS0yLjI1NyA0LjkyOS01LjA3IDQuOTI5LTIuOCAwLTUuMDc1LTIuMTk0LTUuMDc1LTQuOTI5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjk5LjYzNCAxOTIuODk2YzAtLjYwNC40NzMtMS4wOTMgMS4wNjItMS4wOTMuNTg0IDAgMS4wNi40ODkgMS4wNiAxLjA5MyAwIC42MTEtLjQ3NiAxLjA5OC0xLjA2IDEuMDk4LS41ODkgMC0xLjA2Mi0uNDg3LTEuMDYyLTEuMDk4Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjkyLjI3MSAxOTguMTkzYzAtMi43MiAyLjI2Mi00LjkyIDUuMDc2LTQuOTIgMi43OTMgMCA1LjA3IDIuMiA1LjA3IDQuOTIgMCAyLjc1NC0yLjI3NyA0Ljk0OC01LjA3IDQuOTQ4LTIuODE0IDAtNS4wNzYtMi4xOTQtNS4wNzYtNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zMDAuNiAxODkuNjQ4YzAtLjYwNC40NzctMS4wOTYgMS4wNjctMS4wOTYuNTg0IDAgMS4wNi40OTEgMS4wNiAxLjA5NiAwIC42MDctLjQ3NiAxLjA5OC0xLjA2IDEuMDk4LS41OSAwLTEuMDY3LS40OTEtMS4wNjctMS4wOTgiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02OTYuODkgMTgzLjU2NGMwLTIuNzIgMi4yOC00LjkzNCA1LjA5OC00LjkzNCAyLjc5NCAwIDUuMDcgMi4yMTMgNS4wNyA0LjkzNCAwIDIuNzM1LTIuMjc3IDQuOTQ4LTUuMDcgNC45NDgtMi44MTggMC01LjEtMi4yMTMtNS4xLTQuOTQ4eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMzAwLjcyNSAxODYuMTYyYzAtLjYwNy40NzUtMS4wOTQgMS4wNi0xLjA5NHMxLjA2MS40ODcgMS4wNjEgMS4wOTRjMCAuNjA5LS40NzYgMS4wOTYtMS4wNjIgMS4wOTYtLjU4NCAwLTEuMDYtLjQ4Ny0xLjA2LTEuMDk2Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjk3LjQ4NiAxNjcuODY3YzAtMi43MzUgMi4yNzItNC45MjkgNS4wNjUtNC45MjkgMi44IDAgNS4wNzYgMi4xOTQgNS4wNzYgNC45MjkgMCAyLjc0LTIuMjc3IDQuOTM0LTUuMDc2IDQuOTM0LTIuNzkzIDAtNS4wNjUtMi4xOTQtNS4wNjUtNC45MzR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yOTkuOTM2IDE4Mi43MzFjMC0uNjA0LjQ3Ny0xLjA5MiAxLjA2LTEuMDkyLjU5IDAgMS4wNjYuNDg4IDEuMDY2IDEuMDkyIDAgLjYxLS40NzcgMS4wOTktMS4wNjYgMS4wOTktLjU4MyAwLTEuMDYtLjQ4OC0xLjA2LTEuMDk5Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjkzLjcxNyAxNTIuNDE0YzAtMi43MiAyLjI3Ny00LjkyIDUuMDY2LTQuOTIgMi44MTcgMCA1LjA5MyAyLjIgNS4wOTMgNC45MiAwIDIuNzUtMi4yNzYgNC45NDgtNS4wOTMgNC45NDgtMi43ODkgMC01LjA2Ni0yLjE5OC01LjA2Ni00Ljk0OHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI5OC4zMDEgMTc5LjYxN2MwLS42MDcuNDc2LTEuMDk0IDEuMDYyLTEuMDk0LjU4OCAwIDEuMDYyLjQ4NyAxLjA2MiAxLjA5NHMtLjQ3NCAxLjEtMS4wNjIgMS4xYy0uNTg2IDAtMS4wNjItLjQ5Mi0xLjA2Mi0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02ODUuOSAxMzguMzljMC0yLjczNiAyLjI3NS00LjkzIDUuMDc0LTQuOTMgMi44MTMgMCA1LjA4IDIuMTk0IDUuMDggNC45MjkgMCAyLjc0LTIuMjY3IDQuOTUzLTUuMDggNC45NTMtMi43OTkgMC01LjA3NC0yLjIxMy01LjA3NC00Ljk1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI5Ni4xMjEgMTc3LjA2YzAtLjYwOC40NzUtMS4xIDEuMDYtMS4xLjU5IDAgMS4wNjUuNDkyIDEuMDY1IDEuMSAwIC42MDMtLjQ3NSAxLjA5NS0xLjA2NCAxLjA5NS0uNTg2IDAtMS4wNi0uNDkyLTEuMDYtMS4wOTYiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02NzUuNDggMTI2Ljg2OWMwLTIuNzM1IDIuMjctNC45NDggNS4wNjktNC45NDggMi44MTggMCA1LjA4OSAyLjIxMyA1LjA4OSA0Ljk0OCAwIDIuNzItMi4yNzEgNC45MzQtNS4wOSA0LjkzNC0yLjc5OCAwLTUuMDY5LTIuMjEzLTUuMDY5LTQuOTM0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjkzLjU4OCAxNzQuOTMzYzAtLjYwOC40NzYtMS4xIDEuMDY2LTEuMS41ODQgMCAxLjA2LjQ5MiAxLjA2IDEuMSAwIC42MDMtLjQ3NiAxLjA5NS0xLjA2IDEuMDk1LS41OSAwLTEuMDY2LS40OTItMS4wNjYtMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02NjMuMzcgMTE3LjI5NGMwLTIuNzQgMi4yNzYtNC45NTMgNS4wOTMtNC45NTMgMi43OTUgMCA1LjA3IDIuMjEzIDUuMDcgNC45NTMgMCAyLjcxNi0yLjI3NSA0LjkyOS01LjA3IDQuOTI5LTIuODE3IDAtNS4wOTMtMi4yMTMtNS4wOTMtNC45M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI5MC41NjIgMTczLjE5MmMwLS42MDcuNDc1LTEuMDkxIDEuMDYtMS4wOTEuNTkgMCAxLjA2NS40ODQgMS4wNjUgMS4wOTEgMCAuNjA4LS40NzYgMS4xLTEuMDY0IDEuMS0uNTg2IDAtMS4wNi0uNDkyLTEuMDYtMS4xIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjQ4LjkwNSAxMDkuNDUyYzAtMi43MzUgMi4yNzEtNC45MTQgNS4wNy00LjkxNCAyLjgxMyAwIDUuMDkgMi4xOCA1LjA5IDQuOTE0IDAgMi43NC0yLjI3NyA0Ljk1My01LjA5IDQuOTUzLTIuNzk5IDAtNS4wNy0yLjIxMy01LjA3LTQuOTUzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjg3LjQyMiAxNzEuOTVjMC0uNjAzLjQ3Ni0xLjA5NCAxLjA2NS0xLjA5NC41ODUgMCAxLjA2Mi40OSAxLjA2MiAxLjA5NSAwIC42MDctLjQ3OCAxLjA5OC0xLjA2MiAxLjA5OC0uNTg5IDAtMS4wNjUtLjQ5LTEuMDY1LTEuMDk4Ii8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjc1LjI0OCAxOTIuODE4YzYuODI5LTcuODU1IDExLjAxMy0xOC4wMDUgMTEuMDEzLTI5LjEwNGE0MS40ODggNDIuNjA1IDAgMCAwLTQuMjM2LTE4LjhjLTkuODY0LTIwLjg0Ny00MC44Mi0zNi4wMTctNzcuNjA4LTM2LjAxNy0xMC4wMjQgMC0xOS42MTUgMS4xMTYtMjguNDcyIDMuMTkgMS45NjQgMi4xOTkgMy41MDcgNC42MTMgNS4wMSA3LjA0NiA3LjM2LTEuNDcgMTUuMjQzLTIuMjY2IDIzLjQ2Mi0yLjI2NiAzMy42NzggMCA2MS44NTIgMTMuNDUgNzAuMDE1IDMxLjYyNGEzNC4wNzYgMzQuOTkzIDAgMCAxIDMuMzkxIDE1LjIyM2MwIDExLjA0Ni01LjAzOCAyMC45NDctMTIuOTI2IDI3LjcwNmwxMi4xOTQgMjAuNDUzIDYuNTMtNS4zMzYtOC4zNzMtMTMuN3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNjMzLjg5NSAxMDMuODYyYzAtMi43MiAyLjI3NS00LjkzMyA1LjA4OS00LjkzMyAyLjc5NCAwIDUuMDc1IDIuMjEzIDUuMDc1IDQuOTMzIDAgMi43MzUtMi4yODIgNC45NDgtNS4wNzUgNC45NDgtMi44MTQgMC01LjA5LTIuMjEzLTUuMDktNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yODMuOTEzIDE3MS4yNjhjMC0uNjA0LjQ3NS0xLjA5OSAxLjA2LTEuMDk5LjU5IDAgMS4wNjQuNDk1IDEuMDY0IDEuMSAwIC42MDMtLjQ3NCAxLjA5NS0xLjA2NCAxLjA5NS0uNTg1IDAtMS4wNi0uNDkyLTEuMDYtMS4wOTYiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik02MTcuMTE2IDEwMC43ODdjMC0yLjcyIDIuMjcyLTQuOTQ4IDUuMDctNC45NDggMi44MTggMCA1LjA4NSAyLjIyNyA1LjA4NSA0Ljk0OCAwIDIuNzItMi4yNjcgNC45MzQtNS4wODQgNC45MzQtMi43OTkgMC01LjA3LTIuMjEzLTUuMDctNC45MzR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yODAuNTggMTcxLjA3N2MwLS42MDQuNDc2LTEuMDkyIDEuMDY1LTEuMDkyLjU4NSAwIDEuMDYxLjQ4OCAxLjA2MSAxLjA5MiAwIC42MDgtLjQ3NiAxLjEtMS4wNjEgMS4xLS41ODkgMC0xLjA2NS0uNDkyLTEuMDY1LTEuMSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTYwMS4xODYgOTkuOTI1YzAtMi43MiAyLjI3Ny00LjkxNSA1LjA5LTQuOTE1IDIuNzk5IDAgNS4wNzQgMi4xOTQgNS4wNzQgNC45MTUgMCAyLjc0LTIuMjc1IDQuOTUzLTUuMDc0IDQuOTUzLTIuODEzIDAtNS4wODktMi4yMTMtNS4wODktNC45NTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNzcuMzEgMTcxLjIwMWMwLS42MDQuNDc3LTEuMDk1IDEuMDY0LTEuMDk1LjU5IDAgMS4wNjIuNDkxIDEuMDYyIDEuMDk1IDAgLjYwNy0uNDcyIDEuMDk5LTEuMDYyIDEuMDk5LS41ODcgMC0xLjA2NS0uNDkyLTEuMDY1LTEuMDk5Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNTg1LjU1IDEwMC40ODVjMC0yLjcyIDIuMjgzLTQuOTMzIDUuMDktNC45MzMgMi44MTggMCA1LjA3NSAyLjIxMyA1LjA3NSA0LjkzMyAwIDIuNzM1LTIuMjU3IDQuOTQ4LTUuMDc1IDQuOTQ4LTIuODA3IDAtNS4wOS0yLjIxMy01LjA5LTQuOTQ4eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjc0LjA0NCAxNzEuMjAxYzAtLjYwNC40NzUtMS4wOTUgMS4wNi0xLjA5NXMxLjA2LjQ5MSAxLjA2IDEuMDk1YzAgLjYwNy0uNDc1IDEuMDk5LTEuMDYgMS4wOTlzLTEuMDYtLjQ5Mi0xLjA2LTEuMDk5Ii8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSJub25lIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNTczLjAzMiAxMDAuNDg1YzAtMi43MiAyLjMzMy00LjkzMyA1LjIwNy00LjkzMyAyLjg2OSAwIDUuMjA2IDIuMjEzIDUuMjA2IDQuOTMzIDAgMi43MzUtMi4zMzcgNC45NDgtNS4yMDYgNC45NDgtMi44NzQgMC01LjIwNy0yLjIxMy01LjIwNy00Ljk0OHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSIxLjg1OSIgZD0iTTU4MS4wNiAxMTQuMjUyYzAtMi43MzUgMi4zMzgtNC45NDggNS4yMDctNC45NDggMi44ODggMCA1LjIwNyAyLjIxMyA1LjIwNyA0Ljk0OCAwIDIuNzItMi4zMTkgNC45NDgtNS4yMDcgNC45NDgtMi44NyAwLTUuMjA3LTIuMjI3LTUuMjA3LTQuOTQ4bTMuMjYyIDE1LjIwNGMwLTIuNzM2IDIuMzM4LTQuOTUzIDUuMjEyLTQuOTUzIDIuODg4IDAgNS4yMjYgMi4yMTcgNS4yMjYgNC45NTMgMCAyLjcwMS0yLjMzOCA0LjkxNC01LjIyNiA0LjkxNC0yLjg3NCAwLTUuMjEyLTIuMjEzLTUuMjEyLTQuOTE0bS41ODkgMTUuMTUxYzAtMi43NTUgMi4zMzgtNC45NDkgNS4yMjYtNC45NDkgMi44NzQgMCA1LjIwMiAyLjE5NCA1LjIwMiA0Ljk0OSAwIDIuNzItMi4zMjggNC45MzMtNS4yMDIgNC45MzMtMi44ODggMC01LjIyNi0yLjIxMy01LjIyNi00LjkzM20tNC43NDcgMTMuNzg1YzAtMi43MiAyLjMzOC00Ljk0OCA1LjIwNy00Ljk0OCAyLjg5MyAwIDUuMjEyIDIuMjI4IDUuMjEyIDQuOTQ4IDAgMi43MzUtMi4zMTkgNC45MzQtNS4yMTIgNC45MzQtMi44NyAwLTUuMjA3LTIuMTk5LTUuMjA3LTQuOTM0bS04Ljg2NiAxMi42N2MwLTIuNzIgMi4zNDItNC45NDggNS4yMTEtNC45NDggMi44ODQgMCA1LjIwNyAyLjIyNyA1LjIwNyA0Ljk0OCAwIDIuNzItMi4zMjMgNC45MzQtNS4yMDcgNC45MzQtMi44NjkgMC01LjIxMS0yLjIxMy01LjIxMS00LjkzNCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI3MS41NyAxNjkuMDc4YzAtLjYwNC40NzUtMS4wOTIgMS4wNjQtMS4wOTIuNTg1IDAgMS4wNi40ODggMS4wNiAxLjA5MiAwIC42MDgtLjQ3NSAxLjA5OS0xLjA2IDEuMDk5LS41ODkgMC0xLjA2NS0uNDkxLTEuMDY1LTEuMDk5Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNTU4LjExIDkwLjkyNGMwLTIuNzIgMi4yNzYtNC45MTkgNS4wODktNC45MTkgMi43OTggMCA1LjA3IDIuMTk5IDUuMDcgNC45MiAwIDIuNzM1LTIuMjcyIDQuOTQ4LTUuMDcgNC45NDgtMi44MTMgMC01LjA5LTIuMjEzLTUuMDktNC45NDl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNjguNjY1IDE2Ny4zM2MwLS42MDQuNDczLTEuMDk5IDEuMDYyLTEuMDk5LjU4NSAwIDEuMDYuNDk1IDEuMDYgMS4wOTlzLS40NzUgMS4wOTUtMS4wNiAxLjA5NWMtLjU4OSAwLTEuMDYyLS40OTEtMS4wNjItMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik01NDQuMjI4IDgzLjA1YzAtMi43MjEgMi4yNjItNC45NDkgNS4wNzUtNC45NDkgMi43OTggMCA1LjA2NSAyLjIyOCA1LjA2NSA0Ljk0OXMtMi4yNjcgNC45MzMtNS4wNjUgNC45MzNjLTIuODEzIDAtNS4wNzUtMi4yMTMtNS4wNzUtNC45MzN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNjUuNDY1IDE2Ni4yNzZjMC0uNjA0LjQ3Ni0xLjA5MSAxLjA2My0xLjA5MS41ODYgMCAxLjA2Mi40ODcgMS4wNjIgMS4wOSAwIC42MDgtLjQ3NiAxLjEtMS4wNjIgMS4xcy0xLjA2My0uNDkyLTEuMDYzLTEuMSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTUyOC45MjggNzguMzAzYzAtMi43MjEgMi4yNzctNC45MTUgNS4wODQtNC45MTUgMi44IDAgNS4wNzYgMi4xOTQgNS4wNzYgNC45MTUgMCAyLjczNS0yLjI3NiA0Ljk1My01LjA3NiA0Ljk1My0yLjgwNyAwLTUuMDgzLTIuMjE4LTUuMDgzLTQuOTUzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjYyLjEzNiAxNjUuNjUzYzAtLjYwMy40NzctMS4wOTUgMS4wNjEtMS4wOTUuNTg4IDAgMS4wNjIuNDkyIDEuMDYyIDEuMDk1IDAgLjYwNC0uNDc0IDEuMDk2LTEuMDYyIDEuMDk2LS41ODUgMC0xLjA2LS40OTItMS4wNi0xLjA5NiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTUxMy4wMTcgNzUuNWMwLTIuNzIgMi4yNzctNC45MzMgNS4wNy00LjkzMyAyLjgxMyAwIDUuMDc2IDIuMjEzIDUuMDc2IDQuOTMzIDAgMi43MTYtMi4yNjMgNC45MzQtNS4wNzUgNC45MzQtMi43OTUgMC01LjA3LTIuMjE4LTUuMDctNC45MzR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNTguODc4IDE2NS43MTNjMC0uNjA0LjQ3NS0xLjA5OCAxLjA2LTEuMDk4LjU4OCAwIDEuMDY1LjQ5NCAxLjA2NSAxLjA5OCAwIC42MDktLjQ3NyAxLjA5NS0xLjA2NSAxLjA5NS0uNTg1IDAtMS4wNi0uNDg2LTEuMDYtMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik00OTcuNDM5IDc1Ljc2OWMwLTIuNzIxIDIuMjctNC45NDggNS4wNy00Ljk0OCAyLjgxMyAwIDUuMDg4IDIuMjI3IDUuMDg4IDQuOTQ4IDAgMi43NC0yLjI3NSA0LjkzMy01LjA4OSA0LjkzMy0yLjc5OCAwLTUuMDctMi4xOTMtNS4wNy00LjkzM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI1NS40ODcgMTY2LjMzNmMwLS42MDQuNDc2LTEuMDkyIDEuMDYxLTEuMDkyLjU4OSAwIDEuMDY1LjQ4OCAxLjA2NSAxLjA5MiAwIC42MTEtLjQ3NiAxLjEtMS4wNjUgMS4xLS41ODUgMC0xLjA2MS0uNDktMS4wNjEtMS4xIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNNDgxLjIzIDc4LjU3NmMwLTIuNzIxIDIuMjc1LTQuOTIgNS4wNzQtNC45MiAyLjgxMyAwIDUuMDg5IDIuMTk5IDUuMDg5IDQuOTIgMCAyLjc1LTIuMjc2IDQuOTQ4LTUuMDkgNC45NDgtMi43OTggMC01LjA3NC0yLjE5OS01LjA3NC00Ljk0OHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI1Mi4zNDggMTY3LjUxOGMwLS42MDguNDc2LTEuMSAxLjA2LTEuMS41ODkgMCAxLjA2NS40OTIgMS4wNjUgMS4xIDAgLjYwMy0uNDc2IDEuMDk5LTEuMDY1IDEuMDk5LS41ODQgMC0xLjA2LS40OTYtMS4wNi0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik00NjYuMjIzIDgzLjg5N2MwLTIuNzQgMi4yNzYtNC45NTIgNS4wNy00Ljk1MiAyLjgxMyAwIDUuMDkgMi4yMTMgNS4wOSA0Ljk1MiAwIDIuNzE2LTIuMjc3IDQuOTQ5LTUuMDkgNC45NDktMi43OTQgMC01LjA3LTIuMjMzLTUuMDctNC45NDl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0xOTkuMTc3IDE5NS43MDFjMC0uNjA4LjQ3Ni0xLjA5MiAxLjA2LTEuMDkyLjU5IDAgMS4wNjMuNDg0IDEuMDYzIDEuMDkycy0uNDczIDEuMDk1LTEuMDYyIDEuMDk1Yy0uNTg1IDAtMS4wNi0uNDg3LTEuMDYtMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0yMTIuMDQ3IDIxMC44MjljMC0yLjc0IDIuMjc3LTQuOTIgNS4wNy00LjkyIDIuODE5IDAgNS4wNzYgMi4xOCA1LjA3NiA0LjkyIDAgMi43MzUtMi4yNTcgNC45MjktNS4wNzUgNC45MjktMi43OTQgMC01LjA3LTIuMTk0LTUuMDctNC45Mjl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0xOTcuNzI0IDE5Mi44OTZjMC0uNjA0LjQ3Ni0xLjA5MyAxLjA2LTEuMDkzLjU5IDAgMS4wNjYuNDg5IDEuMDY2IDEuMDkzIDAgLjYxMS0uNDc3IDEuMDk4LTEuMDY1IDEuMDk4LS41ODUgMC0xLjA2Mi0uNDg3LTEuMDYyLTEuMDk4Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNMjA1LjA5OCAxOTguMTkzYzAtMi43MiAyLjI3Ni00LjkyIDUuMDc0LTQuOTIgMi44MTQgMCA1LjA5IDIuMiA1LjA5IDQuOTIgMCAyLjc1NC0yLjI3NyA0Ljk0OC01LjA5IDQuOTQ4LTIuNzk4IDAtNS4wNzUtMi4xOTQtNS4wNzUtNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0xOTYuNzU0IDE4OS42NDhjMC0uNjA0LjQ3Ni0xLjA5NiAxLjA2NC0xLjA5Ni41ODYgMCAxLjA2Mi40OTEgMS4wNjIgMS4wOTYgMCAuNjA3LS40NzYgMS4wOTgtMS4wNjIgMS4wOTgtLjU4OCAwLTEuMDY0LS40OTEtMS4wNjQtMS4wOTgiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0yMDAuNDYxIDE4My41NjRjMC0yLjcyIDIuMjc2LTQuOTM0IDUuMDg5LTQuOTM0IDIuNzk5IDAgNS4wNzQgMi4yMTMgNS4wNzQgNC45MzQgMCAyLjczNS0yLjI3NSA0Ljk0OC01LjA3NCA0Ljk0OC0yLjgxMyAwLTUuMDg5LTIuMjEzLTUuMDg5LTQuOTQ4eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMTk2LjYzNCAxODYuMTYyYzAtLjYwNy40NzYtMS4wOTQgMS4wNjEtMS4wOTQuNTg5IDAgMS4wNjUuNDg3IDEuMDY1IDEuMDk0IDAgLjYwOS0uNDc2IDEuMDk2LTEuMDY1IDEuMDk2LS41ODUgMC0xLjA2MS0uNDg3LTEuMDYxLTEuMDk2Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNMTk5Ljg4NyAxNjcuODY3YzAtMi43MzUgMi4yNzYtNC45MjkgNS4wNzUtNC45MjkgMi44MTMgMCA1LjA4OSAyLjE5NCA1LjA4OSA0LjkyOSAwIDIuNzQtMi4yNzYgNC45MzQtNS4wOSA0LjkzNC0yLjc5OCAwLTUuMDc0LTIuMTk0LTUuMDc0LTQuOTM0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMTk3LjQyMiAxODIuNzMxYzAtLjYwNC40NzYtMS4wOTIgMS4wNi0xLjA5Mi41ODYgMCAxLjA2Mi40ODggMS4wNjIgMS4wOTIgMCAuNjEtLjQ3NiAxLjA5OS0xLjA2MSAxLjA5OXMtMS4wNjEtLjQ4OC0xLjA2MS0xLjA5OSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTIwMy42NTcgMTUyLjQxNGMwLTIuNzIgMi4yNzYtNC45MiA1LjA3LTQuOTIgMi43OTggMCA1LjA3NSAyLjIgNS4wNzUgNC45MiAwIDIuNzUtMi4yNzcgNC45NDgtNS4wNzYgNC45NDgtMi43OTQgMC01LjA3LTIuMTk4LTUuMDctNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0xOTkuMDUzIDE3OS42MTdjMC0uNjA3LjQ3Ny0xLjA5NCAxLjA2Ni0xLjA5NC41ODQgMCAxLjA2LjQ4NyAxLjA2IDEuMDk0cy0uNDc2IDEuMS0xLjA2IDEuMWMtLjU5IDAtMS4wNjUtLjQ5Mi0xLjA2NS0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0yMTEuNDU1IDEzOC4zOWMwLTIuNzM2IDIuMjc3LTQuOTMgNS4wOTMtNC45MyAyLjc5NSAwIDUuMDcxIDIuMTk0IDUuMDcxIDQuOTI5IDAgMi43NC0yLjI3NiA0Ljk1My01LjA3IDQuOTUzLTIuODE3IDAtNS4wOTMtMi4yMTMtNS4wOTMtNC45NTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMDEuMjM0IDE3Ny4wNmMwLS42MDguNDc2LTEuMSAxLjA2NS0xLjEuNTg0IDAgMS4wNi40OTIgMS4wNiAxLjEgMCAuNjAzLS40NzYgMS4wOTUtMS4wNiAxLjA5NS0uNTg5IDAtMS4wNjUtLjQ5Mi0xLjA2NS0xLjA5NiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTIyMS44OCAxMjYuODY5YzAtMi43MzUgMi4yNzctNC45NDggNS4wOS00Ljk0OCAyLjc5NCAwIDUuMDcgMi4yMTMgNS4wNyA0Ljk0OCAwIDIuNzItMi4yNzcgNC45MzQtNS4wNyA0LjkzNC0yLjgxMyAwLTUuMDktMi4yMTMtNS4wOS00LjkzNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIwMy43NjYgMTc0LjkzM2MwLS42MDguNDc2LTEuMSAxLjA2NS0xLjEuNTg1IDAgMS4wNjEuNDkyIDEuMDYxIDEuMSAwIC42MDMtLjQ3NiAxLjA5NS0xLjA2MSAxLjA5NS0uNTg5IDAtMS4wNjUtLjQ5Mi0xLjA2NS0xLjA5NSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTIzMy45ODUgMTE3LjI5NGMwLTIuNzQgMi4yNzYtNC45NTMgNS4wODktNC45NTMgMi43OTggMCA1LjA3NSAyLjIxMyA1LjA3NSA0Ljk1MyAwIDIuNzE2LTIuMjc3IDQuOTI5LTUuMDc1IDQuOTI5LTIuODEzIDAtNS4wOS0yLjIxMy01LjA5LTQuOTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMDYuNzkzIDE3My4xOTJjMC0uNjA3LjQ3Ni0xLjA5MSAxLjA2NS0xLjA5MS41ODUgMCAxLjA2MS40ODQgMS4wNjEgMS4wOTEgMCAuNjA4LS40NzYgMS4xLTEuMDYxIDEuMS0uNTg5IDAtMS4wNjUtLjQ5Mi0xLjA2NS0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0yNDguNDU0IDEwOS40NTJjMC0yLjczNSAyLjI3Ny00LjkxNCA1LjA5LTQuOTE0IDIuNzk4IDAgNS4wNzQgMi4xOCA1LjA3NCA0LjkxNCAwIDIuNzQtMi4yNzYgNC45NTMtNS4wNzUgNC45NTMtMi44MTIgMC01LjA4OS0yLjIxMy01LjA4OS00Ljk1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIwOS45MzMgMTcxLjk1YzAtLjYwMy40NzUtMS4wOTQgMS4wNi0xLjA5NC41OSAwIDEuMDY1LjQ5IDEuMDY1IDEuMDk1IDAgLjYwNy0uNDc2IDEuMDk4LTEuMDY0IDEuMDk4LS41ODYgMC0xLjA2LS40OS0xLjA2LTEuMDk4Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNMjYzLjQ2NSAxMDMuODYyYzAtMi43MiAyLjI3Mi00LjkzMyA1LjA3LTQuOTMzIDIuODEzIDAgNS4wOSAyLjIxMyA1LjA5IDQuOTMzIDAgMi43MzUtMi4yNzcgNC45NDgtNS4wOSA0Ljk0OC0yLjc5OCAwLTUuMDctMi4yMTMtNS4wNy00Ljk0OHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIxMy40NDcgMTcxLjI2OGMwLS42MDQuNDc1LTEuMDk5IDEuMDYtMS4wOTlzMS4wNjEuNDk1IDEuMDYxIDEuMWMwIC42MDMtLjQ3NiAxLjA5NS0xLjA2IDEuMDk1LS41ODYgMC0xLjA2MS0uNDkyLTEuMDYxLTEuMDk2Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNMjgwLjI2MiAxMDAuNzg3YzAtMi43MiAyLjI3Mi00Ljk0OCA1LjA3LTQuOTQ4IDIuNzk0IDAgNS4wNyAyLjIyNyA1LjA3IDQuOTQ4IDAgMi43Mi0yLjI3NiA0LjkzNC01LjA3IDQuOTM0LTIuNzk4IDAtNS4wNy0yLjIxMy01LjA3LTQuOTM0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjE2Ljc3NSAxNzEuMDc3YzAtLjYwNC40NzUtMS4wOTIgMS4wNjUtMS4wOTIuNTg0IDAgMS4wNi40ODggMS4wNiAxLjA5MiAwIC42MDgtLjQ3NiAxLjEtMS4wNiAxLjEtLjU5IDAtMS4wNjUtLjQ5Mi0xLjA2NS0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0yOTYuMTczIDk5LjkyNWMwLTIuNzIgMi4yNzEtNC45MTUgNS4wODktNC45MTUgMi43OTQgMCA1LjA3IDIuMTk0IDUuMDcgNC45MTUgMCAyLjc0LTIuMjc3IDQuOTUzLTUuMDcgNC45NTMtMi44MTggMC01LjA5LTIuMjEzLTUuMDktNC45NTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMjAuMDQ0IDE3MS4yMDFjMC0uNjA0LjQ3Ny0xLjA5NSAxLjA2Mi0xLjA5NS41ODkgMCAxLjA2NC40OTEgMS4wNjQgMS4wOTUgMCAuNjA3LS40NzUgMS4wOTktMS4wNjQgMS4wOTktLjU4NSAwLTEuMDYyLS40OTItMS4wNjItMS4wOTkiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0zMTEuNzk5IDEwMC40ODVjMC0yLjcyIDIuMjgtNC45MzMgNS4wNzQtNC45MzMgMi44MTggMCA1LjA5IDIuMjEzIDUuMDkgNC45MzMgMCAyLjczNS0yLjI3MiA0Ljk0OC01LjA5IDQuOTQ4LTIuNzkzIDAtNS4wNzQtMi4yMTMtNS4wNzQtNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMjMuMzE1IDE3MS4yMDFjMC0uNjA0LjQ3Ni0xLjA5NSAxLjA2MS0xLjA5NS41ODkgMCAxLjA2NS40OTEgMS4wNjUgMS4wOTUgMCAuNjA3LS40NzYgMS4wOTktMS4wNjUgMS4wOTktLjU4NSAwLTEuMDYxLS40OTItMS4wNjEtMS4wOTkiLz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik0zMjQgMTAwLjQ4NWMwLTIuNzIgMi4zMzctNC45MzMgNS4yMS00LjkzMyAyLjg5IDAgNS4yMjcgMi4yMTMgNS4yMjcgNC45MzMgMCAyLjczNS0yLjMzOCA0Ljk0OC01LjIyNiA0Ljk0OC0yLjg3NCAwLTUuMjEyLTIuMjEzLTUuMjEyLTQuOTQ4eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMzM2LjcxNyAxNzYuNDk5Yy0xMi41MjEtOS4zNC0yMC4yOTYtMjIuMDQ0LTIwLjI5Ni0zNi4wMzEgMC0xNi4xMTQgMTAuNTM4LTMwLjQ4OSAyNi41NTctNDAuMDE2LTkuODgyIDcuOTM3LTE1Ljg3NSAxOC4xOTItMTYuNzMyIDI5LjY0NWE0NCA0NCAwIDAgMC0uMjE2IDQuMzRjMCAxMy4xNjMgNi4wMTcgMjUuMDE5IDE1LjUyIDMzLjI2MmwtNC44MzMgOC44IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIHN0cm9rZS13aWR0aD0iMS44NTkiIGQ9Ik0zMTUuOTc2IDExNC4yNTJjMC0yLjczNSAyLjMzMy00Ljk0OCA1LjIwNy00Ljk0OCAyLjg4OCAwIDUuMjI2IDIuMjEzIDUuMjI2IDQuOTQ4IDAgMi43Mi0yLjMzOCA0Ljk0OC01LjIyNiA0Ljk0OC0yLjg3NCAwLTUuMjA3LTIuMjI3LTUuMjA3LTQuOTQ4bS0zLjI2NyAxNS4yMDRjMC0yLjczNiAyLjMxOC00Ljk1MyA1LjIxMi00Ljk1MyAyLjg2OSAwIDUuMjA2IDIuMjE3IDUuMjA2IDQuOTUzIDAgMi43MDEtMi4zMzcgNC45MTQtNS4yMDYgNC45MTQtMi44OTQgMC01LjIxMi0yLjIxMy01LjIxMi00LjkxNG0tLjYwNCAxNS4xNTFjMC0yLjc1NSAyLjMzOC00Ljk0OSA1LjIyNi00Ljk0OSAyLjg3IDAgNS4yMDcgMi4xOTQgNS4yMDcgNC45NDkgMCAyLjcyLTIuMzM3IDQuOTMzLTUuMjA3IDQuOTMzLTIuODg4IDAtNS4yMjYtMi4yMTMtNS4yMjYtNC45MzNtNC43NjIgMTMuNzg1YzAtMi43MiAyLjMzNy00Ljk0OCA1LjIwNy00Ljk0OCAyLjg5MyAwIDUuMjI2IDIuMjI4IDUuMjI2IDQuOTQ4IDAgMi43MzUtMi4zMzMgNC45MzQtNS4yMjYgNC45MzQtMi44NyAwLTUuMjA3LTIuMTk5LTUuMjA3LTQuOTM0bTguODYxIDEyLjY3YzAtMi43MiAyLjM0My00Ljk0OCA1LjIwNy00Ljk0OCAyLjg5MyAwIDUuMjMxIDIuMjI3IDUuMjMxIDQuOTQ4IDAgMi43Mi0yLjMzOCA0LjkzNC01LjIzIDQuOTM0LTIuODY1IDAtNS4yMDgtMi4yMTMtNS4yMDgtNC45MzQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMjUuNzg2IDE2OS4wNzhjMC0uNjA0LjQ3Ni0xLjA5MiAxLjA2LTEuMDkyLjU5IDAgMS4wNjUuNDg4IDEuMDY1IDEuMDkyIDAgLjYwOC0uNDc2IDEuMDk5LTEuMDY0IDEuMDk5LS41ODUgMC0xLjA2LS40OTEtMS4wNi0xLjA5OSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTMzOS4yNSA5MC45MjRjMC0yLjcyIDIuMjc2LTQuOTE5IDUuMDctNC45MTkgMi44MTMgMCA1LjA4OSAyLjE5OSA1LjA4OSA0LjkyIDAgMi43MzUtMi4yNzYgNC45NDgtNS4wOSA0Ljk0OC0yLjc5MyAwLTUuMDY5LTIuMjEzLTUuMDY5LTQuOTQ5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMjI4LjY5MyAxNjcuMzNjMC0uNjA0LjQ3Ni0xLjA5OSAxLjA2LTEuMDk5LjU5IDAgMS4wNjUuNDk1IDEuMDY1IDEuMDk5cy0uNDc2IDEuMDk1LTEuMDY0IDEuMDk1Yy0uNTg1IDAtMS4wNi0uNDkxLTEuMDYtMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0zNTMuMTQ1IDgzLjA1YzAtMi43MjEgMi4yNzctNC45NDkgNS4wNy00Ljk0OSAyLjgxNCAwIDUuMDkgMi4yMjggNS4wOSA0Ljk0OXMtMi4yNzYgNC45MzMtNS4wOSA0LjkzM2MtMi43OTQgMC01LjA3LTIuMjEzLTUuMDctNC45MzN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMzEuODkgMTY2LjI3NmMwLS42MDQuNDc3LTEuMDkxIDEuMDY0LTEuMDkxLjU4NiAwIDEuMDYyLjQ4NyAxLjA2MiAxLjA5IDAgLjYwOC0uNDc2IDEuMS0xLjA2MiAxLjFzLTEuMDY0LS40OTItMS4wNjQtMS4xIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODQ1IiBkPSJNMzY4LjQyNyA3OC4zMDNjMC0yLjcyMSAyLjI4LTQuOTE1IDUuMDg5LTQuOTE1IDIuNzk4IDAgNS4wNzQgMi4xOTQgNS4wNzQgNC45MTUgMCAyLjczNS0yLjI3NiA0Ljk1My01LjA3NCA0Ljk1My0yLjgwOSAwLTUuMDktMi4yMTgtNS4wOS00Ljk1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIzNS4yMjEgMTY1LjY1M2MwLS42MDMuNDc3LTEuMDk1IDEuMDYyLTEuMDk1LjU4OSAwIDEuMDY1LjQ5MiAxLjA2NSAxLjA5NSAwIC42MDQtLjQ3NiAxLjA5Ni0xLjA2NSAxLjA5Ni0uNTg1IDAtMS4wNjItLjQ5Mi0xLjA2Mi0xLjA5NiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg0NSIgZD0iTTM4NC4zNSA3NS41YzAtMi43MiAyLjI4Mi00LjkzMyA1LjA3Ni00LjkzMyAyLjgxNyAwIDUuMDkzIDIuMjEzIDUuMDkzIDQuOTMzIDAgMi43MTYtMi4yNzYgNC45MzQtNS4wOTMgNC45MzQtMi43OTQgMC01LjA3NS0yLjIxOC01LjA3NS00LjkzNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIzOC40ODIgMTY1LjcxM2MwLS42MDQuNDcxLTEuMDk4IDEuMDYtMS4wOTguNTg1IDAgMS4wNjEuNDk0IDEuMDYxIDEuMDk4IDAgLjYwOS0uNDc2IDEuMDk1LTEuMDYgMS4wOTUtLjU5IDAtMS4wNi0uNDg2LTEuMDYtMS4wOTUiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik0zOTkuOTQgNzUuNzY5YzAtMi43MjEgMi4yNTMtNC45NDggNS4wNy00Ljk0OCAyLjc5NSAwIDUuMDcgMi4yMjcgNS4wNyA0Ljk0OCAwIDIuNzQtMi4yNzUgNC45MzMtNS4wNyA0LjkzMy0yLjgxNyAwLTUuMDctMi4xOTMtNS4wNy00LjkzM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTI0MS44NzIgMTY2LjMzNmMwLS42MDQuNDc2LTEuMDkyIDEuMDYtMS4wOTIuNTkgMCAxLjA2Mi40ODggMS4wNjIgMS4wOTIgMCAuNjExLS40NzIgMS4xLTEuMDYyIDEuMS0uNTg0IDAtMS4wNi0uNDktMS4wNi0xLjEiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NDUiIGQ9Ik00MTYuMTQ0IDc4LjU3NmMwLTIuNzIxIDIuMjc3LTQuOTIgNS4wNy00LjkyIDIuODE4IDAgNS4wNzYgMi4xOTkgNS4wNzYgNC45MiAwIDIuNzUtMi4yNTggNC45NDgtNS4wNzUgNC45NDgtMi43OTUgMC01LjA3LTIuMTk5LTUuMDctNC45NDh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNDUuMDA4IDE2Ny41MThjMC0uNjA4LjQ3NS0xLjEgMS4wNjMtMS4xLjU4NiAwIDEuMDYyLjQ5MiAxLjA2MiAxLjEgMCAuNjAzLS40NzYgMS4wOTktMS4wNjIgMS4wOTktLjU4OCAwLTEuMDYzLS40OTYtMS4wNjMtMS4xIi8+PGcgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3Ij48cGF0aCBmaWxsPSJub25lIiBkPSJNNDMwLjQ5MyA4My44OTdjMC0yLjc0IDIuMzMzLTQuOTUyIDUuMjIxLTQuOTUyIDIuODc0IDAgNS4yMTIgMi4yMTMgNS4yMTIgNC45NTIgMCAyLjcxNi0yLjMzOCA0Ljk0OS01LjIxMiA0Ljk0OS0yLjg4OCAwLTUuMjIxLTIuMjMzLTUuMjIxLTQuOTQ5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNMjM5LjA5NSAxMjQuMjg3Yy05LjA5NyA1LjcyNC0xNS45ODUgMTIuNzctMTkuNzgzIDIwLjYyNmE0Mi42IDQyLjYgMCAwIDAtNC4zNSAxOC44MDFjMCAxMS4wOTkgNC4yOTcgMjEuMjQ5IDExLjMxIDI5LjEwNGwtNy42MDIgMTIuMzM1Yy03LjI3Ny05LjM0Ni0xMS41MDYtMjAuMjU3LTExLjUwNi0zMS44NjQgMC0xOS45ODQgMTIuNzE4LTM3LjQ0OCAzMS45My00OS4wMDJ6bTQyOS4yNiAwYzkuMDk2IDUuNzI0IDE1Ljk4NCAxMi43NyAxOS44MDIgMjAuNjI2YTQzLjEgNDMuMSAwIDAgMSA0LjMyNiAxOC44MDFjMCAxMS4wOTktNC4yOTIgMjEuMjQ5LTExLjI4NiAyOS4xMDRsNy41ODMgMTIuMzM1YzcuMjc2LTkuMzQ2IDExLjQ4Ni0yMC4yNTcgMTEuNDg2LTMxLjg2NCAwLTE5Ljk4NC0xMi42OTgtMzcuNDQ4LTMxLjkxMS00OS4wMDJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNMzIyLjM0IDIxOC42M3MtLjcxMy44MTgtMS4yMzMuOTM0Yy0uNTE5LjExMy0xLjE3Ny0uNTEtMS4xNzctLjUxcy0uNDY4LjUzMy0xLjA0My42NzVjLS41NzQuMTQzLTEuMzctLjcwNS0xLjM3LS43MDVzLS41NDguODQ4LTEuMDQgMS4wNDdjLS40OTMuMTk4LTEuMDkzLS4yNTUtMS4wOTMtLjI1NXMtLjIxNy40Mi0uNjI4LjY1MmMtLjE3NS4wOS0uNDY1LS4wNi0uNDY1LS4wNmwtLjU4LS4zOTQtLjY1Ny0uNzY1LS42MDItLjI1NXMtLjI3Mi0uOTYtLjMwMS0xLjEyOGwtLjA4LS41OTdjLS4xMjQtLjY4Ni44NDctMS40ODEgMi4yMy0xLjgyMy43OTYtLjIwMiAxLjQ5LS4xODcgMi0uMDE1LjU1Mi0uNTE0IDEuNzIyLS44NyAzLjA5OC0uODcgMS4yNDYgMCAyLjM0LjI4OSAyLjk0NC43MzUuNTk2LS40NDYgMS42OS0uNzM1IDIuOTQtLjczNSAxLjM3IDAgMi41MzguMzU2IDMuMDkyLjg3LjUxMi0uMTcyIDEuMjAyLS4xODQgMi4wMDIuMDE1IDEuMzguMzQyIDIuMzU0IDEuMTM3IDIuMjMgMS44MjMgMCAwLS4wNTguNDI4LS4wODMuNTk3LS4wMjkuMTY4LS4zMDEgMS4xMjgtLjMwMSAxLjEyOGwtLjYwNC4yNTYtLjY1OC43NjQtLjU3LjM5NXMtLjI5LjE1LS40NjUuMDZjLS40MS0uMjMtLjYzMi0uNjUzLS42MzItLjY1M3MtLjYwMy40NTMtMS4wOTQuMjU1Yy0uNDk0LS4yLTEuMDQyLTEuMDQ3LTEuMDQyLTEuMDQ3cy0uNzkzLjg0OC0xLjM3MS43MDVjLS41NzQtLjE0Mi0xLjA0LS42NzQtMS4wNC0uNjc0cy0uNjU4LjYyMi0xLjE3Ni41MWMtLjUyMy0uMTE3LTEuMjI4LS45MzUtMS4yMjgtLjkzNSIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0ibm9uZSIgZD0iTTgxMC4xMiAzMTQuMDk2cy0zLjQ5NiAzLjY4NC02LjA1IDQuMjA2Yy0yLjU0OC41MDgtNS43NzYtMi4yOTQtNS43NzYtMi4yOTRzLTIuMyAyLjM5NS01LjEyMSAzLjAzNmMtMi44MTcuNjQyLTYuNzMtMy4xNzUtNi43My0zLjE3NXMtMi42ODcgMy44MTctNS4xMDIgNC43MTNjLTIuNDE5Ljg5Ni01LjM2NS0xLjE0NS01LjM2NS0xLjE0NXMtMS4wNjggMS44OTItMy4wODQgMi45MzdjLS44NTguNDA3LTIuMjgtLjI2OS0yLjI4LS4yNjlsLTIuODQ2LTEuNzc3LTMuMjI4LTMuNDQ0LTIuOTU2LTEuMTVzLTEuMzM2LTQuMzI1LTEuNDgtNS4wODJjLS4xMDUtLjc2MS0uMzkzLTIuNjg3LS4zOTMtMi42ODctLjYwNC0zLjA5IDQuMTU4LTYuNjcyIDEwLjk1LTguMjEgMy45MDktLjkxIDcuMzEtLjg0MyA5LjgxNS0uMDY3IDIuNzExLTIuMzE0IDguNDU1LTMuOTE4IDE1LjIxMy0zLjkxOCA2LjExNyAwIDExLjQ4NyAxLjI5OCAxNC40NTIgMy4zMSAyLjkyMi0yLjAxMiA4LjI5Mi0zLjMxIDE0LjQyOC0zLjMxIDYuNzI1IDAgMTIuNDY0IDEuNjA0IDE1LjE4IDMuOTE4IDIuNTE1LS43NzYgNS45MDEtLjgyOSA5LjgzLjA2NyA2Ljc3MiAxLjUzOCAxMS41NTggNS4xMiAxMC45NDQgOC4yMSAwIDAtLjI4MiAxLjkyNi0uNDAyIDIuNjg3LS4xNDQuNzU3LTEuNDggNS4wODMtMS40OCA1LjA4M2wtMi45NjUgMS4xNS0zLjIyOSAzLjQ0My0yLjc5NyAxLjc3N3MtMS40MjguNjc2LTIuMjg1LjI2OWMtMi4wMTctMS4wMy0zLjEwNC0yLjkzNy0zLjEwNC0yLjkzN3MtMi45NiAyLjA0LTUuMzcgMS4xNDVjLTIuNDI0LS44OTYtNS4xMTYtNC43MTMtNS4xMTYtNC43MTNzLTMuODkgMy44MTctNi43MyAzLjE3NWMtMi44MTYtLjY0MS01LjEwNi0zLjAzNi01LjEwNi0zLjAzNnMtMy4yMjggMi44MDItNS43NzIgMi4yOTRjLTIuNTY3LS41MjItNi4wMjYtNC4yMDYtNi4wMjYtNC4yMDZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIGZpbGw9IiM5ZjdlMDAiPjxwYXRoIGQ9Ik04MDMuNDY3IDI5My45OTJjMC01LjE0OSAyLjkyNy05LjMyMSA2LjU0My05LjMyMSAzLjYyMSAwIDYuNTY3IDQuMTcyIDYuNTY3IDkuMzIxIDAgNS4xNzQtMi45NDYgOS4zNi02LjU2NyA5LjM2LTMuNjE2IDAtNi41NDMtNC4xODYtNi41NDMtOS4zNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTgwNy4xMjIgMjkzLjk5MmMwLTQuNzI3IDEuMzU1LTguNTc5IDMuMDE3LTguNTc5IDEuNjcyIDAgMy4wMTMgMy44NTIgMy4wMTMgOC41OCAwIDQuNzQ2LTEuMzQgOC42MDItMy4wMTMgOC42MDItMS42NjIgMC0zLjAxNy0zLjg1Ni0zLjAxNy04LjYwM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjwvZz48ZyBzdHJva2Utd2lkdGg9Ii45ODciPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik0zMTUuNDYgMjIyLjY3NGMtLjE5Ni0uNjA0LS41NjQtMS4xNDQtLjU2NC0xLjE0NCAxLjg4Ny0uNjA0IDQuNTE0LS45ODMgNy40MzYtLjk5IDIuOTIxLjAwNyA1LjU2Ny4zODYgNy40NTMuOTlsLS41MDYuOTY4Yy0uMTYzLjMxMS0uMzc3Ljg1NS0uMzYzLjg1NS0xLjcwNS0uNTctMy45LS44NjMtNi41OTUtLjg2Ni0yLjcuMDAzLTUuMjk0LjM2NC02LjY0Ny45MDMuMDIgMC0uMDk0LS4zNC0uMjI4LS43MTZ6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBkPSJNNzY3LjkyOCAzMzIuMzA4Yy0uOTM4LTIuNzItMi42OTctNS4xNTQtMi42OTctNS4xNTQgOS4wMjEtMi43MiAyMS41OC00LjQyNiAzNS41NDQtNC40NiAxMy45NjcuMDM0IDI2LjYxMiAxLjc0IDM1LjYyOCA0LjQ2IDAgMC0xLjAwNyAxLjgyNS0yLjQxNiA0LjM1OS0uNTguOTYtLjcxMyAxLjQxNS0xLjczNSAzLjg1MS04LjE1LTIuNTY3LTE4LjY0LTMuODg1LTMxLjUyOC0zLjg5OS0xMi45MDcuMDE1LTI1LjMwOSAxLjYzOC0zMS43NzUgNC4wNjcuMDk0IDAtLjQ0OC0xLjUzMy0xLjA5LTMuMjI0aC4wNjkiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTMyMi4zMzIgMjI1LjI4OGMyLjM1Ny0uMDA0IDQuOTUzLS4zOTMgNS45MTItLjY2My42MzktLjIwMyAxLjAxNC0uNTE4Ljk0NC0uODgyLS4wMzItLjE3Mi0uMTctLjMyMi0uMzU3LS40MDgtMS40MDYtLjQ5Mi0zLjk0LS44NC02LjUtLjg0NS0yLjU1My4wMDQtNS4xLjM1My02LjUxMi44NDUtLjE4LjA4Ni0uMzIzLjIzNi0uMzUyLjQwOC0uMDcyLjM2NC4zMDMuNjc5Ljk0Ni44ODIuOTU2LjI3IDMuNTYzLjY2IDUuOTE5LjY2MyIvPjwvZz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik04MTAuMDgyIDM0NC4wODJjMTEuNTczLS4wMTkgMjQuMzE1LTEuNzcyIDI5LjAyMy0yLjk4OSAzLjEzOC0uOTE1IDQuOTc3LTIuMzMzIDQuNjM3LTMuOTctLjE1OC0uNzc3LS44MzgtMS40NTItMS43NTMtMS44NC02LjkwMy0yLjIxMy0xOS4zNDctMy43ODQtMzEuOTA3LTMuODA0LTEyLjUzNi4wMi0yNS4wNDMgMS41OS0zMS45NyAzLjgwNC0uODg1LjM4OC0xLjU4NSAxLjA2My0xLjcyOCAxLjg0LS4zNTUgMS42MzcgMS40ODUgMy4wNTUgNC42NDEgMy45NyA0LjY5NSAxLjIxNyAxNy40OTQgMi45NyAyOS4wNTcgMi45ODl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNlNmU2ZTYiIGQ9Ik04MzguMTQyIDI5OC4xN2MwLTEuMTM2Ljk2My0yLjA0NiAyLjEzNy0yLjA0NiAxLjE5NyAwIDIuMTYuOTEgMi4xNiAyLjA0NSAwIDEuMTMtLjk2MyAyLjAyNy0yLjE2IDIuMDI3LTEuMTc0IDAtMi4xMzctLjg5Ni0yLjEzNy0yLjAyN20tMS4yMTItNy4xMzJjMC0xLjEzLjk1OS0yLjA0IDIuMTQyLTIuMDQgMS4xODggMCAyLjE1NS45MSAyLjE1NSAyLjA0IDAgMS4xMTYtLjk2NyAyLjAzMS0yLjE1NSAyLjAzMS0xLjE4MyAwLTIuMTQxLS45MTUtMi4xNDEtMi4wMzF6bS01LjM4OC00LjQ2YzAtMS4xMy45NTgtMi4wNCAyLjE2LTIuMDQgMS4xNjkgMCAyLjE0MS45MSAyLjE0MSAyLjA0IDAgMS4xMzYtLjk3MiAyLjA0Ni0yLjE0MSAyLjA0Ni0xLjIwMiAwLTIuMTYtLjkxLTIuMTYtMi4wNDZ6bS02LjczLTIuMTQ1YzAtMS4xNDUuOTY3LTIuMDYgMi4xNi0yLjA2IDEuMTk3IDAgMi4xNDYuOTE1IDIuMTQ2IDIuMDYgMCAxLjEwMS0uOTQ5IDIuMDMtMi4xNDYgMi4wMy0xLjE5MyAwLTIuMTYtLjkyOS0yLjE2LTIuMDN6bS02Ljg0Ni4yMzljMC0xLjEzNS45NTktMi4wNDUgMi4xNDItMi4wNDUgMS4xOTcgMCAyLjE2LjkxIDIuMTYgMi4wNDUgMCAxLjEzLS45NjMgMi4wMjYtMi4xNiAyLjAyNi0xLjE4MyAwLTIuMTQyLS44OTYtMi4xNDItMi4wMjZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgZD0iTTg1OS40MDYgMzEyLjAxN2MuNjQyLTEuNTcgMS4wNDQtMy4zMSAxLjA0NC01LjExNSAwLTcuNTY5LTYuMDAyLTEzLjcxOS0xMy40NDEtMTMuNzE5YTEzLjEgMTMuMSAwIDAgMC02LjU0OCAxLjc1OCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSJub25lIiBkPSJNODM1LjQ2NSAzMDIuMzljLjY5NC0xLjIzMiAxLjE5Ny0yLjczNiAxLjE5Ny00LjE1NCAwLTUuNDU1LTUuNjM4LTkuODgxLTEyLjU3NC05Ljg4MS0yLjk2NSAwLTUuNjc2LjgxLTcuODEyIDIuMTQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2U2ZTZlNiIgZD0iTTg2MS4yNiAzMDUuODA1YzAtMS4xMTYuOTgxLTIuMDQ2IDIuMTYtMi4wNDYgMS4xOTIgMCAyLjE1NS45MyAyLjE1NSAyLjA0NiAwIDEuMTMtLjk2MyAyLjAyNi0yLjE1NSAyLjAyNi0xLjE3OSAwLTIuMTYtLjg5Ni0yLjE2LTIuMDI2em0tLjgxLTcuNTAxYzAtMS4xMzYuOTcyLTIuMDI3IDIuMTYtMi4wMjcgMS4xODMgMCAyLjE0Ni44OTEgMi4xNDYgMi4wMjcgMCAxLjExNi0uOTYzIDIuMDI2LTIuMTQ2IDIuMDI2LTEuMTg4IDAtMi4xNi0uOTEtMi4xNi0yLjAyNnptLTQuODI5LTUuNzQ0YzAtMS4xMTYuOTYzLTIuMDI2IDIuMTQyLTIuMDI2IDEuMTk3IDAgMi4xNTUuOTEgMi4xNTUgMi4wMjYgMCAxLjEzLS45NTggMi4wNC0yLjE1NSAyLjA0LTEuMTc5IDAtMi4xNDItLjkxLTIuMTQyLTIuMDR6bS02LjQ1Ny0zLjA2YzAtMS4xMTIuOTYzLTIuMDI3IDIuMTU2LTIuMDI3IDEuMTgzIDAgMi4xNDYuOTE1IDIuMTQ2IDIuMDI2IDAgMS4xMzYtLjk2MyAyLjA2NS0yLjE0NiAyLjA2NS0xLjE5MyAwLTIuMTU2LS45My0yLjE1Ni0yLjA2NXptLTYuODY0LjI3MmMwLTEuMTMuOTYzLTIuMDQ1IDIuMTU2LTIuMDQ1IDEuMTkyIDAgMi4xNi45MTUgMi4xNiAyLjA0NSAwIDEuMTE3LS45NjggMi4wMjctMi4xNiAyLjAyN3MtMi4xNTYtLjkxLTIuMTU2LTIuMDI3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0ibTMyOS45IDIyMC4zODItLjU3My0uNTY2cy0uNTUuMzY3LTEuMjM1LjI1NWMtLjY4My0uMTEyLS45MDItMS4wMTYtLjkwMi0xLjAxNnMtLjc3LjctMS4zOTUuNjQ4Yy0uNjI5LS4wNi0xLjA0LS42NDgtMS4wNC0uNjQ4cy0uNjg3LjUzMi0xLjI5LjQ4Yy0uNjAyLS4wNi0xLjE3Ny0uODc4LTEuMTc3LS44NzhzLS42MDIuODQ4LTEuMjA2LjkwN2MtLjYwMy4wNTQtMS4wOTQtLjU3LTEuMDk0LS41N3MtLjI3Ni42MjMtMS4wNDMuNzYyYy0uNzY2LjE0Mi0xLjQyNC0uNjUtMS40MjQtLjY1cy0uNDMyLjc2Ni0uOTU2Ljk2NWMtLjUyLjE5OC0xLjIwMi0uMjg2LTEuMjAyLS4yODZzLS4xMS4yODYtLjE5My40NTUtLjMwMi4xOTgtLjMwMi4xOThsLjE3Mi41MDdjMS44NzYtLjU5MyA0LjQyMi0uOTYgNy4zLS45NjQgMi44OC4wMDMgNS40OTYuMzcxIDcuMzcxLjk2OGwuMTk0LS41NjciLz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIGQ9Im04NDcuMjM0IDMyMS45ODYtMi44MTItMi41NDlzLTIuNjk3IDEuNjUzLTYuMDY0IDEuMTQ1Yy0zLjM1My0uNTAzLTQuNDI2LTQuNTc0LTQuNDI2LTQuNTc0cy0zLjc4IDMuMTU2LTYuODUgMi45MjFjLTMuMDg1LS4yNzMtNS4xMDEtMi45MjEtNS4xMDEtMi45MjFzLTMuMzczIDIuMzk1LTYuMzMzIDIuMTZjLTIuOTYtLjI2OC01Ljc4Mi0zLjk1Mi01Ljc4Mi0zLjk1MnMtMi45NTUgMy44MTgtNS45MiA0LjA4NmMtMi45Ni4yNC01LjM3LTIuNTY3LTUuMzctMi41NjdzLTEuMzU1IDIuODA2LTUuMTIgMy40M2MtMy43Ni42NDEtNi45OS0yLjkyMy02Ljk5LTIuOTIzcy0yLjEyMSAzLjQ0NC00LjY5MyA0LjM0Yy0yLjU0OS44OTYtNS45MDItMS4yODQtNS45MDItMS4yODRzLS41MzYgMS4yODQtLjk0NCAyLjA0NmMtLjQxMi43NjEtMS40ODUuODk1LTEuNDg1Ljg5NWwuODQ0IDIuMjhjOS4yMS0yLjY2OCAyMS43MDgtNC4zMjUgMzUuODM0LTQuMzQgMTQuMTQ1LjAxNSAyNi45ODMgMS42NzIgMzYuMTkgNC4zNmwuOTQ4LTIuNTUzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBkPSJNNzc3LjQ0MiAyOTguMTdjMC0xLjEzNi45NTgtMi4wNDYgMi4xNTYtMi4wNDYgMS4xNzMgMCAyLjE0MS45MSAyLjE0MSAyLjA0NSAwIDEuMTMtLjk2OCAyLjAyNy0yLjE0MSAyLjAyNy0xLjE5OCAwLTIuMTU2LS44OTYtMi4xNTYtMi4wMjd6bTEuMjEyLTcuMTMzYzAtMS4xMy45NjMtMi4wNCAyLjE1Ni0yLjA0IDEuMTc4IDAgMi4xNC45MSAyLjE0IDIuMDQgMCAxLjExNi0uOTYyIDIuMDMxLTIuMTQgMi4wMzEtMS4xOTMgMC0yLjE1Ni0uOTE1LTIuMTU2LTIuMDMxem01LjM3LTQuNDZjMC0xLjEzLjk2My0yLjA0IDIuMTU1LTIuMDQgMS4xOTggMCAyLjE2LjkxIDIuMTYgMi4wNCAwIDEuMTM2LS45NjIgMi4wNDYtMi4xNiAyLjA0Ni0xLjE5MiAwLTIuMTU1LS45MS0yLjE1NS0yLjA0NnptNi43MjUtMi4xNDVjMC0xLjE0NS45NjMtMi4wNiAyLjE1Ni0yLjA2IDEuMTk3IDAgMi4xNi45MTUgMi4xNiAyLjA2IDAgMS4xMDEtLjk2MyAyLjAzLTIuMTYgMi4wMy0xLjE5MyAwLTIuMTU2LS45MjktMi4xNTYtMi4wM3ptNi44NjQuMjM5YzAtMS4xMzUuOTYzLTIuMDQ1IDIuMTQyLTIuMDQ1IDEuMTk3IDAgMi4xNi45MSAyLjE2IDIuMDQ1IDAgMS4xMy0uOTYzIDIuMDI2LTIuMTYgMi4wMjYtMS4xNzkgMC0yLjE0Mi0uODk2LTIuMTQyLTIuMDI2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2UtbGluZWNhcD0icm91bmQiIGQ9Ik03NjAuNDYxIDMxMi4wMTdjLS42MjctMS41Ny0xLjAzNC0zLjMxLTEuMDM0LTUuMTE1IDAtNy41NjkgNi4wMDYtMTMuNzE5IDEzLjQ0LTEzLjcxOSAyLjM3NyAwIDQuNjA0LjY0MiA2LjU1NCAxLjc1OCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSJub25lIiBkPSJNNzg0LjU3NSAzMDIuMjIyYy0uNjk1LTEuMjE3LTEuMzYtMi41NjgtMS4zNi0zLjk4NiAwLTUuNDU1IDUuNjQyLTkuODgxIDEyLjU3OC05Ljg4MSAyLjk0MSAwIDUuNjcyLjgxIDcuODEzIDIuMTQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2U2ZTZlNiIgZD0iTTc1NC4zMDYgMzA1LjgwNWMwLTEuMTE2Ljk1OC0yLjA0NiAyLjE2LTIuMDQ2IDEuMTcgMCAyLjEzNy45MyAyLjEzNyAyLjA0NiAwIDEuMTMtLjk2OCAyLjAyNi0yLjEzNyAyLjAyNi0xLjIwMiAwLTIuMTYtLjg5Ni0yLjE2LTIuMDI2em0uOC03LjUwMWMwLTEuMTM2Ljk4Mi0yLjAyNyAyLjE2LTIuMDI3IDEuMTk4IDAgMi4xNi44OTEgMi4xNiAyLjAyNyAwIDEuMTE2LS45NjIgMi4wMjYtMi4xNiAyLjAyNi0xLjE3OCAwLTIuMTYtLjkxLTIuMTYtMi4wMjZ6bTQuODUyLTUuNzQ0YzAtMS4xMTYuOTYzLTIuMDI2IDIuMTYtMi4wMjYgMS4xNzkgMCAyLjE0Mi45MSAyLjE0MiAyLjAyNiAwIDEuMTMtLjk2MyAyLjA0LTIuMTQxIDIuMDQtMS4xOTggMC0yLjE2LS45MS0yLjE2LTIuMDR6bTYuNDU3LTMuMDZjMC0xLjExMi45NjMtMi4wMjcgMi4xMzctMi4wMjcgMS4yMDIgMCAyLjE2LjkxNSAyLjE2IDIuMDI2IDAgMS4xMzYtLjk1OCAyLjA2NS0yLjE2IDIuMDY1LTEuMTc0IDAtMi4xMzctLjkzLTIuMTM3LTIuMDY1em02Ljg1LjI3MmMwLTEuMTMuOTYzLTIuMDQ1IDIuMTYtMi4wNDUgMS4xOTMgMCAyLjE0Mi45MTUgMi4xNDIgMi4wNDUgMCAxLjExNy0uOTQ5IDIuMDI3LTIuMTQxIDIuMDI3LTEuMTk4IDAtMi4xNi0uOTEtMi4xNi0yLjAyN3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0ibTgxMC4xNTQgMzA5LjY3IDEuMzM2LjI0Yy0uMjEuNTU1LS4yNTQgMS4xNDUtLjI1NCAxLjc3MiAwIDIuNzY5IDIuMzggNS4wMTUgNS4zMDMgNS4wMTUgMi4zNTcgMCA0LjM1NC0xLjQ1MSA1LjAzNC0zLjQ2My4wODIuMDUzLjUxMy0xLjgyNS43MjQtMS43OTEuMiAwIC4xNjcgMS45NDQuMjE1IDEuOTEuMzU1IDIuNTE2IDIuNjU0IDQuMjQgNS4yNjQgNC4yNCAyLjkyMiAwIDUuMjkzLTIuMjQ2IDUuMjkzLTUuMDE1cS4wMDEtLjMwOC0uMDUtLjYwOGwxLjY3Ny0xLjY1OC44ODYgMi4xMTNjLS4zNTQuNjQxLS40OTggMS4zODQtLjQ5OCAyLjE4IDAgMi42NTMgMi4yNyA0Ljc5OSA1LjA1NCA0Ljc5OSAxLjc2NyAwIDMuMzItLjg2MyA0LjIxLTIuMTQ2bDEuMDY4LTEuMzUxLS4wMiAxLjY3MmMwIDEuNjUyLjcxOSAzLjE0MiAyLjMzMyAzLjQxIDAgMCAxLjg3My4xMzQgNC4zNC0xLjgyNSAyLjQ4MS0xLjk0IDMuODM3LTMuNTY0IDMuODM3LTMuNTY0bC4xNDMgMS45OTNzLTIuNDMzIDMuOTg1LTQuNjIyIDUuMjU1Yy0xLjIxMi43MDktMy4wNTYgMS40NTEtNC41MTIgMS4xOTctMS41NTctLjIzNC0yLjY0LTEuNDg1LTMuMjE1LTIuOTAzYTcuNCA3LjQgMCAwIDEtMy43OTggMS4wM2MtMi45OTQgMC01LjY4Ni0xLjY1Ny02Ljc0LTQuMTA1LTEuMzggMS40ODUtMy4zIDIuMzgtNS41NTEgMi4zOC0yLjM4NiAwLTQuNTgtMS4wNjItNS45Ni0yLjczNC0xLjM1IDEuMjUtMy4xODUgMi4wMTItNS4yMDYgMi4wMTItMi42MzUgMC01LjAxLTEuMzIyLTYuMzQ3LTMuMjYyLTEuMzQxIDEuOTQtMy42NzkgMy4yNjItNi4zMzcgMy4yNjJhNy42NCA3LjY0IDAgMCAxLTUuMjAyLTIuMDEyYy0xLjM3NSAxLjY3Mi0zLjU1IDIuNzM1LTUuOTYgMi43MzUtMi4yNDYgMC00LjE1Ny0uODk2LTUuNTI3LTIuMzgtMS4wNTkgMi40MzMtMy43NjUgNC4xMDQtNi43NDUgNC4xMDRhNy40IDcuNCAwIDAgMS0zLjc4NC0xLjAzYy0uNTcgMS40MTgtMS42NzIgMi42NjktMy4yMSAyLjkwMy0xLjQ2LjI1NC0zLjMtLjQ4OC00LjUxMS0xLjE5Ny0yLjIxMy0xLjI3LTQuODM0LTUuMjU1LTQuODM0LTUuMjU1bC4zNC0xLjk5M3MxLjM1MSAxLjYyNCAzLjgxOCAzLjU2NGMyLjQ3NyAxLjk2IDQuMzUgMS44MjUgNC4zNSAxLjgyNSAxLjYyMy0uMjY4IDIuMzEzLTEuNzU4IDIuMzEzLTMuNDF2LTEuNjcybDEuMDU5IDEuMzVhNS4xNiA1LjE2IDAgMCAwIDQuMjA2IDIuMTQ3YzIuODA3IDAgNS4wNjctMi4xNDYgNS4wNjctNC44IDAtLjc5NS0uMTQzLTEuNTM4LS40OTgtMi4xOGwuODkxLTIuMTEyIDEuNjU4IDEuNjU4Yy0uMDM1LjItLjAzNS40MDItLjAzNS42MDggMCAyLjc2OSAyLjM1NiA1LjAxNSA1LjI1NCA1LjAxNSAyLjYzIDAgNC45My0xLjcyNCA1LjI3LTQuMjQuMDcyLjAzNC4wNS0xLjkxLjIzLTEuOTEuMjM1LS4wMzQuNjYgMS44NDQuNzMyIDEuNzkxLjY5NSAyLjAxMiAyLjY5MyAzLjQ2MyA1LjA0NCAzLjQ2MyAyLjkzMiAwIDUuMzAzLTIuMjQ2IDUuMzAzLTUuMDE1IDAtLjYyNy0uMDM1LTEuMjE3LS4yNDktMS43NzJsMS4zNzUtLjI0aC4wMzV6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48ZyBzdHJva2Utd2lkdGg9Ii45ODciPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMjIuMzMyIDIyMC41NDRjLTIuOTIyLjAwMy01LjU0Ni4zODItNy40My45OS0uMTI4LjA0NS0uMjgyLS4wNi0uMzI0LS4xODQtLjA0LS4xMy4wNTEtLjI5My4xNzMtLjMzNyAxLjg5OC0uNjMgNC41ODctMS4wMjkgNy41OC0xLjAzMiAyLjk5MS4wMDMgNS42OTQuNDAxIDcuNTg4IDEuMDMyLjEyNi4wNDQuMjE4LjIwNi4xNzguMzM3LS4wNC4xMjMtLjIuMjI5LS4zMjMuMTg0LTEuODg2LS42MDgtNC41Mi0uOTg3LTcuNDQyLS45OSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZT0iIzAwMCIgZD0iTTgwMC43NzUgMzIyLjcxNGMtMTMuOTY2LjAxNC0yNi41MDggMS43Mi0zNS41MiA0LjQ2LS42MDYuMi0xLjM0NC0uMjc0LTEuNTQ0LS44My0uMTk2LS41ODkuMjQzLTEuMzE3LjgyNi0xLjUxOCA5LjA3Mi0yLjg0IDIxLjkyOC00LjYzMiAzNi4yMzgtNC42NDYgMTQuMjk4LjAxNCAyNy4yMTggMS44MDYgMzYuMjcyIDQuNjQ2LjYwMi4yMDEgMS4wNC45My44NSAxLjUxOC0uMTkzLjU1Ni0uOTU3IDEuMDMtMS41NDUuODMtOS4wMTctMi43NC0yMS42MS00LjQ0Ni0zNS41NzctNC40NnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTMxOS41MDUgMjIxLjY3MmMwLS4yNC4xOS0uNDM1LjQyNS0uNDM1YS40My40MyAwIDAgMSAuNDIyLjQzNWMwIC4yNDQtLjE5LjQzNS0uNDIyLjQzNWEuNDI3LjQyNyAwIDAgMS0uNDI1LS40MzUiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBzdHJva2U9IiMwMDAiIGQ9Ik03ODcuMjYyIDMyNy43OTZjMC0xLjA3OC45MDYtMS45NiAyLjAzNC0xLjk2IDEuMTEgMCAyLjAxNS44ODIgMi4wMTUgMS45NiAwIDEuMDk3LS45MDUgMS45NTktMi4wMTYgMS45NTktMS4xMjggMC0yLjAzMy0uODYyLTIuMDMzLTEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0zMjIuMzY4IDIyMS44NmgtLjk0YS4zMy4zMyAwIDAgMS0uMzIxLS4zMy4zMi4zMiAwIDAgMSAuMzE2LS4zMjJoMS45MDFjLjE3NSAwIC4zMTEuMTQ1LjMxMS4zMjIgMCAuMTgtLjE0LjMzLS4zMTUuMzN6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBkPSJNODAwLjk0OSAzMjguNjQ0aC00LjQ5N2MtLjgzNiAwLTEuNTMxLS42NzYtMS41MzEtMS40OSAwLS43OTUuNjc3LTEuNDUxIDEuNTExLTEuNDUxaDkuMDg4Yy44MzQgMCAxLjQ4OC42NTYgMS40ODggMS40NTEgMCAuODE0LS42NzIgMS40OS0xLjUwOCAxLjQ5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA2ZjQ2IiBkPSJtMzE3LjY2IDIyMi4yMTMtLjY3Mi4xMDhhLjMyLjMyIDAgMCAxLS4zNjUtLjI3My4zMi4zMiAwIDAgMSAuMjYyLS4zNjhsLjY3NS0uMTA5LjY5LS4xMTZhLjMyLjMyIDAgMCAxIC4zNjEuMjcuMzMuMzMgMCAwIDEtLjI2NS4zNzJ6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBkPSJtNzc4LjQ0MiAzMzAuMjMtMy4yMTQuNDg4Yy0uODI2LjEyLTEuNi0uNDIyLTEuNzQtMS4yMzFhMS40NTcgMS40NTcgMCAwIDEgMS4yNS0xLjY1OGwzLjIyNy0uNDg4IDMuMjk5LS41MjJjLjgyNS0uMSAxLjU4Ni40MjEgMS43MjUgMS4yMTYuMTIyLjc5LS40NTIgMS41NTItMS4yNjkgMS42NzJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Im0zMTQuOTQ0IDIyMi43MjYuMjk5LS41MjQuNjQuMTMtLjM3Mi41OXoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIGQ9Im03NjUuNDYgMzMyLjU0MyAxLjQyOC0yLjM2MiAzLjA2LjU5LTEuNzc4IDIuNjUzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMzI0LjMxNiAyMjEuNjcyYzAtLjI0LjE5My0uNDM1LjQyNS0uNDM1LjIzMyAwIC40MjUuMTk2LjQyNS40MzVhLjQzLjQzIDAgMCAxLS40MjUuNDM1LjQzLjQzIDAgMCAxLS40MjUtLjQzNSIvPjxwYXRoIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0iIzAwMCIgZD0iTTgxMC4yNjMgMzI3Ljc5NmMwLTEuMDc4LjkyLTEuOTYgMi4wMy0xLjk2IDEuMTE0IDAgMi4wMzMuODgyIDIuMDMzIDEuOTYgMCAxLjA5Ny0uOTE5IDEuOTU5LTIuMDM0IDEuOTU5LTEuMTEgMC0yLjAyOS0uODYyLTIuMDI5LTEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiMwMDZmNDYiIGQ9Im0zMjcuMDA4IDIyMi4yMTMuNjc3LjEwOGMuMTcuMDI3LjMzLS4wOTQuMzU5LS4yNzMuMDI0LS4xNzctLjA4Ny0uMzQyLS4yNTgtLjM2OGwtLjY3Ni0uMTA5LS42OS0uMTE2YS4zMi4zMiAwIDAgMC0uMzYuMjcuMzI1LjMyNSAwIDAgMCAuMjY2LjM3MnoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIGQ9Im04MjMuMTMyIDMzMC4yMyAzLjIzMy40ODhhMS41MSAxLjUxIDAgMCAwIDEuNzE2LTEuMjMxIDEuNDUgMS40NSAwIDAgMC0xLjIzLTEuNjU4bC0zLjIzMy0uNDg4LTMuMjk4LS41MjJjLS44MzUtLjEtMS42LjQyMS0xLjcyMSAxLjIxNi0uMTQuNzkuNDUyIDEuNTUyIDEuMjY5IDEuNjcyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwOTE5IDAgMCAuMjIyMDQgMTU0LjgyIDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJtMzI5LjY2OCAyMjIuNzU2LS4yNC0uNTU4LS42NTUuMDYuMzE0LjYyNnoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIGQ9Im04MzUuNzQgMzMyLjUyMi0xLjA0LTIuMzYtMy4xMzQuMjY4IDEuNTAyIDIuODIyYy45NS0uMjE5IDEuODY2LS41NCAyLjY3Mi0uNzN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0zMjIuMzI4IDIyNC42OTJjLTIuMzU4LS4wMDQtNC40OS0uMjI5LTYuMTE1LS42ODYgMS42MjQtLjQ1NCAzLjc1Ny0uNzM1IDYuMTE1LS43NDMgMi4zNTguMDA0IDQuNTAyLjI4NSA2LjEyMi43NDMtMS42Mi40NTctMy43NjQuNjgyLTYuMTIyLjY4NiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgZD0iTTgwMC43NTcgMzQxLjM5NWMtMTEuMjctLjAxNS0yMS40NjYtMS4wMy0yOS4yMzMtMy4wOSA3Ljc2Ny0yLjA0NSAxNy45NjMtMy4zMSAyOS4yMzMtMy4zNDMgMTEuMjc0LjAxNCAyMS41MjIgMS4yODQgMjkuMjY1IDMuMzQzLTcuNzQzIDIuMDYtMTcuOTkgMy4wNzUtMjkuMjY1IDMuMDl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMjkuNzYzIDIxOS4xMTljLjA2Mi0uMi4wMDctLjM5NS0uMTI5LS40NDQtLjEzLS4wNC0uMjg2LjA4Ny0uMzQ3LjI3OC0uMDY1LjIwMy0uMDA4LjQwMi4xMjMuNDQ3LjEzLjA0LjI5LS4wODMuMzUzLS4yODEiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBzdHJva2U9IiMwMDAiIGQ9Ik04MzYuMyAzMTYuMjk1Yy4yOTQtLjg5Ni4wMzQtMS43NzctLjYxNS0xLjk5OC0uNjI1LS4xODItMS4zNjYuMzkzLTEuNjYgMS4yNS0uMzEzLjkxNi0uMDQgMS44MTEuNTg3IDIuMDEzLjYyNS4xODYgMS4zOS0uMzcgMS42ODgtMS4yNjV6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMjUuMDY4IDIxOC4xMjhjLjAyNS0uMjA2LS4wNy0uMzktLjIwNy0uNDEtLjEzNS0uMDE3LS4yNy4xNC0uMjkxLjM0Ny0uMDI1LjIwNi4wNjUuMzg5LjIwNC40MDguMTM4LjAxNS4yNjgtLjE0Mi4yOTQtLjM0NSIvPjxwYXRoIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0iIzAwMCIgZD0iTTgxMy44NTQgMzExLjgzNWMuMTIyLS45MjktLjMzLTEuNzU4LS45ODgtMS44NDQtLjY0NC0uMDgxLTEuMjg3LjYyOC0xLjM5IDEuNTU3LS4xMjEuOTMuMzEyIDEuNzUzLjk3NSAxLjg0LjY1Ny4wNjYgMS4yODMtLjY0MiAxLjQwMy0xLjU1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTMxOS42MTggMjE4LjEyOGMtLjAyNS0uMjA2LjA2NS0uMzkuMjAzLS40MS4xMzktLjAxNy4yNjguMTQuMjk1LjM0Ny4wMi4yMDYtLjA3LjM4OS0uMjA0LjQwOC0uMTM4LjAxNS0uMjctLjE0Mi0uMjk0LS4zNDUiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBzdHJva2U9IiMwMDAiIGQ9Ik03ODcuODAzIDMxMS44MzVjLS4xMjEtLjkyOS4zMDgtMS43NTguOTctMS44NDQuNjYzLS4wODEgMS4yODMuNjI4IDEuNDEgMS41NTcuMDk3LjkzLS4zMzEgMS43NTMtLjk3NSAxLjg0LS42NTguMDY2LTEuMjg4LS42NDItMS40MDQtMS41NTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMTQuOTIzIDIxOS4xMTljLS4wNjYtLjItLjAwNy0uMzk1LjEyNC0uNDQ0LjEzLS4wNC4yOS4wODcuMzUyLjI3OC4wNjEuMjAzLjAwNy40MDItLjEyMy40NDctLjEzNS4wNC0uMjkyLS4wODMtLjM1My0uMjgxIi8+PC9nPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iI2U2ZTZlNiIgZD0iTTc3My43MSAzMTYuMjk1Yy0uMzItLjg5Ni0uMDM0LTEuNzc3LjYxLTEuOTk4LjYzNi0uMTgyIDEuNDIyLjM5MyAxLjcyOCAxLjI1LjMwMi45MTYuMDM1IDEuODExLS42MDMgMi4wMTMtLjY2MS4xODYtMS40MzMtLjM3LTEuNzM0LTEuMjY1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJtODEwLjA2MyAyOTguNTI0LTQuMDgxIDIuNDYyIDMuMDI3IDYuNTcyIDEuMDU0LjY5NCAxLjA0LS42OTQgMy4wNDYtNi41NzJjLTEuMzYyLS44Mi0yLjcxLTEuNjY0LTQuMDg2LTIuNDYyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJtODAxLjEwNSAzMDguNDU0IDEuODY0IDIuNzA2IDYuMzY2LTEuOTY0LjY3NS0uODktLjY3NS0uOTE2LTYuMzY2LTEuODU4YTQ1IDQ1IDAgMCAwLTEuODY0IDIuOTIyem0xNy45NDkgMC0xLjg3MyAyLjcwNi02LjM2Ni0xLjk2NC0uNjc2LS44OS42NzYtLjkxNiA2LjM2Ni0xLjg1OGMuNjU1Ljk1NCAxLjI2MyAxLjkzOCAxLjg3MyAyLjkyMnptLTM1LjU1Ny03LjAwOC0zLjIgMy4wMjIgNC4xIDUuNDA4IDEuMDg4LjQzNi44MDUtLjgyOCAxLjQ0MS02LjUzNGEyMDMgMjAzIDAgMCAwLTQuMjM0LTEuNTA0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJtNzc2Ljc4MSAzMTIuMjkgMi40MDUgMi4yNjFMNzg1IDMxMS40MWwuNDQ2LTEuMDEtLjgzNC0uNzYyLTYuNjUzLS41NzVjLS40NDUgMS4wNTctLjgwNSAyLjE0NS0xLjE3OSAzLjIyOHptMTcuNTUxLTMuNTMtMS4yMyAyLjk5LTYuNjYtLjYxLS44NjYtLjc2LjQ2LTEuMDMgNS44MzQtMy4wNzZjLjg0Ny44MDMgMS42NTEgMS42NDcgMi40NjIgMi40ODZ6bS0yMy45NTUgNC4zNzQtLjU1MSAzLjE2LTYuNjYzLjY5LTEuMDEtLjU3NC4yNTMtMS4wNzggNS4wMDYtNC4xNThjLjk2NS42OSAxLjk2NSAxLjMyMyAyLjk2NSAxLjk2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PC9nPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMTYuODU3IDIxNy44MTNjMC0uMjc0LjIxMy0uNDk1LjQ3NS0uNDk1LjI2NSAwIC40NzYuMjIxLjQ3Ni40OTUgMCAuMjctLjIxLjQ5MS0uNDc2LjQ5MWEuNDg1LjQ4NSAwIDAgMS0uNDc1LS40OTEiLz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik03ODMuMjA1IDMxMC40MTNjMC0xLjIzMSAxLjA0OS0yLjIyOCAyLjMzMy0yLjIyOCAxLjMwMiAwIDIuMzM3Ljk5NyAyLjMzNyAyLjIyOCAwIDEuMjE2LTEuMDM1IDIuMjEzLTIuMzM3IDIuMjEzLTEuMjg0IDAtMi4zMzMtLjk5Ny0yLjMzMy0yLjIxM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggZD0ibTgzNi43MTUgMzAxLjQ0NiAzLjIxIDMuMDIyLTQuMTA2IDUuNDA4LTEuMDg3LjQzNi0uOC0uODI4LTEuNDQ3LTYuNTM0YTgzIDgzIDAgMCAwIDQuMjMtMS41MDR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im04NDMuNDQgMzEyLjI5LTIuNDEgMi4yNjEtNS44MTQtMy4xNDItLjQ2NS0xLjAxLjg1OC0uNzYyIDYuNjUzLS41NzVjLjQ2MyAxLjA3Mi43OTQgMi4xMjkgMS4xNzggMy4yMjh6bS0xNy41NTUtMy41MyAxLjIzIDIuOTkgNi42NTktLjYxLjg1Mi0uNzYtLjQ0NS0xLjAzLTUuODMtMy4wNzZjLS44MS44NDEtMS42MzYgMS42NjUtMi40NjYgMi40ODZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48L2c+PGcgc3Ryb2tlLXdpZHRoPSIuOTg3Ij48cGF0aCBmaWxsPSIjYzhiMTAwIiBkPSJtMzMwLjI0OSAyMTguNDE3LjExLjcwMSAxLjM1NC4xNTQuMjA0LS4xMjgtLjA1MS0uMjQtMS4wMTctLjkyMnoiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIGQ9Im04MzguNjI0IDMxMy4xMzQuNTIyIDMuMTYgNi40NzQuNjkuOTc1LS41NzQtLjI0Mi0xLjA3OC00Ljg2LTQuMTU4Yy0uOTY0LjY0NC0xLjkyNiAxLjI4OC0yLjg3IDEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMjEuODYgMjE3LjM0OGEuNDguNDggMCAwIDEgLjQ3Ni0uNDk1Yy4yNTcgMCAuNDc2LjIxNy40NzYuNDk1IDAgLjI3LS4yMTYuNDkxLS40NzYuNDkxYS40OC40OCAwIDAgMS0uNDc3LS40OTEiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIGQ9Ik03OTguNTE4IDMwOC4zMmMwLTEuMjUgMS4wMDMtMi4yMjggMi4yNzYtMi4yMjggMS4yMzIgMCAyLjI3Ny45NzcgMi4yNzcgMi4yMjggMCAxLjIxNi0xLjAzMiAyLjIxMy0yLjI3NyAyLjIxMy0xLjI3NCAwLTIuMjc2LS45OTctMi4yNzYtMi4yMTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMjYuODc0IDIxNy44MTNjMC0uMjc0LjIxNC0uNDk1LjQ3Ni0uNDk1LjI2NSAwIC40OC4yMjEuNDguNDk1IDAgLjI3LS4yMTUuNDkxLS40OC40OTFhLjQ4NS40ODUgMCAwIDEtLjQ3Ni0uNDkxIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgc3Ryb2tlPSIjMDAwIiBkPSJNODIyLjQ4OSAzMTAuNDEzYzAtMS4yMzEgMS4wMjEtMi4yMjggMi4yNzYtMi4yMjggMS4yNjUgMCAyLjI5NS45OTcgMi4yOTUgMi4yMjggMCAxLjIxNi0xLjAzIDIuMjEzLTIuMjk1IDIuMjEzLTEuMjU1IDAtMi4yNzYtLjk5Ny0yLjI3Ni0yLjIxM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTMyMi45NjggMjExLjQ3di42MTJoLTEuMzgydi0uNjExaC40NTJ2LTEuMzgxaC0uNnYtLjYxNWguNnYtLjYwNGguNTkydi42MDRoLjU4OXYuNjE1aC0uNTg5djEuMzhoLjMzNCIvPjwvZz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIGQ9Ik04MTMuMjA1IDI4MS44NXYyLjc1NGgtNi43ODN2LTIuNzU0aDIuMjE4di02LjIxOGgtMi45NDZ2LTIuNzY4aDIuOTQ2di0yLjcyMWgyLjkwOHYyLjcyaDIuODg4djIuNzdoLTIuODg4djYuMjE3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA0NGFkIiBkPSJNODExLjg3NSAyNzhjMi40MTYuNjU0IDQuMTcxIDIuNzg1IDQuMTcxIDUuMjk2IDAgMy4wNDYtMi42MDcgNS41MTMtNS44NSA1LjUxMy0zLjIxNyAwLTUuODI1LTIuNDY3LTUuODI1LTUuNTEzIDAtMi41NTYgMS44MjUtNC42ODYgNC4zMTItNS4zNDEiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTc2MS4xNSAzMTYuNTNhMjMuNCAyMy40IDAgMCAwLTIuOTAyLTMuMTc2Yy0uOTI5LS44MjktMy4yMS0xLjUzOC0zLjIxLTEuNTM4IDAtLjQyMSAxLjMzNy0xLjM3IDIuNzg0LTEuMzcuODM4IDAgMS42MzguMzU1IDIuMTEyLjk0OWwuMTY4LS45MTVzMS4xNzguMjIgMS42OTYgMS41MjNjLjUzNiAxLjM1LjE5NiAzLjM5Ni4xOTYgMy4zOTYtLjE4Ni40MzItLjU3NC43NDYtLjg0NCAxLjEzMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTc2MS40NTggMzE1LjY2N2MuNTU1LS41NzQgMS42OTUtLjQ1NSAyLjUzNC4yNzQuODU3LjcyMyAxLjEwNiAxLjc4Ni41NDYgMi4zOC0uNTQ2LjU5LTEuNjcyLjQ1NS0yLjUyNS0uMjczLS44NjItLjcyMy0xLjEwNi0xLjgwNi0uNTU1LTIuMzh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48ZyBzdHJva2Utd2lkdGg9Ii45ODciPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0zMzIuMDggMjE5LjIzOGMuMDE0LjAxMS4zNjYtLjUxLjYzNy0uNzcyLjE4NS0uMTg0LjY1NC0uMzQyLjY1NC0uMzQyIDAtLjA5My0uMjczLS4zMDQtLjU2OC0uMzA0YS41NC41NCAwIDAgMC0uNDMyLjIxbC0uMDM2LS4yMDJzLS4yNC4wNDgtLjM0NS4zMzhjLS4xMDguMy0uMDQxLjc1NC0uMDQxLjc1NHMuMDQ0LjIxLjEzLjMxOCIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZT0iIzAwMCIgZD0iTTg0Ny4zNzQgMzE2LjgzMWMuMDcuMDUzIDEuNzU0LTIuMjk0IDMuMDQ2LTMuNDc3Ljg4Ni0uODI5IDMuMTI2LTEuNTM4IDMuMTI2LTEuNTM4IDAtLjQyMS0xLjMwMi0xLjM3LTIuNzExLTEuMzctLjgxNiAwLTEuNi4zNTUtMi4wNjYuOTQ5bC0uMTczLS45MTVzLTEuMTUyLjIyLTEuNjUgMS41MjNjLS41MTggMS4zNS0uMTk2IDMuMzk2LS4xOTYgMy4zOTYtLjAyLjU5Mi4yNDEuNzcyLjYyNCAxLjQzMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTMzMi4wOTIgMjE4Ljk4Yy0uMTE0LS4xMjgtLjM0NS0uMTAyLS41Mi4wNi0uMTc0LjE2LS4yMjEuMzk3LS4xMTMuNTI4LjExMy4xMzEuMzQ1LjEwMi41Mi0uMDYuMTc0LS4xNi4yMjUtLjQwMS4xMTMtLjUyOSIvPjwvZz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik04NTcuOTk3IDMxNS42NjdjLS41Ni0uNTc0LTEuNjk1LS40NTUtMi41NTMuMjc0LS44NTcuNzIzLTEuMDg3IDEuNzg2LS41NTUgMi4zOC41NTUuNTkgMS42OTUuNDU1IDIuNTQ4LS4yNzMuODU3LS43MjMgMS4xMTEtMS44MDYuNTYtMi4zOHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTgxNi4yMzcgMjgxLjg1djIuNzU0aC0xMi4wNTZ2LTIuNzU0aDQuNDZ2LTYuMjE4aC0yLjk0N3YtMi43NjhoMi45NDZ2LTIuNzIxaDIuOTA4djIuNzJoMi45MDN2Mi43N2gtMi45MDN2Ni4yMTdoMy42NXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0ibm9uZSI+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMSIgZD0iTTgwOS45NzUgMzQxLjQ0NHYtNi4wM20tMS42MzggNi4wM3YtNi4wMyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBzdHJva2Utd2lkdGg9Ii4yNSIgZD0iTTgwNi43OSAzNDEuNDQ0di02LjAzbS0xLjUzMiA2LjAzdi02LjAzbS0xLjM2NiA2LjAzdi02LjAzbS0yLjYwNSA1LjcwNi0uMDM2LTUuNDltMS4yNzEgNS41NjJ2LTUuNzQyIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIHN0cm9rZS13aWR0aD0iLjUiIGQ9Ik03OTguODgyIDM0MC44NzN2LTUuMDU3bTEuMjE5IDUuMjAxLS4wMzYtNS4zODJtLTQuNDA4IDQuOTQ4di00LjQ0Mm0xLjA1OCA0LjUxNXYtNC42Nm0xLjA5IDQuODA1di00Ljg0MSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBzdHJva2Utd2lkdGg9Ii43NSIgZD0iTTc5NC41MjUgMzQwLjU0N3YtNC4yOThtLTEuMDU0IDQuMzg3di00LjcwM20tMS4xMzEgNC41Njd2LTQuMzg3bS0yLjMxNSA0LjAwNy0uMDM2LTMuNzEybTEuMjIyIDMuOTM5di00LjEiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTc4OC44MzggMzQwLjAzM3YtMy4zNW0tMS4wODYgMy4zODh2LTMuMjE5bS0xLjE4NiAyLjU5OHYtMi40MThtLTEuMjIgMi40NHYtMi4yMDdtLTEuMjkgMS45MTl2LTEuNjQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMSIgZD0iTTgxNi40OSAzNDEuMTJ2LTUuNTI1bS0yLjc3NCA1LjcwNS4wMzYtNS44NW0tMi4wNTggNS45MjJ2LTUuOTU4IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48L2c+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTMxMS40NjYgMjMxLjI5MmgyMS41OTd2LTYuMTdoLTIxLjU5N3oiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik03NTYuNzQyIDM3MS4xMjNoMTA2LjAydi0yNy43OTJoLTEwNi4wMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTMzMC43OTcgMjM1LjM5OWEuOS45IDAgMCAwLS40LS4wNjdoLTE2LjE3M2MtLjE2IDAtLjMxMy4wMy0uNDQ3LjA4Ni41NTYtLjIwMi45NTUtLjc1Ljk1NS0xLjM5NXMtLjQzNS0xLjIwNC0uOTk1LTEuNDE0Yy4xMzQuMDQ1LjMxNS4wODYuNDc1LjA4NmgxNi4xODVjLjE2MiAwIC4zMTYtLjAwNy40NTQtLjA1NmwtLjA5MS4wMTVjLS41NzguMTk0LS45MDkuNzU0LS45MDkgMS4zNjkgMCAuNTkyLjM2NyAxLjE4NS45NDYgMS4zNzYiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik04NTEuNjM5IDM4OS42MThjLS42NjYtLjI2OS0xLjE3LS4zMDItMS45NjQtLjMwMmgtNzkuMzk2Yy0uNzg2IDAtMS41MzMuMTM0LTIuMTk0LjM4OCAyLjczLS45MSA0LjY5LTMuMzc3IDQuNjktNi4yODUgMC0yLjkwMi0yLjEzNy01LjQyMi00Ljg4Ny02LjM2Ni42NjEuMjAyIDEuNTQ4LjM4OCAyLjMzMy4zODhoNzkuNDU0Yy43OTUgMCAxLjU1Mi0uMDMzIDIuMjI3LS4yNTRsLS40NDYuMDY3Yy0yLjgzNS44NzctNC40NiAzLjM5Ny00LjQ2IDYuMTY1IDAgMi42NjggMS44MDIgNS4zNDEgNC42NDIgNi4xOTl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0zMTQuMjI0IDIzNS4zMzJoMTYuMTczYy41NDQgMCAuOTg4LjM3MS45ODguODI1IDAgLjQ1OC0uNDQ0LjgyOS0uOTg4LjgyOWgtMTYuMTczYy0uNTQ5IDAtLjk5My0uMzcxLS45OTMtLjgyOSAwLS40NTQuNDQ0LS44MjUuOTkzLS44MjUiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik03NzAuMjc5IDM4OS4zMTZoNzkuMzk2YzIuNjcyIDAgNC44NTIgMS42NzIgNC44NTIgMy43MTcgMCAyLjA2LTIuMTggMy43MzEtNC44NTIgMy43MzFoLTc5LjM5NmMtMi42OTIgMC00Ljg3Mi0xLjY3MS00Ljg3Mi0zLjczMSAwLTIuMDQ1IDIuMTgtMy43MTcgNC44NzItMy43MTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0zMTQuMjEyIDIzMS4yOTJoMTYuMTg1Yy41NDQgMCAuOTg4LjMxNS45ODguNjk4IDAgLjM5LS40NDQuNzA1LS45ODguNzA1aC0xNi4xODVjLS41NDggMC0uOTkyLS4zMTUtLjk5Mi0uNzA1IDAtLjM4My40NDQtLjY5OC45OTItLjY5OCIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTc3MC4yMjEgMzcxLjEyM2g3OS40NTRjMi42NzIgMCA0Ljg1MiAxLjQxOCA0Ljg1MiAzLjE0MyAwIDEuNzUzLTIuMTggMy4xNzUtNC44NTIgMy4xNzVINzcwLjIyYy0yLjY4NyAwLTQuODY3LTEuNDIyLTQuODY3LTMuMTc1IDAtMS43MjUgMi4xOC0zLjE0MyA0Ljg2Ny0zLjE0M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTMzMC43OTMgMzI0LjY4M2MtLjA1LjIxNC0uMTIuNDI0LS4xMi42NTMgMCAxLjU0NSAxLjIyNCAyLjc3NSAyLjcxNyAyLjc3NWgtMjIuMjIzYzEuNDk0IDAgMi43MTUtMS4yMyAyLjcxNS0yLjc3NSAwLS4yMjUtLjA0LS40NC0uMDg0LS42NTMuMTIuMDQ5LjI3My4wNTYuNDIyLjA1NmgxNi4xNzNjLjEzIDAgLjI4My0uMDE0LjM5Ni0uMDU2Ii8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNODUxLjYyIDc5MS43MzNjLS4yNS45NjMtLjU5IDEuOTExLS41OSAyLjk0MSAwIDYuOTYgNi4wMDcgMTIuNDk3IDEzLjM0IDEyLjQ5N0g3NTUuMjcyYzcuMzM0IDAgMTMuMzMxLTUuNTM3IDEzLjMzMS0xMi40OTcgMC0xLjAxNS0uMTk2LTEuOTc4LS40MTItMi45NDEuNTkuMjIgMS4zNDEuMjU0IDIuMDcuMjU0aDc5LjM5NWMuNjQyIDAgMS4zOS0uMDY3IDEuOTQ1LS4yNTRoLjAyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMzE0LjIyNCAzMjMuMDgyaDE2LjE3M2MuNTQ0IDAgLjk4OC4zNzUuOTg4LjgyOSAwIC40NTctLjQ0NC44MjgtLjk4OC44MjhoLTE2LjE3M2MtLjU0OSAwLS45OTMtLjM3LS45OTMtLjgyOCAwLS40NTQuNDQ0LS44My45OTMtLjgzIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNzcwLjI3OSA3ODQuNTJoNzkuMzk2YzIuNjcyIDAgNC44NTIgMS42OSA0Ljg1MiAzLjczNSAwIDIuMDYtMi4xOCAzLjczMi00Ljg1MiAzLjczMmgtNzkuMzk2Yy0yLjY5MiAwLTQuODcyLTEuNjcyLTQuODcyLTMuNzMyIDAtMi4wNDUgMi4xOC0zLjczNiA0Ljg3Mi0zLjczNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTMxMS4xOTMgMzM0LjI3NGgyMi4xN3YtNi4xNjNoLTIyLjE3eiIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTc1NS40IDgzNC45M2gxMDguODMydi0yNy43Nkg3NTUuNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2NlMTEyNiIgZD0iTTMzNS4wOTQgMzAxLjI3YzIuMTk2IDEuMzgxIDMuNjg2IDIuNzk1IDMuNDQ2IDMuNS0uMTIxLjY0OS0uODE4IDEuMTMzLTEuODEzIDEuODUzLTEuNTY2IDEuMTg5LTIuNTIzIDMuMzEyLTEuNzc3IDQuMjkxYTYuMyA2LjMgMCAwIDEtMi4xMTItNC43MzdjMC0xLjk4Ljg2Mi0zLjc2NiAyLjI1Ni00LjkwNiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTg3Mi43MzQgNjg2LjI5YzEwLjc3OCA2LjIxNyAxOC4wOTIgMTIuNTgzIDE2LjkxNCAxNS43NTktLjU5NCAyLjkyMi00LjAxNCA1LjEwMS04LjkgOC4zNDQtNy42ODggNS4zNTUtMTIuMzgyIDE0LjkxNi04LjcyMyAxOS4zMjgtNi4zNTEtNS4xMzUtMTAuMzY2LTEyLjgwNC0xMC4zNjYtMjEuMzM1IDAtOC45MTkgNC4yMy0xNi45NjIgMTEuMDc1LTIyLjA5NnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2IyYjJiMiIgZD0iTTMxNC40MzQgMzIyLjA4NGgxNS43NTJ2LTg0LjExOWgtMTUuNzUyeiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTgyNy40MDUgNDAxLjAzN3YzNzguMDRtOC42OTQtMzc4LjA0djM3OC4wNG0tNjQuNzg2Ljk0OWg3Ny4zMjd2LTM3OC44NWgtNzcuMzI3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMjk4LjM0NSAyNjkuNDNjMy40NC0xLjU0OSA5LjI4My0yLjY5NiAxNS45ODgtMi45MzcgMi4zMS4wMiA0Ljg4NS4yNTYgNy41NDYuNzQgOS40MTkgMS43MTMgMTYuNTk1IDUuODEzIDE2LjAyNCA5LjE1MS0uMDExLjA3Mi0uMDI4LjIxNy0uMDQ2LjI4MSAwIDAgMy41MzQtOC42NzUgMy41ODUtOS4wMDUuNjMzLTMuNzA1LTcuMzI2LTguMjYtMTcuNzgyLTEwLjE2MWE0OS42IDQ5LjYgMCAwIDAtOS4yNjItLjc5OWMtNi42OTIgMC0xMi41MDcuOTM0LTE2LjAxIDIuMzUxeiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTY5Mi4zMyA1NDIuODg1YzE2Ljg4NC02Ljk3NCA0NS41NzItMTIuMTQzIDc4LjQ4NS0xMy4yMjUgMTEuMzM4LjA4NiAyMy45ODQgMS4xNSAzNy4wNDcgMy4zMjkgNDYuMjM0IDcuNzE3IDgxLjQ2NSAyNi4xODIgNzguNjYzIDQxLjIxOC0uMDU4LjMyMS0uMTQuOTc3LS4yMyAxLjI2NSAwIDAgMTcuMzUtMzkuMDczIDE3LjYwMy00MC41NTggMy4xMDQtMTYuNjg4LTM1Ljk2NC0zNy4yLTg3LjI5NC00NS43NjQtMTYuMTEtMi42ODctMzEuODQtMy43MzEtNDUuNDY4LTMuNTk3LTMyLjg1NSAwLTYxLjQgNC4yMDYtNzguNTkxIDEwLjU5bC0uMjE2IDQ2Ljc0MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMzMwLjIxNCAyNzkuOTg5YzQuMzY5LS4zNDIgNy4zNTItMS42MTQgNy42OS0zLjYwNS4yNzMtMS41ODYtMS4yMDctMy4zNDEtMy44NDEtNC45MzUtMS4xOC4xMzgtMi41MDguMzE0LTMuODc3LjMxNHoiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik04NDguNzc5IDU5MC40NGMyMS40NDUtMS41MzcgMzYuMDg4LTcuMjY2IDM3Ljc0Ni0xNi4yMzMgMS4zNDEtNy4xNDctNS45Mi0xNS4wNS0xOC44NTQtMjIuMjMtNS43OTYuNjIyLTEyLjMxIDEuNDE3LTE5LjAzMSAxLjQxN2wuMTM5IDM3LjA0NyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMzE0LjQwOSAyNzMuNTZjLTIuNzMyLjQ1LTQuNzggMS4xODktNS44MDQgMi4wOTdsLS4wOS4xODNjLS40OSAxLjA4OCAxLjkxMSAzLjQwMiA1LjkxNSA1Ljk4N3oiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik03NzEuMTg5IDU2MS40ODVjLTEzLjQxMyAyLjAyNi0yMy40NjIgNS4zNTUtMjguNDkyIDkuNDQ2bC0uNDQuODI0Yy0yLjQxIDQuOSA5LjM3OSAxNS4zMjMgMjkuMDM3IDI2Ljk2M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTMzOS45OTYgMjk2LjIxNWMuNDE0LTEuMzU5LTMuODQ1LTQuMDc3LTkuODY0LTYuNDg1LTIuNzUxLTEuMDczLTUuMDIzLTIuMTktNy44MzgtMy41NDUtOC4zNjEtNC4wMjktMTQuNTM5LTguNjUzLTEzLjc3Ni0xMC4zNGwuMDgxLS4xNzNjLS40NC4zOTMtMS4xMyA4LjctMS4xMyA4LjctLjc2MyAxLjU0NiA0Ljg5IDYuMTA0IDEyLjU4MiAxMC4xMjUgMi40NjUgMS4yODMgNy42NyAzLjM3OSAxMC4xMjcgNC4zMTcgNC4zOTMgMS42NjEgOC43NTggNC43OTMgOC4zNjIgNS45NTZsMS40NTYtOC41NTEiLz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik04OTYuOCA2NjMuNTE4YzIuMDMtNi4xMTctMTguODc4LTE4LjM2LTQ4LjQyOC0yOS4yMDUtMTMuNTA0LTQuODMzLTI0LjY1NS05Ljg2OC0zOC40NzQtMTUuOTY2LTQxLjA0Ny0xOC4xNDQtNzEuMzczLTM4Ljk3MS02Ny42MjctNDYuNTczbC4zOTctLjc3NmMtMi4xNiAxLjc3Mi01LjU0NyAzOS4xODctNS41NDcgMzkuMTg3LTMuNzQ1IDYuOTYgMjQuMDA4IDI3LjQ4NiA2MS43NjQgNDUuNTk3IDEyLjEgNS43NzcgMzcuNjU1IDE1LjIxOCA0OS43MTYgMTkuNDQzIDIxLjU2NiA3LjQ4MiA0Mi45OTIgMjEuNTg4IDQxLjA0NyAyNi44MjRsNy4xNTItMzguNTEyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2Utd2lkdGg9Ii41IiBkPSJNNzQwLjUyMyA1MjYuMjgzYzIuOTI2LTExLjA5OSA2LjcwNi0yMS44MjkgMTAuNDE4LTMyLjY4OC0uODIuMjItMS43MS4zODgtMi41MzQuNTIyLS44MzMuMTItMS43My4yMDEtMi41ODIuMjM1LTEuNzY3IDcuODA4LTQuMTU4IDE1LjY0NC02LjcyNSAyMy40OC00LjU3LTYuODU0LTkuNTQ3LTEzLjUxMi0xMy41MDMtMjAuNDM4LTEuNTg2LjMyLTMuMjM0LjcwOS00Ljg1My45NDgtMS41OS4yMzUtMy4yODYuMzU1LTQuOTI0LjUwOCA2LjkwMiA5LjI1NCAxMy41NzUgMTguNTEzIDE5Ljk4IDI4LjEyMi43NjYtLjIgMS41MDgtLjQ1NSAyLjM1Ni0uNTc1Ljc2Ny0uMSAxLjU2Ny0uMDgxIDIuMzY3LS4xMTVtMjkuNDAxLTMyLjQ2NmMtMS40MTMuMDY3LTIuODIxLjE2Ny00LjIzNC4xNDgtMS40MDQtLjAxNS0yLjgxMi0uMTgyLTQuMjA2LS4yODdsLS41NyAzMC41MDggMjEuMzM1LjM1OWMtLjExLS42MjgtLjI2OC0xLjMwMy0uMjQ5LTEuOTQ1IDAtLjYyOC4xOTctMS4yODQuMjk3LTEuOTExLTMuODE4LjI1NC03Ljk4NS40OTMtMTIuODc2LjQwN2wuNTAzLTI3LjI4bTMzLjQ5MyA1LjAxNWMzLjQxLjI4OCA2LjY5MS44NzcgOS45NzcgMS40NzEtLjA2Mi0uNjQxLS4xNjMtMS4yODMtLjExLTEuOTQ0LjA1LS42MjMuMjg4LTEuMjUuNDY1LTEuODU5bC0yOC44OC0yLjM5NWMuMDcyLjY0Mi4xNzcgMS4yNjUuMTEgMS44OTItLjA1Ny42NzYtLjI4NyAxLjI4NC0uNDU1IDEuOTA3IDIuOTQ2LS4wNjcgNi41LS4xIDEwLjQ3Ni4yMzRsLTIuNTE1IDI3LjQ1MmMxLjQwOS4wMzUgMi44MTcuMDIgNC4yMTEuMTM0IDEuNDAzLjEwNSAyLjgwMi4zNTQgNC4xOTEuNTZsMi41MTUtMjcuNDUxbTExLjgyNyAzMC4wNjdjMS4zOTQuMjIgMi43OTcuMzg4IDQuMTc3LjY5NSAxLjM3LjI4NyAyLjcxMS43MjggNC4wNDggMS4xMTZsMy40MjQtMTQuMDIuMzc0LjA4Yy44IDEuOTI2IDEuODQgNC4yNzMgMi4zNzEgNS42MjlsNC4yODIgMTAuNTljMS42NzcuMjcgMy4zNDkuNDkgNC45OTcuODQ0IDEuNjkuMzczIDMuMzEuODYyIDQuOTM4IDEuMzE3bC0xLjQ4NS0zLjE3NmMtMi4zMDQtNC43OC00LjcyMy05LjU0MS02LjcyLTE0LjM4OSA1LjMxNy4yMzUgOS40MzYtMS42OSAxMC40Ny01Ljk2NC43MzQtMi45NzQtLjQ1LTUuMzA3LTMuMjUyLTcuMy0yLjA2NC0xLjQ3LTYuMDczLTIuMjQ2LTguNjYtMi44MmwtMTEuNjUtMi41NS03LjMxNCAyOS45NDhtMTQuOTQ1LTI1Ljc5NGMzLjM1OC43NDIgNy41NSAxLjI4MyA3LjU1IDUuMTAxLS4wMi45NjMtLjExIDEuNjM4LS4yNyAyLjI0Ny0xLjA4NyA0LjQ3OC00LjQ3OCA2LjAzLTEwLjEzIDQuMzQ0bDIuODUtMTEuNjkybTQwLjA2IDM0LjkzM2MtLjI1OSAzLjMxLS44NDggNi41MjUtMS40OSAxMC4wMDIgMS40NjEuNjk1IDIuOTA4IDEuMzE3IDQuMzE2IDIuMDkzIDEuNDA4Ljc4MSAyLjcwNiAxLjYzOSA0LjA2NyAyLjQ4NmwyLjg1NS0zNC4zOTJhMjAgMjAgMCAwIDEtMS45MjYtLjg5NiAxNyAxNyAwIDAgMS0xLjc5Mi0xLjEzNWwtMzAuMzIgMTkuMjZjLjc5OS4zODkgMS42MjguNzQzIDIuNDA4IDEuMTY1Ljc4Ni40NCAxLjQ0Ny45MSAyLjIzMyAxLjM1IDIuNTQzLTIuMTQ2IDUuMjI2LTMuODg0IDguMjkxLTYuMTY0bDExLjM0OCA2LjIxN3ptLTguNTk0LTcuODU1IDEwLjA5OC02LjUzNC0xLjE3OSAxMS40eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iIzAwNWJiZiIgZD0iTTMwNy4xODUgMzM1LjEzM2MxLjQ5NyAwIDIuODI2LS4zNDIgMy44MDgtLjkxMi45NzUtLjU0IDIuMjkzLS44NyAzLjc0Ni0uODcgMS40NTggMCAyLjgxMy4zMzQgMy43ODcuODc4Ljk3My41NiAyLjMyNS45MDQgMy44LjkwNCAxLjQ5IDAgMi44MjctLjM4IDMuODA5LS45NDkuOTY2LS41MTggMi4yNTYtLjgzMyAzLjY3Ni0uODMzIDEuNDY1IDAgMi43NjIuMzA0IDMuNzQuODU1Ljk3Ni41NjcgMi4zNC45MjcgMy44MjguOTI3djIuNTVjLTEuNDg5IDAtMi44NTItLjM3MS0zLjgyOS0uOTM0LS45NzctLjU0OC0yLjI3NC0uODU4LTMuNzM5LS44NTgtMS40MiAwLTIuNzEuMzE4LTMuNjc2Ljg0LS45NzguNTY2LTIuMzE5Ljk1Mi0zLjgwOS45NTItMS40NzEgMC0yLjgyNC0uMzUyLTMuOC0uOTA3LS45NzQtLjU1MS0yLjMyNi0uODg1LTMuNzg3LS44ODUtMS40NTMgMC0yLjc3MS4zMzQtMy43NDYuODc3LS45ODIuNTctMi4yOTIuOTE1LTMuNzg2LjkxNXoiLz48cGF0aCBmaWxsPSIjMDA0NWFmIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik03MzUuNzI4IDgzOC43OTVjNy4zNDggMCAxMy44NzItMS41MzcgMTguNjktNC4xMDUgNC43ODYtMi40MzMgMTEuMjU3LTMuOTE4IDE4LjM5LTMuOTE4IDcuMTU2IDAgMTMuODEgMS41MDQgMTguNTkgMy45NTIgNC43OCAyLjUyIDExLjQxNSA0LjA3MSAxOC42NTggNC4wNzEgNy4zMTQgMCAxMy44NzctMS43MDUgMTguNjk1LTQuMjcyIDQuNzQzLTIuMzMzIDExLjA3NS0zLjc1MSAxOC4wNS0zLjc1MSA3LjE5IDAgMTMuNTU2IDEuMzcgMTguMzU1IDMuODUxIDQuNzk1IDIuNTUzIDExLjQ4NyA0LjE3MiAxOC43OTcgNC4xNzJ2MTEuNDg3Yy03LjMxIDAtMTQuMDAyLTEuNjcyLTE4Ljc5Ny00LjIwNi00LjgtMi40NjctMTEuMTY2LTMuODY1LTE4LjM1Ni0zLjg2NS02Ljk3NCAwLTEzLjMwNiAxLjQzMi0xOC4wNDkgMy43ODQtNC44IDIuNTQ4LTExLjM4IDQuMjg3LTE4LjY5NSA0LjI4Ny03LjIyNCAwLTEzLjg2My0xLjU4Ni0xOC42NTgtNC4wODYtNC43OC0yLjQ4MS0xMS40MTUtMy45ODUtMTguNTktMy45ODUtNy4xMzMgMC0xMy42MDQgMS41MDQtMTguMzkgMy45NTEtNC44MTggMi41NjgtMTEuMjUxIDQuMTItMTguNTg1IDQuMTJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiMmIyYjIiIGQ9Ik0zMDcuMTg1IDMzNy42ODNjMS40OTcgMCAyLjgyNi0uMzQ1IDMuODA4LS45MTUuOTc1LS41NDMgMi4yOTMtLjg3NyAzLjc0Ni0uODc3IDEuNDU4IDAgMi44MTMuMzM0IDMuNzg3Ljg4NS45NzMuNTU1IDIuMzI1LjkwNyAzLjguOTA3IDEuNDkgMCAyLjgyNy0uMzg2IDMuODA5LS45NTIuOTY2LS41MjIgMi4yNTYtLjg0IDMuNjc2LS44NCAxLjQ2NSAwIDIuNzYyLjMxIDMuNzQuODU4Ljk3Ni41NjMgMi4zNC45MzQgMy44MjguOTM0djIuNTQzYy0xLjQ4OSAwLTIuODUyLS4zNjQtMy44MjktLjkyNi0uOTc3LS41NTUtMi4yNzQtLjg2My0zLjczOS0uODYzLTEuNDIgMC0yLjcxLjMyLTMuNjc2Ljg0LS45NzguNTY3LTIuMzE5Ljk0OS0zLjgwOS45NDktMS40NzEgMC0yLjgyNC0uMzUyLTMuOC0uOTA3LS45NzQtLjU0OC0yLjMyNi0uODgyLTMuNzg3LS44ODItMS40NTMgMC0yLjc3MS4zMzQtMy43NDYuODc4LS45ODIuNTY2LTIuMjkyLjkxMS0zLjc4Ni45MTF6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNzM1LjcyOCA4NTAuMjgyYzcuMzQ4IDAgMTMuODcyLTEuNTUyIDE4LjY5LTQuMTIgNC43ODYtMi40NDcgMTEuMjU3LTMuOTUxIDE4LjM5LTMuOTUxIDcuMTU2IDAgMTMuODEgMS41MDQgMTguNTkgMy45ODUgNC43OCAyLjUgMTEuNDE1IDQuMDg2IDE4LjY1OCA0LjA4NiA3LjMxNCAwIDEzLjg3Ny0xLjczOSAxOC42OTUtNC4yODcgNC43NDMtMi4zNTIgMTEuMDc1LTMuNzg0IDE4LjA1LTMuNzg0IDcuMTkgMCAxMy41NTYgMS4zOTggMTguMzU1IDMuODY1IDQuNzk1IDIuNTM0IDExLjQ4NyA0LjIwNiAxOC43OTcgNC4yMDZ2MTEuNDUzYy03LjMxIDAtMTQuMDAyLTEuNjM4LTE4Ljc5Ny00LjE3Mi00LjgtMi41LTExLjE2Ni0zLjg4NS0xOC4zNTYtMy44ODUtNi45NzQgMC0xMy4zMDYgMS40MzctMTguMDQ5IDMuNzg0LTQuOCAyLjU1My0xMS4zOCA0LjI3My0xOC42OTUgNC4yNzMtNy4yMjQgMC0xMy44NjMtMS41ODYtMTguNjU4LTQuMDg2LTQuNzgtMi40NjctMTEuNDE1LTMuOTcxLTE4LjU5LTMuOTcxLTcuMTMzIDAtMTMuNjA0IDEuNTA0LTE4LjM5IDMuOTUyLTQuODE4IDIuNTUzLTExLjI1MSA0LjEwNS0xOC41ODUgNC4xMDVsLS4xMDUtMTEuNDUzIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiMwMDViYmYiIGQ9Ik0zMDcuMTg1IDM0MC4yMjZjMS40OTcgMCAyLjgyNi0uMzQ1IDMuODA4LS45MTEuOTc1LS41NDQgMi4yOTMtLjg3OCAzLjc0Ni0uODc4IDEuNDU4IDAgMi44MTMuMzM0IDMuNzg3Ljg4Mi45NzMuNTU1IDIuMzI1LjkwNyAzLjguOTA3IDEuNDkgMCAyLjgyNy0uMzgyIDMuODA5LS45NDkuOTY2LS41MiAyLjI1Ni0uODQgMy42NzYtLjg0IDEuNDY1IDAgMi43NjIuMzA3IDMuNzQuODYzLjk3Ni41NjIgMi4zNC45MjYgMy44MjguOTI2djIuNTQzYy0xLjQ4OSAwLTIuODUyLS4zNjQtMy44MjktLjkzLS45NzctLjU0Ny0yLjI3NC0uODU0LTMuNzM5LS44NTQtMS40MiAwLTIuNzEuMzE4LTMuNjc2LjgzNS0uOTc4LjU3LTIuMzE5Ljk0OS0zLjgwOS45NDktMS40NzEgMC0yLjgyNC0uMzQ4LTMuOC0uOTAzLS45NzQtLjU0OC0yLjMyNi0uODgxLTMuNzg3LS44ODEtMS40NTMgMC0yLjc3MS4zMjktMy43NDYuODc0LS45ODIuNTczLTIuMjkyLjkxLTMuNzg2LjkxeiIvPjxwYXRoIGZpbGw9IiMwMDQ1YWYiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTczNS43MjggODYxLjczNWM3LjM0OCAwIDEzLjg3Mi0xLjU1MiAxOC42OS00LjEwNSA0Ljc4Ni0yLjQ0OCAxMS4yNTctMy45NTIgMTguMzktMy45NTIgNy4xNTYgMCAxMy44MSAxLjUwNCAxOC41OSAzLjk3IDQuNzggMi41MDEgMTEuNDE1IDQuMDg3IDE4LjY1OCA0LjA4NyA3LjMxNCAwIDEzLjg3Ny0xLjcyIDE4LjY5NS00LjI3MyA0Ljc0My0yLjM0NyAxMS4wNzUtMy43ODQgMTguMDUtMy43ODQgNy4xOSAwIDEzLjU1NiAxLjM4NCAxOC4zNTUgMy44ODUgNC43OTUgMi41MzQgMTEuNDg3IDQuMTcyIDE4Ljc5NyA0LjE3MnYxMS40NTNjLTcuMzEgMC0xNC4wMDItMS42MzgtMTguNzk3LTQuMTg3LTQuOC0yLjQ2Ny0xMS4xNjYtMy44NS0xOC4zNTYtMy44NS02Ljk3NCAwLTEzLjMwNiAxLjQzNi0xOC4wNDkgMy43NjQtNC44IDIuNTY4LTExLjM4IDQuMjczLTE4LjY5NSA0LjI3My03LjIyNCAwLTEzLjg2My0xLjU2Ny0xOC42NTgtNC4wNjctNC43OC0yLjQ2Ny0xMS40MTUtMy45Ny0xOC41OS0zLjk3LTcuMTMzIDAtMTMuNjA0IDEuNDg0LTE4LjM5IDMuOTM3LTQuODE4IDIuNTgxLTExLjI1MSA0LjEtMTguNTg1IDQuMWwtLjEwNS0xMS40NTMiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2IyYjJiMiIgZD0iTTMwNy4yMDcgMzQ1LjMxNmMxLjQ5NCAwIDIuODA0LS4zNDQgMy43ODYtLjkxNS45NzUtLjU0IDIuMjkzLS44NyAzLjc0Ni0uODcgMS40NTggMCAyLjgxMy4zMyAzLjc4Ny44NzguOTczLjU1NSAyLjMyNS45MDcgMy44LjkwNyAxLjQ5IDAgMi44MjctLjM4MyAzLjgwOS0uOTUzLjk2Ni0uNTE3IDIuMjU2LS44MzIgMy42NzYtLjgzMiAxLjQ2NSAwIDIuNzYyLjMwOCAzLjc0Ljg1NC45NzYuNTY4IDIuMzQuOTMxIDMuODI4LjkzMXYtMi41MzFjLTEuNDg5IDAtMi44NTItLjM4LTMuODI5LS45NDYtLjk3Ny0uNTQ3LTIuMjc0LS44NTQtMy43MzktLjg1NC0xLjQyIDAtMi43MS4zMTgtMy42NzYuODM1LS45NzguNTctMi4zMTkuOTQ5LTMuODA5Ljk0OS0xLjQ3MSAwLTIuODI0LS4zNDgtMy44LS45MDMtLjk3NC0uNTQ4LTIuMzI2LS44ODEtMy43ODctLjg4MS0xLjQ1MyAwLTIuNzcxLjMyOS0zLjc0Ni44NzQtLjk4Mi41NzMtMi4zMS45MS0zLjgwOC45MXoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik03MzUuODMzIDg4NC42NmM3LjMzNCAwIDEzLjc2Ny0xLjU1MiAxOC41ODYtNC4xMiA0Ljc4NS0yLjQzMyAxMS4yNTYtMy45MjIgMTguMzg5LTMuOTIyIDcuMTU2IDAgMTMuODEgMS40OSAxOC41OSAzLjk1NiA0Ljc4IDIuNSAxMS40MTUgNC4wODYgMTguNjU4IDQuMDg2IDcuMzE0IDAgMTMuODc3LTEuNzI0IDE4LjY5NS00LjI5MiA0Ljc0My0yLjMyOCAxMS4wNzUtMy43NSAxOC4wNS0zLjc1IDcuMTkgMCAxMy41NTYgMS4zODkgMTguMzU1IDMuODUgNC43OTUgMi41NTQgMTEuNDg3IDQuMTkyIDE4Ljc5NyA0LjE5MnYtMTEuNGMtNy4zMSAwLTE0LjAwMi0xLjcxLTE4Ljc5Ny00LjI1OS00LjgtMi40NjctMTEuMTY2LTMuODUtMTguMzU2LTMuODUtNi45NzQgMC0xMy4zMDYgMS40MzYtMTguMDQ5IDMuNzY0LTQuOCAyLjU2OC0xMS4zOCA0LjI3My0xOC42OTUgNC4yNzMtNy4yMjQgMC0xMy44NjMtMS41NjctMTguNjU4LTQuMDY3LTQuNzgtMi40NjctMTEuNDE1LTMuOTctMTguNTktMy45Ny03LjEzMyAwLTEzLjYwNCAxLjQ4NC0xOC4zOSAzLjkzNy00LjgxOCAyLjU4MS0xMS4zNDIgNC4xLTE4LjY5IDQuMWwuMTA1IDExLjQ3MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA1YmJmIiBkPSJNMzA3LjIwNyAzNDcuODYzYzEuNDk0IDAgMi44MDQtLjM0NSAzLjc4Ni0uOTExLjk3NS0uNTQ4IDIuMjkzLS44ODIgMy43NDYtLjg4MiAxLjQ1OCAwIDIuODEzLjMzOCAzLjc4Ny44ODUuOTczLjU1NSAyLjMyNS45MDggMy44LjkwOCAxLjQ5IDAgMi44MjctLjM4NyAzLjgwOS0uOTUzLjk2Ni0uNTIgMi4yNTYtLjg0IDMuNjc2LS44NCAxLjQ2NSAwIDIuNzYyLjMxMiAzLjc0Ljg2My45NzYuNTYyIDIuMzQuOTMgMy44MjguOTN2LTIuNTI0Yy0xLjQ4OSAwLTIuODUyLS4zODctMy44MjktLjk1My0uOTc3LS41NDctMi4yNzQtLjg1MS0zLjczOS0uODUxLTEuNDIgMC0yLjcxLjMxNS0zLjY3Ni44MzItLjk3OC41NjYtMi4zMTkuOTUtMy44MDkuOTUtMS40NzEgMC0yLjgyNC0uMzUzLTMuOC0uOTA4LS45NzQtLjU0OC0yLjMyNi0uODc0LTMuNzg3LS44NzQtMS40NTMgMC0yLjc3MS4zMjYtMy43NDYuODctLjk4Mi41NjctMi4zMDcuOTExLTMuOC45MTF6Ii8+PHBhdGggZmlsbD0iIzAwNDVhZiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNzM1LjgzMyA4OTYuMTMyYzcuMzM0IDAgMTMuNzY3LTEuNTU3IDE4LjU4Ni00LjEwNSA0Ljc4NS0yLjQ2NyAxMS4yNTYtMy45NyAxOC4zODktMy45NyA3LjE1NiAwIDEzLjgxIDEuNTE4IDE4LjU5IDMuOTg0IDQuNzggMi41IDExLjQxNSA0LjA5MSAxOC42NTggNC4wOTEgNy4zMTQgMCAxMy44NzctMS43NDMgMTguNjk1LTQuMjkyIDQuNzQzLTIuMzQ3IDExLjA3NS0zLjc4NCAxOC4wNS0zLjc4NCA3LjE5IDAgMTMuNTU2IDEuNDA0IDE4LjM1NSAzLjg4NSA0Ljc5NSAyLjUzNCAxMS40ODcgNC4xOTEgMTguNzk3IDQuMTkxdi0xMS4zNzFjLTcuMzEgMC0xNC4wMDItMS43NC0xOC43OTctNC4yOTItNC44LTIuNDYyLTExLjE2Ni0zLjgzMi0xOC4zNTYtMy44MzItNi45NzQgMC0xMy4zMDYgMS40MTgtMTguMDQ5IDMuNzUtNC44IDIuNTQ5LTExLjM4IDQuMjczLTE4LjY5NSA0LjI3My03LjIyNCAwLTEzLjg2My0xLjU4Ni0xOC42NTgtNC4wODYtNC43OC0yLjQ2Ny0xMS40MTUtMy45MzctMTguNTktMy45MzctNy4xMzMgMC0xMy42MDQgMS40Ny0xOC4zOSAzLjkxOC00LjgxOCAyLjU1My0xMS4zMjMgNC4xMDUtMTguNjU3IDQuMTA1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMTcwLjQxOCAyMjAuNTUxcy0uNDk1IDAtLjc2Ny0uMTY5Yy0uMjcyLS4xNzItMS4wOTQtMS4wMi0xLjA5NC0xLjAybC0uNjU3LS41MS0uNi0uOTA0cy0uNzEyLTEuMjM3LS4zODUtMi4yMDJjLjMyNy0uOTYuODc1LTEuMzAyIDEuMzctMS41ODMuNDk0LS4yODIgMS41My0uNjIyIDEuNTMtLjYyMnMuODI1LS4zOTQgMS4wOTctLjQ1NGMuMjcyLS4wNTYgMS4yNi0uMzM4IDEuMjYtLjMzOHMuMjc0LS4xNjguNTQ2LS4yOGMuMjc2LS4xMTQuNjU4LS4xMTQuODgtLjE3My4yMTctLjA1Ni43NjYtLjI0OCAxLjA5My0uMjY3LjUwOC0uMDIyIDEuMzE1LjA5OCAxLjU5MS4wOTguMjczIDAgMS4yMDQuMDYgMS41ODUuMDZzMS43NS0uMTE3IDIuMTM2LS4xMTdjLjM4MSAwIC42NTgtLjA1MiAxLjA5OCAwIC40MzYuMDU3IDEuMjAyLjMzOCAxLjQyMy40NTUuMjE5LjExMiAxLjUzNC42MjIgMi4wMjUuNzkuNDk0LjE2NiAxLjcuMzk0IDIuMjUuNjc2LjU0NC4yODUuODc4Ljc2MiAxLjE1IDEuMTU5LjI3Ny4zOTQuMzI4LjgyNS40MzcgMS4xMS4xMDUuMjgyLjExLjg4OS4wMDQgMS4xNy0uMTEuMjgyLS40OTguODYzLS40OTguODYzbC0uNjA0IDEuMDcyLS43NjYuNjc2cy0uNTUuNTctLjk4NC41MWMtLjQ0LS4wNDktNC44NzctLjkwNC03LjcyNi0uOTA0cy03LjM5OC45MDQtNy4zOTguOTA0Ii8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBkPSJNNjQuMzI1IDMyMi43NDdzLTIuNDI4IDAtMy43NjUtLjc2MWMtMS4zMzYtLjc3Ni01LjM3LTQuNTk0LTUuMzctNC41OTRsLTMuMjI4LTIuMy0yLjk0MS00LjA3cy0zLjQ5Ny01LjU3Mi0xLjg5Mi05LjkxNmMxLjYwNC00LjMyNiA0LjI5Ni01Ljg2MyA2LjcyNS03LjEyOCAyLjQyNC0xLjI3IDcuNTEtMi44MDIgNy41MS0yLjgwMnM0LjA0OS0xLjc3NyA1LjM4NS0yLjA0NWMxLjMzNi0uMjU0IDYuMTg5LTEuNTI0IDYuMTg5LTEuNTI0czEuMzQxLS43NTcgMi42NzctMS4yNjRjMS4zNTYtLjUwOCAzLjIyOS0uNTA4IDQuMzE2LS43NzYgMS4wNjktLjI1NCAzLjc2NS0xLjExNiA1LjM3LTEuMjAzIDIuNDk2LS4xIDYuNDU3LjQ0MSA3LjgxMy40NDEgMS4zMzYgMCA1LjkwNi4yNjggNy43NzkuMjY4czguNTkzLS41MjIgMTAuNDg1LS41MjJjMS44NzMgMCAzLjIyOS0uMjM0IDUuMzkgMCAyLjE0LjI1NCA1LjkgMS41MTkgNi45ODggMi4wNDYgMS4wNzMuNTA3IDcuNTMgMi44MDIgOS45NCAzLjU2MyAyLjQyMy43NDMgOC4zNDQgMS43NzMgMTEuMDQgMy4wNDIgMi42NzMgMS4yODQgNC4zMTYgMy40MyA1LjY1MyA1LjIxNyAxLjM1NiAxLjc3NyAxLjYwNSAzLjcxNyAyLjE0MSA1IC41MTcgMS4yNy41MzcgNC4wMDUuMDIgNS4yNzQtLjU0MiAxLjI2NS0yLjQ0NCAzLjg4NS0yLjQ0NCAzLjg4NWwtMi45NjUgNC44MjgtMy43NiAzLjA0MnMtMi42OTcgMi41NjctNC44MzMgMi4zYy0yLjE2LS4yMjEtMjMuOTQxLTQuMDcyLTM3LjkyNC00LjA3Mi0xMy45ODcgMC0zNi4zMTggNC4wNzEtMzYuMzE4IDQuMDcxeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJNOTQuMjQgMjkxLjU0NWMwLTYuNTcyIDIuOTQtMTEuODc1IDYuNTYyLTExLjg3NSAzLjYyMSAwIDYuNTYyIDUuMzAzIDYuNTYyIDExLjg3NSAwIDYuNTM4LTIuOTQgMTEuODYtNi41NjIgMTEuODZzLTYuNTYzLTUuMzIyLTYuNTYzLTExLjg2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNOTcuOTEzIDI5MS41NDVjMC02LjA0NSAxLjM1Ni0xMC45NDYgMy4wMTMtMTAuOTQ2IDEuNjc3IDAgMy4wMTMgNC45IDMuMDEzIDEwLjk0NiAwIDUuOTk3LTEuMzM2IDEwLjg5Ny0zLjAxMyAxMC44OTctMS42NTcgMC0zLjAxMy00LjktMy4wMTMtMTAuODk3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNMTAwLjkwNyAzMjEuOTg2SDc4LjA0bC0uNTMxLTUuNjEtMS4wNzMtNS44NDMtMS4xNC03LjI5NmMtNi4zLTguMzE1LTEyLjA5Ni0xMy43NzEtMTQuMDQtMTIuNjAyLjQ2NC0xLjUzOCAxLjAxNS0yLjY4OCAyLjIzMi0zLjM5NyA1LjYtMy4zMjkgMTcuMTU4IDQuNjYxIDI1Ljg0NyAxNy43ODYuNzgxIDEuMjAyIDEuNTMzIDIuNCAyLjE5NCAzLjYwMmgxOC44ODhhODMgODMgMCAwIDEgMi4yMTMtMy42MDJjOC42Ny0xMy4xMjUgMjAuMjQzLTIxLjExNSAyNS44MjgtMTcuNzg2IDEuMjEyLjcxIDEuNzY3IDEuODU5IDIuMjQ2IDMuMzk3LTEuOTU5LTEuMTUtNy43NCA0LjI4Ny0xNC4wNzMgMTIuNjAybC0xLjEyNiA3LjI5Ni0xLjA2OCA1Ljg0My0uNTIyIDUuNjF6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSJub25lIiBkPSJNNjIuMjU2IDI5MC40MTRjNC4yOTctMi41MzQgMTQuMzQxIDUuNDIzIDIyLjQ5IDE3Ljc4Nm01NC45NDItMTcuNzg2Yy00LjMxNi0yLjUzNC0xNC4zNDIgNS40MjMtMjIuNDk0IDE3Ljc4NiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTE3MC45NTggMjIyLjY3NGMtLjE5Ni0uNjA0LS41NjQtMS4xNDQtLjU2NC0xLjE0NCAxLjg4Ny0uNjA0IDQuNTE0LS45ODMgNy40MzUtLjk5IDIuOTIyLjAwNyA1LjU2Ny4zODYgNy40NTMuOTkgMCAwLS4yMS40MDUtLjUwNS45NjgtLjE2My4zMTEtLjM3OC44NTUtLjM2My44NTUtMS43MDUtLjU3LTMuOS0uODYzLTYuNTk1LS44NjYtMi43LjAwMy01LjI5NS4zNjQtNi42NDcuOTAzLjAyIDAtLjA5NC0uMzQtLjIyOC0uNzE2eiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgZD0iTTY2Ljk3NyAzMzIuMzA4Yy0uOTYzLTIuNzItMi43NjktNS4xNTQtMi43NjktNS4xNTQgOS4yNjQtMi43MiAyMi4xNTktNC40MjYgMzYuNS00LjQ2IDE0LjM0Mi4wMzQgMjcuMzI4IDEuNzQgMzYuNTg3IDQuNDYgMCAwLTEuMDM0IDEuODI1LTIuNDggNC4zNTktLjU5Ni45Ni0uNzMzIDEuNDE1LTEuNzgzIDMuODUxLTguMzY4LTIuNTY3LTE5LjE0MS0zLjg4NS0zMi4zNzYtMy44OTktMTMuMjU0LjAxNS0yNS45OTEgMS42MzgtMzIuNjMgNC4wNjcuMDk2IDAtLjQ2LTEuNTMzLTEuMTIxLTMuMjI0aC4wNzIiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTE3Ny44MyAyMjUuMjg4YzIuMzU3LS4wMDQgNC45NTItLjM5MyA1LjkxMi0uNjYzLjYzOS0uMjAzIDEuMDE0LS41MTguOTQ0LS44ODItLjAzMi0uMTcyLS4xNy0uMzIyLS4zNTctLjQwOC0xLjQwNi0uNDkyLTMuOTQxLS44NC02LjUtLjg0NS0yLjU1My4wMDQtNS4xLjM1My02LjUxMi44NDUtLjE4LjA4Ni0uMzIzLjIzNi0uMzUyLjQwOC0uMDcyLjM2NC4zMDMuNjc5Ljk0Ni44ODIuOTU2LjI3IDMuNTYzLjY2IDUuOTE5LjY2MyIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZT0iIzAwMCIgZD0iTTEwMC43MDkgMzQ0LjA4MmMxMS41NzItLjAxOSAyNC4zMTQtMS43NzIgMjkuMDIzLTIuOTg5IDMuMTM3LS45MTUgNC45NzctMi4zMzMgNC42MzctMy45Ny0uMTU4LS43NzctLjgzOS0xLjQ1Mi0xLjc1NC0xLjg0LTYuOTAyLTIuMjEzLTE5LjM0Ny0zLjc4NC0zMS45MDYtMy44MDQtMTIuNTM2LjAyLTI1LjA0MyAxLjU5LTMxLjk3IDMuODA0LS44ODYuMzg4LTEuNTg1IDEuMDYzLTEuNzI5IDEuODQtLjM1NCAxLjYzNyAxLjQ4NSAzLjA1NSA0LjY0MiAzLjk3IDQuNjk0IDEuMjE3IDE3LjQ5MyAyLjk3IDI5LjA1NyAyLjk4OXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0ibTE4NS4zOTcgMjIwLjM4Mi0uNTcyLS41NjZzLS41NS4zNjctMS4yMzUuMjU1Yy0uNjg0LS4xMTItLjkwMi0xLjAxNi0uOTAyLTEuMDE2cy0uNzcuNy0xLjM5NS42NDhjLS42MjktLjA2LTEuMDQtLjY0OC0xLjA0LS42NDhzLS42ODcuNTMyLTEuMjkuNDhjLS42MDMtLjA2LTEuMTc3LS44NzgtMS4xNzctLjg3OHMtLjYwMi44NDgtMS4yMDYuOTA3Yy0uNjAzLjA1NC0xLjA5NC0uNTctMS4wOTQtLjU3cy0uMjc2LjYyMy0xLjA0My43NjJjLS43NjYuMTQyLTEuNDI0LS42NS0xLjQyNC0uNjVzLS40MzIuNzY2LS45NTYuOTY1Yy0uNTIuMTk4LTEuMjAyLS4yODYtMS4yMDItLjI4NnMtLjExLjI4Ni0uMTkzLjQ1NWMtLjA4NC4xNjktLjMwMi4xOTgtLjMwMi4xOThsLjE3Mi41MDdjMS44NzYtLjU5MyA0LjQyMi0uOTYgNy4zLS45NjQgMi44OC4wMDMgNS40OTYuMzcxIDcuMzcxLjk2OGwuMTk0LS41NjciLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIGQ9Im0xMzcuODYgMzIxLjk4Ni0yLjgxMS0yLjU0OXMtMi42OTcgMS42NTMtNi4wNjQgMS4xNDVjLTMuMzU0LS41MDMtNC40MjYtNC41NzQtNC40MjYtNC41NzRzLTMuNzggMy4xNTYtNi44NSAyLjkyMWMtMy4wODUtLjI3My01LjEwMi0yLjkyMS01LjEwMi0yLjkyMXMtMy4zNzIgMi4zOTUtNi4zMzIgMi4xNmMtMi45Ni0uMjY4LTUuNzgyLTMuOTUyLTUuNzgyLTMuOTUycy0yLjk1NSAzLjgxOC01LjkyIDQuMDg2Yy0yLjk2LjI0LTUuMzctMi41NjctNS4zNy0yLjU2N3MtMS4zNTYgMi44MDYtNS4xMiAzLjQzYy0zLjc2MS42NDEtNi45OS0yLjkyMy02Ljk5LTIuOTIzcy0yLjEyMiAzLjQ0NC00LjY5NCA0LjM0Yy0yLjU0OC44OTYtNS45MDEtMS4yODQtNS45MDEtMS4yODRzLS41MzcgMS4yODQtLjk0NCAyLjA0NmMtLjQxMi43NjEtMS40ODUuODk1LTEuNDg1Ljg5NWwuODQzIDIuMjhjOS4yMTItMi42NjggMjEuNzA5LTQuMzI1IDM1LjgzNS00LjM0IDE0LjE0NS4wMTUgMjYuOTgzIDEuNjcyIDM2LjE5IDQuMzZsLjk0OC0yLjU1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBkPSJtMTAwLjc4IDMwOS42NyAxLjMzNy4yNGMtLjIxLjU1NS0uMjU0IDEuMTQ1LS4yNTQgMS43NzIgMCAyLjc2OSAyLjM4IDUuMDE1IDUuMzAyIDUuMDE1IDIuMzU3IDAgNC4zNTUtMS40NTEgNS4wMzUtMy40NjMuMDgxLjA1My41MTItMS44MjUuNzIzLTEuNzkxLjIwMSAwIC4xNjggMS45NDQuMjE2IDEuOTEuMzU0IDIuNTE2IDIuNjUzIDQuMjQgNS4yNjQgNC4yNCAyLjkyMiAwIDUuMjkzLTIuMjQ2IDUuMjkzLTUuMDE1cS4wMDEtLjMwOC0uMDUtLjYwOGwxLjY3Ny0xLjY1OC44ODYgMi4xMTNjLS4zNTUuNjQxLS40OTggMS4zODQtLjQ5OCAyLjE4IDAgMi42NTMgMi4yNyA0Ljc5OSA1LjA1MyA0Ljc5OSAxLjc2OCAwIDMuMzItLjg2MyA0LjIxLTIuMTQ2bDEuMDY5LTEuMzUxLS4wMiAxLjY3MmMwIDEuNjUyLjcxOCAzLjE0MiAyLjMzMyAzLjQxIDAgMCAxLjg3My4xMzQgNC4zNC0xLjgyNSAyLjQ4LTEuOTQgMy44MzYtMy41NjQgMy44MzYtMy41NjRsLjE0NCAxLjk5M3MtMi40MzMgMy45ODUtNC42MjIgNS4yNTVjLTEuMjEyLjcwOS0zLjA1NyAxLjQ1MS00LjUxMyAxLjE5Ny0xLjU1Ny0uMjM0LTIuNjQtMS40ODUtMy4yMTQtMi45MDNhNy40IDcuNCAwIDAgMS0zLjc5OCAxLjAzYy0yLjk5NCAwLTUuNjg2LTEuNjU3LTYuNzQtNC4xMDUtMS4zOCAxLjQ4NS0zLjMgMi4zOC01LjU1MiAyLjM4LTIuMzg1IDAtNC41OC0xLjA2Mi01Ljk1OS0yLjczNC0xLjM1IDEuMjUtMy4xODUgMi4wMTItNS4yMDcgMi4wMTItMi42MzQgMC01LjAxLTEuMzIyLTYuMzQ2LTMuMjYyLTEuMzQyIDEuOTQtMy42OCAzLjI2Mi02LjMzOCAzLjI2MmE3LjY0IDcuNjQgMCAwIDEtNS4yMDItMi4wMTJjLTEuMzc1IDEuNjcyLTMuNTUgMi43MzUtNS45NTkgMi43MzUtMi4yNDYgMC00LjE1OC0uODk2LTUuNTI4LTIuMzgtMS4wNTggMi40MzMtMy43NjUgNC4xMDQtNi43NDQgNC4xMDRhNy40IDcuNCAwIDAgMS0zLjc4NC0xLjAzYy0uNTcgMS40MTgtMS42NzIgMi42NjktMy4yMSAyLjkwMy0xLjQ2LjI1NC0zLjMtLjQ4OC00LjUxMi0xLjE5Ny0yLjIxMy0xLjI3LTQuODMzLTUuMjU1LTQuODMzLTUuMjU1bC4zNC0xLjk5M3MxLjM1IDEuNjI0IDMuODE4IDMuNTY0YzIuNDc2IDEuOTYgNC4zNSAxLjgyNSA0LjM1IDEuODI1IDEuNjIzLS4yNjggMi4zMTMtMS43NTggMi4zMTMtMy40MXYtMS42NzJsMS4wNTggMS4zNWE1LjE2IDUuMTYgMCAwIDAgNC4yMDYgMi4xNDdjMi44MDcgMCA1LjA2OC0yLjE0NiA1LjA2OC00LjggMC0uNzk1LS4xNDMtMS41MzgtLjQ5OC0yLjE4bC44OTEtMi4xMTIgMS42NTcgMS42NThjLS4wMzUuMi0uMDM1LjQwMi0uMDM1LjYwOCAwIDIuNzY5IDIuMzU3IDUuMDE1IDUuMjU1IDUuMDE1IDIuNjMgMCA0LjkzLTEuNzI0IDUuMjctNC4yNC4wNzEuMDM0LjA1LTEuOTEuMjMtMS45MS4yMzQtLjAzNC42NiAxLjg0NC43MzIgMS43OTEuNjk1IDIuMDEyIDIuNjkyIDMuNDYzIDUuMDQ0IDMuNDYzIDIuOTMyIDAgNS4zMDMtMi4yNDYgNS4zMDMtNS4wMTUgMC0uNjI3LS4wMzUtMS4yMTctLjI1LTEuNzcybDEuMzc1LS4yNGguMDM1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYzhiMTAwIiBkPSJNMTc3LjgzIDIyMC41NDRjLTIuOTIyLjAwMy01LjU0Ni4zODItNy40My45OS0uMTI4LjA0NS0uMjgyLS4wNi0uMzI0LS4xODQtLjA0LS4xMy4wNTEtLjI5My4xNzMtLjMzNyAxLjg5OC0uNjMgNC41ODctMS4wMjkgNy41OC0xLjAzMiAyLjk5MS4wMDMgNS42OTQuNDAxIDcuNTg4IDEuMDMyLjEyNi4wNDQuMjE4LjIwNi4xNzguMzM3LS4wNC4xMjMtLjIuMjI5LS4zMjMuMTg0LTEuODg3LS42MDgtNC41MjEtLjk4Ny03LjQ0Mi0uOTkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIGQ9Ik0xMDAuNzA5IDMyMi43MTRjLTE0LjM0Mi4wMTQtMjcuMjIzIDEuNzItMzYuNDc3IDQuNDYtLjYyMy4yLTEuMzgtLjI3NC0xLjU4Ni0uODMtLjItLjU4OS4yNS0xLjMxNy44NDgtMS41MTggOS4zMTctMi44NCAyMi41MTktNC42MzIgMzcuMjE1LTQuNjQ2IDE0LjY4MS4wMTQgMjcuOTUgMS44MDYgMzcuMjQ3IDQuNjQ2LjYxOC4yMDEgMS4wNjkuOTMuODcyIDEuNTE4LS4xOTYuNTU2LS45ODIgMS4wMy0xLjU4NS44My05LjI2LTIuNzQtMjIuMTkzLTQuNDQ2LTM2LjUzNC00LjQ2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMTc1LjAwMyAyMjEuNjcyYzAtLjI0LjE5LS40MzUuNDI1LS40MzVhLjQzLjQzIDAgMCAxIC40MjIuNDM1YzAgLjI0NC0uMTkuNDM1LS40MjIuNDM1YS40MjcuNDI3IDAgMCAxLS40MjUtLjQzNSIvPjxwYXRoIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0iIzAwMCIgZD0iTTg2LjgzMiAzMjcuNzk2YzAtMS4wNzguOTI5LTEuOTYgMi4wODgtMS45NiAxLjE0IDAgMi4wNy44ODIgMi4wNyAxLjk2IDAgMS4wOTctLjkzIDEuOTU5LTIuMDcgMS45NTktMS4xNTkgMC0yLjA4OC0uODYyLTIuMDg4LTEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjZTExMjYiIGQ9Ik0xNzcuODY2IDIyMS44NmgtLjk0MWEuMzMuMzMgMCAwIDEtLjMyLS4zMy4zMi4zMiAwIDAgMSAuMzE2LS4zMjJoMS45Yy4xNzYgMCAuMzEyLjE0NS4zMTIuMzIyIDAgLjE4LS4xNC4zMy0uMzE1LjMzeiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgZD0iTTEwMC44ODYgMzI4LjY0NGgtNC42MThjLS44NTcgMC0xLjU3MS0uNjc2LTEuNTcxLTEuNDkgMC0uNzk1LjY5NS0xLjQ1MSAxLjU1Mi0xLjQ1MWg5LjMzMWMuODU4IDAgMS41MjguNjU2IDEuNTI4IDEuNDUxIDAgLjgxNC0uNjkgMS40OS0xLjU0NyAxLjQ5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA2ZjQ2IiBkPSJtMTczLjE1OCAyMjIuMjEzLS42NzMuMTA4YS4zMi4zMiAwIDAgMS0uMzY0LS4yNzMuMzIuMzIgMCAwIDEgLjI2Mi0uMzY4bC42NzUtLjEwOS42OS0uMTE2YS4zMi4zMiAwIDAgMSAuMzYxLjI3LjMzLjMzIDAgMCAxLS4yNjUuMzcyeiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgZD0ibTc3Ljc3NCAzMzAuMjMtMy4zLjQ4OGMtLjg0OS4xMi0xLjY0NC0uNDIyLTEuNzg3LTEuMjMxLS4xMjUtLjc5NS40NC0xLjUzOCAxLjI4My0xLjY1OGwzLjMxNS0uNDg4IDMuMzg3LS41MjJjLjg0Ny0uMSAxLjYyOC40MjEgMS43NzIgMS4yMTYuMTI0Ljc5LS40NjUgMS41NTItMS4zMDMgMS42NzJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjZTExMjYiIGQ9Im0xNzAuNDQyIDIyMi43MjYuMjk5LS41MjQuNjQuMTMtLjM3Mi41OXoiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIGQ9Im02NC40NDMgMzMyLjU0MyAxLjQ2Ni0yLjM2MiAzLjE0Mi41OS0xLjgyNSAyLjY1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTE3OS44MTQgMjIxLjY3MmMwLS4yNC4xOTItLjQzNS40MjUtLjQzNXMuNDI1LjE5Ni40MjUuNDM1YS40My40MyAwIDAgMS0uNDI1LjQzNS40My40MyAwIDAgMS0uNDI1LS40MzUiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBzdHJva2U9IiMwMDAiIGQ9Ik0xMTAuNDUyIDMyNy43OTZjMC0xLjA3OC45NDMtMS45NiAyLjA4My0xLjk2IDEuMTQ1IDAgMi4wODkuODgyIDIuMDg5IDEuOTYgMCAxLjA5Ny0uOTQ0IDEuOTU5LTIuMDg5IDEuOTU5LTEuMTQgMC0yLjA4My0uODYyLTIuMDgzLTEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiMwMDZmNDYiIGQ9Im0xODIuNTA2IDIyMi4yMTMuNjc3LjEwOGMuMTcuMDI3LjMzLS4wOTQuMzU5LS4yNzNhLjMyLjMyIDAgMCAwLS4yNTgtLjM2OGwtLjY3Ni0uMTA5LS42OS0uMTE2YS4zMi4zMiAwIDAgMC0uMzYuMjcuMzI1LjMyNSAwIDAgMCAuMjY1LjM3MnoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIGQ9Im0xMjMuNjY4IDMzMC4yMyAzLjMyLjQ4OGMuODM3LjEyIDEuNjE4LS40MjIgMS43NjItMS4yMzEuMTItLjc5NS0uNDI3LTEuNTM4LTEuMjY1LTEuNjU4bC0zLjMyLS40ODgtMy4zODYtLjUyMmMtLjg1Ny0uMS0xLjY0My40MjEtMS43NjcgMS4yMTYtLjE0NC43OS40NjQgMS41NTIgMS4zMDIgMS42NzJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjZTExMjYiIGQ9Im0xODUuMTY2IDIyMi43NTYtLjI0LS41NTgtLjY1NS4wNi4zMTQuNjI2eiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgZD0ibTEzNi42MTUgMzMyLjUyMi0xLjA2OC0yLjM2LTMuMjE5LjI2OCAxLjU0MiAyLjgyMmMuOTc3LS4yMTkgMS45MTctLjU0IDIuNzQ1LS43M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2NlMTEyNiIgZD0iTTE3Ny44MjYgMjI0LjY5MmMtMi4zNTgtLjAwNC00LjQ5LS4yMjktNi4xMTUtLjY4NiAxLjYyNC0uNDU0IDMuNzU3LS43MzUgNi4xMTUtLjc0MyAyLjM1OC4wMDQgNC41MDIuMjg1IDYuMTIyLjc0My0xLjYyLjQ1Ny0zLjc2NC42ODItNi4xMjIuNjg2Ii8+PHBhdGggZmlsbD0iI2I1MDAyNyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBkPSJNMTAwLjY5IDM0MS4zOTVjLTExLjU3My0uMDE1LTIyLjA0NS0xLjAzLTMwLjAyLTMuMDkgNy45NzUtMi4wNDUgMTguNDQ3LTMuMzEgMzAuMDItMy4zNDMgMTEuNTc3LjAxNCAyMi4xMDEgMS4yODQgMzAuMDUzIDMuMzQzLTcuOTUyIDIuMDYtMTguNDc2IDMuMDc1LTMwLjA1NCAzLjA5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYzhiMTAwIiBkPSJNMTg1LjI2IDIxOS4xMTljLjA2Mi0uMi4wMDgtLjM5NS0uMTI4LS40NDQtLjEzLS4wNC0uMjg2LjA4Ny0uMzQ3LjI3OC0uMDY1LjIwMy0uMDA4LjQwMi4xMjMuNDQ3LjEzLjA0LjI5LS4wODMuMzUzLS4yODEiLz48cGF0aCBmaWxsPSIjZTZlNmU2IiBzdHJva2U9IiMwMDAiIGQ9Ik0xMzcuMTkgMzE2LjI5NWMuMzAyLS44OTYuMDM1LTEuNzc3LS42MzItMS45OTgtLjY0Mi0uMTgyLTEuNDA0LjM5My0xLjcwNiAxLjI1LS4zMi45MTYtLjA0IDEuODExLjYwNCAyLjAxMy42NDIuMTg2IDEuNDI3LS4zNyAxLjczNC0xLjI2NXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTE4MC41NjYgMjE4LjEyOGMuMDI1LS4yMDYtLjA3LS4zOS0uMjA3LS40MS0uMTM1LS4wMTctLjI3LjE0LS4yOTEuMzQ3LS4wMjUuMjA2LjA2NS4zODkuMjA0LjQwOC4xMzguMDE1LjI2OC0uMTQyLjI5NC0uMzQ1Ii8+PHBhdGggZmlsbD0iI2U2ZTZlNiIgc3Ryb2tlPSIjMDAwIiBkPSJNMTE0LjE0IDMxMS44MzVjLjEyNS0uOTI5LS4zNC0xLjc1OC0xLjAxNS0xLjg0NC0uNjYyLS4wODEtMS4zMjMuNjI4LTEuNDI4IDEuNTU3LS4xMjQuOTMuMzIxIDEuNzUzIDEuMDAxIDEuODQuNjc2LjA2NiAxLjMxNy0uNjQyIDEuNDQyLTEuNTUzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYzhiMTAwIiBkPSJNMTc1LjExNiAyMTguMTI4Yy0uMDI1LS4yMDYuMDY0LS4zOS4yMDMtLjQxLjEzOC0uMDE3LjI2OC4xNC4yOTUuMzQ3LjAyLjIwNi0uMDcuMzg5LS4yMDQuNDA4LS4xMzguMDE1LS4yNy0uMTQyLS4yOTQtLjM0NSIvPjxwYXRoIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0iIzAwMCIgZD0iTTg3LjM4NyAzMTEuODM1Yy0uMTI0LS45MjkuMzE2LTEuNzU4Ljk5Ny0xLjg0NC42OC0uMDgxIDEuMzE3LjYyOCAxLjQ0NiAxLjU1Ny4xLjkzLS4zNCAxLjc1My0xIDEuODQtLjY3Ni4wNjYtMS4zMjMtLjY0Mi0xLjQ0My0xLjU1M3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTE3MC40MiAyMTkuMTE5Yy0uMDY1LS4yLS4wMDctLjM5NS4xMjUtLjQ0NC4xMy0uMDQuMjkuMDg3LjM1Mi4yNzguMDYxLjIwMy4wMDcuNDAyLS4xMjMuNDQ3LS4xMzUuMDQtLjI5Mi0uMDgzLS4zNTMtLjI4MSIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iI2U2ZTZlNiIgZD0iTTY0LjMzNyAzMTYuMjk1Yy0uMzItLjg5Ni0uMDM1LTEuNzc3LjYwOS0xLjk5OC42MzctLjE4MiAxLjQyMi4zOTMgMS43MjkgMS4yNS4zMDIuOTE2LjAzNSAxLjgxMS0uNjA0IDIuMDEzLS42Ni4xODYtMS40MzItLjM3LTEuNzM0LTEuMjY1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJtMTAwLjY5IDI5OC41MjQtNC4wODIgMi40NjIgMy4wMjggNi41NzIgMS4wNTMuNjk0IDEuMDQtLjY5NCAzLjA0Ni02LjU3MmMtMS4zNjItLjgyLTIuNzEtMS42NjQtNC4wODYtMi40NjJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im05MS43MzIgMzA4LjQ1NCAxLjg2MyAyLjcwNiA2LjM2Ni0xLjk2NC42NzYtLjg5LS42NzYtLjkxNi02LjM2Ni0xLjg1OGE0NSA0NSAwIDAgMC0xLjg2MyAyLjkyMnptMTcuOTQ4IDAtMS44NzIgMi43MDYtNi4zNjctMS45NjQtLjY3NS0uODkuNjc1LS45MTYgNi4zNjctMS44NThjLjY1NC45NTQgMS4yNjMgMS45MzggMS44NzIgMi45MjJ6bS0zNS41NTYtNy4wMDgtMy4yIDMuMDIyIDQuMSA1LjQwOCAxLjA4Ny40MzYuODA1LS44MjggMS40NDItNi41MzRhMjAzIDIwMyAwIDAgMC00LjIzNC0xLjUwNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0ibTY3LjQwOCAzMTIuMjkgMi40MDQgMi4yNjEgNS44MTYtMy4xNDIuNDQ1LTEuMDEtLjgzMy0uNzYyLTYuNjU0LS41NzVjLS40NDQgMS4wNTctLjgwNSAyLjE0NS0xLjE3OCAzLjIyOHptMTcuNTUxLTMuNTMtMS4yMzEgMi45OS02LjY1OS0uNjEtLjg2Ny0uNzYuNDYtMS4wMyA1LjgzNS0zLjA3NmMuODQ2LjgwMyAxLjY1MSAxLjY0NyAyLjQ2MiAyLjQ4NnptLTIzLjk1NiA0LjM3NC0uNTUgMy4xNi02LjY2My42OS0xLjAxMS0uNTc0LjI1NC0xLjA3OCA1LjAwNi00LjE1OGMuOTY0LjY5IDEuOTY1IDEuMzIzIDIuOTY0IDEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48L2c+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTE3Mi4zNTQgMjE3LjgxM2MwLS4yNzQuMjE0LS40OTUuNDc2LS40OTUuMjY1IDAgLjQ3Ni4yMjEuNDc2LjQ5NSAwIC4yNy0uMjEuNDkxLS40NzYuNDkxYS40ODUuNDg1IDAgMCAxLS40NzYtLjQ5MSIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTczLjgzMSAzMTAuNDEzYzAtMS4yMzEgMS4wNS0yLjIyOCAyLjMzMy0yLjIyOCAxLjMwMyAwIDIuMzM4Ljk5NyAyLjMzOCAyLjIyOCAwIDEuMjE2LTEuMDM1IDIuMjEzLTIuMzM4IDIuMjEzLTEuMjg0IDAtMi4zMzMtLjk5Ny0yLjMzMy0yLjIxM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggZD0ibTEyNy4zNDIgMzAxLjQ0NiAzLjIwOSAzLjAyMi00LjEwNSA1LjQwOC0xLjA4OC40MzYtLjgtLjgyOC0xLjQ0Ni02LjUzNGE4MyA4MyAwIDAgMCA0LjIzLTEuNTA0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJtMTM0LjA2NyAzMTIuMjktMi40MSAyLjI2MS01LjgxNS0zLjE0Mi0uNDY0LTEuMDEuODU3LS43NjIgNi42NTQtLjU3NWMuNDYzIDEuMDcyLjc5NCAyLjEyOSAxLjE3OCAzLjIyOHptLTE3LjU1Ni0zLjUzIDEuMjMxIDIuOTkgNi42NTgtLjYxLjg1My0uNzYtLjQ0NS0xLjAzLTUuODMtMy4wNzZjLS44MS44NDEtMS42MzcgMS42NjUtMi40NjcgMi40ODZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48L2c+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0ibTE4NS43NDcgMjE4LjQxNy4xMS43MDEgMS4zNTQuMTU0LjIwMy0uMTI4LS4wNS0uMjQtMS4wMTctLjkyMnoiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIGQ9Im0xMzkuNTc1IDMxMy4xMzQuNTM3IDMuMTYgNi42NDkuNjkgMS0uNTc0LS4yNDgtMS4wNzgtNC45OTItNC4xNThjLS45ODguNjQ0LTEuOTc2IDEuMjg4LTIuOTQ2IDEuOTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0xNzcuMzU3IDIxNy4zNDhhLjQ4LjQ4IDAgMCAxIC40NzYtLjQ5NWMuMjU4IDAgLjQ3Ny4yMTcuNDc3LjQ5NSAwIC4yNy0uMjE2LjQ5MS0uNDc3LjQ5MWEuNDgzLjQ4MyAwIDAgMS0uNDc2LS40OTEiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIGQ9Ik05OC4zOSAzMDguMzJjMC0xLjI1IDEuMDMtMi4yMjggMi4zMzgtMi4yMjggMS4yNjQgMCAyLjMzNy45NzcgMi4zMzcgMi4yMjggMCAxLjIxNi0xLjA1OCAyLjIxMy0yLjMzNyAyLjIxMy0xLjMwOCAwLTIuMzM4LS45OTctMi4zMzgtMi4yMTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0xODIuMzcyIDIxNy44MTNjMC0uMjc0LjIxNC0uNDk1LjQ3Ni0uNDk1LjI2NCAwIC40OC4yMjEuNDguNDk1IDAgLjI3LS4yMTYuNDkxLS40OC40OTFhLjQ4NS40ODUgMCAwIDEtLjQ3Ni0uNDkxIi8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNMTIzLjAwNyAzMTAuNDEzYzAtMS4yMzEgMS4wNDktMi4yMjggMi4zMzctMi4yMjggMS4yOTggMCAyLjM1Ny45OTcgMi4zNTcgMi4yMjggMCAxLjIxNi0xLjA1OSAyLjIxMy0yLjM1NyAyLjIxMy0xLjI4OCAwLTIuMzM3LS45OTctMi4zMzctMi4yMTN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik01MS43NzcgMzE2LjUzYTIzLjQgMjMuNCAwIDAgMC0yLjkwMi0zLjE3NmMtLjkzLS44MjktMy4yMS0xLjUzOC0zLjIxLTEuNTM4IDAtLjQyMSAxLjMzNy0xLjM3IDIuNzg0LTEuMzcuODM4IDAgMS42MzguMzU1IDIuMTEyLjk0OWwuMTY4LS45MTVzMS4xNzguMjIgMS42OTUgMS41MjNjLjUzNyAxLjM1LjE5NyAzLjM5Ni4xOTcgMy4zOTYtLjE4Ni40MzItLjU3NC43NDYtLjg0NCAxLjEzMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTUyLjA4NCAzMTUuNjY3Yy41NTYtLjU3NCAxLjY5Ni0uNDU1IDIuNTM0LjI3NC44NTguNzIzIDEuMTA3IDEuNzg2LjU0NiAyLjM4LS41NDYuNTktMS42NzEuNDU1LTIuNTI0LS4yNzMtLjg2Mi0uNzIzLTEuMTA3LTEuODA2LS41NTYtMi4zOHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik0xODcuNTc3IDIxOS4yMzhjLjAxNS4wMTEuMzY3LS41MS42MzgtLjc3Mi4xODUtLjE4NC42NTMtLjM0Mi42NTMtLjM0MiAwLS4wOTMtLjI3Mi0uMzA0LS41NjctLjMwNGEuNTQuNTQgMCAwIDAtLjQzMi4yMWwtLjAzNi0uMjAycy0uMjQuMDQ4LS4zNDUuMzM4Yy0uMTA5LjMtLjA0MS43NTQtLjA0MS43NTRzLjA0NC4yMS4xMy4zMTgiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2U9IiMwMDAiIGQ9Ik0xNDguNTYyIDMxNi44MzFjLjA3Mi4wNTMgMS44LTIuMjk0IDMuMTI4LTMuNDc3LjkxLS44MjkgMy4yMDktMS41MzggMy4yMDktMS41MzggMC0uNDIxLTEuMzM2LTEuMzctMi43ODMtMS4zNy0uODM4IDAtMS42NDMuMzU1LTIuMTIyLjk0OWwtLjE3Ny0uOTE1cy0xLjE4My4yMi0xLjY5NiAxLjUyM2MtLjUzMSAxLjM1LS4yIDMuMzk2LS4yIDMuMzk2LS4wMi41OTIuMjQ3Ljc3Mi42NCAxLjQzMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2M4YjEwMCIgZD0iTTE4Ny41OSAyMTguOThjLS4xMTQtLjEyOC0uMzQ1LS4xMDItLjUyLjA2LS4xNzUuMTYtLjIyMS4zOTctLjExMy41MjguMTEzLjEzMS4zNDUuMTAyLjUxOS0uMDYuMTc1LS4xNi4yMjYtLjQwMS4xMTQtLjUyOSIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTE0OC42MjQgMzE1LjY2N2MtLjU2LS41NzQtMS42OTYtLjQ1NS0yLjU1My4yNzQtLjg1OC43MjMtMS4wODcgMS43ODYtLjU1NiAyLjM4LjU1Ni41OSAxLjY5Ni40NTUgMi41NDktLjI3My44NTctLjcyMyAxLjExLTEuODA2LjU2LTIuMzh6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiMwMDQ0YWQiIGQ9Ik0xMDIuNTAyIDI3MmMyLjQxNi42NTQgNC4xNzEgMi43ODUgNC4xNzEgNS4yOTYgMCAzLjA0Ni0yLjYwNyA1LjUxMy01Ljg1IDUuNTEzLTMuMjE4IDAtNS44MjUtMi40NjctNS44MjUtNS41MTMgMC0yLjU1NiAxLjgyNS00LjY4NiA0LjMxMS01LjM0MSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNMTA2Ljg2NCAyNzUuODV2Mi43NTRIOTQuODA3di0yLjc1NGg0LjQ2di02LjIxOEg5Ni4zMnYtMi43NjhoMi45NDZ2LTIuNzIxaDIuOTA3djIuNzJoMi45MDN2Mi43N2gtMi45MDN2Ni4yMTdoMy42NXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0ibm9uZSI+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMSIgZD0iTTEwMC4zNzYgMzQxLjQ0NHYtNi4wM20tMS42MzggNi4wM3YtNi4wMyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBzdHJva2Utd2lkdGg9Ii4yNSIgZD0iTTk3LjE5MiAzNDEuNDQ0di02LjAzbS0xLjUzMiA2LjAzdi02LjAzbS0xLjM2NiA2LjAzdi02LjAzbS0yLjYwNSA1LjcwNi0uMDM2LTUuNDltMS4yNyA1LjU2MnYtNS43NDIiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuNSIgZD0iTTg5LjI4NCAzNDAuODczdi01LjA1N20xLjIxOCA1LjIwMS0uMDM2LTUuMzgybS00LjQwOCA0Ljk0OHYtNC40NDJtMS4wNTkgNC41MTV2LTQuNjZtMS4wOSA0LjgwNXYtNC44NDEiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuNzUiIGQ9Ik04NC45MjcgMzQwLjU0N3YtNC4yOThtLTEuMDU0IDQuMzg3di00LjcwM20tMS4xMzEgNC41Njd2LTQuMzg3bS0yLjMxNSA0LjAwNy0uMDM2LTMuNzEybTEuMjIyIDMuOTM5di00LjEiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTc5LjI0IDM0MC4wMzN2LTMuMzVtLTEuMDg2IDMuMzg4di0zLjIxOW0tMS4xODcgMi41OTh2LTIuNDE4bS0xLjIxOSAyLjQ0di0yLjIwN20tMS4yOTEgMS45MTl2LTEuNjQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuMSIgZD0iTTEwNi44OTIgMzQxLjEydi01LjUyNW0tMi43NzQgNS43MDUuMDM2LTUuODVtLTIuMDU4IDUuOTIydi01Ljk1OCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PC9nPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik0xNjYuOTQ0IDIzMS4yOTJoMjEuNTk3di02LjE3aC0yMS41OTd6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNDcuMjcgMzcxLjEyM2gxMDYuMDI0di0yNy43OTJINDcuMjd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0xNjkuMjEgMjM1LjM5OWMuMTM1LS4wNi4yMzQtLjA2Ny40LS4wNjdoMTYuMTc0Yy4xNiAwIC4zMTIuMDMuNDM5LjA4NmExLjQ4IDEuNDggMCAwIDEtLjk1MS0xLjM5NWMwLS42NDUuNDMyLTEuMjA0Ljk5MS0xLjQxNGExLjYgMS42IDAgMCAxLS40NjguMDg2SDE2OS42MWMtLjE2NCAwLS4zMi0uMDA3LS40NTQtLjA1NmwuMDg3LjAxNWMuNTc3LjE5NC45MDguNzU0LjkwOCAxLjM2OSAwIC41OTItLjM2NyAxLjE4NS0uOTQxIDEuMzc2Ii8+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNTguMzk4IDM4OS42MThjLjY2LS4yNjkgMS4xNDQtLjMwMiAxLjk2NC0uMzAyaDc5LjM5NmMuNzg1IDAgMS41MzIuMTM0IDIuMTU1LjM4OC0yLjcxMS0uOTEtNC42Ny0zLjM3Ny00LjY3LTYuMjg1IDAtMi45MDIgMi4xMjItNS40MjIgNC44NjYtNi4zNjYtLjYyMi4yMDItMS41NTIuMzg4LTIuMjk5LjM4OEg2MC4zNjJjLS44MDUgMC0xLjU3Mi0uMDMzLTIuMjI4LS4yNTRsLjQyNi4wNjdjMi44MzYuODc3IDQuNDYgMy4zOTcgNC40NiA2LjE2NSAwIDIuNjY4LTEuODAxIDUuMzQxLTQuNjIyIDYuMTk5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNMTY5LjYxIDIzNS4zMzJoMTYuMTc0Yy41NDggMCAuOTkxLjM3MS45OTEuODI1IDAgLjQ1OC0uNDQzLjgyOS0uOTkuODI5SDE2OS42MWMtLjU0OSAwLS45OTMtLjM3MS0uOTkzLS44MjkgMC0uNDU0LjQ0NC0uODI1Ljk5My0uODI1Ii8+PHBhdGggc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNjAuMzYyIDM4OS4zMTZoNzkuMzk2YzIuNjkyIDAgNC44NjYgMS42NzIgNC44NjYgMy43MTcgMCAyLjA2LTIuMTc0IDMuNzMxLTQuODY2IDMuNzMxSDYwLjM2MmMtMi42OTIgMC00Ljg3Mi0xLjY3MS00Ljg3Mi0zLjczMSAwLTIuMDQ1IDIuMTgtMy43MTcgNC44NzItMy43MTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMTY5LjYxIDIzMS4yOTJoMTYuMTg1Yy41NDUgMCAuOTkyLjMxNS45OTIuNjk4IDAgLjM5LS40NDcuNzA1LS45OTIuNzA1SDE2OS42MWMtLjU0OSAwLS45OTMtLjMxNS0uOTkzLS43MDUgMC0uMzgzLjQ0NC0uNjk4Ljk5My0uNjk4Ii8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNjAuMzYyIDM3MS4xMjNoNzkuNDQ4YzIuNjc4IDAgNC44NzIgMS40MTggNC44NzIgMy4xNDMgMCAxLjc1My0yLjE5NCAzLjE3NS00Ljg3MiAzLjE3NUg2MC4zNjJjLTIuNjkyIDAtNC44NzItMS40MjItNC44NzItMy4xNzUgMC0xLjcyNSAyLjE4LTMuMTQzIDQuODcyLTMuMTQzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMTY5LjIxIDMyNC42ODNjLjA1Mi4yMTQuMTI1LjQyNC4xMjUuNjUzIDAgMS41NDUtMS4yMjUgMi43NzUtMi43MjIgMi43NzVoMjIuMjI3Yy0xLjQ5OCAwLTIuNzIyLTEuMjMtMi43MjItMi43NzUgMC0uMjI1LjA0LS40NC4wOTEtLjY1M2ExLjIgMS4yIDAgMCAxLS40MjUuMDU2SDE2OS42MWMtLjEzMSAwLS4yODMtLjAxNC0uNC0uMDU2Ii8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNTguMzk4IDc5MS43MzNjLjI1NC45NjMuNjA4IDEuOTExLjYwOCAyLjk0MSAwIDYuOTYtNi4wMTIgMTIuNDk3LTEzLjM2IDEyLjQ5N0gxNTQuNzZjLTcuMzUzIDAtMTMuMzY0LTUuNTM3LTEzLjM2NC0xMi40OTcgMC0xLjAxNS4xOTYtMS45NzguNDUtMi45NDEtLjYyOC4yMi0xLjM3NS4yNTQtMi4wODkuMjU0SDYwLjM2MmMtLjY0MiAwLTEuMzktLjA2Ny0xLjk2NC0uMjU0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMTY5LjYxIDMyMy4wODJoMTYuMTc0Yy41NDggMCAuOTkxLjM3NS45OTEuODI5IDAgLjQ1Ny0uNDQzLjgyOC0uOTkuODI4SDE2OS42MWMtLjU0OSAwLS45OTMtLjM3LS45OTMtLjgyOCAwLS40NTQuNDQ0LS44My45OTMtLjgzIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNNjAuMzYyIDc4NC41Mmg3OS4zOTZjMi42OTIgMCA0Ljg2NiAxLjY5IDQuODY2IDMuNzM1IDAgMi4wNi0yLjE3NCAzLjczMi00Ljg2NiAzLjczMkg2MC4zNjJjLTIuNjkyIDAtNC44NzItMS42NzItNC44NzItMy43MzIgMC0yLjA0NSAyLjE4LTMuNzM2IDQuODcyLTMuNzM2eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNMTY2LjY0MiAzMzQuMjc0aDIyLjE2OXYtNi4xNjNoLTIyLjE2OXoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik00NS43OSA4MzQuOTNoMTA4LjgyNnYtMjcuNzZINDUuNzl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjZTExMjYiIGQ9Ik0xNjQuOTA4IDMwMS4yN2MtMi4xOTQgMS4zODEtMy42OCAyLjc5NS0zLjQ0IDMuNS4xMi42NDkuODE4IDEuMTMzIDEuODEzIDEuODUzIDEuNTY2IDEuMTg5IDIuNTE4IDMuMzEyIDEuNzczIDQuMjkxYTYuMyA2LjMgMCAwIDAgMi4xMTgtNC43MzdjMC0xLjk4LS44NjQtMy43NjYtMi4yNjQtNC45MDYiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik0zNy4yNzggNjg2LjI5Yy0xMC43NzMgNi4yMTctMTguMDY4IDEyLjU4My0xNi44OSAxNS43NTkuNTkgMi45MjIgNC4wMTQgNS4xMDEgOC45IDguMzQ0IDcuNjg4IDUuMzU1IDEyLjM2MyAxNC45MTYgOC43MDQgMTkuMzI4IDYuMzctNS4xMzUgMTAuNC0xMi44MDQgMTAuNC0yMS4zMzUgMC04LjkxOS00LjI0NS0xNi45NjItMTEuMTE0LTIyLjA5NnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2IyYjJiMiIgZD0iTTE2OS44MTggMzIyLjA4NGgxNS43NTF2LTg0LjExOWgtMTUuNzUxeiIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTExNi40OTcgNDAxLjY5OHYzNzguMDI2bTguNjg0LTM3OC4wMjZ2Mzc4LjAyNm0tNjMuODA0LjMwMmg3Ny4zMjd2LTM3OC44NUg2MS4zNzd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0yMDEuNjU5IDI2OS40M2MtMy40MzctMS41NDktOS4yOC0yLjY5Ni0xNS45ODQtMi45MzctMi4zMS4wMi00Ljg4Ny4yNTYtNy41NDcuNzQtOS40MjIgMS43MTMtMTYuNTk5IDUuODEzLTE2LjAyOCA5LjE1MS4wMTEuMDcyLjAzMi4yMTcuMDQ3LjI4MSAwIDAtMy41MzEtOC42NzUtMy41OS05LjAwNS0uNjI4LTMuNzA1IDcuMzMzLTguMjYgMTcuNzktMTAuMTYxYTQ5LjYgNDkuNiAwIDAgMSA5LjI2Mi0uNzk5YzYuNjkgMCAxMi41MDQuOTM0IDE2LjAwNiAyLjM1MXoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik0yMTcuNjg4IDU0Mi44ODVjLTE2Ljg3MS02Ljk3NC00NS41NTQtMTIuMTQzLTc4LjQ2Ny0xMy4yMjUtMTEuMzQzLjA4Ni0yMy45ODkgMS4xNS0zNy4wNDcgMy4zMjktNDYuMjUzIDcuNzE3LTgxLjQ4NCAyNi4xODItNzguNjgyIDQxLjIxOC4wNTMuMzIxLjE1OC45NzcuMjMgMS4yNjUgMCAwLTE3LjMzNS0zOS4wNzMtMTcuNjIzLTQwLjU1OC0zLjA4NS0xNi42ODggMzUuOTk4LTM3LjIgODcuMzMzLTQ1Ljc2NCAxNi4xMS0yLjY4NyAzMS44MjEtMy43MzEgNDUuNDY4LTMuNTk3IDMyLjg0MSAwIDYxLjM4IDQuMjA2IDc4LjU3MiAxMC41OWwuMjE2IDQ2Ljc0MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMTY5Ljc5MiAyNzkuOTg5Yy00LjM2Ny0uMzQyLTcuMzUtMS42MTQtNy42OTItMy42MDUtLjI3LTEuNTg2IDEuMjA2LTMuMzQxIDMuODQ1LTQuOTM1IDEuMTc3LjEzOCAyLjUwMy4zMTQgMy44NzMuMzE0eiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTYxLjI1MyA1OTAuNDRjLTIxLjQ0MS0xLjUzNy0zNi4wODQtNy4yNjYtMzcuNzYtMTYuMjMzLTEuMzIzLTcuMTQ3IDUuOTItMTUuMDUgMTguODcyLTIyLjIzIDUuNzc3LjYyMiAxMi4yODcgMS40MTcgMTkuMDEyIDEuNDE3bC0uMTI0IDM3LjA0NyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjY2UxMTI2IiBkPSJNMTg1LjU5OCAyNzMuNTZjMi43MjkuNDUgNC43NzkgMS4xODkgNS44IDIuMDk3bC4wOS4xODNjLjQ4NyAxLjA4OC0xLjkxIDMuNDAyLTUuOTE1IDUuOTg3eiIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjg1NyIgZD0iTTEzOC44NDcgNTYxLjQ4NWMxMy4zOTQgMi4wMjYgMjMuNDU4IDUuMzU1IDI4LjQ2OCA5LjQ0NmwuNDQ1LjgyNGMyLjM5IDQuOS05LjM3OSAxNS4zMjMtMjkuMDM3IDI2Ljk2M2wuMTI0LTM3LjIzMyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNMTYwLjAwNyAyOTYuMjE1Yy0uNDE0LTEuMzU5IDMuODQ1LTQuMDc3IDkuODY1LTYuNDg1IDIuNzUxLTEuMDczIDUuMDIxLTIuMTkgNy44MzctMy41NDUgOC4zNjItNC4wMjkgMTQuNTQtOC42NTMgMTMuNzgtMTAuMzRsLS4wODQtLjE3M2MuNDQ3LjM5MyAxLjEzNyA4LjcgMS4xMzcgOC43Ljc2MyAxLjU0Ni00Ljg5IDYuMTA0LTEyLjU5IDEwLjEyNS0yLjQ2NCAxLjI4My03LjY2NyAzLjM3OS0xMC4xMjQgNC4zMTctNC4zOTMgMS42NjEtOC43NiA0Ljc5My04LjM2IDUuOTU2bC0xLjQ2LTguNTUxIi8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSJub25lIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMTMuMjE3IDY2My41MThjLTIuMDM1LTYuMTE3IDE4Ljg3My0xOC4zNiA0OC40MjgtMjkuMjA1IDEzLjUwNC00LjgzMyAyNC42NS05Ljg2OCAzOC40NzQtMTUuOTY2IDQxLjA0Ny0xOC4xNDQgNzEuMzczLTM4Ljk3MSA2Ny42NDEtNDYuNTczbC0uNDA3LS43NzZjMi4xOTQgMS43NzIgNS41OCAzOS4xODcgNS41OCAzOS4xODcgMy43NDcgNi45Ni0yNC4wMDcgMjcuNDg2LTYxLjgwNiA0NS41OTdDOTkuMDMyIDY2MS41NTkgNzMuNDkxIDY3MSA2MS40MyA2NzUuMjI1Yy0yMS41NjUgNy40ODItNDMuMDA2IDIxLjU4OC00MS4wNDIgMjYuODI0bC03LjE3LTM4LjUxMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIuNSIgZD0iTTU2LjA0NiA1MjQuNzEyYzkuNDU1LTMuNDUgMTUuNjQ0LTcuNTIgMTIuNjEyLTE0Ljk3LTEuOTExLTQuNzI3LTYuNzk3LTUuNjQyLTE0LjA5Mi0yLjk3bC0xMi45MzQgNC42OTUgMTEuNjUgMjguNzAyYzEuMjY0LS41NzUgMi41MjktMS4xNjkgMy44NTEtMS42NTcgMS4zMDMtLjQ3NCAyLjY3OC0uODI5IDQuMDE0LTEuMjE3bC01LjEwMS0xMi41N3YtLjAxNHptLTUuNjItMTMuODUzIDMuMjYzLTEuMTgzYzIuNzExLS45OTcgNS43ODIuNDQgNy4xMzcgMy43ODQgMS4wMTYgMi41NTMuNzQ3IDUuMzg5LTIuMzcgNy4zODEtMS4wMjEuNjI4LTIuMTk1IDEuMDk3LTMuMzQgMS41NTd6bTM1LjgzNi0xMi4wMDljLTEuMzU2LjM3LTIuNzEyLjc3Ni00LjA4NiAxLjA0NC0xLjM3LjI3My0yLjc4My40MjItNC4xNzIuNjA5bDYuNzA2IDI5Ljg1MSAyMC44NTEtNC4xOTFjLS4yNS0uNTktLjU3LTEuMjE3LS42OTUtMS44MjUtLjE0My0uNjIzLS4xMjQtMS4zMTctLjE2Mi0xLjk0LTMuNjU1IDEuMDQ0LTcuNjUgMi4xOC0xMi40NSAzLjE0MmwtNS45NzMtMjYuNjltNDEuNzQxIDI1Ljc0MmMzLjk0Mi0xMC44MjYgOC43MDMtMjEuMjAxIDEzLjM5My0zMS43MDYtLjgzOC4xMzQtMS43My4yNTQtMi41NjguMzAyLS44MzguMDUzLTEuNzQ4LjA2Ny0yLjU4Ni4wMzUtMi40OTYgNy42MjEtNS42IDE1LjIzOC04Ljg2NyAyMi44MjUtMy45MjMtNy4yLTguMjU4LTE0LjIyNi0xMS41NTgtMjEuNDc0LTEuNjI0LjIwNi0zLjI4MS40NC00LjkyNC41Ni0xLjYyLjEwMS0zLjMxNS4wODItNC45NC4xMDEgNi4wMTIgOS43OTYgMTEuODA5IDE5LjU2MyAxNy4zMDMgMjkuNjY1Ljc2Ni0uMTQgMS41NTItLjMyMSAyLjM4NS0uMzc0Ljc3MS0uMDUyIDEuNTc2LjAyIDIuMzYyLjA1M200My41OTQtMjIuOTZjLjcyOS0xLjQ1MiAxLjQ2MS0yLjg3NCAyLjI4LTQuMjI1LTEuMTItMS4wNjQtNC41NjQtMi42MTUtOC41OTgtMy4wMjMtOC41MDctLjg0My0xMy4zOTMgMi45NDEtMTMuOTYzIDguMDc2LTEuMTk3IDEwLjc0NCAxNS43NjQgOS44MTUgMTQuOTg0IDE2Ljk0My0uMzQgMy4wNzUtMy42MDcgNC4zMjUtNy4wNjYgMy45ODUtMy44Ny0uMzg4LTYuNjg3LTIuNTE1LTcuMTktNS42NzZsLTEuMDQ5LS4xYy0uNTU1IDEuODc3LTEuMzc1IDMuNjgzLTIuMjUxIDUuNDg5IDIuNDc2IDEuNjA0IDUuNzEgMi41MiA4Ljc5NSAyLjgyMSA4LjY3Ljg2MiAxNS4yOS0yLjYxNSAxNS45MTItOC4zMjUgMS4xMjYtMTAuMjA4LTE1Ljk5OS0xMC43OTctMTUuMzQyLTE2LjgwOC4yODctMi41MzQgMi4yMzItNC4xOTIgNi42NTMtMy43NSAzLjE3Ni4zMiA1LjE0IDIuMDQgNS45OTcgNC41MDdsLjgzOC4wODYiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiMwMDViYmYiIGQ9Ik0xOTIuODE4IDMzNS4xMzNjLTEuNDkzIDAtMi44MjMtLjM0Mi0zLjgwNC0uOTEyLS45NzQtLjU0LTIuMjkyLS44Ny0zLjc0Ni0uODctMS40NiAwLTIuODEyLjMzNC0zLjc4Ni44NzgtLjk3OC41Ni0yLjMzLjkwNC0zLjgwNS45MDQtMS40OTQgMC0yLjgyMi0uMzgtMy44MDQtLjk0OS0uOTY2LS41MTgtMi4yNi0uODMzLTMuNjc3LS44MzMtMS40NjUgMC0yLjc2NS4zMDQtMy43MzkuODU1LS45ODIuNTY3LTIuMzQuOTI3LTMuODMuOTI3djIuNTVjMS40OSAwIDIuODQ4LS4zNzEgMy44My0uOTM0Ljk3NC0uNTQ4IDIuMjc1LS44NTggMy43NC0uODU4IDEuNDEyIDAgMi43MDYuMzE4IDMuNjc2Ljg0Ljk3OC41NjYgMi4zMS45NTIgMy44MDQuOTUyIDEuNDc2IDAgMi44MjctLjM1MiAzLjgwNS0uOTA3Ljk3NC0uNTUxIDIuMzI1LS44ODUgMy43ODYtLjg4NSAxLjQ1NCAwIDIuNzcyLjMzNCAzLjc0Ni44NzcuOTgxLjU3IDIuMjg5LjkxNSAzLjc4Ny45MTV6Ii8+PHBhdGggZmlsbD0iIzAwNDRhZCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMTc0LjI5IDgzOC43OTVjLTcuMzMgMC0xMy44NTgtMS41MzctMTguNjc3LTQuMTA1LTQuNzgtMi40MzMtMTEuMjUyLTMuOTE4LTE4LjM5LTMuOTE4LTcuMTcgMC0xMy44MDUgMS41MDQtMTguNTg1IDMuOTUyLTQuOCAyLjUyLTExLjQzNCA0LjA3MS0xOC42NzcgNC4wNzEtNy4zMzMgMC0xMy44NTctMS43MDUtMTguNjc2LTQuMjcyLTQuNzQyLTIuMzMzLTExLjA5NC0zLjc1MS0xOC4wNS0zLjc1MS03LjE5IDAtMTMuNTc1IDEuMzctMTguMzU1IDMuODUxLTQuODE5IDIuNTUzLTExLjQ4NyA0LjE3Mi0xOC44MDEgNC4xNzJ2MTEuNDg3YzcuMzE0IDAgMTMuOTgyLTEuNjcyIDE4LjgwMS00LjIwNiA0Ljc4LTIuNDY3IDExLjE2Ni0zLjg2NSAxOC4zNTYtMy44NjUgNi45MzYgMCAxMy4yODcgMS40MzIgMTguMDQ5IDMuNzg0IDQuOCAyLjU0OCAxMS4zNDMgNC4yODcgMTguNjc2IDQuMjg3IDcuMjQzIDAgMTMuODc3LTEuNTg2IDE4LjY3Ny00LjA4NiA0Ljc4LTIuNDgxIDExLjQxNS0zLjk4NSAxOC41ODYtMy45ODUgNy4xMzcgMCAxMy42MDggMS41MDQgMTguMzg5IDMuOTUxIDQuODE5IDIuNTY4IDExLjIzNyA0LjEyIDE4LjU5IDQuMTJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiMmIyYjIiIGQ9Ik0xOTIuODE4IDMzNy42ODNjLTEuNDkzIDAtMi44MjMtLjM0NS0zLjgwNC0uOTE1LS45NzQtLjU0My0yLjI5Mi0uODc3LTMuNzQ2LS44NzctMS40NiAwLTIuODEyLjMzNC0zLjc4Ni44ODUtLjk3OC41NTUtMi4zMy45MDctMy44MDUuOTA3LTEuNDk0IDAtMi44MjItLjM4Ni0zLjgwNC0uOTUyLS45NjYtLjUyMi0yLjI2LS44NC0zLjY3Ny0uODQtMS40NjUgMC0yLjc2NS4zMS0zLjczOS44NTgtLjk4Mi41NjMtMi4zNC45MzQtMy44My45MzR2Mi41NDNjMS40OSAwIDIuODQ4LS4zNjQgMy44My0uOTI2Ljk3NC0uNTU1IDIuMjc1LS44NjMgMy43NC0uODYzIDEuNDEyIDAgMi43MDYuMzIgMy42NzYuODQuOTc4LjU2NyAyLjMxLjk0OSAzLjgwNC45NDkgMS40NzYgMCAyLjgyNy0uMzUyIDMuODA1LS45MDcuOTc0LS41NDggMi4zMjUtLjg4MiAzLjc4Ni0uODgyIDEuNDU0IDAgMi43NzIuMzM0IDMuNzQ2Ljg3OC45ODEuNTY2IDIuMjg5LjkxMSAzLjc4Ny45MTF6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMTc0LjI5IDg1MC4yODJjLTcuMzMgMC0xMy44NTgtMS41NTItMTguNjc3LTQuMTItNC43OC0yLjQ0Ny0xMS4yNTItMy45NTEtMTguMzktMy45NTEtNy4xNyAwLTEzLjgwNSAxLjUwNC0xOC41ODUgMy45ODUtNC44IDIuNS0xMS40MzQgNC4wODYtMTguNjc3IDQuMDg2LTcuMzMzIDAtMTMuODU3LTEuNzM5LTE4LjY3Ni00LjI4Ny00Ljc0Mi0yLjM1Mi0xMS4wOTQtMy43ODQtMTguMDUtMy43ODQtNy4xOSAwLTEzLjU3NSAxLjM5OC0xOC4zNTUgMy44NjUtNC44MTkgMi41MzQtMTEuNDg3IDQuMjA2LTE4LjgwMSA0LjIwNnYxMS40NTNjNy4zMTQgMCAxMy45ODItMS42MzggMTguODAxLTQuMTcyIDQuNzgtMi41IDExLjE2Ni0zLjg4NSAxOC4zNTYtMy44ODUgNi45MzYgMCAxMy4yODcgMS40MzcgMTguMDQ5IDMuNzg0IDQuOCAyLjU1MyAxMS4zNDMgNC4yNzMgMTguNjc2IDQuMjczIDcuMjQzIDAgMTMuODc3LTEuNTg2IDE4LjY3Ny00LjA4NiA0Ljc4LTIuNDY3IDExLjQxNS0zLjk3MSAxOC41ODYtMy45NzEgNy4xMzcgMCAxMy42MDggMS41MDQgMTguMzg5IDMuOTUyIDQuODE5IDIuNTUzIDExLjIzNyA0LjEwNSAxOC41OSA0LjEwNWwuMDg2LTExLjQ1MyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA1YmJmIiBkPSJNMTkyLjgxOCAzNDAuMjI2Yy0xLjQ5MyAwLTIuODIzLS4zNDUtMy44MDQtLjkxMS0uOTc0LS41NDQtMi4yOTItLjg3OC0zLjc0Ni0uODc4LTEuNDYgMC0yLjgxMi4zMzQtMy43ODYuODgyLS45NzguNTU1LTIuMzMuOTA3LTMuODA1LjkwNy0xLjQ5NCAwLTIuODIyLS4zODItMy44MDQtLjk0OS0uOTY2LS41Mi0yLjI2LS44NC0zLjY3Ny0uODQtMS40NjUgMC0yLjc2NS4zMDctMy43MzkuODYzLS45ODIuNTYyLTIuMzQuOTI2LTMuODMuOTI2djIuNTQzYzEuNDkgMCAyLjg0OC0uMzY0IDMuODMtLjkzLjk3NC0uNTQ3IDIuMjc1LS44NTQgMy43NC0uODU0IDEuNDEyIDAgMi43MDYuMzE4IDMuNjc2LjgzNS45NzguNTcgMi4zMS45NDkgMy44MDQuOTQ5IDEuNDc2IDAgMi44MjctLjM0OCAzLjgwNS0uOTAzLjk3NC0uNTQ4IDIuMzI1LS44ODEgMy43ODYtLjg4MSAxLjQ1NCAwIDIuNzcyLjMyOSAzLjc0Ni44NzQuOTgxLjU3MyAyLjI4OS45MSAzLjc4Ny45MXoiLz48cGF0aCBmaWxsPSIjMDA0NGFkIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS44NTciIGQ9Ik0xNzQuMjkgODYxLjczNWMtNy4zMyAwLTEzLjg1OC0xLjU1Mi0xOC42NzctNC4xMDUtNC43OC0yLjQ0OC0xMS4yNTItMy45NTItMTguMzktMy45NTItNy4xNyAwLTEzLjgwNSAxLjUwNC0xOC41ODUgMy45Ny00LjggMi41MDEtMTEuNDM0IDQuMDg3LTE4LjY3NyA0LjA4Ny03LjMzMyAwLTEzLjg1Ny0xLjcyLTE4LjY3Ni00LjI3My00Ljc0Mi0yLjM0Ny0xMS4wOTQtMy43ODQtMTguMDUtMy43ODQtNy4xOSAwLTEzLjU3NSAxLjM4NC0xOC4zNTUgMy44ODUtNC44MTkgMi41MzQtMTEuNDg3IDQuMTcyLTE4LjgwMSA0LjE3MnYxMS40NTNjNy4zMTQgMCAxMy45ODItMS42MzggMTguODAxLTQuMTg3IDQuNzgtMi40NjcgMTEuMTY2LTMuODUgMTguMzU2LTMuODUgNi45MzYgMCAxMy4yODcgMS40MzYgMTguMDQ5IDMuNzY0IDQuOCAyLjU2OCAxMS4zNDMgNC4yNzMgMTguNjc2IDQuMjczIDcuMjQzIDAgMTMuODc3LTEuNTY3IDE4LjY3Ny00LjA2NyA0Ljc4LTIuNDY3IDExLjQxNS0zLjk3IDE4LjU4Ni0zLjk3IDcuMTM3IDAgMTMuNjA4IDEuNDg0IDE4LjM4OSAzLjkzNyA0LjgxOSAyLjU4MSAxMS4yMzcgNC4xIDE4LjU5IDQuMWwuMDg2LTExLjQ1MyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjJiMmIyIiBkPSJNMTkyLjggMzQ1LjMxNmMtMS40OTcgMC0yLjgwNS0uMzQ0LTMuNzg2LS45MTUtLjk3NC0uNTQtMi4yOTItLjg3LTMuNzQ2LS44Ny0xLjQ2IDAtMi44MTIuMzMtMy43ODYuODc4LS45NzguNTU1LTIuMzMuOTA3LTMuODA1LjkwNy0xLjQ5NCAwLTIuODIyLS4zODMtMy44MDQtLjk1My0uOTY2LS41MTctMi4yNi0uODMyLTMuNjc3LS44MzItMS40NjUgMC0yLjc2NS4zMDgtMy43MzkuODU0LS45ODIuNTY4LTIuMzQuOTMxLTMuODMuOTMxdi0yLjUzMWMxLjQ5IDAgMi44NDgtLjM4IDMuODMtLjk0Ni45NzQtLjU0NyAyLjI3NS0uODU0IDMuNzQtLjg1NCAxLjQxMiAwIDIuNzA2LjMxOCAzLjY3Ni44MzUuOTc4LjU3IDIuMzEuOTQ5IDMuODA0Ljk0OSAxLjQ3NiAwIDIuODI3LS4zNDggMy44MDUtLjkwMy45NzQtLjU0OCAyLjMyNS0uODgxIDMuNzg2LS44ODEgMS40NTQgMCAyLjc3Mi4zMjkgMy43NDYuODc0Ljk4MS41NzMgMi4zMTEuOTEgMy44MDQuOTF6Ii8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMTc0LjIwMyA4ODQuNjZjLTcuMzUzIDAtMTMuNzcxLTEuNTUyLTE4LjU5LTQuMTItNC43OC0yLjQzMy0xMS4yNTItMy45MjItMTguMzktMy45MjItNy4xNyAwLTEzLjgwNSAxLjQ5LTE4LjU4NSAzLjk1Ni00LjggMi41LTExLjQzNCA0LjA4Ni0xOC42NzcgNC4wODYtNy4zMzMgMC0xMy44NTctMS43MjQtMTguNjc2LTQuMjkyLTQuNzQyLTIuMzI4LTExLjA5NC0zLjc1LTE4LjA1LTMuNzUtNy4xOSAwLTEzLjU3NSAxLjM4OS0xOC4zNTUgMy44NS00LjgxOSAyLjU1NC0xMS40ODcgNC4xOTItMTguODAxIDQuMTkydi0xMS40YzcuMzE0IDAgMTMuOTgyLTEuNzEgMTguODAxLTQuMjU5IDQuNzgtMi40NjcgMTEuMTY2LTMuODUgMTguMzU2LTMuODUgNi45MzYgMCAxMy4yODcgMS40MzYgMTguMDQ5IDMuNzY0IDQuOCAyLjU2OCAxMS4zNDMgNC4yNzMgMTguNjc2IDQuMjczIDcuMjQzIDAgMTMuODc3LTEuNTY3IDE4LjY3Ny00LjA2NyA0Ljc4LTIuNDY3IDExLjQxNS0zLjk3IDE4LjU4Ni0zLjk3IDcuMTM3IDAgMTMuNjA4IDEuNDg0IDE4LjM4OSAzLjkzNyA0LjgxOSAyLjU4MSAxMS4zNDcgNC4xIDE4LjY3NiA0LjFsLS4wODYgMTEuNDcyIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiMwMDViYmYiIGQ9Ik0xOTIuOCAzNDcuODYzYy0xLjQ5NyAwLTIuODA1LS4zNDUtMy43ODYtLjkxMS0uOTc0LS41NDgtMi4yOTItLjg4Mi0zLjc0Ni0uODgyLTEuNDYgMC0yLjgxMi4zMzgtMy43ODYuODg1LS45NzguNTU1LTIuMzMuOTA4LTMuODA1LjkwOC0xLjQ5NCAwLTIuODIyLS4zODctMy44MDQtLjk1My0uOTY2LS41Mi0yLjI2LS44NC0zLjY3Ny0uODQtMS40NjUgMC0yLjc2NS4zMTItMy43MzkuODYzLS45ODIuNTYyLTIuMzQuOTMtMy44My45M3YtMi41MjRjMS40OSAwIDIuODQ4LS4zODcgMy44My0uOTUzLjk3NC0uNTQ3IDIuMjc1LS44NTEgMy43NC0uODUxIDEuNDEyIDAgMi43MDYuMzE1IDMuNjc2LjgzMi45NzguNTY2IDIuMzEuOTUgMy44MDQuOTUgMS40NzYgMCAyLjgyNy0uMzUzIDMuODA1LS45MDguOTc0LS41NDggMi4zMjUtLjg3NCAzLjc4Ni0uODc0IDEuNDU0IDAgMi43NzIuMzI2IDMuNzQ2Ljg3Ljk4MS41NjcgMi4zMDQuOTExIDMuOC45MTF6Ii8+PHBhdGggZmlsbD0iIzAwNDRhZCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuODU3IiBkPSJNMTc0LjIwMyA4OTYuMTMyYy03LjM1MyAwLTEzLjc3MS0xLjU1Ny0xOC41OS00LjEwNS00Ljc4LTIuNDY3LTExLjI1Mi0zLjk3LTE4LjM5LTMuOTctNy4xNyAwLTEzLjgwNSAxLjUxOC0xOC41ODUgMy45ODQtNC44IDIuNS0xMS40MzQgNC4wOTEtMTguNjc3IDQuMDkxLTcuMzMzIDAtMTMuODU3LTEuNzQzLTE4LjY3Ni00LjI5Mi00Ljc0Mi0yLjM0Ny0xMS4wOTQtMy43ODQtMTguMDUtMy43ODQtNy4xOSAwLTEzLjU3NSAxLjQwNC0xOC4zNTUgMy44ODUtNC44MTkgMi41MzQtMTEuNDg3IDQuMTkxLTE4LjgwMSA0LjE5MXYtMTEuMzcxYzcuMzE0IDAgMTMuOTgyLTEuNzQgMTguODAxLTQuMjkyIDQuNzgtMi40NjIgMTEuMTY2LTMuODMyIDE4LjM1Ni0zLjgzMiA2LjkzNiAwIDEzLjI4NyAxLjQxOCAxOC4wNDkgMy43NSA0LjggMi41NDkgMTEuMzQzIDQuMjczIDE4LjY3NiA0LjI3MyA3LjI0MyAwIDEzLjg3Ny0xLjU4NiAxOC42NzctNC4wODYgNC43OC0yLjQ2NyAxMS40MTUtMy45MzcgMTguNTg2LTMuOTM3IDcuMTM3IDAgMTMuNjA4IDEuNDcgMTguMzg5IDMuOTE4IDQuODE5IDIuNTUzIDExLjMxIDQuMTA1IDE4LjY1NyA0LjEwNXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2IyYjJiMiIgZD0iTTI1MC4yIDM0OS41NTljLTEyLjY3NyAwLTI1LjI0Mi0zLjM4OC0zNS44MDYtOS4wMjEtNy43ODYtNC4yMDUtMTIuOTUtMTIuNjgxLTEyLjk1LTIyLjM4MXYtMzUuMTc1aDk3LjMxOXYzNS4xNzVjMCA5LjctNS4xNjMgMTguMTc2LTEyLjk1IDIyLjM4LTEwLjU2MyA1LjYzNC0yMi45MzIgOS4wMjItMzUuNjEzIDkuMDIyIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuNDY1IiBkPSJNNDU1Ljk4IDkwMy43NjhjLTYyLjIzMiAwLTEyMy45MTQtMTUuMjU3LTE3NS43NzItNDAuNjMtMzguMjI1LTE4LjkzNS02My41Ny01Ny4xMTItNjMuNTctMTAwLjc5N1Y2MDMuOTJINjk0LjM4djE1OC40MmMwIDQzLjY4NS0yNS4zNDQgODEuODYyLTYzLjU3NCAxMDAuNzk3LTUxLjg1MyAyNS4zNzMtMTEyLjU3MiA0MC42My0xNzQuODI0IDQwLjYzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNMjUwLjAzIDMxOC4xMTVjMCAxMy45MDEtMTAuODA3IDI1LjE2OS0yNC4yNjkgMjUuMTY5LTEzLjQ2NyAwLTI0LjM4MS0xMS4yNjgtMjQuMzgxLTI1LjE2OXYtMzUuMjI3aDQ4LjY1eiIvPjxnIHN0cm9rZT0iIzAwMCI+PGcgZmlsbD0iI2EwN2UwMCI+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIyLjQ2NSIgZD0iTTI2OC40OTEgODU1LjdjNy40NjMgMy45NiAxNy43MTQgMTAuNTU3IDI4LjY2NCAxMy4xOTZsLS42OTQtMjcwLjk4OGgtMjcuOTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMi4zODciIGQ9Ik0yMTUuOTI1IDc2MC4wMThjLjcyOCAzMy40MzUgMTQuMDAxIDU4LjI5IDI3LjI3NSA3NC41Njd2LTIzNS4zNmgtMjYuOTR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZS13aWR0aD0iMi40NjUiIGQ9Ik0zMjEuNzM4IDg3NC44MzZjMTAuOTQ2IDEuMTAxIDE5LjEwOC44ODEgMjcuOTcgMFY1OTcuOTA4aC0yNy45N3ptNTIuNTYyLTUuOTRjMTAuOTUtMi4xOTkgMjMuMjk0LTkuMDE1IDI4LjY2OS0xMi41MzZWNTk3LjkwOGgtMjcuOTd6bTU0LjY2LTM2Ljk1MWMxMS42NDUtMTAuMzM2IDIyLjU5NS0zMy44NzUgMjYuNTc1LTYwLjcwOWwuNjk1LTE3My4zMjhoLTI3Ljk3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIyLjQ2NSIgZD0iTTQ1NS4xNDMgNzYyLjE1NGMwIDYyLjYwNi01My4wNSAxMTMuMzUyLTExOS4xMzUgMTEzLjM1Mi02Ni4xMDggMC0xMTkuNjktNTAuNzQ2LTExOS42OS0xMTMuMzUyVjYwMy40OThoMjM4LjgyNXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik0yMDEuMzgyIDI4Mi45MjJoNDguNjI5di01OC44NWgtNDguNjI5eiIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iIzJiMTEwMCIgc3Ryb2tlLW1pdGVybGltaXQ9IjMuODY0IiBzdHJva2Utd2lkdGg9Ii4wNDUiIGQ9Ik0yNjMuNjMyIDU1My4yMjh2LTE5LjMwNWgyMC43ODhsLS4xMTYtMzQuMDYtLjExNS0zNC4wNi0xMC4xNjYtLjI1Mi4wMDEtMTAuMDgyYy4wMDEtNS41NDQuMTM1LTEzLjIyNi4yOTctMTcuMDdsLjI5NS02Ljk5IDIuMzAxLS4wMDJjMS4yNjYtLjAwMSA0LjU4OS0uMTMyIDcuMzg0LS4yOWw1LjA4My0uMjg4di0xNi43MjhoLTkuNDg4bC4wMDItNS42NThjLjAwMS0zLjExMi4xMzQtNy42MDYuMjk0LTkuOTg1bC4yOTItNC4zMjdoOC40NDh2MS45NWMwIDIuMTA1LjQxNiAyLjQ4OCAyLjcxIDIuNDg4czIuNzExLS4zODMgMi43MTEtMi40ODl2LTEuOTVoMTIuMDk2bC4yOTkgMS45NThjLjMyIDIuMS44MDIgMi40OCAzLjEzOSAyLjQ4IDEuOSAwIDIuNTM4LS42OSAyLjUzOC0yLjc1di0xLjY4N2g4LjU4NHYxOS45NGwtOS43MTQuMjUyLS4xMjMgOC4zMjEtLjEyMiA4LjMyMWgxMy41NzN2LTQxLjI3MmgtOS4wMzZ2LTE5Ljk3MWg5LjA2N2wtLjMgMi4yMi0uMjk5IDIuMjE4aDEuNTgzYy44NyAwIDIuMjE4LS4xMjUgMi45OTUtLjI3NyAxLjMyMy0uMjYgMS40MTItLjQgMS40MTItMi4yMTl2LTEuOTQyaDExLjc0NnYxLjkwOWMwIDIuMzg2LjU4NyAyLjk3MyAyLjk3MiAyLjk3MyAyLjIxNiAwIDIuNjktLjQ1NSAzLjExNi0yLjk5NWwuMzE3LTEuODg3aDguNTA0djE5Ljk3MWgtOS40ODd2NDEuMjcyaDExLjMxNWwtLjI0Ni0xNi42NDItOC44MS0uMjU0LjA0LTguMDgzYy4wMjEtNC40NDYuMTc0LTkuMDgyLjMzOC0xMC4zMDJsLjMtMi4yMTkgNC4xNzktLjEyOCA0LjE3OS0uMTI3djIuMTQ3YzAgMi41MTYuNTUgMy4yMTIgMi41MzggMy4yMTIgMi40MTQgMCAyLjg0Mi0uMzY3IDMuMTU4LTIuNzA3bC4yOTMtMi4xNzVoMy40OTNjMS45MjIgMCA0LjQzNy0uMTI3IDUuNTktLjI4MmwyLjA5Ni0uMjgzdjUuNDQ3aDIuNjU1YzIuOTggMCAzLjUyNC0uMzgzIDMuNzQ2LTIuNjM2LjE3MS0xLjc0Mi41OC0xLjkyMyA1LjQ1OC0yLjQxbDMuMDUtLjMwNXYyMC4zMThsLTIuMDk2LjI4M2MtMS4xNTMuMTU1LTMuMjg4LjI4Mi00Ljc0NC4yODJoLTIuNjQ4djE2LjcyN2w1LjQ5My4yOWMzLjAyLjE2IDYuNzgyLjI5IDguMzU4LjI5aDIuODY2djguNzY1Yy4wMDEgNC44MjEuMTM1IDEyLjUwMy4yOTcgMTcuMDdsLjI5NiA4LjMwNi00LjkyOC4xMjYtNC45MjguMTI3djY3LjlsOS42MDEuMTIgOS42LjExOXYzOC41OTJoLTE0NC4xMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIGQ9Ik0yODUuNTU3IDQ2NC4xNjJ2NzEuMDMxbC0xOS45MjMuMDZ2MzYuNTVsMTQwLjExNi0uMjA0di0zNi41NWwtMTkuMjctLjA3M3YtNzAuODE0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJtMjY1LjYzNCA1NzEuODA0IDEzOC41OTEtLjIwNU0yNjUuNTggNTYyLjc5bDE0MC4wMzEtLjEyNG0tMTM5Ljk3Ny04LjgzOSAxMzkuOTc3LjEyM20tMTQwLjAzMS04Ljg4MiAxNDAuMDMxLS4xMjNtLTEzOS45NTUtOS42OCAxNDAuMTEtLjI4OW0tMTE5Ljg4My05LjQyNiAxMDAuNjUyLS4wNW0tMTAwLjk3OC05LjE4M0gzODYuNDhtLTEwMC45MjMtNy44NTFIMzg2LjQ4bS0xMDAuOTIzLTguODYxSDM4Ni40OG0tMTAwLjkyMy04Ljg2MUgzODYuNDgiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTI4NS41NTcgNDgxLjg4NEgzODYuNDgiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTM2NS42NDkgNDczLjI0djguMzg0bS04MC4wOTItOC42MDFIMzg2LjQ4IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0yODUuNTU3IDU3MS42di04Ljg2MiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNMjg1LjU1NyA1NTMuODc4di04Ljg2MW0tOC44NzMgOC44NjF2OC44NiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMjk1LjUwMiA1NjIuNzM4di04Ljg2IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Ik0zMDUuOTQ2IDUzNS4wNDh2LTkuNDc3bS4xNTQtOS4zMDYtLjE1NC03Ljc5OW0tMTAuNDQ0IDM2LjU1MXYtOS45NjkiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTI3Ni42ODQgNTQ1LjAxN3YtOS45NjkiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTI5NS41MDIgNTE2LjMxN3Y4Ljg2bTIwLjA5NC04Ljg2djguODZtMTkuODM2LTguNjg2LjA3NyA5LjExbS0xMC4xOS05LjA0N3YtOC4wODhtMTAuMjIxLTguODYxdjguODYxbS05Ljk0OC0zNS40NDN2OC44Nm0xMC0xNy43MjF2OC44Nm0tMTkuOTk2LTguODZ2OC44Nm0tMTguOTY2LTguODZ2OC44Nm04OS44NSA5OC41Nzh2LTguODYybTAtOC44NnYtOC44NjFtOC44NzMgOC44NjF2OC44Nm0tMTkuOTk5IDB2LTguODZtLTkuNjItMTguODMtLjA1NC05LjU5NG0wLTkuMDY1di03LjkyMyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMzc1LjM1NCA1NDUuMDE3di05Ljk2OSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNMzk1LjM1MyA1NDUuMDE3di05Ljk2OSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJtMzc1LjM2MSA1MTYuMjg2LjExIDkuMjciIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTM1NS4zNjUgNTE2LjI4NnY5LjI3bS05LjU1Ny05LjE0NnYtNy45NDRtMC0xNy42NTh2OC44NjEiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0iTTMzNS4zMTggNDgxLjg4NHY4Ljg2IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIGZpbGw9IiM5ZjdlMDAiPjxwYXRoIGQ9Ik0zNDUuODA4IDQ3My4wMjN2OC44Nm05LjU1Ny0xNy4zMTJ2OC4yODJtMTkuOTg5LTguMjk0djguMzA3bS01MC4wMzUgMjYuNzM5di04Ljg2IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU2LjM4IDE0Ny44MDcpIj48cGF0aCBkPSJNMzYwLjA4OSA1NzYuNDg3di0yMy45NjhjMC00LjU2NS0xLjk1NC0xOC4yNi0yMC41MTItMTguMjYtMTcuNTgyIDAtMTkuNTM2IDEzLjY5NS0xOS41MzYgMTguMjZ2MjMuOTY4eiIvPjxwYXRoIGQ9Im0zNTAuNjIyIDU1OC44MTUgMTkuNTE3LjA5My0uMDIyLTkuMTMtNi42MzQtOS45MTQtMTMuNTIxIDkuNTUzYzEuNDEyIDMuMzYuNjYgNy4xODEuNjYgOS4zOTd6bS00Ljk4Ny0xNC4xNTEgNC4zNC0xNC4xNTUtMjAuMDkzLS4xMjEgNC42NDYgMTQuMDE3YzMuNjc2LS43MzkgNy40Ny0uNjUgMTEuMTA3LjI2em0xNC44MjktMzEuMzE0di0yMC45MDNjMC01LjcwMSAzLjUzMS0xMC40NTIgOS43MS0xMC40NTJzOS43MSA0Ljc1IDkuNzEgMTAuNDUydjIwLjkwM3oiLz48cmVjdCB3aWR0aD0iMTkuNDA1IiBoZWlnaHQ9IjguNzY2IiB4PSIzMTAuNTM2IiB5PSI1NjcuNjA3IiByeD0iLjAzNiIvPjxwYXRoIGQ9Ik0zNTAuNzg1IDU2Ny42NGgxOS41MTl2OC43NjZoLTE5LjUxOXptLTIwLjg5NC05LjAxNS0xOS4zNTQuMTg2LjE3LTkuMDIxIDUuNzQzLTkuNTYzIDEzLjc4MSA5LjA1NmMtLjgzNSAzLjY4NS0uMjU5IDMuNDg5LS4zNCA5LjM0MnoiLz48L2c+PHBhdGggZD0iTTMwNS43ODYgNDczLjI0M3Y4LjM4Nk0yOTUuNTI0IDUwOC41MDNWNDg3LjQ1YzAtNS43NDIgMy42NzMtMTAuNTI3IDEwLjEwMi0xMC41MjdzMTAuMTAzIDQuNzg1IDEwLjEwMyAxMC41Mjd2MjEuMDU0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIyLjc0NiIgZD0iTS02MTQuNzMzIDQzLjcwMmgzNS41NHY5OC4zNzhoLTM1LjU0em02MS41NDktNDQuNzI5aDM1LjM4NnYxNDMuMDNoLTM1LjM4NnptNTguOTM3IDQ0LjcyOWgzNS41NHY5OC4zNzhoLTM1LjU0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjExNDgxIDAgMCAuMTE3NTcgMjg3LjE2NyAyMzUuNDc2KSIvPjxnIGZpbGw9IiM5ZjdlMDAiPjxwYXRoIGQ9Im0zMjUuOTc5IDQzNS43NzcgMTkuNzU0LjAzNm0tMTkuOTYzIDcuNDU2IDE5Ljc1NS4wMzZtMTMuMzk1LTI1LjMyN2gxOS43OTRtLTE5Ljg2NyA5LjgyM2gxOS43OTRtLTE5Ljc5NCA3LjY2OGgxOS43OTRtLTE5LjQ4NiA4LjI0NWgxOS43OTRtLTEwLjA1MS0yNS45MTF2LTQuNzc2bS4wNzcgMjIuMTR2LTcuMjA5bS0uMjMxIDIzLjEyMnYtNy4yMW0tNzcuODA2LTguMDQ3aDE5Ljc5NG0tMTkuNDg2IDguMjQ2aDE5Ljc5NCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZS13aWR0aD0iMS41IiBkPSJNMjc1Ljg2OSA0NjUuMjc0di0zMi45MzhsMTUuMDQ4LS4wODUgNC40NyAyLjkxNC4xOTIgMTUuOTU4IDEyLjY4Ny4wMzUtLjEwMy0xNi40NzQgMy44NTYtMi41NTIgMTIuOTktLjAxMyA0LjQzMiAzLjI4Ni0uMDM5IDE1LjgwMSAxMy4xMzEuMDQ5LjE5Mi0xNS42NDYgMy4zNTctMy40MTggMTIuODk5LS4wMTIgMy45MiAzLjE5LjUxMiAxNS4zMiAxMS45NzguMDYtLjIxOC0xNS4xNCA0LjEzOC0zLjQ3OCAxNi41NS4wNDh2MzIuODU1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJNMjc1Ljc0IDQ1NS43MzRoMTE5LjkybS0xMTAuMTIuMDM0djkuNTA1bTIwLjI2My05LjZ2OS41MDUiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0zMjUuODM4IDQ1NS43NzZ2OS41MDQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTM0NS44MTkgNDU1LjcyNXY5LjUwNG0xOS44NzEtOS40NTN2OS41MDRtMjAuNzg3LTkuNTM0djkuNTA0bS05MC45NjQtMTguODA5djkuNTA0bS0uMjU2LTE4LjUxOUgyNzUuOTNtMTkuNDQ2IDkuNjUxaC0xOS4zMjVtNTMuMjQzLTkuNzE4aC0yMS4wMm01NC42NzYtLjAzLTIwLjQwMy0uMDcybTUzLjMyNCAwSDM3NS4xNm0tNDUuOTIzIDkuODItMjEuMDk3LS4wNzNtNTUuMDY2LjA3M2gtMjAuNjM0bTUzLjE1My0uMDMtMjAuNDgtLjA3M20tODkuNzQzLTkuMzgydjkuNTA1bTMwLjEwNS0uMDY1LjAzOCA4LjgxN20xMC4xOTItMTguNDg1LjAyMiA5LjU5NW0xOS45NTctOS41NDQuMDIyIDkuNTk1bTQwLjY1Ni05LjkxLjAyMiA5LjkybS03MS4wMDYtMTQuNzgzLjAyMiA1LjI3MyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGVhZDAwIiBkPSJNMzM1LjU5MiA0NTEuMjE2djQuNTM5IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Im0zNTUuMzc2IDQ0Ny4wNTguMDM4IDguNTI4bS0uMTM0LTIzLjYxMy4wMjIgNS4yNzQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0ibTM3NS4zNjUgNDQ2Ljk4NC4wMzkgOC43NDQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0iIzAwNDRhZCIgc3Ryb2tlLXdpZHRoPSIxLjgzMSI+PHBhdGggc3Ryb2tlLXdpZHRoPSIyLjc0NiIgZD0iTS0yMzkuMzM0IDM1MC43NDlWMzEzLjAyYzAtNi4yODggMS4zMi0yNS4yNDktMTkuNTQzLTIzLjYwNy0yMS4yMi0xLjIyNC0xNy40MDEgMTcuMzItMTcuNDAxIDIzLjYwN3YzNy43Mjl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMTE0ODEgMCAwIC4xMTc1NyAyNTUuMjk3IDIzNC41NzcpIi8+PHBhdGggZD0iTS0xOTUuMTM4IDIyNC44MjZ2LTI5LjYyM2MwLTcuNzk1LTMuMTc4LTE1LjU5MS05LjUzNC0xNS41OTFzLTkuNTM1IDcuNzk1LTkuNTM1IDE1LjU5djI5LjYyNHptLTEwNi41MTMtLjMxN3YtMjkuNjIzYzAtNy43OTUtMy4xNzgtMTUuNTkxLTkuNTM1LTE1LjU5MS02LjM1NiAwLTkuNTM0IDcuNzk1LTkuNTM0IDE1LjU5djI5LjYyNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4xMTQ4MSAwIDAgLjExNzU3IDI1NS4yOTcgMjM0LjU3NykiLz48L2c+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0ibTMyNS42NTIgNDI4LjEwNiAxOS43NTUuMDM2bS0xOS43NTUtOS42ODggMTkuNzU1LjAzNm0tMTkuNzU1LTguMTk1IDE5Ljc1NS4wMzZtLTE5Ljc1NS04LjYyOCAxOS43NTUuMDM2bS0xOS43NTUtNy41OTQgMjAuMTkuMDM2bS0xMC4yNjIgNy41MzF2LTcuNjQ3IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik0zMzUuNTggNDE4LjEzOHYtNy42NDciIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTMzNS41OCA0MzUuODM0di03LjY0N20wIDIyLjc4NnYtNy42NDdtLTQ0LjU3LTI0Ljk5M2gxOS43OTVtLTE5Ljg2NyA5LjgyM2gxOS43OTRtLTkuNzQzLTkuOTk5di01LjAyOW0uMDc3IDIyLjM5NHYtNy4yMSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjZGVhZDAwIj48cGF0aCBkPSJNMzAwLjgzNSA0NTEuNDM1di03LjIxIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIHN0cm9rZS13aWR0aD0iMS44MzEiPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIHN0cm9rZS13aWR0aD0iMi43NDYiIGQ9Im0tMjkxLjQ1Ni0yOS4xNzgtLjI5OCAzNS44OCA2OC42OTMtLjI3NC0uMjMtMzUuNDEtMTEuOTA1LjI3My0uNTQ3IDguNzczLTEyLjc3NS0uMjczdi04LjYwOGgtMTcuNzV2OC42MDhoLTEzLjE1NmwuMjczLTguOTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMTE0ODEgMCAwIC4xMTc1NyAyNTUuMjk3IDIzNC41NzcpIi8+PHBhdGggZD0ibS0yOTEuNDQtOC40MjggNjguNjA2LjA2N20tMzUuMTc3IDE0LjgzOVYtNy45NjQiIHRyYW5zZm9ybT0ibWF0cml4KC4xMTQ4MSAwIDAgLjExNzU3IDI1NS4yOTcgMjM0LjU3NykiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBzdHJva2Utd2lkdGg9IjIuNzQ2IiBkPSJtLTI5MS40NTYtMjkuMTc4LS4yOTggMzUuODggNjguNjkzLS4yNzQtLjIzLTM1LjQxLTExLjkwNS4yNzMtLjU0NyA4Ljc3My0xMi43NzUtLjI3M3YtOC42MDhoLTE3Ljc1djguNjA4aC0xMy4xNTZsLjI3My04Ljk3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjExNDgxIDAgMCAuMTE3NTcgMjQ4LjE5NSAyMzkuOTYzKSIvPjxwYXRoIGQ9Im0tMjkxLjQ0LTguNDI4IDY4LjYwNi4wNjdtLTM1LjE3NyAxNC44MzlWLTcuOTY0IiB0cmFuc2Zvcm09Im1hdHJpeCguMTE0ODEgMCAwIC4xMTc1NyAyNDguMTk1IDIzOS45NjMpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIyLjc0NiIgZD0ibS0yOTEuNDU2LTI5LjE3OC0uMjk4IDM1Ljg4IDY4LjY5My0uMjc0LS4yMy0zNS40MS0xMS45MDUuMjczLS41NDcgOC43NzMtMTIuNzc1LS4yNzN2LTguNjA4aC0xNy43NXY4LjYwOGgtMTMuMTU2bC4yNzMtOC45N3oiIHRyYW5zZm9ybT0ibWF0cml4KC4xMTQ4MSAwIDAgLjExNzU3IDI2Mi4xMjQgMjM5LjkxKSIvPjxwYXRoIGQ9Im0tMjkxLjQ0LTguNDI4IDY4LjYwNi4wNjdtLTM1LjE3NyAxNC44MzlWLTcuOTY0IiB0cmFuc2Zvcm09Im1hdHJpeCguMTE0ODEgMCAwIC4xMTc1NyAyNjIuMTI0IDIzOS45MSkiLz48L2c+PC9nPjxnIGZpbGw9Im5vbmUiPjxwYXRoIHN0cm9rZS13aWR0aD0iMi40NjUiIGQ9Ik0yMTYuMzMyIDYwMy42NTJoMjM4LjcyVjMzOC42MDRoLTIzOC43MnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIxLjA2NyIgZD0ibTYyMC4xMjIgNjY5LjU3NC04LjUxLTMuNTMyLTE1LjM4IDE3LjM1OCA1LjE1NyA3LjI5OHptNi42MjQgNS4yOCA1LjE1MiA3LjMxOS0xNS4zNzUgMTcuMzU3LTguNDktMy41NTJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjwvZz48cGF0aCBmaWxsPSIjYjYwMDI4IiBzdHJva2Utd2lkdGg9IjIuNDY1IiBkPSJNNjk0LjU5NSA2MDMuNDk4djE1OC42NTZjMCA2Mi42MDYtNTMuNjU0IDExMy4zNTItMTE5Ljc2MiAxMTMuMzUyLTY2LjA5IDAtMTE5LjY5LTUwLjc0Ni0xMTkuNjktMTEzLjM1MlY2MDMuNDk4eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBzdHJva2Utd2lkdGg9IjEuMDY3Ij48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJNNDkwLjA3MiA2MTkuNjI4Yy03LjY1MSAwLTEzLjgzOCA1LjkwOS0xMy44MzggMTMuMTcxIDAgNS43NiAzLjg5MyAxMC43MzYgOS4zMzcgMTIuNTA1djIwLjUwN2wtOC44MzcgMi41djIyLjY3NWw4LjY3IDIuNXYtNy4zMzVoLjE2N1Y2NzIuOThoOC41MDN2LTI3LjUxYy4zNjMtLjEwNy45ODYtLjIwNSAxLjMzNC0uMzMzbDI3LjE3NSAzMC41MS01LjAwMSA3LjUwMyAxNS41MDUgMTcuMTcyIDguNTAzLTMuNjY4IDIxLjUwNyAyNC4xNzVjLS4zNjguNjUtLjU4OCAxLjI5Ni0uODMzIDJoLTE0LjAwNWwtMi41MDEtOC41MDJoLTIzLjg0MWwtMi42NjggOC41MDNINTAyLjkxYy0xLjMxMy00LjA0OC00LjU4OS03LjMzLTguODM2LTguNjd2LTI4LjAxaC04LjUwM3Y3LjMzN2gtLjE2N2wuMTY3IDIwLjY3M2MtNC42OTcgMS40MTYtOC40MyA1LjAyOC05LjUwMyA5LjY3LS4wMS4wNS4wMS4xMTYgMCAuMTY3LS4xNTQuOC0uMzM0IDEuNjM3LS4zMzQgMi41IDAgNS44NzMgNC4wNjMgMTAuODI4IDkuNjcgMTIuNTA1djEzLjMzOGwtOC44MzYgMyAxLjMzNCAyMi42NzUgOC44MzYgMmMxLjE5IDYuMjk0IDMuMTI4IDEyLjI2NyA1LjY2OSAxOC4wMDdsLS42NjcuODMzYy00Ljk4OSA1LjUtNC4zMjcgMTMuNzg0IDEuNSAxOC41MDcgMy43NjcgMy4wNjYgOC43NTUgMy43OTkgMTMuMTcxIDIuNSAzLjgzNCA0LjMwNyA4LjE3NiA4LjMgMTIuODM4IDExLjgzOGwtMiA4LjgzNmM2LjQzNCA0LjMzIDEzLjM4MiA4LjA4MiAyMC44NCAxMC44MzdsNi42NjktNi4zMzVhOTUgOTUgMCAwIDAgMTcuMTcyIDQuMDAxYzEuMzc1IDUuODkzIDYuODYgMTAuMzM3IDEzLjUwNSAxMC4zMzcgNi42NiAwIDEyLjE3LTQuNDA4IDEzLjUwNC0xMC4zMzcgNS41MzItLjgzMyAxMS4wMjQtMi4wOTcgMTYuMTcyLTMuODM0bC0uMTY3LS4xNjdjMi4zMjktLjc5NCA0LjU5Ni0xLjUzNiA2LjgzNi0yLjUwMWwtNC4xNjgtNy4zMzZjNC4yNS0xLjgwOSA4LjMzNi0zLjg5MiAxMi4xNy02LjMzNmw0LjE2OSA3LjE3Yy0zLjg3IDIuNDAyLTcuOTIzIDQuNjcyLTEyLjE3MSA2LjUwMi0yLjIxLjk0OC00LjM2IDEuODg4LTYuNjY5IDIuNjY3bDYuNTAyIDYuMTY5YzcuNDYzLTIuNzU1IDE0LjQwNi02LjUwOCAyMC44NC0xMC44MzdsLTEuODMzLTguODM2YzQuNjItMy41MTkgOC44NjUtNy41NjMgMTIuNjctMTEuODM4IDQuMzk2IDEuMjk5IDkuNDEuNTY2IDEzLjE3Mi0yLjUgNS44MjctNC43MjMgNi42MjUtMTMuMDA3IDEuNjY3LTE4LjUwN2wtLjgzNC0uODMzYzIuNTQ5LTUuNzQgNC40OS0xMS43MTMgNS42NjktMTguMDA3bDguODM2LTIgMS4zMzQtMjIuNjc1LTguODM2LTN2LTEzLjMzOGM1LjYxNy0xLjY3NyA5LjY3LTYuNjMyIDkuNjctMTIuNTA1IDAtLjg2My0uMTUtMS43LS4zMzQtMi41LS4wMS0uMDUzLjAxLS4xMTUgMC0uMTY3LTEuMDc4LTQuNjQtNC43OTctOC4yNTUtOS41MDMtOS42N2wuMTY3LTIwLjY3NCA4LjgzNi0yLjVWNjY4LjMxbC04LjgzNi0yLjV2LTIwLjUwOGM1LjYzMi0xLjY4MSA5LjY3LTYuNiA5LjY3LTEyLjUwNCAwLTcuMjYzLTYuMTg3LTEzLjE3LTEzLjgzOS0xMy4xNzEtNi4xNjQgMC0xMS4zNjYgMy44OC0xMy4xNyA5LjE3SDYyMy40NXY4LjE3aC0xNC4wMDR2LTguMTdoLTIxLjM0Yy0xLjgxLTUuMjktNy4wMDMtOS4xNy0xMy4xNzItOS4xN3MtMTEuMzYyIDMuODgtMTMuMTcxIDkuMTdoLTIxLjAwN3Y4LjE3SDUyNi43NXYtOC4xN2gtMjMuNTA4Yy0xLjc5NC01LjI5LTYuOTg3LTkuMTctMTMuMTcxLTkuMTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Im01MjEuNTgzIDYyMC4yOTUtMi41MDEgOC4zMzZoMjkuMDFsLTIuNTAxLTguMzM2em04My4xOTUgMC0yLjY2OCA4LjMzNmgyOS4wMWwtMi41LTguMzM2em0tMTE0LjcwNiA2LjgzNWMzLjI3MSAwIDYuMDAyIDIuNTY3IDYuMDAyIDUuNjcgMCAzLjEwNy0yLjczIDUuNjY4LTYuMDAyIDUuNjY4LTMuMjc2IDAtNi4wMDItMi41NjEtNi4wMDItNS42NjkgMC0zLjEwMiAyLjcyNi01LjY2OCA2LjAwMi01LjY2OHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTUwMy40MSA2MzYuOTY4aDE1LjY3MmwyLjUgOC41MDJoMjQuMDA5bDIuNS04LjUwMmgxMy42NzJjMS40MDYgNC4wNjggNC43MiA3LjIzNSA5LjAwMyA4LjUwMnY5LjY3bC04LjgzNiAyLjUwMXYyMi42NzVsOC44MzYgMi41djMxLjUxMWMtLjQ3LjE2NC0xLjA0NS40NDctMS41LjY2N2wtMjEuMTc0LTIzLjY3NSA1LjE2OC03LjMzNi0xNS42NzItMTcuMzM5LTguMzM2IDMuNjY4LTI3LjM0Mi0zMC4zNDNhMTIuMyAxMi4zIDAgMCAwIDEuNS0zLjAwMXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTU4Ny45MzkgNjM2Ljk2OGgxNC4xNzFsMi42NjggOC41MDJoMjMuODQxbDIuNTAxLTguNTAyaDE1LjgzOWMuMTg5LjU4Mi41NjcuOTc5LjgzMyAxLjVsLTI3LjY3NiAzMS4xNzctOC41MDMtMy41LTE1LjMzOCAxNy4zMzggNS4xNjggNy4zMzYgNS4wMDItNS41MDIgOC44MzYtMTAuMTcgNi42NyA1LjMzNS0xMy44MzkgMTUuNjcyIDguMzM2IDMuNTAxIDE1LjUwNi0xNy4zMzktNS4xNjktNy4zMzYgMjcuMDEtMzAuNTFjLjYxMy4zMDcgMS4xNzQuNjMgMS44MzMuODM0djIwLjUwN2wtOS4wMDMgMi41djIyLjY3NWw5LjAwMyAyLjV2MjAuODQxYy00LjIyMSAxLjM0LTcuNTIyIDQuNDU1LTguODM2IDguNTAzaC0xNS44MzlsLTIuNjY3LTguNTAzaC0yMy44NDJsLTIuNSA4LjUwM2gtMTMuMzM4Yy0uMzYzLTEuMTU1LS42Ny0yLjE5Mi0xLjMzNC0zLjE2OGwyMC44NC0yMy41MDggNC44MzUtNS42NjgtNi41MDItNS4xNjktMjUuNjc1IDI5LjE3N2MtLjM4NC0uMTEzLTEuMTE4LS4yMjYtMS41LS4zMzR2LTM4LjY4aC04LjUwNHYtMTMuMTdoOC42N3YyMC41MDZsOC44MzYtMi41VjY1Ny42NGwtOC44MzYtMi41di05LjgzN2M0LjA5NC0xLjMyIDcuMTQ4LTQuNDE2IDguNTAzLTguMzM3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYzhiMTAwIiBkPSJNNDk0LjI0IDY2NS44MXYyNy42NzdsOC44MzctMi41MDFWNjY4LjMxeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNjU1LjYyOCA2NzIuOThoOC42N3YxMy4xN2gtOC42N3ptLTEyMS41NDEgMi44MzQgOS4wMDMgMTAuMDAzLTYuNTAyIDUuMzM2LTkuMTctMTAuMTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik00ODkuNzM5IDcyMC45OTZjMi4yNjUgMCA0LjE3NyAxLjE3OCA1LjE2OCAyLjgzNC4wMi4wNDUtLjAyLjEyIDAgLjE2Ny4zNjQuODE3LjY2NyAxLjYzMS42NjcgMi41IDAgMy4xMTgtMi41MzkgNS42Ny01LjgzNSA1LjY3LTMuMjc3IDAtNi4wMDItMi41NTItNi4wMDItNS42NyAwLS44NjQuMjk5LTEuNjEuNjY3LTIuMzMzLjAyNS0uMDQ1LS4wMjUtLjEyMSAwLS4xNjcuOTk2LTEuNzU2IDMuMDktMy4wMDEgNS4zMzUtMy4wMDF6bTE3MC4zOTEgMGMyLjMyNSAwIDQuMTgyIDEuMzQzIDUuMTY4IDMuMTY4aC4xNjdjLjMwMy43NTMuNSAxLjUzNC41IDIuMzM0IDAgMy4xMTgtMi41MzkgNS42NjgtNS44MzUgNS42NjgtMy4yNzIgMC02LjAwMi0yLjU1LTYuMDAyLTUuNjY4IDAtLjkyLjI0OC0xLjc0NS42NjYtMi41MDEuOTY3LTEuNzE3IDMuMDE1LTMuMDAxIDUuMzM2LTMuMDAxeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTI2LjA4NCA3MjIuODNoMTQuNTA1djcuODM2aDIxLjg0MWMuMjg2LjgzMy41NiAxLjYyOSAxIDIuMzM0bC0yMC4zNCAyMi41MDctOC41MDMtMy42NjctMTUuNTA1IDE3LjMzOSA1LjE2OCA3LjMzNi0xNi44MzkgMTguNjczYy0yLjM0LS44Ny01LjA1OS0xLjE3Ni03LjUwMi0uODM0LTIuMDY1LTQuNzQ1LTMuNTItOS42ODYtNC41MDItMTQuODM4LS40MjgtMi4yNDYtLjc5Mi00LjUyMS0xLTYuODM2aC04LjY3YTgwIDgwIDAgMCAxLS4zMzMtNy4zMzZ2LTYuMDAybDguODM2LjE2N3Y1LjgzNWMwIDIuNDktLjAzIDQuOTE2LjE2NyA3LjMzNi4xODggMi4zMDkuNTYzIDQuNTgyIDEgNi44MzVsOC44MzYtMi44MzRzLTEuMDYzLTE1LjE0LS44MzMtMTEuMzM3Yy4xODkgMy4yNi0uMzM0LTExLjMzNy0uMzM0LTExLjMzN2wtOC44MzYtMi4xNjh2LTEyLjgzN2M0LjAzOC0xLjMxNCA3LjExMy00LjQ3OCA4LjUwMy04LjMzNmgyMy4zNDF6bTgzLjUyOSAwaDE0LjAwNHY3LjgzNmgyMy4zNDJjMS4zOSAzLjg1OSA0LjYgNy4wMjIgOC42NyA4LjMzNnYxMi44MzhsLTkuMDA0IDIuMTY3cy0uMzYgMTQuNTk4LS4xNjcgMTEuMzM3Yy4yNDYtMy44MDMtMSAxMS4zMzctMSAxMS4zMzdsOS4wMDMgMi44MzVjLS45ODcgNS4xNjItMi42MDcgMTAuMDg0LTQuNjY4IDE0LjgzOC0yLjQ1NC0uMzQzLTQuOTc1LS4wMzUtNy4zMzYuODM0bC0xNi44NC0xOC42NzMgNS4wMDMtNy4zMzYtMTUuNTA2LTE3LjM0LTguNTAzIDMuNjY4LTE5LjM0LTIyLjE3NGMuNTA3LS44MDcgMS4wMTItMS41OCAxLjMzNC0yLjVsMjEuMDA3LS4xNjd2LTcuODM1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjZGVhZDAwIj48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJtNjY0LjI5OCA3NTkuNDEyLS4wMi0yMC4zNjhjNS42MTctMS42NiA5LjY4NS02LjY1NCA5LjY4NS0xMi41MjcgMC01Ljg2Mi00LjEyNS0xMC45MDctOS43NDItMTIuNjA0bC4wNTctMjcuODY2aC04LjYwN2wtLjAzNSAyOC4wM2MtNC4yMjIgMS4zMzQtNy40OTkgNC40NTEtOC44MTIgOC40OWwtMjMuMjM1LjAzNHY4LjE0N2gyMy4zODhjMS4zOSAzLjg2IDQuNTM0IDYuODkgOC42MDIgOC4yMDRsLjAxNSAyMC41MSA4LjY4NC0uMDV6bS4wNTYtMTE0LjEtLjA3NyAyNy41MDhoLTguNjA3di0yNy42MTZjLS42Ni0uMi0xLjMwOC0uNDctMS45MjItLjc3N2wtMzEuODM3IDM1Ljg1NS02LjU4My01LjIyOSAzMi40NDUtMzYuNTU1Yy0uMjY2LS41Mi0uNTUyLTEuMDYzLS43NC0xLjY0SDYyMy40OXYtOC4xNDdoMjMuNDdjMS44MDUtNS4yOCA3LjAwMy05LjA2NyAxMy4xNjctOS4wNjcgNy42NTEgMCAxMy44NzcgNS44NzcgMTMuODc3IDEzLjEyNSAwIDUuODkzLTQuMDE4IDEwLjg2Ni05LjY1IDEyLjU0M3ptLTg0LjkwNy0uMTA4LS4wNzYgMTYuOTQ0aC04LjYwM2wuMDItMTYuOGMtNC4yODMtMS4yNjMtNy42NTYtNC40MzItOS4wNjItOC40OUg1NDAuNzN2LTguMTQ3aDIwLjk5NmMxLjgxLTUuMjggNi45ODItOS4wNjcgMTMuMTUxLTkuMDY3IDYuMTcgMCAxMS4zODMgMy43ODcgMTMuMTkyIDkuMDY3aDIxLjQxMXY4LjE0N2gtMjEuNDY3YTEzLjM1IDEzLjM1IDAgMCAxLTguNTY2IDguMzQ2em0zOS41MDkgMTM2LjYzMS04LjQ4NCAzLjYwMy0xNS41MzMtMTcuMjMgNS4xLTcuMzR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im01NDguMTM2IDYzNi44NzgtMi42MjIgOC40N2gtMjMuOTFsLTIuNTg2LTguNDd6bTAtOC4yMDMtMi42MjItOC40NTRoLTIzLjkxbC0yLjU4NiA4LjQ1NHpNNTMwLjc5OSA3ODEuODM1bDguNDkgMy42MDMgMTUuNTI3LTE3LjIzLTUuMS03LjM0em0tNi41ODMtNS4zMjEtNS4wOTEtNy4zNyAxNS41MzgtMTcuMjMgOC40NjQgMy42MTl6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im01MjkuOTM1IDgyOC44OTgtNC4yMzcgNy4yOTljLTcuMjU4LTQuNTA4LTEzLjcyNC0xMC4wNzQtMTkuMjgtMTYuMzE1LTQuNDE1IDEuMjk4LTkuNDA0LjUyNi0xMy4xNy0yLjU0LTUuODI4LTQuNzIzLTYuNTMzLTEzLjAxMy0xLjU0NC0xOC41MTNsLjcyNS0uNzcyYy0zLjUxMS03LjkzMi01Ljg4OC0xNi40NTctNi43LTI1LjM5N2w4LjY3OC4wMzVhNjkuOSA2OS45IDAgMCAwIDUuNTUxIDIxLjcwMiAxNS40IDE1LjQgMCAwIDEgNy4zOS44MTNsMjEuNzE4LTI0LjAyOCA2LjU0MiA1LjI4LTIxLjU3OSAyMy45OTJjMi45MTMgNC40MzEgMi43OTYgMTAuMTQ1LS41MzEgMTQuNTEgNC43ODkgNS4zIDEwLjI5MyAxMC4wMjMgMTYuNDM3IDEzLjkzM3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTUyMy41IDgyNC4yMjZjNy40ODggNS44NDIgMTYuMTg3IDEwLjU4NSAyNS41OTIgMTMuNTlsMS45NzgtOC41OTZjLTcuNzI4LTIuNDMzLTE0Ljg5LTYtMjEuMTg2LTEwLjYzMXptLTQuMjk4IDcuNDI3YzcuNTk1IDUuNzE0IDE2LjI3OSAxMC4yOTQgMjUuNTg2IDEzLjQ2OGwtNi42NSA2LjIxNWE5OSA5OSAwIDAgMS0yMC45MS0xMC43MjN6TTQ4NS40NjMgNzU5LjQxMmwuMDEtMjAuMzY4Yy01LjYwNy0xLjY2LTkuNjgtNi42NTQtOS42OC0xMi41MjcgMC01Ljg2MiA0LjEyOS0xMC45MDcgOS43NDYtMTIuNjA0bC0uMDY2LTI3Ljg2Nmg4LjYxMmwuMDE1IDI4LjAzYzQuMjQ3IDEuMzM0IDcuNTE5IDQuNDUxIDguODMyIDguNDlsMjMuMjIuMDM0djguMTQ3aC0yMy4zNjhjLTEuMzkgMy44Ni00LjU3IDYuODktOC42MDcgOC4yMDRsLS4wMTUgMjAuNTEtOC43LS4wNSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBkPSJtNDg2Ljc5MiA3NzkuOTM4LTguOTI0LTEuOTk4LTEuMjU4LTIyLjYwMSA4Ljg1My0yLjkyNC4wMSAxMi45NjJjMCA1LjAzLjQ0NCA5Ljc4OCAxLjMxOCAxNC41NjF6bTcuNDA2LTI4LjAyNCA4Ljg4OCAyLjA5cy40NTUgMTQuNTI2LjI2NiAxMS4yNjZjLS4yMy0zLjgwMy45NzEgMTEuMzU2Ljk3MSAxMS4zNTZsLTguOTY1IDIuOTU1Yy0uODk0LTQuNjE2LTEuMTk2LTkuMzM4LTEuMTk2LTE0LjIwNGwuMDE1LTEzLjQ2M2guMDJ6bS04LjYyMy04Ni4xNDMtOC45MjQgMi41MDV2MjIuNjQybDguOTI0IDIuNDQ4em04LjY2NCAwIDguOTAzIDIuNTA1djIyLjY0MmwtOC45MDMgMi40NDh6bTI0Ljk4OCA1Ni44MTYgMi42MDctOC40NTRoMjMuOTI1bDIuNTgxIDguNDU0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZD0ibTUxOS4yMjcgNzMwLjc3IDIuNjA3IDguNDY5aDIzLjkyNWwyLjU4MS04LjQ3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJNNTg4LjI3NCA4NDAuODI3YzYuODE4LTEuMDc4IDEzLjEtMi45NTQgMTkuMzA1LTUuNTY2bDQuMjYzIDcuMjYzYy03LjEzNiAzLjA2Mi0xNC44MjggNS4yNjUtMjIuODQyIDYuNDctMS4zMzQgNS45My02Ljg3IDEwLjM4MS0xMy41MyAxMC4zODEtNi42NDQgMC0xMi4xODUtNC4zOTUtMTMuNTYtMTAuMjg4LTguNDY0LTEuMTU1LTE2LjQ5My0zLjMzOC0yNC4wMTItNi41NjNsNC4yODMtNy4yNjNjNi41MjcgMi43NTUgMTMuNDk0IDQuNTk1IDIwLjcyMSA1LjYwMiAxLjUyOC0zLjMxMiA0LjMyNC01Ljg3MyA4LTcuMDY0bC4wNzYtMzUuNTYzaDguNTgxbC4wNzcgMzUuNDM2YzMuODA4IDEuMTQgNy4wMjMgMy43MyA4LjYyMiA3LjE1NXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTYyNi4yNSA4MjQuMjI2Yy03LjQ5OCA1Ljg0Mi0xNi4yMDIgMTAuNTg1LTI1LjU4MSAxMy41OWwtMS45NzgtOC41OTZjNy43MDctMi40MzMgMTQuODgzLTYgMjEuMTY1LTEwLjYzMXptNC4zMDQgNy40MjdjLTcuNjIxIDUuNzE0LTE2LjI3NCAxMC4yOTQtMjUuNTg3IDEzLjQ2OGw2LjY0NSA2LjIxNWE5OSA5OSAwIDAgMCAyMC45Mi0xMC43MjN6TTU3OS42IDgwNS4yNDlsOC45MjQtMi41MDV2LTIyLjYyMmwtOC45MjQtMi40NTN6bS04LjY1OCAwLTguOTA5LTIuNTA1di0yMi42MjJsOC45MDktMi40NTN6TTYwMi4wNzQgNjM2Ljg3OGwyLjYzMiA4LjQ3aDIzLjlsMi41OTItOC40N3ptMC04LjIwMyAyLjYzMi04LjQ1NGgyMy45bDIuNTkyIDguNDU0eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PC9nPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Im01MTkuMjQ5IDczMC44MzMgMi42NjcgOC4zMzZoMjMuODQybDIuNS04LjMzNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RlYWQwMCIgZD0ibTYwMS45NDMgNzMwLjgzMyAyLjUwMSA4LjMzNmgyMy44NDJsMi42NjctOC4zMzZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIGZpbGw9IiNiNTAwMjciPjxwYXRoIGQ9Ik01NjkuOTMzIDczOC41MDJhNSA1IDAgMCAwIDEgLjMzM3YzOC44NDdsLTguODM2IDIuNXYyMi41MDhsOC44MzYgMi41MDF2MjguNjc3Yy0zLjY3NSAxLjE5LTYuNDc1IDMuNjktOC4wMDMgNy4wMDItNC43MTMtLjY1Ny05LjM5Ni0xLjYxMy0xMy44MzgtMy4wMDFsMi04LjY3Yy03LjcyNy0yLjQzMi0xNC44NzYtNi4wNC0yMS4xNzMtMTAuNjdsLTYuNTAyIDUuNjY5YTg0IDg0IDAgMCAwIDUuODM1IDQuMTY4Yy0yLjAzMi0xLjMyNS0zLjk0OC0yLjY3NC01LjgzNS00LjE2OC0zLjU1NC0yLjgxNS02LjgzLTUuODQxLTkuODM3LTkuMTcgMy4zMjgtNC4zNjUgMy40MTQtMTAuMDc0LjUtMTQuNTA1bDE2LjY3My0xOC42NzMgOC41MDIgMy42NjggMTUuNTA2LTE3LjM0LTUuMDAyLTcuMzM1em0xMC44MzcuMTY3IDI0LjM0MSAyNy42NzYgNi41MDItNS4xNjkgOS4wMDMgMTAuMDA0LTYuNTAyIDUuMzM1LTkuMDAzLTEwLjE3LTUuMDAyLTUuNTAyLTUuMTY4IDcuMzM2IDE1LjUwNSAxNy4zMzkgOC41MDMtMy42NjggMTYuODQgMTguNjczYy0yLjg5NCA0LjQzMS0yLjgxMyAxMC4xNC41IDE0LjUwNS0zLjAxNiAzLjM0NS02LjQzMiA2LjM0NC0xMC4wMDQgOS4xN2E3OCA3OCAwIDAgMS01LjgzNSA0LjE2OCA4NSA4NSAwIDAgMCA1LjgzNS00LjE2OGwtNi41MDItNS42NjljLTYuMjgyIDQuNjMtMTMuNDY2IDguMjM3LTIxLjE3NCAxMC42N2wyIDguNjdjLTMuOTc3IDEuMjk0LTguMDUgMi4zMjMtMTIuMzM3IDMuMDAxLTEuNi0zLjQyNC00Ljg2Mi02LjAzLTguNjctNy4xN3YtMjguNTA5bDkuMDA0LTIuNXYtMjIuNTA4bC05LjAwMy0yLjUwMXYtMzguNTEzYy40NzUtLjEyOC43MjItLjM1NyAxLjE2Ny0uNXptODMuNTI4IDIwLjY3M3Y2LjAwMmMwIDIuNTE1LS4xMTMgNC45MjEtLjMzNCA3LjMzNmgtOC42N2MuMTk4LTIuNDIuMzM0LTQuODQ2LjMzNC03LjMzNnYtNS44MzV6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im01MzguMDg4IDc2MS4xNzYgNi42NyA1LjE2OS05LjE3IDEwLjE3LTYuNTAzLTUuMzM1em0zMi44NDUgMjMuODQyaDguNjd2MTMuMTdoLTguNjd6bS00MS4wMTQgNDMuODQ4YzMuODMyIDIuNDQ0IDguMDgyIDQuNTI3IDEyLjMzOCA2LjMzNWwtNC4zMzUgNy4zMzZhOTMgOTMgMCAwIDEtMTIuMTcxLTYuMzM1eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48L2c+PHBhdGggZmlsbD0iIzlmN2UwMCIgZD0iTTU2My4zODMgNzMzLjA3NWMtLjQzNS0uNzIxLS43NjItMS40OTMtMS4wNDgtMi4zMjZoLTIxLjcxOHYtOC4xNDdoMjEuNTdjLjI0NS0uNjg1LjU4Ny0xLjM3Ljk0NS0yLjAxOWwtMjYuNjI0LTI5LjYxNCA2LjU0Mi01LjMgMjYuMjkyIDI5LjExM2MuNDU1LS4yMi45MTUtLjQxNCAxLjQwNi0uNTc4bC4wMi0zOC43ODhoOC41ODJ2MzguNTUzYy4zODMuMTA4Ljk3LjIxNSAxLjM1NC4zNDNsMjUuNjU4LTI5LjE4NSA2LjU5OSA1LjI1LTI1Ljc2NiAyOS4wMmMuNjY1Ljk3MSAxLjEyIDIuMDU1IDEuNDgyIDMuMjA1aDIwLjl2OC4xNDdsLTIxLjAxNy4wNTdjLS4zMDIuOTItLjgzMyAxLjc2OC0xLjMzIDIuNTc2bDI0LjQwMiAyNy43NDMtNi41NDggNS4zLTI0LjI4My0yNy43NzljLS40NDQuMTY0LS42Ny4zNDMtMS4xNjUuNDdsLS4wNTYgNDUuODcyaC04LjYwMmwtLjAyNS00Ni4wNzFjLS4zNTgtLjEwOC0uNjYtLjI5Mi0xLjAwMi0uNDVsLTI1LjI4IDI3Ljk1OC02LjU0Mi01LjMgMjUuMjU0LTI4LjA1IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik00OTcuMjQgODAzLjU5OWMyLjEzNi0yLjM4MiA1Ljg4Mi0yLjY1MyA4LjM3Ny0uNjM0IDIuNDk0IDIuMDIgMi44IDUuNTg3LjY3IDcuOTMzLTIuMTQyIDIuMzYxLTUuODg0IDIuNjQ3LTguMzc4LjYyOC0yLjQ5NC0yLjAzNC0yLjc5Ni01LjU2Ni0uNjctNy45Mjd6bS0xMy41MS03Ny4wODJjMC0zLjEyMyAyLjY1OC01LjY0MyA1LjkzNC01LjY0M3M1LjkyNCAyLjUyIDUuOTI0IDUuNjQzYzAgMy4xMTgtMi42NDggNS42MDItNS45MjQgNS42MDJzLTUuOTM0LTIuNDg0LTUuOTM0LTUuNjAyeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJtNjE5LjgxNSA4MjguODk4IDQuMjQ3IDcuMjk5YzcuMjQ4LTQuNTA4IDEzLjcyNC0xMC4wNzQgMTkuMjgtMTYuMzE1IDQuMzk1IDEuMjk4IDkuNDA0LjUyNiAxMy4xNjYtMi41NCA1LjgyNy00LjcyMyA2LjQ5Ni0xMy4wMTMgMS41MzktMTguNTEzbC0uNzM2LS43NzJjMy41MjEtNy45MzIgNS45MDMtMTYuNDU3IDYuNjgtMjUuMzk3bC04LjYzOC4wMzVjLS42ODUgNy42MjYtMi42MDcgMTQuODg5LTUuNTYgMjEuNzAyYTE1LjQ2IDE1LjQ2IDAgMCAwLTcuNDAyLjgxM2wtMjEuNjk3LTI0LjAyOC02LjU0NyA1LjI4IDIxLjU2NCAyMy45OTJjLTIuODkzIDQuNDMxLTIuNzggMTAuMTQ1LjUzMSAxNC41MS00Ljc3OSA1LjMtMTAuMjc4IDEwLjAyMy0xNi40MjcgMTMuOTMzeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNjUyIDgwMy43Yy0yLjEzMS0yLjM4Mi01Ljg2Mi0yLjY1My04LjM1Mi0uNjM0LTIuNDk5IDIuMDItMi44IDUuNTg3LS42NyA3LjkzMyAyLjEzMiAyLjM2MSA1Ljg4NCAyLjY0NyA4LjM3OC42MjggMi40OTQtMi4wMzQgMi43NzUtNS41NjYuNjQ0LTcuOTI3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjOWY3ZTAwIiBkPSJtNjYyLjk0OCA3NzkuOTM4IDguOTI0LTEuOTk4IDEuMjU4LTIyLjYwMS04LjgzMi0yLjkyNC0uMDIgMTIuOTYyYzAgNS4wMy0uNDQgOS43ODgtMS4zMyAxNC41NjF6bS03LjM4NS0yOC4wMjQtOC44ODkgMi4wOXMtLjQ4IDE0LjUyNi0uMjg2IDExLjI2NmMuMjQ2LTMuODAzLS45NyAxMS4zNTYtLjk3IDExLjM1Nmw4Ljk2NCAyLjk1NWMuODk1LTQuNjE2IDEuMTk2LTkuMzM4IDEuMTk2LTE0LjIwNGwtLjAxNS0xMy40NjNtLjAzLTg2LjE0My04LjkwMyAyLjUwNXYyMi42NDJsOC45MDMgMi40NDh6bTguNjY0IDAgOC45MjkgMi41MDV2MjIuNjQybC04LjkzIDIuNDQ4ek02MjUuNTQgNzc2LjUxNGw1LjA5LTcuMzctMTUuNTMzLTE3LjIzLTguNDY5IDMuNjE5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSJub25lIiBkPSJNNDg0LjE1IDYzMi43ODRjMC0zLjA5NyAyLjY2Mi01LjYyMiA1LjkzOC01LjYyMiAzLjI3MiAwIDUuOTIgMi41MjUgNS45MiA1LjYyMiAwIDMuMTAzLTIuNjQ4IDUuNjA3LTUuOTIgNS42MDctMy4yNzYgMC01LjkzOS0yLjUwNC01LjkzOS01LjYwN3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTY1NC4xMzEgNzI2LjUxN2MwLTMuMTIzIDIuNjY4LTUuNjQzIDUuOTQtNS42NDMgMy4yOTYgMCA1LjkxOCAyLjUyIDUuOTE4IDUuNjQzIDAgMy4xMTgtMi42MjIgNS42MDItNS45MTggNS42MDItMy4yNzIgMC01Ljk0LTIuNDg0LTUuOTQtNS42MDJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Im02MzAuOTgzIDcyMi41ODctMi42MjItOC40NTRoLTIzLjkxbC0yLjU4MSA4LjQ1NHptMCA4LjE4My0yLjYyMiA4LjQ2OWgtMjMuOTFsLTIuNTgxLTguNDd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik01NjkuNTMxIDg0Ni4yMzVjMC0zLjExOCAyLjY2My01LjYzOCA1Ljk0LTUuNjM4IDMuMjcgMCA1LjkxMyAyLjUyIDUuOTEzIDUuNjM4IDAgMy4xMDItMi42NDIgNS42MDctNS45MTMgNS42MDctMy4yNzcgMC01Ljk0LTIuNTA1LTUuOTQtNS42MDd6bTg0LjY2Mi0yMTMuNDUxYzAtMy4wOTcgMi42NDItNS42MjIgNS45MzQtNS42MjIgMy4yNzYgMCA1LjkyNCAyLjUyNSA1LjkyNCA1LjYyMiAwIDMuMTAzLTIuNjQ4IDUuNjA3LTUuOTI0IDUuNjA3LTMuMjkyIDAtNS45MzQtMi41MDQtNS45MzQtNS42MDd6bS04NS4yNDkgMGMwLTMuMDk3IDIuNjYyLTUuNjIyIDUuOTM0LTUuNjIyIDMuMjc2IDAgNS45MjMgMi41MjUgNS45MjMgNS42MjIgMCAzLjEwMy0yLjY0NyA1LjYwNy01LjkyMyA1LjYwNy0zLjI3MiAwLTUuOTM0LTIuNTA0LTUuOTM0LTUuNjA3eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48ZyBmaWxsPSIjOWY3ZTAwIj48cGF0aCBkPSJtNDk1LjQ3NiA2NDUuMTMzIDMyLjAwNiAzNS44MTMgNi41NTItNS4zLTMyLjE4NS0zNS42N2MuNjQ0LS45NTYgMS4xLTEuOTk5IDEuNDgyLTMuMTE4aDIzLjQxNXYtOC4xNDdoLTIzLjQzYy0xLjc5NC01LjI4LTcuMDQzLTkuMDY3LTEzLjIyOC05LjA2Ny03LjY1MSAwLTEzLjg3NiA1Ljg3Ny0xMy44NzYgMTMuMTI1IDAgNS43NSAzLjg5NCAxMC42NTEgOS4zMzggMTIuNDE1bC0uMDUxIDI3LjYzNmg4LjYwMnYtMjcuNDUyYy4zNjMtLjEwOCAxLjAyNy0uMTA4IDEuMzc1LS4yMzV6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Im01MjkuMTczIDY3MC4yMzkgOC40OTUtMy42MDQgMTUuNTMzIDE3LjIzNS01LjEgNy4zNXptLTYuNTc4IDUuMzM2LTUuMDggNy4zNzUgMTUuNTI4IDE3LjIxNCA4LjQ2OS0zLjYyNHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGQ9Im01NzAuODQ1IDY1NS4xMi04LjkwOSAyLjUwNHYyMi42MzdsOC45MDkgMi40NTR6bTguNTY2IDAgOC45MDQgMi41MDR2MjIuNjM3bC04LjkwNCAyLjQ1NHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzAwNmY0NiIgZD0iTTU2MS40MTUgNzI2LjgzOWMwLTcuMjgzIDYuMjI1LTEzLjE3NyAxMy44OTctMTMuMTc3IDcuNjUyIDAgMTMuODcyIDUuODk0IDEzLjg3MiAxMy4xNzcgMCA3LjI0Ny02LjIyIDEzLjEyLTEzLjg3MiAxMy4xMi03LjY3MiAwLTEzLjg5Ny01Ljg3My0xMy44OTctMTMuMTIiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxwYXRoIGZpbGw9IiNjOGIxMDAiIGQ9Ik00NzAuMzAzIDYwMy4wMWgyMC42OTR2LTQuOTM0aC0yMC42OTR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkZWFkMDAiIGQ9Ik00NzAuMzAzIDYwMy4wMWgyMC42OTR2LTQuOTM0aC0yMC42OTR6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIHN0cm9rZS13aWR0aD0iMi40NjciPjxwYXRoIGZpbGw9IiNmNmNiN2UiIGQ9Ik00NjcuNDY4IDgzMy40NGM5Ljk1MyAyLjk5NCAxNC45OTcgMTAuNDA5IDE0Ljk5NyAxOS4wODggMCAxMS4zMDUtMTAuOTY0IDE5Ljg4NC0yNS4yIDE5Ljg4NC0xNC4yMzIgMC0yNS43NzYtOC41OC0yNS43NzYtMTkuODg0IDAtOC41NDUgNC43NDctMTguMDkyIDE0LjY0My0xOC43ODEgMCAwLS4zMDEtLjg5Ni0xLjE1NC0yLjM2Ny0xLjAyNS0xLjA5Ny0zLjA1MS0zLjE0Mi0zLjA1MS0zLjE0MnMzLjc4LS43MDkgNS45NTkuMTJjMi4xOTMuODI4IDMuNjM1IDIuMjEzIDMuNjM1IDIuMjEzczEuMDM1LTIuMDI3IDIuNDgyLTMuNTk4YzEuNDYtMS41NTcgMy4zNTMtMi41MzQgMy4zNTMtMi41MzRzMi4xODkgMS44NCAyLjkwNyAzLjA3Yy43MTQgMS4yNyAxLjE3OSAyLjc3NCAxLjE3OSAyLjc3NHMyLjAxMS0xLjY1NyAzLjc2LTIuMzMzYzEuNzQzLS42OSAzLjk5NS0xLjIzIDMuOTk1LTEuMjNzLS42NDIgMi4xNzktMS4wNjggMy4yOWEzMSAzMSAwIDAgMC0uODEgMi40NDRsLS40MjUuNzY5eiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjMDA2ZjQ2IiBkPSJNNDU1LjE2MiA4ODQuNjhzLTE4LjkyNi0xMi43NTctMjcuMTMxLTE0LjQ4MWMtMTAuNDktMi4yMTMtMjIuMjgtLjQyMi0yNy4zOC0uNjkuMTQzLjE0OSA2LjExNiA0LjQwNyA4LjczNyA3LjA0MSAyLjYyNSAyLjYyIDExLjM2NiA3Ljg1NiAxNi4zMDUgOS4wOTIgMTUuMzU3IDMuODUxIDI5LjQ2OS0uOTYzIDI5LjQ2OS0uOTYzbTUuNDAzIDEuMTExczEyLjEyNC0xMi42MDIgMjQuODEzLTE0LjM0MWMxNC45OTgtMi4wNzkgMjQuODEyIDEuMjM2IDMwLjYzNyAyLjc1NC4xMzQgMC00LjgxNCAyLjM0Ny03LjQzIDQuMTM5LTIuNjI5IDEuNzkxLTkuMzgzIDcuNDQ4LTE5LjcxIDcuNTY4LTEwLjM0Ny4xNTQtMjEuNzYyLTEuMDgyLTIzLjY1NC0uNzk1YTMzMSAzMzEgMCAwIDAtNC42NTYuNjc1IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik00NTQuNTk1IDg2Ny42MmMtNC43NjYtNC40MjUtNS4zOTctOC4xMzItNS4zOTctMTUuMTA2IDAtNi45NiAyLjk4NC0xMy4yNDUgNy43NDYtMTcuNjUxYTI0IDI0IDAgMCAxIDcuNjg4IDE3LjY1MWMwIDYuOTc0LS4yMjYgMTAuNDU0LTQuOTY4IDE0Ljg4bC0yLjYyOSAxLjgzMXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzAwNmY0NiIgZD0iTTQ1MS45MTMgODk0Ljk4N3MzLjEyNC02LjE3IDMuNDA3LTEyLjM4N2MuMjQ5LTUuMjAyLS43MzMtMTAuMzM3LS43MzMtMTAuMzM3aDMuNzg0czEuODkyIDUuNTIzIDEuODkyIDEwLjMzN2MwIDQuODI5LS44NzYgMTEuMjUyLS44NzYgMTEuMjUycy0yLjYyLjQwMy0zLjQ5Mi44MWMtLjg1OC40MjEtMy4xMiAxLjUwNy0zLjEyIDEuNTA3bC0xLjM3NS4zNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjwvZz48cGF0aCBmaWxsPSIjYjJiMmIyIiBkPSJNMjQ5Ljk5MyAyODIuOTIyaDQ4Ljc2NnYtNTguODVoLTQ4Ljc2NnoiLz48cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMi40NjUiIGQ9Ik00NTQuOTY1IDYwMy42NTJINjk0LjM2VjMzOC42MDRINDU0Ljk2NXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgc3Ryb2tlPSIjMDAwIj48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNjA0LjM5MyA1NjguOTkxcy0yLjk2IDMuMDU2LTEuODkyIDUuNjA1YzEuMDg3IDIuNTUzIDIuOTYgNS4yMiAyLjk2IDUuMjJzLS4xMDUtMy43OTggMS4wOTItNC44MjhjMS43My0xLjUyMyA0Ljk1OC0xLjc5MSA0Ljk1OC0xLjc5MXMtMi41NTMtMi4yOC0zLjM3Mi0yLjUzNGMtLjc4Ni0uMjczLTMuNzQ2LTEuNjcyLTMuNzQ2LTEuNjcyem0xNC43ODcgNC40NzRzLTEuNDggMy42ODQgMS4zNTYgNi4wOThjMi44MTYgMi40MzMgNS4yNDUgMi42ODcgNS4yNDUgMi42ODdzLTIuMTYtMy44MzctMS40OC01Ljg2M2MuNjk0LTIuMTEyIDIuNTQ4LTMuNDMgMi41NDgtMy40M3MtMy40OTctMS4xNjQtNC4wMzMtMS4wM2MtLjUzMi4xMi0zLjYzNiAxLjUzOC0zLjYzNiAxLjUzOHptLTQxLjYwNC0xNjUuNDYzLjI2OC0yLjk0LjQwNy0xLjYzOXMtNy42NjQuNjI3LTExLjY5OC0uNTA4Yy00LjAzMy0xLjE0NS03LjY2OC0yLjgwMi0xMS40MzgtNS45NzgtMy43NTYtMy4xOTUtNS4yNC01LjE4Ny03LjkzMy01LjU5LTYuNDU3LTEuMDMtMTEuNDM0IDEuODkyLTExLjQzNCAxLjg5MnM0Ljg1MyAxLjc4NyA4LjQ5MyA2LjIzMmMzLjYxNyA0LjQ3OSA3LjU2NCA2Ljc0IDkuMjc0IDcuMjgxIDIuODIxLjg2MiAxMi42MzEuMjU0IDE1LjMyMy4zNTUgMi42OTIuMTM0IDguNzM3LjkxIDguNzM3LjkxeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJtNTY0LjAwNiA0MTIuMjA4IDEuNi0yLjUzNCAxLjU4NSAyLjMtMy4xODUuMjM0bTMuODg0LS4xMiAxLjg4OC0yLjUzNCAyLjAyMSAyLjI4LTMuOTA5LjI1NG0tMS43NDMtMTUuNjU4IDMuOTA0IDEuNDAzLTMuNDk3IDEuNzcyLS40MDctMy4xNzVtNC43MDMgMS4yODMgMy40OTcuODgyLTIuODE2IDIuMTZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkODVhYWMiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iMS4yMDMiIGQ9Ik02MTMuNDE1IDM5Ny4yMjVzLjAyIDMuNDMuMzU1IDYuNzA2Yy4zMiAzLjE0Mi0xLjAxNiA1Ljg5Ni0uNDk4IDcuNjM1LjQ5OCAxLjc1OC43NDcgMy4xNDIgMS40MjcgNC40MDcuNjQyIDEuMjcuOTk3IDQuNDc5Ljk5NyA0LjQ3OXMtMS44MzUtMS4zMDMtMy41MzUtMi41NjhhNTYgNTYgMCAwIDAtMi44NzQtMi4wNzlzLjM0NSAzLjQzLjUwMiA0LjljLjE4MiAxLjQ3MSAxLjA0IDQuMjQgMi40MyA1Ljg3OCAxLjM3NCAxLjYwNSA0LjEyMyA0LjI0IDQuOTcxIDYuMzUyLjg4MiAyLjEzMS43MDQgNi44MjUuNzA0IDYuODI1cy0yLjIzMi0zLjU2My00LjE0OC00LjIwNWMtMS44ODItLjY2MS02LjAyMS0yLjk1Ni02LjAyMS0yLjk1NnMzLjc5NCAzLjc2NSAzLjc5NCA3LjM0OGMwIDMuNTc4LTEuNTQ3IDcuNjUtMS41NDcgNy42NXMtMS43MTUtMy4yNDMtMy45NDMtNS4zN2MtMi4yNDYtMi4xMTItNS4zNS00LjIzOS01LjM1LTQuMjM5czIuNDI0IDUuNTM3IDIuNDI0IDkuMjc0YzAgMy43NjUtLjY3NiAxMS43NTQtLjY3NiAxMS43NTRzLTEuODkyLTMuMDktMy43ODQtNC41OTNjLTEuOTA3LTEuNDUyLTQuMTM0LTIuNzU1LTQuODMzLTMuNzE3LS42NzYtLjk3OCAyLjI1MSAzLjA3NSAyLjU2NyA1LjUyMy4zMzYgMi40NTIgMS41IDExLjE4NCA5LjEzNSAyMi4zMzYgNC40NiA2LjUxOSAxMS4zNjIgMTcuOTIgMjYuMTUgMTQuMTY5IDE0LjgwNS0zLjczMiA5LjMxMS0yMy42MyA2LjIwNy0zMi45MjMtMy4xMDQtOS4yNzMtNC42NTYtMTkuNTYyLTQuNDc0LTIzLjE2LjE1OC0zLjU2MyAyLjc0NS0xNC4xNTQgMi40MDUtMTYuMTMyLS4zNC0xLjk0LTEuMTQ1LTkuNTA5LjY5NC0xNS42MDYgMS44OTItNi4zNTIgMy40NjQtOC44MTkgNC40OC0xMS40MzkgMS4wMS0yLjYgMS44NjctNC4wNzEgMi4yMTItNi4zNTIuMzQtMi4yOC4zNC02LjUzOC4zNC02LjUzOHMyLjc0NSA1LjA2OCAzLjQ0IDYuODZjLjY4IDEuODA1LjY4IDcuMTYuNjggNy4xNnMuNTEyLTUuMzU1IDQuNjU2LTcuOTU2YzQuMTM4LTIuNjM0IDguOTUyLTUuMzg5IDEwLjE2LTYuODYgMS4yMDItMS40ODQgMS41NTYtMi40NDcgMS41NTYtMi40NDdzLS4zNTQgOS4xNC0yLjkyNyAxMi43MzdjLTEuNzEgMi4zMzMtOC40NSA5LjkzNC04LjQ1IDkuOTM0czMuNDYtMS4zMTcgNS44NjQtMS40NWMyLjQxLS4xODggNC4xMjQgMCA0LjEyNCAwcy0yLjkyNyAyLjI4LTYuNzEgNy44MTZjLTMuNzggNS41MjgtMi4yNDMgNi4wMTctNC45OTIgMTAuNTc3LTIuNzY5IDQuNTYtNC45OTYgNC43MjgtOC40NCA3LjUwMS01LjE3NCA0LjE1My0yLjM4NiAyMC42NzQtMS43MSAyMy4xMjYuNjk0IDIuNDM0IDkuNjMyIDIyLjY2NyA5LjgxIDI3LjU1My4xNTggNC44OTUgMS4wMzQgMTUuODEyLTcuNTgzIDIyLjgyLTUuNTQ3IDQuNTQ1LTE0LjYyNCA0LjU3OS0xNi42OTQgNS44NzctMi4wNzQgMS4yODQtNi4xNzQgNS4zNTUtNi4xNzQgMTMuODM5IDAgOC40OTcgMy4wNyA5Ljc4IDUuNDggMTEuOTA4IDIuNDI0IDIuMTI2IDUuNTEzLjk4MiA2LjIwMyAyLjYyLjcgMS42MTkgMS4wMzUgMi42IDIuMDc0IDMuNTc4IDEuMDM1Ljk2MyAxLjczIDIuMTEyIDEuMzc1IDMuODg1LS4zNCAxLjgxLTQuMzAyIDUuODgyLTUuNjc2IDguODM3LTEuMzkgMi45MDMtNC4xMzkgMTAuNTkxLTQuMTM5IDExLjcyMiAwIDEuMTUtLjMyMSA0LjczMi44NTcgNi41MzggMCAwIDQuMzAyIDUuMDIgMS4zNyA1Ljk5Ny0xLjg4Ny42NDItMy43NC0xLjE4My00LjYzMi0uOTc3LTIuNTcyLjY3NS0zLjkxMyAyLjI2LTQuNjU2IDIuMTI3LTEuNzE0LS4zMjEtMS43MTQtMS4xNjQtMS44OTItMy41ODMtLjE1OC0yLjQzNC0uMDcyLTMuNDMtLjgzOC0zLjQzLTEuMDM1IDAtMS41NTcuODQ4LTEuNzMgMi4xMzItLjE4NiAxLjI5OC0uMTg2IDQuMjItMS4zNzQgNC4yMi0xLjIxMiAwLTIuOTI3LTIuMTEzLTMuOTYxLTIuNTgyLTEuMDM1LS40OTQtMy45NTctLjk4Mi00LjEyNS0yLjI4LS4xNzItMS4zMDMgMS43Mi00LjA3MiAzLjYwNy00LjU2NSAxLjg5Mi0uNDg5IDMuNjIyLTEuNDUxIDIuNDEtMi40MjktMS4yMTItLjk4Mi0yLjQxLS45ODItMy42MDIgMC0xLjIxMi45NzgtMy43ODUuMTQ5LTMuNjIyLTEuMzE3LjE3Ny0xLjQ3LjUxOC0zLjI0OC4zMzYtNC4wNzEtLjE1OC0uNzk2LTIuMjI4LTIuNDM0LjUwMy0zLjkyNCAyLjc2NC0xLjQ1IDMuOTU2IDEuMzIzIDYuNzA2LjgzIDIuNzY0LS40NyA0LjEzOS0xLjQ4NiA1LjE3My0zLjA5IDEuMDM1LTEuNjI0Ljg1My01LjA1NC0xLjAzNC03LjE2Mi0xLjg5My0yLjEzMS0zLjc4LTIuNDY2LTQuNDgtMy43Ny0uNjk0LTEuMjk3LTEuNzEtNC4zOTItMS43MS00LjM5MnMuNDk5IDUuNjk2LjE1OSA2LjUyNGMtLjMzNi44MS0uMTU4IDQuMjItLjE1OCA0LjIycy0xLjg5Mi0yLjExMi0zLjQ0NC0zLjczMWMtMS41MzMtMS42MzgtMy4wODUtNi41Mi0zLjA4NS02LjUycy0uMTYzIDQuNTYtLjE2MyA2LjM2N2MwIDEuNzcyIDIuMDUgMy40MSAxLjM3NSA0LjA3MS0uNjk1LjY0Mi0zLjk1Ny0zLjQzLTQuODE0LTQuMDcxLS44NzctLjY1Ny0zLjYyMi0yLjc3LTQuODM0LTUuMDY4LTEuMTk3LTIuMjgtMi4wNzQtNS41MjMtMi40MS02LjY4Ny0uMzQ0LTEuMTM2LS45MS02LjIxOC0uMzQ0LTcuNTAxLjg1Ny0xLjk0NSAyLjIzNy01LjM3NSAyLjIzNy01LjM3NWgtNi43MTFjLTMuNjAyIDAtNi4xODktMS4xMy03LjU2NCAxLjMwMy0xLjM3IDIuNDQ4LS42OTQgNy4zNDggMS4wMiAxMy43IDEuNzMgNi4zMzIgMi43NDUgOS40NCAyLjI0NyAxMC41OS0uNTAzIDEuMTMtMi43NDUgMy43NTEtMy42MDIgNC4yMjUtLjg3Ny41MDgtMy4yODYuMzM2LTQuMzItLjEzNC0xLjAxNi0uNDkzLTIuNzI2LTEuMzIyLTYuMDEyLTEuMzIyLTMuMjYyIDAtNS4zMzIuMTU0LTYuNTI0LS4xMzQtMS4yMTItLjMzNS00LjEzOS0xLjgwNi01LjUzMy0xLjQ4NS0xLjM3NS4zMzYtMy43NSAxLjU1Mi0zLjEwNCAzLjQzIDEuMDU0IDIuOTM2LTEuMDE1IDMuNTk3LTIuNDA0IDMuNDMtMS4zNzUtLjE3My0yLjU1NC0uNjYxLTQuMzAyLTEuMTM2LTEuNzEtLjUwMy00LjMwMSAwLTMuOTU3LTEuOTczLjMzNi0xLjk2IDEuMDM1LTIuMTEzIDEuODg4LTMuNTY0Ljg3MS0xLjQ5IDEuMTkyLTIuNDMzLjIyNS0yLjUzNC0xLjIwNy0uMTItMi40Mi0uMjU0LTMuMzYzLjUyMi0uOTEuNzYyLTIuMzkgMi40LTMuNjA3IDEuNzkyLTEuMjE3LS42NDItMi4xNTUtMi4wNDYtMi4xNTUtNS4xMiAwLTMuMDU3LTMuMjM0LTUuNzI1LS4yNjktNS41OSAyLjk2LjEzMyA2LjcyNSAyLjI5OCA3LjQuNjQxLjY2Mi0xLjY3Mi4yNTUtMi40MTQtMS4zNS0zLjcxNy0xLjYxNC0xLjI2NS0zLjYyNi0yLjAyNi0xLjQ3LTMuNjg0IDIuMTQ1LTEuNjM4IDIuNjgyLTEuNjM4IDMuNS0yLjU0OC44MDYtLjg4MSAxLjk2LTMuNzUgMy40NjQtMy4wNDIgMi45NTYgMS40MDQuMTQgMy40NDQgMy4xIDYuNzQgMi45NjQgMy4zMSA0LjgzNyA0LjQ3OSA5LjgxNCAzLjk1MiA0Ljk3Mi0uNTAzIDYuMzMzLTEuMTQ1IDYuMzMzLTIuNTQ5cy0uNDE3LTMuOTM3LS41Ni00Ljk2N2MtLjEyLTEuMDE1LjY4NC00LjcxMy42ODQtNC43MTNzLTIuMjg1IDEuNDE4LTIuOTYgMi44MDJjLS42NDcgMS40MDMtMi4wMDIgMy44MDMtMi4wMDIgMy44MDNzLS41NTEtMi44NTUtLjM5My01LjE4N2MuMDktMS4zNjYuNTc1LTMuNzUxLjUyMi00LjIyLS4xMy0xLjI3LTEuMDczLTQuNDYtMS4wNzMtNC40NnMtLjgxIDMuNDQ0LTEuMzM2IDQuNDZjLS41MzcgMS4wMS0uODA1IDUuMTAxLS44MDUgNS4xMDFzLTMuMTU3LTIuNzU0LTIuMjgtNy4zODFjLjY1Ni0zLjU3LS41NDItOC4yNzguNTMxLTkuODE1IDEuMDU0LTEuNTM4IDMuNjAzLTcuNzc1IDkuNzk2LTguMDQzIDYuMTg5LS4yMzQgMTEuMDIyLjI2OSAxMy4xODMuMTU0IDIuMTUtLjE1NCA5LjgxLTEuNTM4IDkuODEtMS41MzhzLTE0LjExNy03LjI0Ny0xNy4zNC05LjQyN2MtMy4yMy0yLjE0Ni04LjIwNi03Ljc1NS05LjgzLTEwLjMwMy0xLjYxLTIuNTUzLTMuMDg1LTcuNTAxLTMuMDg1LTcuNTAxcy0yLjUzNC4xMTUtNC44MzMgMS4zODRjLTIuMjg1IDEuMjUtNC41NjUgMy4xOTUtNS45MDYgNC42OTQtMS4zNiAxLjUzOC0zLjQ5NyA0Ljk4Ny0zLjQ5NyA0Ljk4N3MuMzkzLTQuNDYuMzkzLTUuODYzYzAtMS4zNy0uMjY4LTQuMDg2LS4yNjgtNC4wODZzLTEuNjA1IDYuMTEyLTQuODM0IDguMzkyYy0zLjIyOCAyLjMxMy02Ljk5MyA1LjQ5LTYuOTkzIDUuNDlzLjQxMi0zLjQxMS40MTItNC4xODdjMC0uNzYyLjgwNS00LjcxNC44MDUtNC43MTRzLTIuMjg1IDMuNDEtNS43ODIgNC4wODZjLTMuNDk3LjYyOC04LjYxNy40OTQtOS4wMjUgMi42NzMtLjM5MyAyLjE0MS45NDQgNS4wODIuMTQ0IDYuNi0uODEgMS41MzgtMi41NTMgMi41NTQtMi41NTMgMi41NTRzLTIuMDEyLTEuNjcyLTMuNzY1LTEuNzkyYy0xLjc0OS0uMTM0LTMuMzY4Ljc3Ni0zLjM2OC43NzZzLTEuNDgtMS45MjUtLjk0OC0zLjE5Yy41NS0xLjI3IDMuMjI4LTMuMTc2IDIuNTY3LTMuOTUyLS42NzUtLjc2MS0yLjgzLjI2OC00LjE3Mi44OTYtMS4zMzYuNjQyLTQuMTcyIDEuMjY1LTMuOTA0LS44OTYuMjY5LTIuMTY1Ljk0NC0zLjQzLjI2OS00Ljk2Ny0uNjctMS41MDQtLjI2OS0yLjUzNC44MTktMi45MjIgMS4wNjgtLjM1NCA1LjM3LjExNSA1Ljc3Ny0uODYyLjM5My0xLjAzLTEuMDY4LTIuMy0zLjkwNC0yLjk0MS0yLjgyMi0uNjIzLTQuMTcyLTIuMjk0LTIuNjkyLTMuNjk4czEuODg3LTEuNzcyIDIuNTU4LTMuMDU2LjkzNC0zLjU2OSAzLjUwMS0yLjQxOWMyLjUzNCAxLjEzNSAxLjk5OCAzLjkzNyA0LjcxNCA0LjgzMyAyLjY1OC45MSA4Ljk5LS4zNzMgMTAuMzIyLTEuMTMgMS4zNi0uNzgxIDUuNjU4LTMuOTU3IDcuMTM4LTQuNzMzIDEuNDg1LS43NDIgNy42NTQtNS4zMzYgNy42NTQtNS4zMzZzLTMuNjIxLTIuNTItNC45NzctMy44MThjLTEuMzM2LTEuMjY5LTMuNzQ2LTQuMzEtNC45MzgtNC45NTMtMS4yMTctLjY1Ni03LjEzOC0yLjkyMi05LjE1NC0zLjA1NnMtOC4yMDYtMi4yOC04LjIwNi0yLjI4IDIuODIyLS45MSAzLjc2NS0xLjY3MSAzLjA2Ni0yLjY4OCA0LjE3My0yLjU1NGMxLjA1My4xNCAxLjMxNy4xNCAxLjMxNy4xNHMtNS43NTgtLjI3NC02Ljk3NS0uNjI4Yy0xLjIwNy0uNDA3LTQuNzAzLTIuNTY4LTYuMDQtMi41NjgtMS4zNiAwLTQuMDMzLjUyMy00LjAzMy41MjNzMy42MjEtMi4yOTUgNi41ODEtMi44MDNjMi45Ni0uNDg4IDUuMjQ2LS4zODggNS4yNDYtLjM4OHMtNC41NjUtMS4yNjktNS42NTctMi43ODdjLTEuMDY5LTEuNTM4LTIuMTM3LTMuODA0LTIuOTYtNC44MzQtLjgtMS4wMS0xLjMzNy0yLjY4Mi0yLjgxNy0yLjgwMi0xLjQ4LS4xMzQtNC4wMzggMS43OTItNS41MTQgMS42NTMtMS40Ni0uMTE1LTIuNTUzLTEuMDMtMi42OTctMy4xNzYtLjEtMi4xNzUgMC0xLjQxOC0uNTEyLTIuNTQ4LS41MzctMS4xNjQtMi42OTItMy44MzctLjY4LTQuNDYgMi4wMzUtLjY0MiA2LjMzMi4zNzQgNi43MjUtLjM4OC40MTItLjc2Mi0yLjI4LTMuMDU2LTQuMDI4LTMuOTUyLTEuNzQ5LS44ODEtNC41Ny0yLjQxOS0zLjA5LTMuNjgzIDEuNDg1LTEuMjcgMi45NTUtMS43NzMgMy43NjUtMi45MjIuODA1LTEuMTUgMS43NDgtNC4zMjYgMy40OTctMy4zMTUgMS43NDggMS4wMTYgNC4xNjcgNS45OTcgNS41MTMgNS42MSAxLjM1Ni0uMzg5IDEuNDU2LTMuOTUzIDEuMjEyLTUuNDcxLS4yNjgtMS41MzggMC00LjIwNiAxLjMyMi0zLjk1NyAxLjM1Ni4yNTQgMi40MjQgMi4wMzEgNC41ODQgMi4xOCAyLjEzNy4xMiA1LjM2NS0uNTAzIDUuMDk3Ljk5Ni0uMjY5IDEuNTIzLTEuNDg1IDMuNDE2LTIuOTYgNS4wODctMS40NDIgMS42NzItMi4xMjIgNC45NjgtMS4xOTMgNy4xMjguOTM5IDIuMTggMy4zNzIgNS42MjggNS41MTMgNy4wMTMgMi4xMzcgMS4zOTggNi4xNyAyLjQzMyA4LjczNyA0LjA3MSAyLjU0OSAxLjY3MiA4LjQ3NCA2LjM2NiAxMC40OSA2Ljg3NCAyLjAxMy41MjIgNC4wMyAxLjUzNyA0LjAzIDEuNTM3czIuMjgtMS4wMTUgNS4zODgtMS4wMTVjMy4wODUgMCAxMC4yMDMuNTA4IDEyLjg5NS0uNjQyIDIuNjkyLTEuMTY0IDYuMTg5LTMuMDU2IDUuMTE2LTUuNDktMS4wNjQtMi40LTYuOTg5LTQuNTc5LTYuNDUyLTYuNDcuNTM2LTEuOTA3IDIuNjkyLTIuMDQxIDYuMzA4LTIuMTc1IDMuNjI2LS4xMiA4LjYwMy42NDEgOS41MzItNC40Ni45NDQtNS4wODcgMS4yMTItOC4wMjgtMy44Ny05LjE1OS01LjEyLTEuMTUtOC44OS0xLjI2NC05LjgxLTQuOTY3LS45NTMtMy42ODMtMS44OTItNC41NzQtLjgyNC01LjYwOSAxLjA5Mi0uOTk2IDIuOTYtMS41MTggNi43MjUtMS43NTMgMy43NjUtLjI3MyA4LjA2Mi0uMjczIDkuMjc5LTEuMTgzIDEuMjEyLS44NjIgMS40Ni0zLjI5NiAyLjk0LTQuMzI2IDEuNDc2LS45OTYgNy4yNzctMS45MSA3LjI3Ny0xLjkxczYuOTA3IDMuMzggMTMuMzI2IDguMTQyYzUuNzQzIDQuMjkyIDEwLjkzNiAxMC42MyAxMC45MzYgMTAuNjMiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTU2My44NjIgMzkzLjY0MnMtLjgwNS0yLjI5NS0uOTQ0LTIuOTM3Yy0uMTI0LS42MjctLjIyOS0xLjM3Mi0uMjI5LTEuMzcyczMuODY1LS4wMzEgMy43MjYgMS4yMzNjLS4xMyAxLjI4NC0xLjM0MSAxLjI4NC0xLjYxIDEuNzc4LS4yNjMuNTIyLS45NDMgMS4yOTgtLjk0MyAxLjI5OCIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBzdHJva2Utd2lkdGg9Ii43NSIgZD0ibTU4Mi45NjUgMzg3LjAwMy0uMjgzLTIuMDRzMy42MzYuMDMzIDUuMzg0IDEuMjY0YzIuNjk3IDEuOTEgNC40MjYgNC44NDcgNC4zMDIgNC45NjctLjQ3LjQ1NS0yLjU1My0xLjI3LTQuMDMzLTEuNzcyIDAgMC0xLjA3My4yNTQtMi4xNTYuMjU0LTEuMDczIDAtMS42MS0uNTA4LTEuNzUzLTEuMDE2LS4xMi0uNTIyLjE0My0xLjQwMy4xNDMtMS40MDNsLTEuNjA0LS4yMzV2LS4wMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0ibm9uZSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBkPSJNNjA5LjE4NiA0MTUuNzlzLTEuNjI0LTIuMjk4LTIuMDE3LTMuMDc0Yy0uNDEyLS43NDMtMS4wODctMi4yOC0xLjA4Ny0yLjI4IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik01MTAuNzQgMzkyLjg2NnMyLjI4NCAxLjYzOCA0LjAzMyAxLjg5MmMxLjc0OC4yNjggMy42NC4yNjggMy45MDkuMjY4LjI2MyAwIC44MTktMi41NjcuNTMxLTQuMzItLjk0My01Ljc0NC02LjE4OS03LjAxMy02LjE4OS03LjAxM3MxLjU2NyAzLjQ4Mi44MDUgNS4wODdjLTEuMDczIDIuMjk0LTMuMDkgNC4wODYtMy4wOSA0LjA4NiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTEwLjc0IDM5Mi44NjZzMi4yODQgMS42MzggNC4wMzMgMS44OTJjMS43NDguMjY4IDMuNjQuMjY4IDMuOTA5LjI2OC4yNjMgMCAuODE5LTIuNTY3LjUzMS00LjMyLS45NDMtNS43NDQtNi4xODktNy4wMTMtNi4xODktNy4wMTNzMS41NjcgMy40ODIuODA1IDUuMDg3Yy0xLjA3MyAyLjI5NC0zLjA5IDQuMDg2LTMuMDkgNC4wODZ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik00OTkuODQyIDM5Ny44MzNzLTIuMDE3LTMuNjk4LTYuMzEzLTMuMTk1Yy00LjMwMi41MDgtNy4xMzggMy44MzctNy4xMzggMy44MzdzNC43NDctLjE1MyA1LjkyMS42MjNjMS43NTMgMS4xNSAyLjI4NSA0LjA5IDIuMjg1IDQuMDlzMi41NzItMS41MzcgMy4zNzItMi41NTNjLjgtMS4wMyAxLjg3My0yLjgwMiAxLjg3My0yLjgwMiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNDk5Ljg0MiAzOTcuODMzcy0yLjAxNy0zLjY5OC02LjMxMy0zLjE5NWMtNC4zMDIuNTA4LTcuMTM4IDMuODM3LTcuMTM4IDMuODM3czQuNzQ3LS4xNTMgNS45MjEuNjIzYzEuNzUzIDEuMTUgMi4yODUgNC4wOSAyLjI4NSA0LjA5czIuNTcyLTEuNTM3IDMuMzcyLTIuNTUzYy44LTEuMDMgMS44NzMtMi44MDIgMS44NzMtMi44MDJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik00OTQuNTk3IDQxMi43MTZzLTMuNjIxLjUyMi01LjYzMyAyLjgyMWMtMi4wMzYgMi4yOTQtMS43NDkgNi42Mi0xLjc0OSA2LjYyczIuNDA1LTIuNTM0IDQuNTY1LTIuNTM0IDUuNTE0Ljc2MiA1LjUxNC43NjItMS4wNzMtMi43MDItMS4wNzMtMy44MzdjMC0xLjE0NS0xLjYyNC0zLjgzMi0xLjYyNC0zLjgzMiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNDk0LjU5NyA0MTIuNzE2cy0zLjYyMS41MjItNS42MzMgMi44MjFjLTIuMDM2IDIuMjk0LTEuNzQ5IDYuNjItMS43NDkgNi42MnMyLjQwNS0yLjUzNCA0LjU2NS0yLjUzNCA1LjUxNC43NjIgNS41MTQuNzYyLTEuMDczLTIuNzAyLTEuMDczLTMuODM3YzAtMS4xNDUtMS42MjQtMy44MzItMS42MjQtMy44MzJ6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGQ9Ik01NDQuNjI1IDQyNy42MzJzLTMuODI4IDEuMTE2LTUuMjQgMy4xNzZjLTEuNzQ0IDIuNTQ4LTEuNjIgNS4xMDEtMS42MiA1LjEwMXMzLjIyOS0yLjY2OCA3LjQwMS0xLjUzN2M0LjE3NyAxLjE1IDQuNTY1IDEuNTM3IDYuMzMzIDEuNDE3IDEuNzQ4LS4xMzQgNi4wNS0xLjY3MSA2LjA1LTEuNjcxcy0zLjQ5NyA0LjA3MS0zLjEwNSA2Ljg5M2MuNDA3IDIuNzg3LjkyNSA0LjA1Mi44MTUgNS40NzUtLjI4OCAzLjQ0NC0yLjgzMSA3LjY1LTIuODMxIDcuNjVzMS40OC0uOTEgNC45NzctMS42NzJjMy40NzctLjc2MiA2LjQ1Ny0yLjQzNCA4LjMzLTMuODE4IDEuODczLTEuNDE4IDQuMjk2LTQuODQ4IDQuMjk2LTQuODQ4cy0uNzggNC43MTQgMCA2Ljc1NGMuODA1IDIuMDQ2IDEuMDczIDcuOTA5IDEuMDczIDcuOTA5czIuMjQ3LTEuOTkzIDQuMDI5LTIuOTQxYy45NDQtLjUyMyAzLjM3Mi0xLjc5MiA0LjMyLTMuMzEuNjU3LTEuMDgzIDEuNDgtNS4wNjggMS40OC01LjA2OHMuNTMyIDQuMjkyIDEuODY5IDYuMzdjMS4zNiAyLjAwOCAzLjM1MyA4LjI3OCAzLjM1MyA4LjI3OHMxLjM2LTQuMDcyIDIuODQtNS43NDNjMS40NjEtMS42NTggMy4yMjktMy44MTggMy4zNTQtNS4xMDIuMTI0LTEuMjctLjM5My00LjA1Ny0uMzkzLTQuMDU3bDEuODczIDQuMDU3bS01NC4zMTUgMi45MjJzMi4yODUtMy45MzcgNC40NC01LjIyMWMyLjE2LTEuMjg0IDUuMTIxLTMuNTY0IDUuOTIxLTMuODE4Ljc4Ni0uMjU0IDQuMzAxLTIuMTggNC4zMDEtMi4xOG00LjcxIDI0LjU5OHM1LjE3Mi0yLjY1NCA2LjcyLTMuNTgzYzMuMjMzLTEuODkyIDUuNTEzLTUuMzM2IDUuNTEzLTUuMzM2IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik01MDYuODMgNDYwLjg2cy0yLjAxMS0yLjE0NS01LjUwOC0xLjUyM2MtMy40OTcuNjQyLTUuNzgxIDQuNTk5LTUuNzgxIDQuNTk5czIuOTYtLjc4MSA0LjcxMy0uMzkzYzEuNzQ0LjM5MyAyLjk2IDIuMTY1IDIuOTYgMi4xNjVzMS42MDUtMS40MDQgMi4xNDEtMi4xNjVjLjUzNy0uNzU3IDEuNDYxLTIuNjgzIDEuNDYxLTIuNjgzIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNiNTAwMjciIGQ9Ik01MDYuODMgNDYwLjg2cy0yLjAxMS0yLjE0NS01LjUwOC0xLjUyM2MtMy40OTcuNjQyLTUuNzgxIDQuNTk5LTUuNzgxIDQuNTk5czIuOTYtLjc4MSA0LjcxMy0uMzkzYzEuNzQ0LjM5MyAyLjk2IDIuMTY1IDIuOTYgMi4xNjVzMS42MDUtMS40MDQgMi4xNDEtMi4xNjVjLjUzNy0uNzU3IDEuNDYxLTIuNjgzIDEuNDYxLTIuNjgzaC4wMTV6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik01MDIuODAyIDQ3NC45OTZzLTIuOTYtLjUwMy01LjUwOCAxLjUzOGMtMi41NTMgMi4wNDUtMi42OTcgNS45ODItMi42OTcgNS45ODJzMi40MjktMi4wNDUgNC4zMi0xLjc3MmMxLjg3NC4yMzUgNC4xNTQgMS4yNjUgNC4xNTQgMS4yNjVzLjQxMi0yLjQzNC41MzEtMy4wNTZjLjQxNy0xLjc3OC0uOC0zLjk1Ny0uOC0zLjk1NyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTAyLjgwMiA0NzQuOTk2cy0yLjk2LS41MDMtNS41MDggMS41MzhjLTIuNTUzIDIuMDQ1LTIuNjk3IDUuOTgyLTIuNjk3IDUuOTgyczIuNDI5LTIuMDQ1IDQuMzItMS43NzJjMS44NzQuMjM1IDQuMTU0IDEuMjY1IDQuMTU0IDEuMjY1cy40MTItMi40MzQuNTMxLTMuMDU2Yy40MTctMS43NzgtLjgtMy45NTctLjgtMy45NTd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiNkYjQ0NDYiIGQ9Ik01MDkuNjcxIDQ4OC4wMDZzLS4xOTYgMy43ODQgMS42MDUgNi4wOTdjMS44OTIgMi40MzQgNS4zODkgMi44MDcgNS4zODkgMi44MDdzLTEuMTc4LTIuNTMzLTEuMzU2LTMuODIyYy0uMjY4LTEuOTA2IDEuNjA1LTMuNTY0IDEuNjA1LTMuNTY0cy0xLjczLTEuNzcyLTMuNDc4LTEuNzcyYy0xLjc1MyAwLTMuNzY1LjI1NC0zLjc2NS4yNTQiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2I1MDAyNyIgZD0iTTUwOS42NzEgNDg4LjAwNnMtLjE5NiAzLjc4NCAxLjYwNSA2LjA5N2MxLjg5MiAyLjQzNCA1LjM4OSAyLjgwNyA1LjM4OSAyLjgwN3MtMS4xNzgtMi41MzMtMS4zNTYtMy44MjJjLS4yNjgtMS45MDYgMS42MDUtMy41NjQgMS42MDUtMy41NjRzLTEuNzMtMS43NzItMy40NzgtMS43NzJjLTEuNzUzIDAtMy43NjUuMjU0LTMuNzY1LjI1NHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0ibm9uZSIgZD0iTTU4OS4wMTUgNDk0LjM1N3M5LjY4NSA1Ljk5NyA5LjQxNyAxMC45NjVjLS4yODggNC45NjctNS4zODkgMTEuNDY3LTUuMzg5IDExLjQ2NyIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGI0NDQ2IiBkPSJNNTQ0LjYyNSA1MjEuNTAzcy0yLjQyLTMuMDU2LTUuNzcyLTIuOTM3Yy0zLjM3My4xMzQtNi44NzQgMy4yOTEtNi44NzQgMy4yOTFzNC4xODItLjM1NCA1LjI0NSAxLjAzYzEuMDkyIDEuNDIzIDIuMTYgMy4xNzYgMi4xNiAzLjE3NnMxLjg3OC0uOTk3IDIuNjk3LTEuNjM5Yy44MDUtLjYyMiAyLjU0NC0yLjkyMSAyLjU0NC0yLjkyMSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTQ0LjYyNSA1MjEuNTAzcy0yLjQyLTMuMDU2LTUuNzcyLTIuOTM3Yy0zLjM3My4xMzQtNi44NzQgMy4yOTEtNi44NzQgMy4yOTFzNC4xODItLjM1NCA1LjI0NSAxLjAzYzEuMDkyIDEuNDIzIDIuMTYgMy4xNzYgMi4xNiAzLjE3NnMxLjg3OC0uOTk3IDIuNjk3LTEuNjM5Yy44MDUtLjYyMiAyLjU0NC0yLjkyMSAyLjU0NC0yLjkyMXoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iI2RiNDQ0NiIgZD0iTTUzNC4yNjkgNTM0Ljg2N3MtNC40MjItLjY0Mi02LjU4MiAxLjY1MmMtMi4xNiAyLjI4NS0yLjAxNyA2LjQ5LTIuMDE3IDYuNDlzMi42OTctMi45MjEgNS4xMDItMi42NzJjMi40MjguMjU0IDUuMTIgMS41MzggNS4xMiAxLjUzOHMtLjQxMi0yLjU0OS0uNjgtMy42OTgtLjk0My0zLjMxLS45NDMtMy4zMSIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBkPSJNNTM0LjI2OSA1MzQuODY3cy00LjQyMi0uNjQyLTYuNTgyIDEuNjUyYy0yLjE2IDIuMjg1LTIuMDE3IDYuNDktMi4wMTcgNi40OXMyLjY5Ny0yLjkyMSA1LjEwMi0yLjY3MmMyLjQyOC4yNTQgNS4xMiAxLjUzOCA1LjEyIDEuNTM4cy0uNDEyLTIuNTQ5LS42OC0zLjY5OC0uOTQzLTMuMzEtLjk0My0zLjMxeiIgdHJhbnNmb3JtPSJtYXRyaXgoLjIwMzcgMCAwIC4yMjIwNCAxNTcuMzE1IDE0OC44OSkiLz48cGF0aCBmaWxsPSIjZGI0NDQ2IiBkPSJNNTQzLjgzIDU0OS4wMDdzLTIuMTYgMy4wNTYtLjUzNyA1LjQ3YzEuNjA1IDIuNDM0IDQuOTYzIDMuNTgzIDQuOTYzIDMuNTgzcy0xLjE5OC0xLjc3Mi0uNjYxLTMuODM3Yy40MjYtMS42MTkgMy4yMjgtMy44MTcgMy4yMjgtMy44MTdsLTYuOTkzLTEuMzg1IiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxnIGZpbGw9IiNiNTAwMjciPjxwYXRoIGQ9Ik01NDMuODMgNTQ5LjAwN3MtMi4xNiAzLjA1Ni0uNTM3IDUuNDdjMS42MDUgMi40MzQgNC45NjMgMy41ODMgNC45NjMgMy41ODNzLTEuMTk4LTEuNzcyLS42NjEtMy44MzdjLjQyNi0xLjYxOSAzLjIyOC0zLjgxNyAzLjIyOC0zLjgxN2wtNi45OTMtMS4zODV6bTU5LjAyMyA1Ljc0M3MtMy44ODUtLjkxNS02LjA0NS4zN2MtMi4xNDEgMS4yNjktMy44OSA2LjYyNC0zLjg5IDYuNjI0czMuNDk3LTIuOTIyIDYuMDUtMi41NjhjMi41NDkuNDAzIDQuNDQgMS40MTggNC40NCAxLjQxOHMuMzg5LTIuMTguMTItMy42ODNjLS4xNTctLjkxLS42NzUtMi4xNi0uNjc1LTIuMTYiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZD0iTTYwMi44NTMgNTU0Ljc1cy0zLjg4NS0uOTE1LTYuMDQ1LjM3Yy0yLjE0MSAxLjI2OS0zLjg5IDYuNjI0LTMuODkgNi42MjRzMy40OTctMi45MjIgNi4wNS0yLjU2OGMyLjU0OS40MDMgNC40NCAxLjQxOCA0LjQ0IDEuNDE4cy4zODktMi4xOC4xMi0zLjY4M2MtLjE1Ny0uOTEtLjY3NS0yLjE2LS42NzUtMi4xNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjxnIGZpbGw9IiM5ZjdlMDAiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU2LjQzMiAxNDguNzE0KSI+PGcgc3Ryb2tlLXdpZHRoPSIuNzUiPjxwYXRoIGQ9Im02MTQuOTg4IDM3Ny42MTItMS4zNzUuMTAxYy0uMDYzLjE2OC0uNjggMS4xNS0xLjI2NSAxLjY5LTEuMjE2IDEuMTY1LTMuMDUgMS4yOTktNC4wODYuMzIyYTIuMzQgMi4zNCAwIDAgMS0uNjYtMS45NDVjLS44MDUuNDA3LTEuNjQ0LjQwNy0yLjQzLS4wMzMtMS4yMy0uNzEtMS41MzctMi40LS42NDEtMy44MDQuMTQzLS4yNjguMjg3LS42MjIuNTAzLS44MjRsLS4wOTEtMS41MzctMS42NjIuMzg4LS40OC45MWMtMS4wMzQgMS4xNjktMi41NjcgMS40Ny0zLjMzMy43OC0uMzc0LS4zMi0uNDUzLS41OTItLjYyMy0xLjI1LS4zNzMuMzE4LS4zOTcuNDAzLS44MjQuNTAzLTIuNTQ4LjYyOC0zLjU2NC00Ljk4MS0zLjYyMS02LjQzM2wtLjgzOCAxLjE4NHMuNzUyIDMuMzU3LjM3MyA2LjE5OGMtLjM3MyAyLjgzNi0xLjM3NSA1LjY3Ni0xLjM3NSA1LjY3NiAzLjU1NS45MSA4Ljg3MiAzLjc5OSAxNC4xNDYgNy44NyA1LjI4MyA0LjAzOCA5LjQzNiA4LjQzIDExLjE1IDExLjUwNiAwIDAgMi43MzEtMS41MjMgNS42LTIuNDMzIDIuODQxLS45MyA2LjQ1OC0uOTQ5IDYuNDU4LS45NDlsMS4wMy0xLjAxYy0xLjUxNC4yMi03LjUyMS40NzQtNy40MDEtMi4wNDYuMDA2LS4zODItLjA3My0uNDMuNDg2LS45OC0uOTUxIDAtMS4xMDQuMDg0LTEuNTM1LS4xODQtLjg3Mi0uNTc1LS44NTMtMi4wNDUuMTEtMy4yNjJsLjgzOC0uNjA4LjA1My0xLjYyLTEuNjEuMjIxYy0uMTQzLjIwMS0uNTEyLjQzNi0uNzI4LjY0Mi0xLjI2NSAxLjA5Ny0zLjA4NSAxLjE3OC00LjA4Ni4xNDgtLjYwNC0uNTg5LS43OS0xLjM4NC0uNTMyLTIuMjEzLS43MzMuMjItMS40OTkuMTU0LTIuMTQ2LS4yMi0xLjIyNi0uNzQyLTEuNDYtMi40ODEtLjUxMi0zLjgzMi40NC0uNjYxIDEuMzE3LTEuNDM3IDEuNDctMS41MThsLS4zMy0xLjQyMyIvPjxwYXRoIGQ9Im02MDguNzk0IDM4NC42ODctMS41NTItMS4xOTdjLS4yODItLjIyLS4zNzMtLjU3NS0uMTkxLS43NzYuMTc3LS4xODcuNTUtLjE4Ny44MzguMDE0bDEuNTQ3IDEuMjE3IDEuNTkgMS4yMDJjLjI2OS4yMDIuMzcuNTU2LjE5Ny43NzYtLjE5Ny4xODctLjU3LjE2OC0uODU3LS4wMzNsLTEuNTcyLTEuMjAybS04LjI5Mi01LjY3Ny0xLjIzLS43MjNjLS4zMDctLjE4Ny0uNDY1LS41NDEtLjMyMi0uNzc2LjEyNS0uMjU0LjQ5OC0uMjg4LjgtLjEwNmwxLjIyNy43MjkgMS4yNTUuNzI4Yy4zMDIuMTY3LjQ0NS41MjIuMzIuNzc2LS4xNDMuMjItLjQ5Ny4yNjgtLjgxOS4wODZsLTEuMjMtLjcxNCIvPjwvZz48ZWxsaXBzZSBjeD0iNzIzLjE2NyIgY3k9Ii0yOS4zNiIgZmlsbC1ydWxlPSJldmVub2RkIiBzdHJva2Utd2lkdGg9Ii43NTEiIHJ4PSIuOTU4IiByeT0iLjcxMyIgdHJhbnNmb3JtPSJtYXRyaXgoLjgyMjkxIC41NjgxNyAtLjYxMiAuNzkwODYgMCAwKSIvPjxwYXRoIHN0cm9rZS13aWR0aD0iLjc1IiBkPSJtNjE2LjUyIDM5MS4yOTMgMS4wMTYuOTgyYy4yNS4yMzUuNjQyLjMyLjg1Ny4xMzQuMjE2LS4xNjguMTg3LS41MDgtLjA1Mi0uNzQzbC0xLjAwMS0uOTk2LTEuMDM1LTEuMDE1Yy0uMjQ5LS4yMzUtLjY0Mi0uMzAyLS44NTctLjExNS0uMjMuMTQ4LS4xOTcuNTIyLjA3Mi43NTdsMSAuOTk2Ii8+PGVsbGlwc2UgY3g9IjY3MC45NyIgY3k9Ii0yNjYuMzE3IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZS13aWR0aD0iLjc1MSIgcng9Ii45NTgiIHJ5PSIuNzEzIiB0cmFuc2Zvcm09Im1hdHJpeCguNTkyNTEgLjgwNTU2IC0uODM2NTQgLjU0NzkxIDAgMCkiLz48ZyBzdHJva2Utd2lkdGg9Ii43NSI+PHBhdGggZD0ibTYwNy45NTEgMzY2LjQyOC0yLjgxMi4wODYtLjU1IDQuMTM5LjMuNjU2LjczNC0uMDQ4IDMuNjAyLTIuNDJjLS40LS44MTgtLjgzMS0xLjYxOS0xLjI3NC0yLjQxM3oiLz48cGF0aCBkPSJtNjAwLjMyNSAzNjguNzI3LS4wNzYgMi41ODIgNC4zNzMuNTQxLjY4LS4yODctLjA1Ny0uNzEtMi41NDktMy4zOTVjLS44NDQuMzQyLTEuNjIuNzY5LTIuMzcgMS4yNjl6Ii8+PHBhdGggZD0ibTYwOS4zNjQgMzczLjg3Ni0yLjMzMyAxLjMwMy0yLjU1My0zLjQxLS4wNTItLjY5NS42OC0uMjg3IDQuMzg4LjUyMmMuMDU1Ljg3NC4wMzYgMS43MTQtLjEzIDIuNTY3eiIvPjxjaXJjbGUgY3g9IjYwNC43NTIiIGN5PSIzNzEuMTQ0IiByPSIxLjQ3IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBkPSJNNTkzLjQ3NSAzNjYuNDEzYy0uMDcyLjAxNS0uNjEzLTIuMTgtMS4yMTYtMy4zOTYtLjQwNy0uODgxLTEuODU0LTIuMDI2LTEuODU0LTIuMDI2LjE0My0uMjczIDEuOTY0LS45MyA0LjEzOS40MzYgMS43NjIgMS40NTYtLjE0NCA0LjEyNC0uMTQ0IDQuMTI0cy0uNDY0LjY0Mi0uOTEuODYyIi8+PHBhdGggZD0ibTU5OC4zOSAzNjcuODk4LTEuOTkzIDEuNzI1LTMuMjQ3LTIuODIyLjI4Mi0uNDA3LjExNS0uNjk0IDQuNDAyLS4zMjFjLjE4Ny44MzQuMzI2IDEuNjc0LjQ0MSAyLjUyeiIvPjxwYXRoIGQ9Ik01OTIuODQgMzY2LjQyOGMuMDI0LS43NTEuNDkxLTEuMzQgMS4wMTMtMS4zNDQuNTMuMDI0LjkzLjYyNi45MTUgMS4zNi0uMDI1Ljc1LS40OTggMS4zMjEtMS4wMTMgMS4zNDMtLjU1NC0uMDIxLS45NDQtLjYyMi0uOTE2LTEuMzU5bTI1Ljg5IDYuNzM5LTIuODAyLS4zMDEtMS4xNzQgNC4wMzguMjE2LjY5LjczMi4wMTggMy45MjMtMS45MWEzODEgMzgxIDAgMCAwLS44OTUtMi41MzV6Ii8+PHBhdGggZD0ibTYxMC44MjUgMzc0LjQxNy0uNDQgMi41NTQgNC4yNDQgMS4xMS43MTMtLjIuMDUzLS42OS0yLjAxNy0zLjczNmMtLjg2OC4yNzctMS43MS42Mi0yLjU1My45NjJ6Ii8+PHBhdGggZD0ibTYxOS4wMzUgMzgwLjcwMi0yLjUxNC45OTYtMi4wMTctMy43MTcuMDUyLS43MDkuNzE0LS4xODYgNC4yNDQgMS4xMTZjLS4xMTUuODQzLS4yOCAxLjY3OS0uNDc5IDIuNXoiLz48Y2lyY2xlIGN4PSI2MTQuODY4IiBjeT0iMzc3LjU3NCIgcj0iMS40NyIgZmlsbC1ydWxlPSJldmVub2RkIi8+PHBhdGggZD0ibTYyOC4xMzIgMzgxLjkwNC41MTIgMi42NS00LjE1MyAxLjM4NC0uNzMzLS4xNDktLjA4Ni0uNjk0IDEuNzMtMy44MzdjLjkxNC4xOTkgMS44MjEuNDI0IDIuNzMuNjQ2eiIvPjxwYXRoIGQ9Im02MjcuMzg0IDM4OS40ODctMi42NTguNTktMS40Ny0zLjk1My4xNjctLjY3NS43MzMtLjEgNC4wNDcgMS42NTdxLS40MDUgMS4yNDItLjgxOSAyLjQ4MXoiLz48cGF0aCBkPSJtNjIwLjE3NSAzODIuMTUzLS44NTcgMi40NTMgNC4wNTIgMS42MzguNzQzLS4xLjE0My0uNjc2LTEuNDQxLTMuOTM3cS0xLjMyLjMwOS0yLjY0LjYyMnoiLz48Y2lyY2xlIGN4PSI2MjMuNzMzIiBjeT0iMzg1LjYwNyIgcj0iMS40NyIgZmlsbC1ydWxlPSJldmVub2RkIi8+PHBhdGggZD0iTTYzMS4xOTcgMzk1LjMzYy0uMDE1LjA2OCAyLjM3Ni4xMiAzLjc1MS40MjIuOTc3LjIwNiAyLjQ5NiAxLjMwMyAyLjQ5NiAxLjMwMy4yNjgtLjIuNTM2LTIuMDEyLTEuMzM3LTMuNzUtMS44NzMtMS4zMzctNC4yMTUgMS4wMTUtNC4yMTUgMS4wMTVzLS41NjUuNTU2LS42OTUgMS4wMSIvPjxwYXRoIGQ9Im02MjguNjMgMzkxLjA3Mi0xLjM3IDIuMjEzIDMuNjAyIDIuNDM0LjQ0LS4zODguNTktLjIwMS0uNTUxLTQuMTU4cS0xLjM1Ni4wNTUtMi43MTEuMXoiLz48cGF0aCBkPSJNNjMxLjMwOCAzOTUuOTM2Yy43NDUtLjEzNSAxLjI2Ny0uNjcgMS4xNDktMS4xNTYtLjEzLS41MS0uODMzLS44MDYtMS41OC0uNjY2LS43NS4xNTMtMS4yNjIuNjU3LTEuMTM3IDEuMTguMTEzLjQ4NS44MjIuNzgyIDEuNTY4LjY0MiIvPjwvZz48L2c+PC9nPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNzYuNjI4IDIzNS4wMDZzLjA1Ny4wOTQuMDQ0LjE0MmMtLjAxLjA0LS4wODguMDgyLS4wODguMDgyLjE3NC4wNjYuMjY1LjAxOS4zMzQtLjAyOC0uMDEzLS4xMTktLjEtLjE1Mi0uMTc0LS4xODktLjAzNS0uMDE3LS4xMTYtLjAwNy0uMTE2LS4wMDciLz48ZyBmaWxsPSIjOWY3ZTAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIuNzUxIiB0cmFuc2Zvcm09Im1hdHJpeCguMTcyNzggLjExNzYyIC0uMTE3MTMgLjE4MTY2IDE1Ni40MzIgMTQ4LjcxNCkiPjxlbGxpcHNlIGN4PSI3MDUuMSIgY3k9IjMuMjM3IiByeD0iLjk1OCIgcnk9Ii43MTMiLz48ZWxsaXBzZSBjeD0iNzE1LjMxMiIgY3k9IjMuMDM5IiByeD0iLjk1OCIgcnk9Ii43MTMiLz48L2c+PHBhdGggZmlsbD0iI2NlMTEyNiIgZD0iTTIzNC4zODcgMjgyLjY2N2MwLTEwLjY3IDcuMDUyLTE5LjMyIDE1Ljc1MS0xOS4zMiA4LjcwMiAwIDE1Ljc1NSA4LjY1IDE1Ljc1NSAxOS4zMnMtNy4wNTMgMTkuMzItMTUuNzU0IDE5LjMyYy04LjcgMC0xNS43NTItOC42NS0xNS43NTItMTkuMzIiLz48cGF0aCBmaWxsPSIjYjUwMDI3IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMi44ODIiIGQ9Ik0zNzguMzUyIDYwMi41MDJjMC00OC4wNTkgMzQuNjIzLTg3LjAxNiA3Ny4zMjctODcuMDE2IDQyLjcxOCAwIDc3LjM0MSAzOC45NTcgNzcuMzQxIDg3LjAxNnMtMzQuNjIzIDg3LjAxNi03Ny4zNCA4Ny4wMTZjLTQyLjcwNSAwLTc3LjMyOC0zOC45NTctNzcuMzI4LTg3LjAxNnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PHBhdGggZmlsbD0iIzAwNWJiZiIgZmlsbC1vcGFjaXR5PSIuOTQxIiBkPSJNMjM5LjA2IDI4Mi42M2MwLTcuODI1IDQuOTYtMTQuMTY3IDExLjA4NS0xNC4xNjcgNi4xMjIgMCAxMS4wODMgNi4zNDIgMTEuMDgzIDE0LjE2NyAwIDcuODI4LTQuOTYgMTQuMTc0LTExLjA4MyAxNC4xNzQtNi4xMjYgMC0xMS4wODUtNi4zNDYtMTEuMDg1LTE0LjE3NCIvPjxnIHN0cm9rZT0iIzAwMCI+PHBhdGggZmlsbD0iIzAwNDRhZCIgc3Ryb2tlLXdpZHRoPSIyLjg4MiIgZD0iTTQwMS4yOTIgNjAyLjMzNGMwLTM1LjI0IDI0LjM0OC02My44MDMgNTQuNDItNjMuODAzIDMwLjA1NCAwIDU0LjQwNyAyOC41NjMgNTQuNDA3IDYzLjgwMyAwIDM1LjI1NS0yNC4zNTMgNjMuODM3LTU0LjQwNiA2My44MzctMzAuMDczIDAtNTQuNDItMjguNTgyLTU0LjQyLTYzLjgzN3oiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PGcgZmlsbD0iIzlmN2UwMCI+PHBhdGggZD0iTTQzMC4wMDkgNTU4LjQxcy02LjQ2MiA3LjA4LTYuNDYyIDEzLjYzMmMwIDYuNTkxIDIuNzMgMTIuMDYxIDIuNzMgMTIuMDYxLS45NzctMi42LTMuNjE2LTQuNDc0LTYuNzItNC40NzQtMy45MjMgMC03LjExOCAzLjAwOS03LjExOCA2Ljc0IDAgMS4wODMuNjYgMi43NjkgMS4xNiAzLjY5OGwyLjMxNyA0LjY4Yy43NjctMS43MjUgMi41NzMtMi42ODcgNC42NzYtMi42ODcgMi44MTEgMCA1LjEwMSAyLjE0NiA1LjEwMSA0LjgxOCAwIC40MDMtLjA1My44MS0uMTU4IDEuMTc5bC01LjguMDJ2NC45MzRoNS4xNzJsLTMuODUgNy42MzUgNS4xLTEuOTkzIDMuODUyIDQuMzQgMy45OTUtNC4zNCA1LjA4NyAxLjk5My0zLjgzNy03LjYzNWg1LjE3M3YtNC45MzRsLTUuODE1LS4wMmMtLjEwNS0uMzctLjEyNC0uNzc2LS4xMjQtMS4xNzkgMC0yLjY3MiAyLjI0Ni00LjgxOCA1LjA2My00LjgxOCAyLjEwMyAwIDMuOTA5Ljk2MiA0LjY5IDIuNjg3bDIuMjk5LTQuNjhjLjUwMy0uOTMgMS4xNjQtMi42MTUgMS4xNjQtMy42OTggMC0zLjczMS0zLjE3Ni02Ljc0LTcuMTE5LTYuNzQtMy4xMDQgMC01LjcyNCAxLjg3My02LjcwNiA0LjQ3NCAwIDAgMi43MTItNS40NyAyLjcxMi0xMi4wNjEgMC02LjU1My02LjU5Ni0xMy42MzItNi41OTYtMTMuNjMyIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Ik00MTkuNzM0IDYwMy4wMWgyMC43MDh2LTQuOTM0aC0yMC43MDh6bTYwLjg0NC00NC42cy02LjQ1NyA3LjA4LTYuNDU3IDEzLjYzMmMwIDYuNTkxIDIuNzExIDEyLjA2MSAyLjcxMSAxMi4wNjEtLjk2My0yLjYtMy42MDItNC40NzQtNi43MDYtNC40NzQtMy45NDIgMC03LjExOCAzLjAwOS03LjExOCA2Ljc0IDAgMS4wODMuNjYxIDIuNzY5IDEuMTYgMy42OThsMi4yOTggNC42OGMuNzktMS43MjUgMi41OTItMi42ODcgNC42OTUtMi42ODcgMi44MTYgMCA1LjA4MiAyLjE0NiA1LjA4MiA0LjgxOCAwIC40MDMtLjAzNS44MS0uMTM5IDEuMTc5bC01LjguMDJ2NC45MzRoNS4xNzJsLTMuODUgNy42MzUgNS4wODItMS45OTMgMy44NyA0LjM0IDMuOTgtNC4zNCA1LjEwMiAxLjk5My0zLjg1Ni03LjYzNWg1LjE3M3YtNC45MzRsLTUuNzk2LS4wMmMtLjExLS4zNy0uMTQzLS43NzYtLjE0My0xLjE3OSAwLTIuNjcyIDIuMjY1LTQuODE4IDUuMDg3LTQuODE4IDIuMTAzIDAgMy45MDQuOTYyIDQuNjcgMi42ODdsMi4zMTktNC42OGMuNTAzLS45MyAxLjE1NC0yLjYxNSAxLjE1NC0zLjY5OCAwLTMuNzMxLTMuMTg1LTYuNzQtNy4xMTMtNi43NC0zLjEgMC01Ljc0OCAxLjg3My02LjcyIDQuNDc0IDAgMCAyLjcyNS01LjQ3IDIuNzI1LTEyLjA2MSAwLTYuNTUzLTYuNTk2LTEzLjYzMi02LjU5Ni0xMy42MzJtLTI1LjI3OCA0My40OThzLTYuNDU3IDcuMDgtNi40NTcgMTMuNjUyIDIuNzMgMTIuMDQyIDIuNzMgMTIuMDQyYy0uOTgxLTIuNjAxLTMuNjA2LTQuNDc0LTYuNzI1LTQuNDc0LTMuOTIzIDAtNy4xMTggMy4wMDgtNy4xMTggNi43NCAwIDEuMDk2LjY2MSAyLjc2OCAxLjE2IDMuNjk3bDIuMzE4IDQuNjhjLjc4NS0xLjcyNCAyLjU2Ny0yLjcwMSA0LjY3LTIuNzAxIDIuODIyIDAgNS4xMDYgMi4xNiA1LjEwNiA0LjgzMyAwIC40MjEtLjA1Mi44MjQtLjE2MiAxLjE5N2wtNS43OTYuMDE1djQuOTM0aDUuMTkybC0zLjg1NiA3LjYzNiA1LjA4Ny0yLjAwOCAzLjg1MSA0LjM0IDMuOTk1LTQuMzQgNS4xMDIgMi4wMDgtMy44Ny03LjYzNmg1LjE4N3YtNC45MzRsLTUuNzk2LS4wMTVhNC40IDQuNCAwIDAgMS0uMTQ0LTEuMTk3YzAtMi42NzMgMi4yNzEtNC44MzMgNS4wODgtNC44MzMgMi4wOTggMCAzLjg4NC45NzcgNC42NzUgMi43MDFsMi4zMTgtNC42OGMuNDk0LS45MjkgMS4xNi0yLjYgMS4xNi0zLjY5NyAwLTMuNzMyLTMuMTk2LTYuNzQtNy4xMTktNi43NC0zLjEwNCAwLTUuNzI0IDEuODczLTYuNzI1IDQuNDc0IDAgMCAyLjczLTUuNDcgMi43My0xMi4wNDJzLTYuNjItMTMuNjUyLTYuNjItMTMuNjUyIiB0cmFuc2Zvcm09Im1hdHJpeCguMjAzNyAwIDAgLjIyMjA0IDE1Ny4zMTUgMTQ4Ljg5KSIvPjxwYXRoIGQ9Ik00NDUuMDEyIDY0Ni41MjNoMjAuNzA3di00LjkzNGgtMjAuNzA3em0yNS4yNzItNDMuNTEzaDIwLjcwOHYtNC45MzRoLTIwLjcwOHoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDM3IDAgMCAuMjIyMDQgMTU3LjMxNSAxNDguODkpIi8+PC9nPjwvZz48ZyBzdHJva2U9IiMwMDAiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMy45NzMiIGQ9Ik00NTUuODgyIDkwMy43NjhjLTYwLjYwMSAwLTEyMC42NjYtMTUuMjU3LTE3MS4xNjQtNDAuNjMtMzcuMjIzLTE4LjkzNS02MS45MDQtNTcuMTEyLTYxLjkwNC0xMDAuNzk3VjYwMy45MmwtLjI5OC0yNjUuMzE2aDQ2NS40OThsLjAxOCAyNjUuMzE2djE1OC40MmMwIDQzLjY4NS0yNC42OCA4MS44NjItNjEuOTA3IDEwMC43OTctNTAuNDk0IDI1LjM3My0xMDkuNjIyIDQwLjYzLTE3MC4yNDIgNDAuNjN6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjxwYXRoIGZpbGw9IiM5ZjdlMDAiIGZpbGwtcnVsZT0iZXZlbm9kZCIgc3Ryb2tlLXdpZHRoPSIxLjMiIGQ9Ik03NDcuNDAyIDgwNy4xNzFoMTA2LjEwNHYyNy43NTlINzQ3LjQwMnoiIHRyYW5zZm9ybT0ibWF0cml4KC4yMDkxOSAwIDAgLjIyMjA0IDE1NC44MiAxNDguODkpIi8+PHBhdGggZmlsbD0iIzlmN2UwMCIgc3Ryb2tlLXdpZHRoPSIxLjMiIGQ9Ik01Ni4zNzcgODA3LjE3MWgxMDYuMTE0djI3Ljc1OUg1Ni4zNzd6IiB0cmFuc2Zvcm09Im1hdHJpeCguMjA5MTkgMCAwIC4yMjIwNCAxNTQuODIgMTQ4Ljg5KSIvPjwvZz48L3N2Zz4=",
  "hi": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iOTAwIiBoZWlnaHQ9IjYwMCIgZmlsbD0iIzA3MDM4RCIgdmlld0JveD0iLTQ1IC0zMCA5MCA2MCI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTS00NS0zMGg5MHY2MGgtOTB6Ii8+PHBhdGggZmlsbD0iI0ZGNjgyMCIgZD0iTS00NS0zMGg5MHYyMGgtOTB6Ii8+PHBhdGggZmlsbD0iIzA0NkEzOCIgZD0iTS00NSAxMGg5MHYyMGgtOTB6Ii8+PGNpcmNsZSByPSI5LjI1Ii8+PGNpcmNsZSByPSI4IiBmaWxsPSIjRkZGIi8+PGNpcmNsZSByPSIxLjYiLz48ZyBpZD0iZCI+PGcgaWQ9ImMiPjxnIGlkPSJiIj48ZyBpZD0iYSI+PHBhdGggZD0ibTAtOCAuMyA0LjgxNEwwLS44MDJsLS4zLTIuMzg0eiIvPjxjaXJjbGUgY3k9Ii04IiByPSIuMzUiIHRyYW5zZm9ybT0icm90YXRlKDcuNSkiLz48L2c+PHVzZSB4bGluazpocmVmPSIjYSIgdHJhbnNmb3JtPSJzY2FsZSgtMSkiLz48L2c+PHVzZSB4bGluazpocmVmPSIjYiIgdHJhbnNmb3JtPSJyb3RhdGUoMTUpIi8+PC9nPjx1c2UgeGxpbms6aHJlZj0iI2MiIHRyYW5zZm9ybT0icm90YXRlKDMwKSIvPjwvZz48dXNlIHhsaW5rOmhyZWY9IiNkIiB0cmFuc2Zvcm09InJvdGF0ZSg2MCkiLz48dXNlIHhsaW5rOmhyZWY9IiNkIiB0cmFuc2Zvcm09InJvdGF0ZSgxMjApIi8+PC9zdmc+",
  "vi": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5MDAiIGhlaWdodD0iNjAwIiB2aWV3Qm94PSIwIDAgMzAgMjAiPjxwYXRoIGZpbGw9InJlZCIgZD0iTTAgMGgzMHYyMEgweiIvPjxwYXRoIGZpbGw9IiNmZmViMDAiIGQ9Im0xNSA0LTMuNTMgMTAuODUgOS4yNC02LjdIOS4yOWw5LjI0IDYuN3oiLz48L3N2Zz4=",
  "de": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDUgMyI+PHBhdGggZD0iTTAgMGg1djNIMHoiLz48cGF0aCBmaWxsPSIjRDAwIiBkPSJNMCAxaDV2MkgweiIvPjxwYXRoIGZpbGw9IiNGRkNFMDAiIGQ9Ik0wIDJoNXYxSDB6Ii8+PC9zdmc+",
  "pl": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NDAiIGhlaWdodD0iNDAwIiB2aWV3Qm94PSIwIDAgOCA1Ij48cGF0aCBmaWxsPSIjZGMxNDNjIiBkPSJNMCAwaDh2NUgweiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0wIDBoOHYyLjVIMHoiLz48L3N2Zz4=",
  "zh": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iOTAwIiBoZWlnaHQ9IjYwMCI+PHBhdGggZmlsbD0iI0VFMUMyNSIgZD0iTTAgMGg5MDB2NjAwSDAiLz48ZyB0cmFuc2Zvcm09Im1hdHJpeCgzIDAgMCAzIDE1MCAxNTApIj48cGF0aCBpZD0iYSIgZmlsbD0iI0ZGMCIgZD0ibTAtMzAgMTcuNjM0IDU0LjI3LTQ2LjE2Ni0zMy41NGg1Ny4wNjRsLTQ2LjE2NiAzMy41NFoiLz48L2c+PHVzZSB4bGluazpocmVmPSIjYSIgdHJhbnNmb3JtPSJyb3RhdGUoMjMuMDM2IDIuNzg0IDc2Ni4wODIpIi8+PHVzZSB4bGluazpocmVmPSIjYSIgdHJhbnNmb3JtPSJyb3RhdGUoNDUuODcgMzguMjAxIDQ4NS4zOTYpIi8+PHVzZSB4bGluazpocmVmPSIjYSIgdHJhbnNmb3JtPSJyb3RhdGUoNjkuOTQ1IDI5Ljg5MiAzNjIuMzI4KSIvPjx1c2UgeGxpbms6aHJlZj0iI2EiIHRyYW5zZm9ybT0icm90YXRlKDIwLjY2IC01OTAuNjYgOTU3Ljk1NSkiLz48L3N2Zz4=",
  "ja": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5MDAiIGhlaWdodD0iNjAwIj48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMCAwaDkwMHY2MDBIMHoiLz48Y2lyY2xlIGZpbGw9IiNiYzAwMmQiIGN4PSI0NTAiIGN5PSIzMDAiIHI9IjE4MCIvPjwvc3ZnPg==",
  "ko": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5MDAiIGhlaWdodD0iNjAwIiB2aWV3Qm94PSItNzIgLTQ4IDE0NCA5NiI+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTS03Mi00OHY5Nkg3MnYtOTZ6Ii8+PGcgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjQiPjxwYXRoIGQ9Ik0tMzQuOTQ2LTM3LjcyLTQ4LjI2LTE3Ljc1bTQuOTkyIDMuMzI4IDEzLjMxMy0xOS45N200Ljk5MiAzLjMyOS0xMy4zMTIgMTkuOTY5bTYzLjIzNiA0Mi4xNTcgNi4xMDEtOS4xNTJtMS4xMS0xLjY2NCA2LjEwMS05LjE1M200Ljk5MyAzLjMyOC02LjEwMiA5LjE1M20tMS4xMSAxLjY2NC02LjEwMSA5LjE1Mm00Ljk5MiAzLjMyOSA2LjEwMi05LjE1M20xLjExLTEuNjY0IDYuMS05LjE1M00tNDguMjU5IDE3Ljc1bDEzLjMxMyAxOS45N200Ljk5Mi0zLjMyOS02LjEwMi05LjE1Mm0tMS4xMDktMS42NjQtNi4xMDItOS4xNTNtNC45OTMtMy4zMjggMTMuMzEyIDE5Ljk3bTYzLjIzNi00Mi4xNTgtNi4xMDEtOS4xNTNtLTEuMTEtMS42NjQtNi4xMDEtOS4xNTJtNC45OTItMy4zMjggMTMuMzEzIDE5Ljk2OW00Ljk5Mi0zLjMyOC02LjEwMi05LjE1M20tMS4xMS0xLjY2NC02LjEtOS4xNTMiLz48L2c+PHBhdGggZmlsbD0iI2NkMmUzYSIgZD0iTTkuOTg1IDYuNjU2QTE4IDE4IDAgMSAxLTE5Ljk3LTEzLjMxM2EyNCAyNCAwIDEgMSAzOS45MzggMjYuNjI2Ii8+PHBhdGggZmlsbD0iIzAwNDdhMCIgZD0iTTAgMGExMiAxMiAwIDEgMSAxOS45NyAxMy4zMTMgMjQgMjQgMCAxIDEtMzkuOTQtMjYuNjI2QTEyIDEyIDAgMSAwIDAgMCIvPjwvc3ZnPg==",
  "pt": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iNjAwIiBoZWlnaHQ9IjQwMCI+PHBhdGggZmlsbD0icmVkIiBkPSJNMCAwaDYwMHY0MDBIMHoiLz48cGF0aCBmaWxsPSIjMDYwIiBkPSJNMCAwaDI0MHY0MDBIMHoiLz48ZyBmaWxsPSIjZmYwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9Ii41NzMiPjxwYXRoIGQ9Ik0zMTguMjQgMjYyLjA0Yy0zMC4yMS0uOTEtMTY4Ljc0LTg3LjM4LTE2OS42OS0xMDEuMTVsNy42NS0xMi43NTdjMTMuNzQgMTkuOTY2IDE1NS4zNiAxMDQuMDYgMTY5LjI3IDEwMS4wOGwtNy4yMyAxMi44MjMiLz48cGF0aCBkPSJNMTU0LjU5IDE0Ni40Yy0yLjcxIDcuMjk0IDM2LjE0OSAzMS4zMTggODIuOTAzIDU5Ljc1NCA0Ni43NTIgMjguNDM0IDg3LjA2NSA0Ni4wMDYgOTAuMDUzIDQzLjQ4Ni4xODMtLjMyNSAxLjQ3LTIuNTQgMS4zNTItMi41MjMtLjU2Ljg0NC0xLjkyMyAxLjExLTQuMDUuNDk3LTEyLjYzMi0zLjY0My00NS41NzYtMTguNzY1LTg2LjM3NS00My41MDYtNDAuNzk4LTI0Ljc0My03Ni4yOTQtNDcuNTQ0LTgxLjgxLTU3LjIzMi0uMzg0LS42NzEtLjY1OC0xLjg5Ni0uNjAyLTIuODQ4bC0uMTM0LS4wMDItMS4xNzUgMi4wNTN6bTE2NC4zNiAxMTYuMDRjLS41MTIuOTMtMS40NjcuOTYtMy4yODIuNzYxLTExLjMtMS4yNS00NS41ODktMTcuOTI1LTg2LjE2Mi00Mi4yMTMtNDcuMjEtMjguMjYtODYuMi01NC4wMS04MS45Ny02MC43NGwxLjE1MS0yLjAzNC4yMjcuMDdjLTMuODA0IDExLjQwNSA3Ni45NDggNTcuNTc4IDgxLjcwMiA2MC41MjIgNDYuNzI0IDI4Ljk0NyA4Ni4xMTUgNDUuODUxIDg5LjYwMSA0MS40NThsLTEuMjY4IDIuMTgxdi0uMDAyeiIvPjxwYXRoIGQ9Ik0yNDAuMTcgMTY5LjIzYzMwLjIzNy0uMjM5IDY3LjU1LTQuMTMyIDg5LjAyMy0xMi42OWwtNC42MjYtNy41MTdjLTEyLjY5MyA3LjAyNS01MC4yMSAxMS42NDQtODQuNjUzIDEyLjMzNS00MC43MzYtLjM3NS02OS40OS00LjE2OC04My44OTctMTMuODM1bC00LjM2NyA4LjAwNWMyNi40ODQgMTEuMjA3IDUzLjYyMyAxMy41ODcgODguNTIgMTMuNzAzIi8+PHBhdGggZD0iTTMzMC40NCAxNTYuNzFjLS43MzkgMS4xODItMTQuNzQzIDYuMDExLTM1LjM3MyA5LjU3NS0xMy45ODggMi4xMzMtMzIuMjM0IDMuOTU2LTU1LjAwNCAzLjk3OC0yMS42MzMuMDItMzkuMzA1LTEuNTItNTIuNjg0LTMuMzMzLTIxLjY1Ni0zLjM5NS0zMi44MzMtOC4xMi0zNi45NjUtOS43OS4zOTUtLjc4NS42NS0xLjMzNyAxLjAzLTIuMDcgMTEuODk1IDQuNzM2IDIzLjEyNCA3LjU5MSAzNi4yOCA5LjYxNSAxMy4yOSAxLjggMzAuNzUgMy4zNjIgNTIuMjc1IDMuMzQyIDIyLjY2NC0uMDIzIDQwLjcxLTEuOTg0IDU0LjYxNi00LjA1MyAyMS4xNTUtMy40MTIgMzIuNzExLTcuODA0IDM0LjMzNC05Ljg0M2wxLjQ5NCAyLjU3OWgtLjAwMnptLTQuMDYtNy42MjNjLTIuMjkzIDEuODQyLTEzLjcxOCA1Ljg5NC0zMy44MiA5LjEwNC0xMy40MTQgMS45MjItMzAuNDcxIDMuNjQzLTUyLjI2NCAzLjY2NC0yMC43MDQuMDItMzcuNjItMS4zNzUtNTAuNDg1LTMuMjQ5LTIwLjQxNC0yLjY2Ni0zMS4yOC03LjQ3NS0zNS4xOTYtOC44NzdxLjU4My0xLjAxIDEuMTk0LTIuMDE0YzMuMDQ4IDEuNTM1IDEzLjUzMyA1Ljc5MSAzNC4yMjYgOC43MjMgMTIuNzIgMS44MDMgMjkuNjYgMy4xNDcgNTAuMjYyIDMuMTI2IDIxLjY5LS4wMjIgMzguNTUzLTEuNzc2IDUxLjg4My0zLjY4OCAyMC4yMDUtMi43OCAzMS4wNzctNy45NDggMzIuNzI4LTkuMjQxbDEuNDczIDIuNDV6TTE0MC44OCAyMDUuNjZjMTguNTk4IDEwLjAwMyA1OS45MDUgMTUuMDQ0IDk4Ljk5NCAxNS4zOTEgMzUuNTkxLjA1NiA4MS45NTgtNS41MDIgOTkuMjk3LTE0LjY5bC0uNDc3LTEwLjAxMmMtNS40MjUgOC40NzctNTUuMTEzIDE2LjYwOS05OS4yMDYgMTYuMjc2LTQ0LjA5My0uMzMyLTg1LjAzOC03LjE0My05OC42ODctMTUuOTU5bC4wOCA4Ljk5MSIvPjxwYXRoIGQ9Ik0zNDAuMTIgMjA0LjIydjIuMzg3Yy0yLjYwNSAzLjExNi0xOC45NDUgNy44MjYtMzkuNDM2IDExLjE0Mi0xNS41OTUgMi4zOTEtMzUuOTI3IDQuMTk1LTYxLjI2MiA0LjE5NS0yNC4wNyAwLTQzLjI2My0xLjcxNi01OC4xNDgtNC4wMDEtMjMuNTMtMy40MjctMzguNTgtOS40MjctNDEuNi0xMS4yMTdsLjAxMy0yLjc4NmM5LjA3NSA2LjAzNCAzMy42NjEgMTAuNDQ3IDQxLjkxNyAxMS43OTggMTQuNzg4IDIuMjcgMzMuODY4IDMuOTc0IDU3LjgxNyAzLjk3NCAyNS4yMTYgMCA0NS40MzQtMS43OTIgNjAuOTMxLTQuMTY3IDE0LjcwMS0yLjEyMyAzNS42NDQtNy42NDYgMzkuNzY3LTExLjMyNGguMDAxem0uMDEtOC40OTJ2Mi4zODdjLTIuNjA1IDMuMTE0LTE4Ljk0NSA3LjgyNC0zOS40MzYgMTEuMTQtMTUuNTk1IDIuMzkxLTM1LjkyNyA0LjE5NS02MS4yNjIgNC4xOTUtMjQuMDcgMC00My4yNjMtMS43MTUtNTguMTQ4LTQuMDAyLTIzLjUzLTMuNDI0LTM4LjU4LTkuNDI0LTQxLjYtMTEuMjE2bC4wMTMtMi43ODVjOS4wNzUgNi4wMzMgMzMuNjYxIDEwLjQ0NyA0MS45MTcgMTEuNzk2IDE0Ljc4OCAyLjI3MiAzMy44NjggMy45NzYgNTcuODE3IDMuOTc2IDI1LjIxNiAwIDQ1LjQzNC0xLjc5MiA2MC45MzEtNC4xNyAxNC43MDEtMi4xMjMgMzUuNjQ0LTcuNjQ2IDM5Ljc2Ny0xMS4zMjN6TTIzOS43OSAyNjAuMzJjLTQyLjc3Mi0uMjU1LTc5LjQyMS0xMS42NTktODcuMTYtMTMuNTQ0bDUuNjQzIDguODM0YzEzLjY3IDUuNzUgNDkuNDI0IDE0LjMyIDgxLjkyNyAxMy4zNzFzNjAuOTEtMy40NjYgODAuOTI4LTEzLjIxbDUuNzg3LTkuMTU2Yy0xMy42NDIgNi40MjUtNjAuMDY4IDEzLjYzOS04Ny4xMjUgMTMuNzA1Ii8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuNTUiIGQ9Ik0zMjMuMyAyNTMuNzJhMTM0IDEzNCAwIDAgMS0yLjU5NiAzLjgzYy05LjQ0MiAzLjMyOS0yNC4zMiA2LjgyNC0zMC41OTcgNy44NDMtMTIuODI0IDIuNjQzLTMyLjY2NSA0LjU5NC01MC4yNzQgNC42MDMtMzcuODktLjU1NC02OC45MDUtNy45NzItODMuNDk2LTE0LjI5OWwtMS4xNzgtMi4wMjQuMTkzLS4zMDQgMS45OTYuNzc0YzI1Ljk0OCA5LjI4NCA1NS4wOTEgMTIuOTg3IDgyLjY5OCAxMy42NTIgMTcuNTM4LjA2MiAzNS4wOTUtMi4wMSA0OS4yOTItNC41NDkgMjEuNzcxLTQuMzYyIDMwLjU3NC03LjY1IDMzLjI3NS05LjE0em01LjAxNy04LjI3NS4wNjYuMDc3YTI2OSAyNjkgMCAwIDEtMS45NjMgMy4yNjNjLTUuMDM1IDEuOC0xOC43MDIgNS43OTgtMzguNjU5IDguNTg5LTEzLjE0OSAxLjc5MS0yMS4zMjIgMy41MjYtNDcuNDc5IDQuMDM0LTQ5LjAxNS0xLjI0Ny04MC43NS0xMC44MzEtODguMjg5LTEzLjE5NWwtMS4xMTctMi4xNDNjMjguNDA2IDcuNDE1IDU3LjQyMiAxMi41OTIgODkuNDA4IDEzLjEyIDIzLjkzLS41MDkgMzQuMTEyLTIuMjcxIDQ3LjE1Mi00LjA1IDIzLjI3LTMuNjE4IDM0Ljk5Ni03LjQ0OSAzOC41MTUtOC41NTVhMyAzIDAgMCAwLS4xNTQtLjJsMi41MjMtLjk0MnoiLz48cGF0aCBkPSJNMzI4LjgzIDE5Ny43NmMuMTM5IDI4LjEzNy0xNC4yNiA1My4zODYtMjUuODU4IDY0LjUyNS0xNi40MDggMTUuNzU5LTM4LjE2MyAyNS44OTYtNjMuNTY5IDI2LjM2My0yOC4zNy41MjEtNTUuMTItMTcuOTc0LTYyLjI5NS0yNi4wOTktMTQuMDI4LTE1Ljg4NS0yNS40NDktMzYuMDU3LTI1LjgxNS02My4yNDMgMS43MzgtMzAuNzA5IDEzLjc5My01Mi4xIDMxLjI2OC02Ni43NjlzNDAuNzQzLTIxLjgxMyA2MC4xMjEtMjEuMzAyYzIyLjM1OC41OSA0OC40NzUgMTEuNTU4IDY2LjUyMSAzMy4zMzIgMTEuODIzIDE0LjI2NiAxNi45NDMgMjkuNzQ4IDE5LjYyNyA1My4xOTNtLTg5LjE4Ni05Ni4zNDJjNTQuNDg1IDAgOTkuMjk2IDQ0LjMzOCA5OS4yOTYgOTguNzAzIDAgNTQuMzY0LTQ0LjgxMSA5OC43MDQtOTkuMjk2IDk4LjcwNHMtOTguOTI0LTQ0LjMzOS05OC45MjQtOTguNzA0IDQ0LjQzOS05OC43MDMgOTguOTI0LTk4LjcwMyIvPjxwYXRoIGQ9Ik0yMzkuOTEgMTAxLjA4YzU0LjUzNCAwIDk5LjAxMSA0NC40ODMgOTkuMDExIDk5LjAyMiAwIDU0LjUzOC00NC40NzggOTkuMDItOTkuMDExIDk5LjAyLTU0LjUzNCAwLTk5LjAxMS00NC40ODEtOTkuMDExLTk5LjAyczQ0LjQ3OC05OS4wMjIgOTkuMDExLTk5LjAyMm0tOTYuODMyIDk5LjAyMmMwIDUzLjI2IDQzLjczNiA5Ni44NDIgOTYuODMyIDk2Ljg0MiA1My4wOTcgMCA5Ni44MzMtNDMuNTgyIDk2LjgzMy05Ni44NDIgMC01My4yNjItNDMuNzM3LTk2Ljg0NC05Ni44MzMtOTYuODQ0cy05Ni44MzIgNDMuNTg0LTk2LjgzMiA5Ni44NDQiLz48cGF0aCBkPSJNMjM5Ljk5IDEwOS4zMWM0OS43MzEgMCA5MC42OTMgNDAuODIxIDkwLjY5MyA5MC43MDQgMCA0OS44ODQtNDAuOTYzIDkwLjcwMy05MC42OTMgOTAuNzAzcy05MC42OTMtNDAuODE5LTkwLjY5My05MC43MDMgNDAuOTY0LTkwLjcwNCA5MC42OTMtOTAuNzA0bS04OC41MTUgOTAuNzAzYzAgNDguNjg1IDM5Ljk3OSA4OC41MjQgODguNTE1IDg4LjUyNHM4OC41MTUtMzkuODM5IDg4LjUxNS04OC41MjQtMzkuOTc4LTg4LjUyNS04OC41MTUtODguNTI1LTg4LjUxNSAzOS44NC04OC41MTUgODguNTI1Ii8+PHBhdGggZD0iTTI0My45OCAxMDAuNjhoLTguNDg1bC4wMSAxOTguOTZoOC41MTR6Ii8+PHBhdGggZD0iTTI0My4xMyA5OS41NDZoMi4xNmwuMDE4IDIwMS4yNWgtMi4xNjF6bS04LjQyMS4wMDJoMi4xNzZsLjAwMyAyMDEuMjVoLTIuMTc4eiIvPjxwYXRoIGQ9Ik0zMzguOTkgMjAzLjkzNXYtNy4zNTVMMzMzIDE5MWwtMzQtOS00OS01LTU5IDMtNDIgMTAtOC40OCA2LjI4djcuMzU3TDE2MiAxOTRsNTEtOGg0OWwzNiA0IDI1IDZ6Ii8+PHBhdGggZD0iTTIzOS45NSAxODQuNzdjMjMuMzgzLS4wNDMgNDYuMDcgMi4yMTUgNjQuMDY1IDUuNzIgMTguNTY5IDMuNzEyIDMxLjYzNyA4LjM1NSAzNi4xMDUgMTMuNTdsLS4wMDUgMi41ODNjLTUuMzg4LTYuNDktMjIuOTczLTExLjI0OC0zNi41MTgtMTMuOTY4LTE3Ljg1OC0zLjQ3NC00MC4zOTMtNS43MTctNjMuNjQ3LTUuNjc0LTI0LjUzOC4wNDYtNDcuMzg3IDIuMzctNjQuOTg0IDUuODAzLTE0LjEyIDIuODAyLTMyLjk1MSA4LjM2OC0zNS4zMDIgMTMuODU4di0yLjY4OWMxLjI5MS0zLjggMTUuMzEzLTkuNDc5IDM0Ljk4NC0xMy40MTcgMTcuNzI5LTMuNDU3IDQwLjYyLTUuNzQxIDY1LjMwMi01Ljc4Nm0uMDEtOC40OTJjMjMuMzgzLS4wNDIgNDYuMDcgMi4yMTcgNjQuMDY1IDUuNzIgMTguNTY5IDMuNzEzIDMxLjYzNyA4LjM1NSAzNi4xMDUgMTMuNTdsLS4wMDUgMi41ODNjLTUuMzg4LTYuNDg5LTIyLjk3My0xMS4yNDctMzYuNTE4LTEzLjk2Ni0xNy44NTgtMy40NzYtNDAuMzkzLTUuNzE5LTYzLjY0Ny01LjY3NC0yNC41MzguMDQ0LTQ3LjI3NiAyLjM3LTY0Ljg3NSA1LjgwMS0xMy42MjYgMi41ODQtMzMuMjI2IDguMzctMzUuNDEyIDEzLjg2di0yLjY5YzEuMjkxLTMuNzYgMTUuNTk3LTkuNjQyIDM0Ljk4NS0xMy40MTcgMTcuNzI5LTMuNDU4IDQwLjYyLTUuNzQgNjUuMzAyLTUuNzg3ek0yMzkuNDggMTMyLjk2YzM2Ljg0OS0uMTg0IDY4Ljk5IDUuMTUyIDgzLjY5NSAxMi42ODVsNS4zNjQgOS4yNzljLTEyLjc4MS02Ljg4OC00Ny40NTYtMTQuMDUtODkuMDA1LTEyLjk3OS0zMy44NTQuMjA4LTcwLjAyNyAzLjcyNy04OC4xNzYgMTMuNDFsNi40MDMtMTAuNzA5YzE0Ljg5NS03LjcyNCA1MC4wMjItMTEuNjQzIDgxLjcyLTExLjY4NCIvPjxwYXRoIGQ9Ik0yMzkuOTcgMTQwLjYyYzIxLjAxNy0uMDU2IDQxLjMyNSAxLjEzIDU3LjQ3NiA0LjA0NCAxNS4wNDEgMi43OTkgMjkuMzg1IDcgMzEuNDM2IDkuMjZsMS41OSAyLjgxYy00Ljk4OC0zLjI1Ny0xNy40LTYuODg0LTMzLjMzOS05LjkwNi0xNi4wMDYtMy4wMDgtMzYuMy00LjAwNS01Ny4yLTMuOTUtMjMuNzIyLS4wODEtNDIuMTUyIDEuMTcxLTU3Ljk2OSAzLjkyOS0xNi43MjggMy4xMy0yOC4zMzQgNy42MDEtMzEuMTk3IDkuNzI2bDEuNTU4LTIuOTdjNS41NjQtMi44MzggMTQuMzktNi4yNiAyOS4yMjMtOC45MyAxNi4zNTctMi45ODggMzQuOTgzLTMuODg0IDU4LjQyMy00LjAxM3ptLS4wMDktOC40ODRjMjAuMTEzLS4wNTMgMzkuOTcyIDEuMDY4IDU1LjQ1MiAzLjg1IDEyLjIwOSAyLjM3NyAyNC4yODMgNi4wODggMjguNzA0IDkuMzlsMi4zMjYgMy42OTVjLTMuOTU0LTQuMzk1LTE4LjgzNi04LjU2LTMxLjk3NC0xMC44OTItMTUuMzYxLTIuNjUtMzQuMzk1LTMuNjk4LTU0LjUwOC0zLjg2Ni0yMS4xMDguMDYtNDAuNjE1IDEuMzUyLTU1Ljc1MiA0LjEwOC0xNC40NDEgMi43NDktMjMuNzYgNi4wMDItMjcuNzAzIDguNTQzbDIuMDQ1LTMuMDg3YzUuNDQxLTIuODY0IDE0LjIzMi01LjQ5NSAyNS4zMDMtNy42NDYgMTUuMjQ5LTIuNzc3IDM0Ljg3Ni00LjAzNiA1Ni4xMDgtNC4wOTV6TTI4OS4xNSAyNDEuMjZjLTE4LjIxOC0zLjQtMzYuNDY5LTMuODk1LTQ5LjIxNy0zLjc0NS02MS40MDcuNzItODEuMjQ0IDEyLjYxLTgzLjY2NSAxNi4yMWwtNC41OS03LjQ4MmMxNS42MzUtMTEuMzMyIDQ5LjA3NC0xNy42ODcgODguNTg4LTE3LjAzNyAyMC41MTguMzM2IDM4LjIyNCAxLjY5OCA1My4xMTkgNC41ODNsLTQuMjM2IDcuNDczIi8+PHBhdGggc3Ryb2tlLXdpZHRoPSIuNTUiIGQ9Ik0yMzkuNTggMjM2LjQ2YzE3LjA4Mi4yNTUgMzMuODQ5Ljk2IDUwLjAzMyAzLjk3OGwtMS4xNzIgMi4wN2MtMTUuMDMxLTIuNzc1LTMxLjA1NS0zLjgzNy00OC44MDMtMy43NS0yMi42NjMtLjE3OC00NS41ODUgMS45MzktNjUuNTQxIDcuNjY2LTYuMjk3IDEuNzUzLTE2LjcyMSA1LjgtMTcuNzg0IDkuMTQ2bC0xLjE2Ni0xLjkyM2MuMzM2LTEuOTc3IDYuNjM2LTYuMDggMTguNDE0LTkuMzkgMjIuODU4LTYuNTQ1IDQ0LjI0LTcuNjQ5IDY2LjAyLTcuNzk5em0uNzc1LTguNTk2YzE3LjY5OC4zMyAzNS45NzUgMS4xNDkgNTMuNzQgNC42NjhsLTEuMjIgMi4xNTNjLTE2LjA0Mi0zLjE4NC0zMS4zNy00LjI0Ni01Mi40MTUtNC41Ny0yMi43MzUuMDQyLTQ2Ljg1MSAxLjY2My02OC43NzggOC4wMzctNy4wOCAyLjA2My0xOS4yOTcgNi41Mi0xOS43MDQgMTAuMDVsLTEuMTY2LTIuMDY1Yy4yNjUtMy4yMDYgMTAuODQyLTcuMzg4IDIwLjM1OC0xMC4xNTYgMjIuMDk2LTYuNDI0IDQ2LjI3NS04LjA3NiA2OS4xODYtOC4xMTd6Ii8+PHBhdGggZD0ibTMyNy41OCAyNDcuMzgtNy4zNzkgMTEuNDQ5TDI5OSAyNDBsLTU1LTM3LTYyLTM0LTMyLjE5LTExLjAxIDYuODYtMTIuNzJMMTU5IDE0NGwyMCA1IDY2IDM0IDM4IDI0IDMyIDIzIDEzIDE1eiIvPjxwYXRoIGQ9Ik0xNDguNjUgMTU4LjI5YzUuNjQ2LTMuODMgNDcuMTM5IDE0LjY1NSA5MC41NTUgNDAuODM0IDQzLjMwMSAyNi4yNTQgODQuNjc3IDU1LjkyMSA4MC45NDIgNjEuNDczbC0xLjIyOCAxLjkzMi0uNTY0LjQ0NWMuMTItLjA4Ny43NDMtLjg0OC0uMDYtMi45MDYtMS44NDYtNi4wNy0zMS4xOTYtMjkuNDkxLTc5Ljg5NS01OC44OTUtNDcuNDc1LTI4LjMxLTg3LjA0LTQ1LjM3MS05MC45OTctNDAuNDk0em0xODAuNDQgODguOTI3YzMuNTctNy4wNTItMzQuOTE2LTM2LjA0NC04Mi42MzItNjQuMjcyLTQ4LjgxMy0yNy42NjYtODMuOTk0LTQzLjk1MS05MC40Mi0zOS4wOTVsLTEuNDI4IDIuNmMtLjAxMi4xNDIuMDUyLS4xNzguMzU0LS40MTEgMS4xNjgtMS4wMiAzLjEwNS0uOTUgMy45NzktLjk2NyAxMS4wNjUuMTY2IDQyLjY2NyAxNC43MSA4Ny4wMDYgNDAuMTI4IDE5LjQyOCAxMS4zMTUgODIuMDcxIDUxLjQ5MSA4MS44MzIgNjIuNzkuMDE3Ljk3LjA4IDEuMTctLjI4NSAxLjY1MXp2LS4wMDJ6Ii8+PC9nPjxwYXRoIGZpbGw9IiNmZmYiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLWxpbmVqb2luPSJiZXZlbCIgc3Ryb2tlLXdpZHRoPSIuNjciIGQ9Ik0xODAuNiAyMTEuMDFjMCAxNi4yNzEgNi42NjMgMzAuOTg3IDE3LjQ1NyA0MS43NDIgMTAuODE1IDEwLjc3OCAyNS41MTIgMTcuNTc5IDQxLjgwOSAxNy41NzkgMTYuMzgxIDAgMzEuMjQ3LTYuNjUzIDQyLjAxNi0xNy4zODkgMTAuNzY5LTEwLjczNSAxNy40NDMtMjUuNTUyIDE3LjQ0Ni00MS44OGgtLjAwMnYtNzkuMTg5bC0xMTguNzQtLjE0MS4wMTIgNzkuMjc4eiIvPjxwYXRoIGZpbGw9InJlZCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii41MDciIGQ9Ik0xODIuODIgMjExLjEydi4wNDVjMCAxNS41NTcgNi40NDEgMjkuNzI0IDE2Ljc3NSA0MC4wMDkgMTAuMzU0IDEwLjMwNSAyNC42MTQgMTYuNzEyIDQwLjIxNCAxNi43MTIgMTUuNjgxIDAgMjkuOTEyLTYuMzYgNDAuMjIyLTE2LjYyNiAxMC4zMDgtMTAuMjY1IDE2LjY5Ny0yNC40MzMgMTYuNjk5LTQwLjA0NGgtLjAwMlYxMzQuMzlsLTExMy44NC0uMDE5LS4wNyA3Ni43NDhtOTEuMDIyLTUzLjc0Ny4wMDQgNDguODkxLS4wNDEgNS4xNzJjMCAxLjM2MS0uMDgxIDIuOTEyLS4yNCA0LjIzMy0uOTI1IDcuNzMtNC40OCAxNC40NjctOS43NDUgMTkuNzA4LTYuMTY0IDYuMTM2LTE0LjY3MSA5Ljk0Mi0yNC4wNDcgOS45NDItOS4zMjcgMC0xNy42NC0zLjkzOC0yMy44My0xMC4xLTYuMzQ5LTYuMzItMTAuMDMtMTQuOTg2LTEwLjAzLTIzLjk0N2wtLjAxMi01NC4wMjMgNjcuOTQuMTIyeiIvPjxnIGlkPSJlIj48ZyBpZD0iZCIgZmlsbD0iI2ZmMCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9Ii41Ij48cGF0aCBzdHJva2U9Im5vbmUiIGQ9Ik0xOTAuMTkgMTU0LjQzYy4xMzUtNS41MjEgNC4wNTItNi44MjggNC4wOC02Ljg0N3M0LjIzMiAxLjQwNyA0LjIxOCA2Ljg5OHoiLz48cGF0aCBkPSJtMTg2LjgxIDE0Ny42OS0uNjgyIDYuMzQ1IDQuMTQuMDA5Yy4wNC01LjI1IDMuOTc1LTYuMTIzIDQuMDctNi4xMDMuMDktLjAwNSAzLjk4OSAxLjE2IDQuMDkzIDYuMTAzaDQuMTUxbC0uNzUtNi4zOTQtMTUuMDIyLjAzOHpNMTg1Ljg1IDE1NC4wNmgxNi45NDZjLjM1NyAwIC42NS4zNTMuNjUuNzg0IDAgLjQzLS4yOTMuNzgxLS42NS43ODFIMTg1Ljg1Yy0uMzU3IDAtLjY1LS4zNS0uNjUtLjc4MXMuMjkzLS43ODQuNjUtLjc4NHoiLz48cGF0aCBkPSJNMTkyLjAxIDE1NC4wM2MuMDE5LTMuMzEzIDIuMjYyLTQuMjUgMi4yNzQtNC4yNDggMCAwIDIuMzQyLjk2NiAyLjM2IDQuMjQ4aC00LjYzNE0xODYuMjEgMTQ1LjA1aDE2LjI0NWMuMzQyIDAgLjYyMy4zMTguNjIzLjcwNXMtLjI4LjcwNC0uNjIzLjcwNEgxODYuMjFjLS4zNDIgMC0uNjIzLS4zMTUtLjYyMy0uNzA0IDAtLjM4Ny4yOC0uNzA1LjYyMy0uNzA1ek0xODYuNTUgMTQ2LjQ3aDE1LjUzOGMuMzI3IDAgLjU5NS4zMTcuNTk1LjcwNCAwIC4zODgtLjI2OC43MDQtLjU5NS43MDRIMTg2LjU1Yy0uMzI3IDAtLjU5NS0uMzE2LS41OTUtLjcwNHMuMjY4LS43MDQuNTk1LS43MDR6TTE5MS41NyAxMzUuODhsMS4yMjcuMDAydi44NzFoLjg5NXYtLjg5bDEuMjU3LjAwNHYuODg3aC44OTd2LS44OWgxLjI1OGwtLjAwMiAyLjAxYzAgLjMxNy0uMjU0LjUyMS0uNTQ5LjUyMWgtNC40MWMtLjI5NyAwLS41Ny0uMjM3LS41NzItLjUyNmwtLjAwMy0xLjk4OHpNMTk2LjE5IDEzOC41N2wuMjc3IDYuNDUxLTQuMzAzLS4wMTUuMjg1LTYuNDUzIDMuNzQxLjAxNyIvPjxwYXRoIGlkPSJhIiBkPSJtMTkwLjk0IDE0MS41Ni4xMzEgMy40NzgtNC4xMjUuMDAxLjExNi0zLjQ3OWgzLjg3OXoiLz48dXNlIHhsaW5rOmhyZWY9IiNhIiB4PSIxMC42MDkiLz48cGF0aCBpZD0iYiIgZD0ibTE4Ni4zIDEzOS4wNCAxLjIuMDAzdi44NzJoLjg3N3YtLjg5MmwxLjIzLjAwNHYuODg5aC44Nzl2LS44OTNsMS4yMy4wMDItLjAwMiAyLjAxMmMwIC4zMTQtLjI0OS41MTgtLjUzNi41MThoLTQuMzE3Yy0uMjkgMC0uNTU5LS4yMzUtLjU2LS41MjVsLS4wMDItMS45ODl6Ii8+PHVzZSB4bGluazpocmVmPSIjYiIgeD0iMTAuNjA5Ii8+PHBhdGggZmlsbD0iIzAwMCIgc3Ryb2tlPSJub25lIiBkPSJNMTkzLjkgMTQwLjYxYy0uMDI2LS42MjcuODc3LS42MzQuODY2IDB2MS41MzZoLS44NjZ6Ii8+PHBhdGggaWQ9ImMiIGZpbGw9IiMwMDAiIHN0cm9rZT0ibm9uZSIgZD0iTTE4OC41NyAxNDIuODRjLS4wMDMtLjYwNi44MzctLjYxOC44MjYgMHYxLjE4N2gtLjgyNnoiLz48dXNlIHhsaW5rOmhyZWY9IiNjIiB4PSIxMC42NDEiLz48L2c+PHVzZSB4bGluazpocmVmPSIjZCIgeT0iNDYuMzIiLz48dXNlIHhsaW5rOmhyZWY9IiNkIiB0cmFuc2Zvcm09InJvdGF0ZSgtNDUuMjAyIDMxMi43NjYgMTgwLjAwNCkiLz48L2c+PHVzZSB4bGluazpocmVmPSIjZCIgeD0iNDUuNzE0Ii8+PHVzZSB4bGluazpocmVmPSIjZSIgdHJhbnNmb3JtPSJtYXRyaXgoLTEgMCAwIDEgNDc5Ljc5MiAwKSIvPjxnIGlkPSJmIj48cGF0aCBmaWxsPSIjMDM5IiBkPSJNMjMyLjYzNiAyMDIuNDA2di4wMDVjMCAyLjIxMi44NSA0LjIyNyAyLjIxMiA1LjY5IDEuMzY1IDEuNDY2IDMuMjQ1IDIuMzc3IDUuMzAyIDIuMzc3IDIuMDY3IDAgMy45NDQtLjkwNSA1LjMwMy0yLjM2NSAxLjM1OC0xLjQ1OSAyLjIwMi0zLjQ3MiAyLjIwMi01LjY5M3YtMTAuNzY4bC0xNC45OTItLjAxM3oiLz48cGF0aCBzdHJva2U9IiNmZmYiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIyLjk3MiIgZD0iTTIzNi4wNzQgMTk1Ljc0MnYwbTguMzE4IDB2MG0tNC4xNjcgMy45OTN2MG0tNC4xNTEgNC4xODF2MG04LjMwOS0uMDExdjAiLz48L2c+PHVzZSB4bGluazpocmVmPSIjZiIgeT0iLTI2LjAxNiIvPjx1c2UgeGxpbms6aHJlZj0iI2YiIHg9Ii0yMC43OTkiLz48dXNlIHhsaW5rOmhyZWY9IiNmIiB4PSIyMC43NDUiLz48dXNlIHhsaW5rOmhyZWY9IiNmIiB5PSIyNS43ODQiLz48L3N2Zz4=",
  "tr": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjgwMCIgdmlld0JveD0iMCAtMzAwMDAgOTAwMDAgNjAwMDAiPjxwYXRoIGZpbGw9IiNlMzBhMTciIGQ9Ik0wLTMwMDAwaDkwMDAwdjYwMDAwSDB6Ii8+PHBhdGggZmlsbD0iI2ZmZiIgZD0ibTQxNzUwIDAgMTM1NjgtNDQwOC04Mzg2IDExNTQxVi03MTMzbDgzODYgMTE1NDF6bTkyNSA4MDIxYTE1MDAwIDE1MDAwIDAgMSAxIDAtMTYwNDIgMTIwMDAgMTIwMDAgMCAxIDAgMCAxNjA0MnoiLz48L3N2Zz4="
}

for _language in LANGS:
    for _key in ("footer_note", "reset_note", "legend_down", "legend_up", "api_invalid", "api_chart_unavailable"):
        UI_TRANSLATIONS[_language][RESEARCH_I18N["ua"][_key]] = RESEARCH_I18N[_language][_key]
    for _key, _movement in (("rec_buy", "movement_down"), ("rec_sell", "movement_up"), ("rec_neutral", "movement_calm")):
        I18N[_key][_language] = RESEARCH_I18N[_language][_movement]
        CHAT_LABELS[_language][_key] = RESEARCH_I18N[_language][_movement]
    I18N["chat_news_risk"][_language] = RESEARCH_I18N[_language]["sentiment_negative"] + ". " + RESEARCH_I18N[_language]["not_factcheck"]
    I18N["chat_news_ok"][_language] = RESEARCH_I18N[_language]["sentiment_neutral"] + ". " + RESEARCH_I18N[_language]["not_factcheck"]

# Reliability UI strings: Ukrainian/English; other locales use explicit English fallback.
_RELIABILITY_EN = {'news_empty': 'No publications found. Sources responded successfully.', 'news_load_error': 'News could not be updated. Try refreshing again.', 'news_cached_warning': 'News could not be fully updated. Previously received articles may be out of date.', 'news_last_success': 'Last successful news update:', 'news_loading': 'Loading news…', 'news_not_updated': 'Not updated', 'news_updated': 'News updated', 'quotes_received': 'Quotes received:', 'quotes_time_unknown': 'Acquisition time unknown', 'quotes_stale': 'Stale quotes: these values may no longer be current.', 'quotes_stale_source': 'stale data', 'quotes_offline_cached': 'Quote update failed. Previously received values are shown; they may be out of date.', 'quotes_unavailable': 'Quotes unavailable. Retry is automatic.', 'quotes_demo': 'Demonstration data — simulated values, not current market observations.'}
_RELIABILITY_UA = {'news_empty': 'Публікацій немає. Джерела успішно відповіли.', 'news_load_error': 'Не вдалося оновити новини. Спробуйте оновити ще раз.', 'news_cached_warning': 'Новини не вдалося повністю оновити. Раніше отримані публікації можуть бути неактуальними.', 'news_last_success': 'Останнє успішне оновлення новин:', 'news_loading': 'Завантаження новин…', 'news_not_updated': 'Не оновлено', 'news_updated': 'Новини оновлено', 'quotes_received': 'Котирування отримано:', 'quotes_time_unknown': 'Час отримання невідомий', 'quotes_stale': 'Застарілі котирування: значення можуть бути неактуальними.', 'quotes_stale_source': 'застарілі дані', 'quotes_offline_cached': 'Не вдалося оновити котирування. Показано раніше отримані значення; вони можуть бути неактуальними.', 'quotes_unavailable': 'Котирування недоступні. Повторна спроба виконується автоматично.', 'quotes_demo': 'Демонстраційні дані — імітація, а не поточні ринкові спостереження.'}
for _language in LANGS:
    RESEARCH_I18N[_language].update(_RELIABILITY_UA if _language == "ua" else _RELIABILITY_EN)

# ───────────────────── Market research assistant: explainable signals ─────────────────────
RULE_VERSION = "market-context-v1"
SIGNAL_COOLDOWN_SECONDS = 3600
SIGNAL_HORIZONS = (3600, 14400, 86400)
QUOTE_MAX_AGE = 35
CHART_WINDOWS = {"1h": (3600, "1m", 61), "4h": (14400, "5m", 49),
                 "1d": (86400, "30m", 49), "7d": (604800, "4h", 43)}
SOURCE_DOMAINS = {"cointelegraph": "cointelegraph.com", "coindesk": "coindesk.com"}
candle_lock = threading.RLock()
candle_cache = {}
analysis_lock = threading.RLock()
analysis_state = {"items": {}, "updated_at": 0.0}


def init_research_tables(db):
    db.executescript("""
        CREATE TABLE IF NOT EXISTS research_signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL, kind TEXT NOT NULL,
            entry_price REAL NOT NULL CHECK(entry_price > 0),
            created_epoch REAL NOT NULL, source TEXT NOT NULL,
            rule_version TEXT NOT NULL, snapshot TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_research_signal_time
            ON research_signals(created_epoch DESC);
        CREATE INDEX IF NOT EXISTS idx_research_signal_cooldown
            ON research_signals(symbol,kind,created_epoch DESC);
        CREATE TABLE IF NOT EXISTS signal_outcomes (
            signal_id INTEGER NOT NULL, horizon INTEGER NOT NULL,
            target_epoch REAL NOT NULL, observed_epoch REAL,
            price REAL, return_pct REAL, source TEXT, last_attempt REAL NOT NULL DEFAULT 0,
            PRIMARY KEY(signal_id,horizon)
        );
        CREATE INDEX IF NOT EXISTS idx_signal_outcomes_due
            ON signal_outcomes(target_epoch,observed_epoch);
    """)
    if "last_attempt" not in [row["name"] for row in db.execute("PRAGMA table_info(signal_outcomes)")]:
        db.execute("ALTER TABLE signal_outcomes ADD COLUMN last_attempt REAL NOT NULL DEFAULT 0")


def epoch_iso(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="seconds")


def safe_news_url(url, publisher):
    """Only publisher-owned HTTPS article URLs; not proof that the story is true."""
    try:
        parsed = urlsplit(url)
        expected = SOURCE_DOMAINS[publisher]
        host = (parsed.hostname or "").lower()
        if parsed.scheme != "https" or parsed.username or parsed.password:
            return None
        if not (host == expected or host.endswith("." + expected)):
            return None
        if parsed.port not in (None, 443):
            return None
        # Remove tracking parameters, not arbitrary article parameters.
        query = urlencode([(k, v) for k, v in parse_qsl(parsed.query)
                           if not k.lower().startswith("utm_") and k.lower() not in ("fbclid", "gclid")])
        return urlunsplit(("https", parsed.netloc.lower(), parsed.path, query, ""))
    except (ValueError, KeyError, TypeError):
        return None


def article_symbols(title):
    result = []
    for sym, meta in COINS.items():
        names = [meta["name"].split(" · ")[0].lower()] + COIN_ALIASES.get(sym, [])
        named = any(re.search(r"\b" + re.escape(n) + r"\b", title.lower()) for n in names)
        # DOT/LINK/NEAR/TON are also common words; tickers must be uppercase.
        ticked = bool(re.search(r"\b" + sym + r"\b", title))
        if named or ticked or (sym == "MATIC" and re.search(r"\bPOL\b", title)):
            result.append(sym)
    return result


def _read_publisher(feed):
    key, name, url = feed
    items = []
    try:
        response = requests.get(url, headers=FEED_HEADERS, timeout=HTTP_TIMEOUT)
        response.raise_for_status()
        if not safe_news_url(response.url, key):
            raise ValueError("RSS redirected outside the publisher domain")
        parsed = feedparser.parse(response.content)
        if not parsed.get("version") or (parsed.get("bozo") and not parsed.entries):
            raise ValueError("RSS could not be parsed as a feed")
        for entry in parsed.entries[:20]:
            title = html.unescape(entry.get("title", "")).strip()[:600]
            link = safe_news_url(entry.get("link", ""), key)
            if not title or not link:
                continue
            stamp = entry.get("published_parsed") or entry.get("updated_parsed")
            published_epoch = None
            if stamp:
                try:
                    published_epoch = datetime(*stamp[:6], tzinfo=timezone.utc).timestamp()
                except (ValueError, OverflowError):
                    pass
            now = time.time()
            fresh = published_epoch is not None and -300 <= now - published_epoch <= 86400
            score = score_headline(title)
            items.append({"id": hashlib.sha256(link.encode()).hexdigest()[:16],
                          "title_en": title, "link": link, "source": name, "publisher": key,
                          "domain": urlsplit(link).hostname, "domain_checked": True,
                          "published": epoch_iso(published_epoch) if published_epoch else None,
                          "published_epoch": published_epoch, "fresh": fresh,
                          "symbols": article_symbols(title), "score": score,
                          "sentiment": sentiment_label(score), "related_publishers": []})
        return items, {"id": key, "name": name, "ok": True,
                       "state": "ok" if items else "empty", "checked_at": epoch_iso(time.time())}
    except Exception as exc:
        app.logger.warning("RSS %s: %s", key, exc)
        return [], {"id": key, "name": name, "ok": False,
                    "state": "error", "checked_at": epoch_iso(time.time())}


def fetch_feed_items():
    """Read both publishers, not just a fallback. Similar titles are not fact-checks."""
    with ThreadPoolExecutor(max_workers=2) as pool:
        responses = list(pool.map(_read_publisher, NEWS_FEEDS))
    items, seen = [], set()
    statuses = []
    for rows, status in responses:
        statuses.append(status)
        for item in rows:
            if item["link"] not in seen:
                seen.add(item["link"])
                items.append(item)
    stopwords = {"the", "and", "for", "with", "from", "that", "this", "after", "crypto", "says", "bitcoin"}
    for item in items:
        a = set(re.findall(r"[a-z]{4,}", item["title_en"].lower())) - stopwords
        for other in items:
            if item["publisher"] == other["publisher"]:
                continue
            b = set(re.findall(r"[a-z]{4,}", other["title_en"].lower())) - stopwords
            if len(a & b) >= 4 and len(a & b) / max(1, len(a | b)) >= .45:
                if other["source"] not in item["related_publishers"]:
                    item["related_publishers"].append(other["source"])
    items.sort(key=lambda x: x["published_epoch"] or 0, reverse=True)
    return items[:30], statuses


def get_raw_news():
    with news_lock:
        if time.time() - news_raw["ts"] > NEWS_CACHE_SECONDS:
            items, statuses = fetch_feed_items()
            failed = {f["id"] for f in statuses if not f["ok"]}
            ids = {i["id"] for i in items}
            cached = [i for i in news_raw["items"]
                      if i.get("publisher") in failed and i["id"] not in ids]
            rows = sorted(items + cached, key=lambda i: i.get("published_epoch") or 0, reverse=True)[:30]
            now = time.time()
            any_ok = any(f["ok"] for f in statuses)
            news_raw.update(ts=now, items=rows, feeds=statuses, degraded=bool(failed), cached=bool(cached),
                            source="rss" if any_ok else "cached" if rows else "unavailable")
            if any_ok:
                news_raw["success_epoch"] = now
        return list(news_raw["items"]), news_raw["source"], news_raw["ts"]


def build_news(lang):
    rows, source, stamp = get_raw_news()
    rows = rows[:NEWS_ITEMS]  # bounded optional headline translations; research uses the full raw feed
    def localize(item):
        translated = translate(item["title_en"], lang) if lang in MYMEMORY_PAIRS else None
        published = item.get("published_epoch")
        fresh = published is not None and -300 <= time.time() - published <= 86400
        return {**item, "title": translated or item["title_en"], "url": item["link"], "fresh": fresh,
                "original": item["title_en"], "translated": bool(translated)}
    with ThreadPoolExecutor(max_workers=4) as pool:
        items = list(pool.map(localize, rows))
    neg = sum(x["sentiment"] == "negative" for x in items)
    pos = sum(x["sentiment"] == "positive" for x in items)
    index = (pos - neg) / max(1, len(items))
    with news_lock:
        feeds = list(news_raw.get("feeds", []))
        degraded = bool(news_raw.get("degraded", any(not f["ok"] for f in feeds)))
        cached = bool(news_raw.get("cached", False))
        success = news_raw.get("success_epoch")
    state = "degraded" if degraded and items else "error" if degraded else "ok" if items else "empty"
    return {"items": items, "lang": lang, "source": source, "live": not degraded,
            "negative": neg, "positive": pos, "neutral": len(items) - neg - pos,
            "sentiment_index": index, "high_risk": index <= NEWS_RISK_INDEX,
            "banner": None, "updated_at": epoch_iso(success) if success else None,
            "last_attempt_at": epoch_iso(stamp), "state": state, "degraded": degraded, "cached": cached,
            "feeds": feeds, "sources": OFFICIAL_SOURCES,
            "verification": "publisher-domain-only-not-fact-check"}


def fetch_candles(symbol, window="1h", refresh=False):
    if symbol not in COINS or window not in CHART_WINDOWS:
        raise ValueError("Unsupported coin or time window")
    key, now = (symbol, window), time.time()
    with candle_lock:
        cached = candle_cache.get(key)
        if not refresh and cached and now - cached["fetched_epoch"] <= 15:
            return cached
    seconds, interval, limit = CHART_WINDOWS[window]
    response = requests.get("https://data-api.binance.vision/api/v3/klines",
                            params={"symbol": COINS[symbol]["binance"], "interval": interval,
                                    "startTime": int((now - seconds) * 1000), "limit": limit},
                            timeout=HTTP_TIMEOUT)
    response.raise_for_status()
    rows = response.json()
    if not isinstance(rows, list):
        raise ValueError("Unexpected candle response")
    points = []
    for row in rows:
        opened, closed = float(row[0]) / 1000, float(row[6]) / 1000
        if opened > now:
            continue
        point = {"t": min(closed, now), "open_time": opened, "close_time": closed,
                 "open": float(row[1]), "high": float(row[2]), "low": float(row[3]),
                 "close": float(row[4]), "quote_volume": float(row[7]), "closed": closed < now}
        if not all(math.isfinite(point[k]) and point[k] > 0 for k in ("open", "high", "low", "close")) or not math.isfinite(point["quote_volume"]) or point["quote_volume"] < 0:
            continue
        points.append(point)
    points.sort(key=lambda p: p["t"])
    if not points:
        raise ValueError("No genuine candle data")
    result = {"symbol": symbol, "pair": COINS[symbol]["binance"], "window": window,
              "interval": interval, "source": "binance", "quote_currency": "USDT",
              "fetched_epoch": now, "updated_at": epoch_iso(now), "points": points,
              "requested_from": epoch_iso(now - seconds)}
    with candle_lock:
        candle_cache[key] = result
    return result


def ema(values, period):
    result, alpha = values[0], 2 / (period + 1)
    for value in values[1:]:
        result = alpha * value + (1 - alpha) * result
    return result


def rsi(values, period=14):
    if len(values) < period + 1:
        return None
    changes = [b - a for a, b in zip(values, values[1:])]
    gain = sum(max(x, 0) for x in changes[:period]) / period
    loss = sum(max(-x, 0) for x in changes[:period]) / period
    for change in changes[period:]:
        gain = (gain * (period - 1) + max(change, 0)) / period
        loss = (loss * (period - 1) + max(-change, 0)) / period
    return 50.0 if gain == loss == 0 else 100.0 if loss == 0 else 100 - 100 / (1 + gain / loss)


def analyze_setup(symbol, quote, btc, candles, news, now=None):
    """Deterministic screening, not a trained model or a probability forecast."""
    now = time.time() if now is None else now
    base = {"symbol": symbol, "kind": "insufficient", "pros": [], "risks": [], "missing": [],
            "metrics": {}, "news_ids": [], "rule_version": RULE_VERSION, "as_of": epoch_iso(now)}
    if quote.get("source") != "binance" or now - quote.get("observed_epoch", 0) > QUOTE_MAX_AGE:
        base["missing"].append("fresh_binance");return base
    points = [p for p in (candles or {}).get("points", []) if p["closed"]]
    if len(points) < 40 or now - points[-1]["t"] > 180 or now - (candles or {}).get("fetched_epoch", 0) > 90:
        base["missing"].append("candles");return base
    if any(b["open_time"] - a["open_time"] > 61 for a, b in zip(points, points[1:])):
        base["missing"].append("candles");return base
    close = [p["close"] for p in points]
    fast, slow, strength = ema(close, 9), ema(close, 21), rsi(close)
    # Non-overlapping 5-minute windows: last completed 5m versus previous 30m average.
    recent_volume = sum(p["quote_volume"] for p in points[-5:])
    previous_volume = sum(p["quote_volume"] for p in points[-35:-5]) / 6
    ratio = recent_volume / previous_volume if previous_volume > 0 else None
    current, change = quote["price"], quote["change_1h"]
    btc_fresh = btc.get("source") == "binance" and now - btc.get("observed_epoch", 0) <= QUOTE_MAX_AGE
    fresh_news = [n for n in news if n["domain_checked"] and n.get("published_epoch") is not None
                  and -300 <= now - n["published_epoch"] <= 86400]
    relevant = [n for n in fresh_news if symbol in n["symbols"]]
    macro = [n for n in fresh_news if re.search(r"\b(fed|cpi|inflation|interest rates|federal reserve)\b", n["title_en"], re.I)]
    negatives = [n for n in relevant + macro if n["score"] <= -2]
    base["news_ids"] = list(dict.fromkeys(n["id"] for n in relevant + macro))[:8]
    base["metrics"] = {"price": current, "change_1h": change, "ema9": fast, "ema21": slow,
                       "rsi14": strength, "volume_ratio": ratio,
                       "quote_volume_1h": quote.get("quote_volume_1h"),
                       "btc_change_1h": btc.get("change_1h") if btc_fresh else None,
                       "closed_candles": len(points)}
    if fast > slow and current > fast:base["pros"].append("trend_up")
    else:base["risks"].append("trend_weak")
    if ratio is not None and ratio >= 1.2:base["pros"].append("volume_up")
    else:base["risks"].append("volume_weak")
    if btc_fresh:
        (base["pros"] if btc["change_1h"] >= 0 else base["risks"]).append("btc_up" if btc["change_1h"] >= 0 else "btc_down")
    else:base["missing"].append("btc_data")
    if strength is not None and strength > 75:base["risks"].append("rsi_hot")
    if abs(change) >= 5:base["risks"].append("large_move")
    if negatives:base["risks"].append("negative_headlines")
    if not relevant:base["missing"].append("coin_news")
    if not fresh_news:base["missing"].append("fresh_news")
    if quote.get("quote_volume_1h") is None:base["missing"].append("turnover")
    elif quote["quote_volume_1h"] < 1_000_000:base["risks"].append("low_turnover")
    conditions = (fast > slow and current > fast and ratio is not None and ratio >= 1.2
                  and strength is not None and 45 <= strength <= 68 and .5 <= change < 5
                  and btc_fresh and btc["change_1h"] >= 0
                  and quote.get("quote_volume_1h", 0) >= 1_000_000
                  and bool(relevant) and bool(fresh_news) and not negatives)
    if change <= -5 or (strength is not None and strength > 75) or negatives:
        base["kind"] = "risk"
    elif conditions:
        base["kind"] = "candidate"
    elif abs(change) >= 3 or (fast > slow and current > fast):
        base["kind"] = "watch"
    else:
        base["kind"] = "calm"
    return base


def record_signal(analysis, quote, now=None):
    now = time.time() if now is None else now
    if analysis["kind"] not in ("candidate", "watch", "risk") or quote.get("source") != "binance":
        return None
    if now - quote.get("observed_epoch", 0) > QUOTE_MAX_AGE:
        return None
    with db_write_lock, get_db() as db:
        same = db.execute("SELECT id FROM research_signals WHERE symbol=? AND kind=? AND created_epoch>? LIMIT 1",
                          (analysis["symbol"], analysis["kind"], now - SIGNAL_COOLDOWN_SECONDS)).fetchone()
        recent = db.execute("SELECT id FROM research_signals WHERE symbol=? AND created_epoch>? LIMIT 1",
                            (analysis["symbol"], now - 300)).fetchone()
        if same or recent:
            return None
        cursor = db.execute("""INSERT INTO research_signals
            (symbol,kind,entry_price,created_epoch,source,rule_version,snapshot) VALUES (?,?,?,?,?,?,?)""",
            (analysis["symbol"], analysis["kind"], quote["price"], now, "binance", RULE_VERSION,
             json.dumps(analysis, ensure_ascii=False)))
        signal_id = cursor.lastrowid
        for horizon in SIGNAL_HORIZONS:
            db.execute("INSERT INTO signal_outcomes(signal_id,horizon,target_epoch) VALUES(?,?,?)",
                       (signal_id, horizon, now + horizon))
    return signal_id


def refresh_signal_analysis():
    def get_one(symbol):
        try:return symbol, fetch_candles(symbol, "1h", refresh=True)
        except Exception as exc:
            app.logger.warning("Signal candles %s: %s", symbol, exc);return symbol, None
    with ThreadPoolExecutor(max_workers=4) as pool:
        candles = dict(pool.map(get_one, COINS))
    news, _, _ = get_raw_news()
    with prices_lock:
        quotes = {s: {**q, "source": prices_state["source"], "observed_epoch": min(prices_state.get("updated_epoch", 0),q.get("exchange_epoch", prices_state.get("updated_epoch", 0)))}
                  for s, q in prices_state["coins"].items()}
    now = time.time()
    analyses = {}
    for symbol in COINS:
        quote = quotes.get(symbol, {})
        analyses[symbol] = analyze_setup(symbol, quote, quotes.get("BTC", {}), candles[symbol], news, now)
        record_signal(analyses[symbol], quote, now)
    with analysis_lock:
        analysis_state.update(items=analyses, updated_at=now)


def process_signal_outcomes(now=None):
    now = time.time() if now is None else now
    with get_db() as db:
        rows = db.execute("""SELECT o.*,s.symbol,s.entry_price,s.source AS entry_source
              FROM signal_outcomes o JOIN research_signals s ON s.id=o.signal_id
              WHERE o.observed_epoch IS NULL AND o.target_epoch<=?
              ORDER BY o.last_attempt,o.target_epoch LIMIT 6""", (now,)).fetchall()
    for row in rows:
        # First actual minute-open AT OR AFTER the horizon, never the next candle's closing price.
        observation = math.ceil(row["target_epoch"] / 60) * 60
        if observation > now:
            continue
        try:
            with db_write_lock, get_db() as db:
                db.execute("UPDATE signal_outcomes SET last_attempt=? WHERE signal_id=? AND horizon=?",
                           (now, row["signal_id"], row["horizon"]))
            r = requests.get("https://data-api.binance.vision/api/v3/klines",
                             params={"symbol": COINS[row["symbol"]]["binance"], "interval": "1m",
                                     "startTime": observation * 1000, "endTime": observation * 1000 + 59999,
                                     "limit": 1}, timeout=HTTP_TIMEOUT)
            r.raise_for_status();data = r.json()
            if not data or not isinstance(data, list) or int(data[0][0]) != observation * 1000:
                continue
            price = float(data[0][1])
            if not math.isfinite(price) or price <= 0:
                continue
            result = (price / row["entry_price"] - 1) * 100
            with db_write_lock, get_db() as db:
                db.execute("""UPDATE signal_outcomes SET observed_epoch=?,price=?,return_pct=?,source=?
                         WHERE signal_id=? AND horizon=? AND observed_epoch IS NULL""",
                         (observation, price, result, "binance-minute-open", row["signal_id"], row["horizon"]))
        except Exception as exc:
            app.logger.warning("Outcome %s/%s unavailable: %s", row["signal_id"], row["horizon"], exc)


def research_worker():
    last = 0
    while True:
        try:
            if time.time() - last >= 60:
                refresh_signal_analysis();last = time.time()
            process_signal_outcomes()
        except Exception:
            app.logger.exception("Research worker")
        time.sleep(10)


@app.get("/api/chart/<symbol>")
def api_chart(symbol):
    symbol = symbol.upper()
    window = request.args.get("window", "1h")
    if symbol not in COINS or window not in CHART_WINDOWS:
        return jsonify({"error": UI_TRANSLATIONS[get_lang()]["Невідома монета або період графіка."]}), 400
    try:
        return jsonify(fetch_candles(symbol, window))
    except Exception:
        # No demo chart, no hidden interpolation, no stale cache returned as fresh.
        return jsonify({"error": UI_TRANSLATIONS[get_lang()]["Справжні дані графіка недоступні. Спробуйте пізніше."]}), 503


@app.get("/api/signals")
def api_signals():
    lang = get_lang()
    with analysis_lock:
        data, updated = dict(analysis_state["items"]), analysis_state["updated_at"]
    stale = not updated or time.time() - updated > 120
    with prices_lock:
        live = prices_state["source"] == "binance" and time.time() - prices_state.get("updated_epoch", 0) <= QUOTE_MAX_AGE
    items = []
    for symbol in COINS:
        item = dict(data.get(symbol) or {"symbol": symbol, "kind": "insufficient", "pros": [], "risks": [],
                                        "missing": ["fresh_binance"], "metrics": {}, "news_ids": []})
        if stale or not live:
            item.update(kind="insufficient", missing=list(dict.fromkeys(item["missing"] + ["fresh_binance"])))
        items.append(item)
    return jsonify({"items": items, "updated_at": epoch_iso(updated) if updated else None,
                    "lang": lang, "rule_version": RULE_VERSION, "live": live and not stale,
                    "cooldown_seconds": SIGNAL_COOLDOWN_SECONDS})


@app.get("/api/signals/history")
def api_signal_history():
    symbol = request.args.get("symbol", "").upper()
    before = request.args.get("before", type=int)
    if symbol and symbol not in COINS:
        return err("err_unknown_coin", 400, coins=", ".join(COINS))
    conditions, params = [], []
    if symbol:conditions.append("symbol=?");params.append(symbol)
    if before:conditions.append("id<?");params.append(before)
    sql = "SELECT * FROM research_signals" + (" WHERE " + " AND ".join(conditions) if conditions else "")
    with get_db() as db:
        rows = db.execute(sql + " ORDER BY id DESC LIMIT 31", params).fetchall()
        items = []
        for row in rows[:30]:
            outcomes = db.execute("SELECT * FROM signal_outcomes WHERE signal_id=? ORDER BY horizon", (row["id"],)).fetchall()
            item = dict(row);item["snapshot"] = json.loads(item["snapshot"]);item["created_at"] = epoch_iso(item["created_epoch"])
            item["outcomes"] = [{**dict(o), "target_at": epoch_iso(o["target_epoch"]),
                                 "observed_at": epoch_iso(o["observed_epoch"]) if o["observed_epoch"] else None,
                                 "status": "measured" if o["observed_epoch"] is not None else "waiting" if o["target_epoch"] > time.time() else "pending_data"}
                                for o in outcomes]
            items.append(item)
    return jsonify({"items": items, "next_before": rows[29]["id"] if len(rows) > 30 else None,
                    "rule_version": RULE_VERSION, "currency": "USDT", "fees_included": False})


# ───────────────────────── Запуск ─────────────────────────
def start_background():
    init_db()
    prefill_history()
    refresh_prices()                                   # щоб перший запит уже мав дані
    threading.Thread(target=background_worker, daemon=True, name="price-worker").start()
    threading.Thread(target=research_worker, daemon=True, name="research-worker").start()


if __name__ == "__main__":
    start_background()
    print("\n  CryptoFluctuation Intelligence Tracker: http://127.0.0.1:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
