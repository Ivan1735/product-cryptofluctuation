"""All mutations use a disposable database. No user database or external request is used."""
import os,sys,tempfile,unittest,time,math,json,base64
from pathlib import Path
from unittest.mock import patch
from datetime import datetime,timezone
from email.utils import format_datetime
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
TEMP=tempfile.TemporaryDirectory(prefix='market-research-tests-');os.environ['CRYPTO_TRACKER_DB']=TEMP.name+'/research.db'
import app as m
class Response:
 def __init__(self,data=None,url='https://cointelegraph.com/rss',content=b''):
  self.data,self.url,self.content=data,url,content
 def raise_for_status(self):pass
 def json(self):return self.data
class ResearchTests(unittest.TestCase):
 def setUp(self):
  self.assertTrue(m.DB_PATH.startswith(TEMP.name));m.init_db();self.c=m.app.test_client();self.now=time.time()
  with m.get_db() as db:
   db.execute('DELETE FROM signal_outcomes');db.execute('DELETE FROM research_signals')
  with m.candle_lock:m.candle_cache.clear()
  with m.prices_lock:m.prices_state.update(source='binance',updated_epoch=self.now,coins={})
  with m.analysis_lock:m.analysis_state.update(items={},updated_at=0)
 def fixture(self,symbol='ETH',now=None):
  now=self.now if now is None else now;bucket=int(now//60)*60;pts=[]
  for i in range(60):
   price=100+i*.02+math.sin(i*1.8)*.2;opened=bucket-(60-i)*60
   pts.append({'open_time':opened,'close_time':opened+59.999,'t':opened+59.999,'open':price,'close':price,'high':price+.1,'low':price-.1,'closed':True,'quote_volume':180000 if i>=55 else 100000})
  price=pts[-1]['close']+.05
  q={'price':price,'change_1h':(price/100-1)*100,'quote_volume_1h':sum(x['quote_volume'] for x in pts),'source':'binance','observed_epoch':now}
  btc={**q,'change_1h':.5};candles={'points':pts,'fetched_epoch':now}
  news=[{'id':'news1','domain_checked':True,'published_epoch':now-60,'symbols':[symbol],'score':0,'title_en':'Ethereum institutional demand update'}]
  return q,btc,candles,news
 def test_01_publisher_url_validation(self):
  for u in ['http://cointelegraph.com/news/a','https://cointelegraph.com.evil.test/a','javascript:alert(1)','https://cointelegraph.com@evil.test/a','https://evil.test/cointelegraph.com']:
   self.assertIsNone(m.safe_news_url(u,'cointelegraph'))
  self.assertEqual(m.safe_news_url('https://cointelegraph.com/news/a?utm_source=x#frag','cointelegraph'),'https://cointelegraph.com/news/a')
 def test_02_rss_provenance(self):
  pub=format_datetime(datetime.fromtimestamp(self.now-120,timezone.utc))
  def get(url,**kw):
   host='cointelegraph.com' if 'cointelegraph' in url else 'www.coindesk.com'
   xml=f'<rss version="2.0"><channel><item><title>Ethereum funds attract record institutional investment inflows</title><link>https://{host}/news/a</link><pubDate>{pub}</pubDate></item><item><title>Injected</title><link>https://evil.test/a</link></item></channel></rss>'
   return Response(url=url,content=xml.encode())
  with patch.object(m.requests,'get',side_effect=get):items,statuses=m.fetch_feed_items()
  self.assertEqual(len(items),2);self.assertTrue(all(x['domain_checked'] and x['fresh'] for x in items));self.assertTrue(all(x['ok'] for x in statuses));self.assertTrue(items[0]['related_publishers']);self.assertIn('ETH',items[0]['symbols'])
  with patch.object(m.requests,'get',side_effect=RuntimeError('offline')):items,statuses=m.fetch_feed_items()
  self.assertEqual(items,[]);self.assertFalse(any(x['ok'] for x in statuses))
 def test_03_candidate_and_independent_math(self):
  q,btc,cs,news=self.fixture();a=m.analyze_setup('ETH',q,btc,cs,news,self.now)
  self.assertEqual(a['kind'],'candidate',a);self.assertAlmostEqual(a['metrics']['volume_ratio'],1.8)
  values=[p['close'] for p in cs['points']];alpha=2/10
  independent=values[0]*(1-alpha)**(len(values)-1)+sum(alpha*v*(1-alpha)**(len(values)-1-i) for i,v in enumerate(values[1:],1))
  self.assertAlmostEqual(m.ema(values,9),independent,places=10)
  self.assertEqual(m.rsi([10]*30),50);self.assertEqual(m.rsi(list(range(1,31))),100);self.assertEqual(m.rsi(list(range(30,0,-1))),0)
 def test_04_missing_and_demo_abstention(self):
  q,b,c,n=self.fixture();q['source']='simulation'
  self.assertEqual(m.analyze_setup('ETH',q,b,c,n,self.now)['kind'],'insufficient')
  self.assertIsNone(m.record_signal({'symbol':'ETH','kind':'candidate'},q,self.now))
  q['source']='binance';q['observed_epoch']=self.now-100
  self.assertEqual(m.analyze_setup('ETH',q,b,c,n,self.now)['kind'],'insufficient')
  q['observed_epoch']=self.now
  self.assertEqual(m.analyze_setup('ETH',q,b,None,n,self.now)['kind'],'insufficient')
  self.assertNotEqual(m.analyze_setup('ETH',q,b,c,[],self.now)['kind'],'candidate')
 def test_05_risks_override_candidate(self):
  q,b,c,n=self.fixture();n[0]['score']=-3
  a=m.analyze_setup('ETH',q,b,c,n,self.now);self.assertEqual(a['kind'],'risk');self.assertIn('negative_headlines',a['risks'])
  n[0]['score']=0;q['change_1h']=-6
  self.assertEqual(m.analyze_setup('ETH',q,b,c,n,self.now)['kind'],'risk')
 def test_06_cooldown_and_waiting_results(self):
  q,b,c,n=self.fixture();a=m.analyze_setup('ETH',q,b,c,n,self.now);i=m.record_signal(a,q,self.now);self.assertIsInstance(i,int)
  self.assertIsNone(m.record_signal(a,q,self.now+1))
  hist=self.c.get('/api/signals/history').json['items'];self.assertEqual(len(hist),1);self.assertEqual(len(hist[0]['outcomes']),3)
  self.assertTrue(all(x['return_pct'] is None and x['status']=='waiting' for x in hist[0]['outcomes']))
  later=self.now+3601;q['observed_epoch']=later;self.assertIsNotNone(m.record_signal(a,q,later))
 def test_07_outcome_clock_and_idempotence(self):
  now=1800000000;created=now-3600
  q,b,c,n=self.fixture(now=created);q['price']=100;a=m.analyze_setup('ETH',q,b,c,n,created);a['kind']='watch'
  m.record_signal(a,q,created)
  with patch.object(m.requests,'get',return_value=Response([[now*1000,'110']])) as get:m.process_signal_outcomes(now)
  self.assertEqual(get.call_args.kwargs['params']['startTime'],now*1000)
  result=self.c.get('/api/signals/history').json['items'][0]['outcomes'][0]
  self.assertAlmostEqual(result['return_pct'],10);self.assertEqual(result['observed_epoch'],now)
  with patch.object(m.requests,'get') as get:m.process_signal_outcomes(now);get.assert_not_called()
 def test_08_catch_up_does_not_use_future_close(self):
  now=1800000000;created=now-86400;q,b,c,n=self.fixture(now=created);q['price']=100;a={'kind':'watch','symbol':'ETH'};m.record_signal(a,q,created)
  def get(url,params,**kw):return Response([[params['startTime'],'120','999','1','999']])
  with patch.object(m.requests,'get',side_effect=get):m.process_signal_outcomes(now)
  rows=self.c.get('/api/signals/history').json['items'][0]['outcomes'];self.assertTrue(all(abs(x['return_pct']-20)<1e-9 for x in rows))
 def test_09_failed_measurement_stays_null(self):
  now=1800000000;created=now-86400;q,*_=self.fixture(now=created);q['price']=100;m.record_signal({'symbol':'ETH','kind':'watch'},q,created)
  with patch.object(m.requests,'get',side_effect=RuntimeError('offline')):m.process_signal_outcomes(now)
  with m.get_db() as db:rows=db.execute('SELECT * FROM signal_outcomes').fetchall()
  self.assertTrue(all(r['return_pct'] is None and r['last_attempt']==now for r in rows))
 def test_10_reset_preserves_research_journal(self):
  q,*_=self.fixture();m.record_signal({'symbol':'ETH','kind':'watch'},q,self.now)
  self.c.post('/api/positions',json={'symbol':'ETH','quantity':1,'buy_price':100})
  self.assertEqual(self.c.post('/api/reset',json={'confirm':True}).status_code,200)
  self.assertEqual(len(self.c.get('/api/signals/history').json['items']),1)
 def test_11_language_flags_and_errors(self):
  for lang in m.LANGS:
   self.assertEqual(set(m.RESEARCH_I18N[lang]),set(m.RESEARCH_I18N['ua']))
   self.assertIn(b'<svg',base64.b64decode(m.LANGUAGE_FLAGS[lang].split(',')[1]))
   self.assertEqual(self.c.get('/api/chart/BTC?window=bad&lang='+lang).status_code,400)
   self.assertEqual(self.c.post('/api/positions?lang='+lang,json=[]).status_code,400)
 def test_12_chart_cache_and_no_fabrication(self):
  rows=[[int((self.now-120)*1000),'100','102','99','101','1',int((self.now-60)*1000),'1000']]
  with patch.object(m.requests,'get',return_value=Response(rows)) as get:
   first=m.fetch_candles('BTC');second=m.fetch_candles('BTC');self.assertEqual(get.call_count,1);self.assertEqual(first,second);self.assertEqual(first['points'][0]['close'],101)
  with m.candle_lock:m.candle_cache[('BTC','1h')]['fetched_epoch']-=100
  with patch.object(m.requests,'get',side_effect=RuntimeError('offline')):self.assertEqual(self.c.get('/api/chart/BTC').status_code,503)
 def test_13_stale_analysis_is_suppressed(self):
  q,b,c,n=self.fixture();a=m.analyze_setup('ETH',q,b,c,n,self.now)
  with m.analysis_lock:m.analysis_state.update(items={'ETH':a},updated_at=self.now-200)
  row=next(x for x in self.c.get('/api/signals').json['items'] if x['symbol']=='ETH');self.assertEqual(row['kind'],'insufficient')
 def test_14_migration_preserves_positions(self):
  r=self.c.post('/api/positions',json={'symbol':'ETH','quantity':.5,'buy_price':100});self.assertEqual(r.status_code,201)
  before=self.c.get('/api/portfolio').json['positions'];m.init_db();after=self.c.get('/api/portfolio').json['positions'];self.assertEqual(before,after)
if __name__=='__main__':
 try:unittest.main(verbosity=2)
 finally:TEMP.cleanup()
