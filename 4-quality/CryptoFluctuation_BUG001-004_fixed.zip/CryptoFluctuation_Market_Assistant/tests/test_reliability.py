"""Controlled regression for BUG-002..004; no user's database or external requests."""
import os,sys,tempfile,unittest,time
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
TMP=tempfile.TemporaryDirectory(prefix='reliability-tests-');os.environ['CRYPTO_TRACKER_DB']=TMP.name+'/test.db'
import app as m
class Response:
 def __init__(self,url,content):self.url,self.content=url,content
 def raise_for_status(self):pass
def rss(url,items=True):
 host=m.urlsplit(url).hostname
 item=f'<item><title>QA Ethereum headline without date</title><link>https://{host}/news/qa-reliability</link></item>' if items else ''
 return Response(url,f'<rss version="2.0"><channel><title>QA feed</title><link>https://{host}/</link><description>Controlled fixture</description>{item}</channel></rss>'.encode())
class ReliabilityTests(unittest.TestCase):
 def setUp(self):
  self.assertTrue(Path(m.DB_PATH).is_relative_to(TMP.name));m.init_db();self.c=m.app.test_client()
  m.news_raw.clear();m.news_raw.update(ts=0,items=[],source='unavailable',feeds=[],success_epoch=None,degraded=True,cached=False)
  with m.prices_lock:
   m.prices_state.update(source='binance',updated_at=m.epoch_iso(time.time()),updated_epoch=time.time(),coins={})
   for sym,meta in m.COINS.items():m.prices_state['coins'][sym]={'symbol':sym,'name':meta['name'],'price':meta['base'],'change_1h':1.,'signal':'neutral','alert':False}
 def news(self,fn):
  with patch.object(m.requests,'get',side_effect=fn),patch.object(m,'translate',return_value=None):return self.c.get('/api/news?lang=ua').json
 def test_01_empty_rss_is_success_not_failure(self):
  d=self.news(lambda url,**kw:rss(url,False));self.assertEqual(d['state'],'empty');self.assertEqual(d['items'],[]);self.assertEqual(d['source'],'rss');self.assertTrue(all(f['ok'] for f in d['feeds']));self.assertFalse(d['degraded'])
 def test_02_timeout_without_cache_is_error(self):
  d=self.news(lambda *a,**k:(_ for _ in ()).throw(m.requests.exceptions.Timeout('controlled')));self.assertEqual(d['state'],'error');self.assertEqual(d['items'],[]);self.assertIsNone(d['updated_at']);self.assertTrue(d['degraded'])
 def test_03_timeout_preserves_cache_and_last_success(self):
  first=self.news(lambda url,**kw:rss(url));m.news_raw['ts']-=61
  second=self.news(lambda *a,**k:(_ for _ in ()).throw(RuntimeError('controlled')))
  self.assertEqual(len(second['items']),len(first['items']));self.assertEqual(second['state'],'degraded');self.assertTrue(second['cached']);self.assertEqual(second['updated_at'],first['updated_at']);self.assertEqual(second['source'],'cached')
 def test_04_successful_empty_replaces_previous_items(self):
  self.news(lambda url,**kw:rss(url));m.news_raw['ts']-=61
  d=self.news(lambda url,**kw:rss(url,False));self.assertEqual(d['items'],[]);self.assertFalse(d['cached']);self.assertEqual(d['state'],'empty')
 def test_05_partial_failure_retains_only_failed_publishers_cache(self):
  self.news(lambda url,**kw:rss(url));m.news_raw['ts']-=61
  def get(url,**kw):
   if 'cointelegraph' in url:raise RuntimeError('controlled')
   return rss(url,False)
  d=self.news(get);self.assertEqual(len(d['items']),1);self.assertEqual(d['items'][0]['publisher'],'cointelegraph');self.assertTrue(d['degraded']);self.assertTrue(d['cached']);self.assertEqual(sum(f['ok'] for f in d['feeds']),1)
 def test_06_malformed_response_is_not_empty_success(self):
  d=self.news(lambda url,**kw:Response(url,b'<html>not RSS</html>'));self.assertEqual(d['state'],'error');self.assertFalse(any(f['ok'] for f in d['feeds']))
 def test_07_missing_dates_remain_null(self):
  d=self.news(lambda url,**kw:rss(url));self.assertTrue(d['items']);self.assertTrue(all(x['published'] is None and not x['fresh'] for x in d['items']))
 def test_08_quote_age_boundary_60_seconds(self):
  now=1800000000
  for age,stale in [(0,False),(60,False),(61,True),(86400,True)]:
   with self.subTest(age=age):
    m.prices_state['updated_at']=m.epoch_iso(now-age)
    with patch.object(m.time,'time',return_value=now):d=self.c.get('/api/prices').json
    self.assertEqual(d['stale'],stale);self.assertEqual(d['age_seconds'],age);self.assertEqual(d['stale_after_seconds'],60);self.assertEqual(d['updated_at'],m.epoch_iso(now-age))
 def test_09_unknown_or_future_quote_time_is_not_fresh(self):
  now=1800000000
  for stamp in [None,'invalid',m.epoch_iso(now+100),'2026-01-01T00:00:00']:
   m.prices_state['updated_at']=stamp
   with patch.object(m.time,'time',return_value=now):d=self.c.get('/api/prices').json
   self.assertTrue(d['stale']);self.assertIsNone(d['age_seconds'])
 def test_10_demo_and_missing_prices_are_explicit(self):
  m.prices_state['source']='simulation';d=self.c.get('/api/prices').json;self.assertEqual(d['source'],'simulation');self.assertEqual(len(d['coins']),15)
  m.prices_state['coins']={};d=self.c.get('/api/prices').json;self.assertEqual(d['coins'],[]);self.assertTrue(d['stale'])
 def test_11_research_stale_guard_with_fresh_positive_control(self):
  now=time.time()
  with m.analysis_lock:m.analysis_state.update(items={},updated_at=now)
  self.assertTrue(self.c.get('/api/signals').json['live'])
  m.prices_state['updated_epoch']=now-65
  d=self.c.get('/api/signals').json;self.assertFalse(d['live']);self.assertTrue(all(x['kind']=='insufficient' for x in d['items']))
 def test_12_all_locales_have_reliability_keys(self):
  for lang in m.LANGS:
   for key in m._RELIABILITY_EN:self.assertTrue(m.RESEARCH_I18N[lang][key])
if __name__=='__main__':
 try:
  with patch.object(m.requests,'get',side_effect=AssertionError('Unexpected external request')):unittest.main(verbosity=2)
 finally:TMP.cleanup()
