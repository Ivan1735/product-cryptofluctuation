import os,sys,tempfile,unittest,json,hashlib
from pathlib import Path
ROOT=str(Path(__file__).resolve().parents[1]);sys.path.insert(0,ROOT)
TEMP=tempfile.TemporaryDirectory(prefix='increment2-isolated-tests-')
os.environ['CRYPTO_TRACKER_DB']=TEMP.name+'/test.db'
import app as m
class Increment2Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  assert m.DB_PATH.startswith(TEMP.name)
  m.init_db();cls.c=m.app.test_client()
  now=m.time.time()
  with m.prices_lock:
   m.prices_state.update(source='simulation',updated_at=m.now_iso(),coins={})
   for sym,meta in m.COINS.items():
    m.prices_state['coins'][sym]={'symbol':sym,'name':meta['name'],'price':meta['base'],'change_1h':1.,'signal':'neutral','alert':False}
    m.price_history[sym].extend((now-60*(59-i),meta['base']*(1+i*.0001)) for i in range(60))
 def add(self,symbol='BTC',qty=1,price=100):
  r=self.c.post('/api/positions',json={'symbol':symbol,'quantity':qty,'buy_price':price});self.assertEqual(r.status_code,201,r.json);return r.json['id']
 def test_01_meta_localization(self):
  self.assertEqual(len(m.COINS),15);self.assertEqual(m.PRICE_REFRESH_SECONDS,10);self.assertEqual(m.COINS['MATIC']['binance'],'POLUSDT')
  for lang in m.LANGS:
   r=self.c.get('/api/prices?lang='+lang);self.assertEqual(r.status_code,200);self.assertEqual(len(r.json['coins']),15)
   school=self.c.get('/api/school?lang='+lang);self.assertEqual(school.status_code,200);self.assertEqual(school.json['lang'],lang)
   for lesson in [l for l in m.SCHOOL if l['core']]:
    r=self.c.post('/api/ai-chat?lang='+lang,json={'message':lesson['term'][lang],'topic':lesson['id']});self.assertEqual(r.status_code,200,r.json);self.assertIn(lesson['text'][lang],r.json['reply']);self.assertEqual(r.json['engine'],'reference-assistant')
   r=self.c.post('/api/ai-chat?lang='+lang,json={'message':'BTC'});self.assertEqual(r.status_code,200,r.json)
   self.assertEqual(self.c.post('/api/positions?lang='+lang,json={'symbol':'BTC','quantity':0,'buy_price':1}).status_code,400)
 def test_02_coin_analytics(self):
  for sym in m.COINS:
   r=self.c.get('/api/coins/'+sym);self.assertEqual(r.status_code,200);self.assertEqual(len(r.json['points']),60);self.assertTrue(r.json['points'][0]['t'].endswith('+00:00'))
 def test_03_delete_without_record(self):
  i=self.add();before=len(self.c.get('/api/trades').json)
  r=self.c.delete('/api/positions/'+str(i));self.assertEqual(r.status_code,200);self.assertFalse(r.json['recorded_in_stats']);self.assertEqual(len(self.c.get('/api/trades').json),before)
 def test_04_average_sell(self):
  i=self.add(qty=2,price=100)
  r=self.c.post(f'/api/positions/{i}/average',json={'quantity':2,'price':80});self.assertEqual(r.status_code,200);self.assertEqual(r.json['avg_price'],90)
  self.assertEqual(self.c.post(f'/api/positions/{i}/average',json={'quantity':1,'price':100}).status_code,400)
  self.assertEqual(self.c.post(f'/api/positions/{i}/stop-loss',json={'percent':.01}).status_code,400)
  self.assertEqual(self.c.post(f'/api/positions/{i}/stop-loss',json={'percent':10}).status_code,200)
  r=self.c.post(f'/api/positions/{i}/sell');self.assertEqual(r.status_code,200);self.assertAlmostEqual(r.json['pnl'],(65000-90)*4)
 def test_05_all_assets(self):
  for sym in m.COINS:self.add(sym,qty=.01,price=m.COINS[sym]['base'])
  self.assertEqual(len(self.c.get('/api/portfolio').json['positions']),15)
 def test_06_reset_confirmation(self):
  count=len(self.c.get('/api/portfolio').json['positions'])
  self.assertEqual(self.c.post('/api/reset',json={'confirm':False}).status_code,400)
  self.assertEqual(len(self.c.get('/api/portfolio').json['positions']),count)
  r=self.c.post('/api/reset',json={'confirm':True});self.assertEqual(r.status_code,200);self.assertEqual(self.c.get('/api/portfolio').json['positions'],[]);self.assertEqual(self.c.get('/api/trades').json,[])
 def test_07_invalid_inputs(self):
  for value in [float('inf'),-1,0,'x']:
   self.assertEqual(self.c.post('/api/positions',json={'symbol':'BTC','quantity':value,'buy_price':100}).status_code,400)
  self.assertEqual(self.c.post('/api/ai-chat',json={'message':''}).status_code,400)
  self.assertEqual(self.c.post('/api/ai-chat',json={'message':'x'*501}).status_code,400)
  self.assertEqual(self.c.get('/api/coins/FAKE').status_code,404)
 def test_08_template(self):
  r=self.c.get('/');self.assertEqual(r.status_code,200);self.assertIn(b'languageSelect',r.data);self.assertIn(b'chatPanel',r.data)
if __name__=='__main__':
 try:unittest.main(verbosity=2)
 finally:TEMP.cleanup()
