import os,sys,tempfile,unittest,time,math,json
from pathlib import Path
from unittest.mock import patch
from datetime import datetime,timezone
root=Path('/data/market-assistant-qa/source/CryptoFluctuation_Market_Assistant')
TMP=tempfile.TemporaryDirectory(prefix='independent-qa-');os.environ['CRYPTO_TRACKER_DB']=TMP.name+'/isolated.db';sys.path.insert(0,str(root))
import app as m
class Response:
 def __init__(self,data=None,content=b'',url='https://cointelegraph.com/rss'):self.data=data;self.content=content;self.url=url
 def json(self):return self.data
 def raise_for_status(self):pass
class IndependentTests(unittest.TestCase):
 def setUp(self):
  self.assertTrue(Path(m.DB_PATH).is_relative_to(TMP.name));m.init_db();self.c=m.app.test_client()
  with m.candle_lock:m.candle_cache.clear()
 def test_01_chart_all_windows_controlled_prices(self):
  now=time.time();rows=[[int((now-120)*1000),'100','103','99','102','1',int((now-60)*1000),'500']]
  for window,interval in [('1h','1m'),('4h','5m'),('1d','30m'),('7d','4h')]:
   with self.subTest(window=window),patch.object(m.requests,'get',return_value=Response(rows)) as get:
    r=self.c.get('/api/chart/ETH?window='+window);self.assertEqual(r.status_code,200);d=r.json
    self.assertEqual((d['symbol'],d['pair'],d['window'],d['interval']),('ETH','ETHUSDT',window,interval))
    self.assertEqual(get.call_args.kwargs['params']['symbol'],'ETHUSDT');self.assertEqual(get.call_args.kwargs['params']['interval'],interval)
    self.assertEqual(len(d['points']),1);self.assertEqual(d['points'][0]['close'],102)
 def test_02_chart_outage_does_not_return_stale_or_synthetic_points(self):
  now=time.time();rows=[[int((now-120)*1000),'100','103','99','102','1',int((now-60)*1000),'500']]
  with patch.object(m.requests,'get',return_value=Response(rows)):self.assertEqual(self.c.get('/api/chart/BTC').status_code,200)
  with m.candle_lock:m.candle_cache[('BTC','1h')]['fetched_epoch']-=100
  with patch.object(m.requests,'get',side_effect=RuntimeError('Controlled outage')):
   r=self.c.get('/api/chart/BTC');self.assertEqual(r.status_code,503);self.assertIn('error',r.json);self.assertNotIn('points',r.json)
 def test_03_empty_candles_have_explicit_error(self):
  with patch.object(m.requests,'get',return_value=Response([])):
   r=self.c.get('/api/chart/ETH');self.assertEqual(r.status_code,503);self.assertNotIn('points',r.json)
 def test_04_news_missing_date_is_null_and_injected_links_rejected(self):
  xml=b'<rss version="2.0"><channel><item><title>Ethereum test headline</title><link>https://cointelegraph.com/news/qa-test</link></item><item><title>Injected</title><link>javascript:alert(1)</link></item></channel></rss>'
  with patch.object(m.requests,'get',return_value=Response(content=xml)):
   items,state=m._read_publisher(('cointelegraph','CoinTelegraph','https://cointelegraph.com/rss'))
  self.assertEqual(len(items),1);self.assertIsNone(items[0]['published']);self.assertIsNone(items[0]['published_epoch']);self.assertFalse(items[0]['fresh'])
 def test_05_redirect_to_untrusted_publisher_rejected(self):
  with patch.object(m.requests,'get',return_value=Response(content=b'<rss/>',url='https://evil.test/rss')):
   items,state=m._read_publisher(('cointelegraph','CoinTelegraph','https://cointelegraph.com/rss'))
  self.assertEqual(items,[]);self.assertFalse(state['ok'])
 def test_06_news_api_is_not_a_fact_check(self):
  with patch.object(m,'get_raw_news',return_value=([],'unavailable',time.time())):
   r=self.c.get('/api/news?lang=en');self.assertEqual(r.status_code,200);self.assertEqual(r.json['items'],[])
   self.assertEqual(r.json['verification'],'publisher-domain-only-not-fact-check')
 def test_07_known_price_fixture_and_coin_mapping(self):
  with m.prices_lock:
   m.prices_state.update(source='simulation',updated_at=m.now_iso(),updated_epoch=time.time(),coins={})
   for i,(sym,meta) in enumerate(m.COINS.items()):m.prices_state['coins'][sym]={'symbol':sym,'name':meta['name'],'price':100+i,'change_1h':1,'signal':'neutral','alert':False}
  r=self.c.get('/api/prices');self.assertEqual(r.status_code,200);self.assertEqual(len(r.json['coins']),15);self.assertEqual(r.json['source'],'simulation')
  self.assertEqual({x['symbol']:x['price'] for x in r.json['coins']},{sym:100+i for i,sym in enumerate(m.COINS)})
  self.assertEqual(m.COINS['MATIC']['binance'],'POLUSDT')
if __name__=='__main__':
 try:
  with patch.object(m.requests,'get',side_effect=AssertionError('Unexpected external network request')):unittest.main(verbosity=2)
 finally:TMP.cleanup()
