import tempfile,subprocess,json,os
from pathlib import Path
r=Path('/data/all-known-bugs-fix');py='/data/market-assistant-qa/venv/bin/python'
with tempfile.TemporaryDirectory(prefix='reliability-restart-check-') as tmp:
 env={**os.environ,'CRYPTO_TRACKER_DB':tmp+'/restart.db'}
 code='''import sys,json
sys.path.insert(0,'/data/all-known-bugs-fix/app')
import app as m
m.init_db()
if sys.argv[1]=='write':
 r=m.app.test_client().post('/api/positions',json={'symbol':'BTC','quantity':0.5,'buy_price':100});assert r.status_code==201
with m.get_db() as db:rows=[dict(r) for r in db.execute('SELECT * FROM positions').fetchall()]
print(json.dumps(rows))
'''
 first=json.loads(subprocess.check_output([py,'-c',code,'write'],env=env,text=True));second=json.loads(subprocess.check_output([py,'-c',code,'read'],env=env,text=True))
 assert first==second and len(second)==1
 (r/'restart-results.json').write_text(json.dumps({'status':'pass','rowsPreserved':1,'method':'Two independent Python processes using one isolated temporary SQLite; no external requests','scope':'One restart example, not full 10/10 QT-02 sample'},indent=2))
 print('Independent-process restart: PASS (one example)')
