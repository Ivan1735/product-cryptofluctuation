import os,sys,tempfile,json,hashlib
from pathlib import Path
from unittest.mock import patch
R=Path('/data/all-known-bugs-fix');A=Path('/data/all-known-bugs-fix/app');sys.path.insert(0,str(A));tmp=tempfile.TemporaryDirectory(prefix='negative-fixtures-');os.environ['CRYPTO_TRACKER_DB']=tmp.name+'/test.db'
import app as m
m.init_db();c=m.app.test_client();observations=[]
class Response:
 def __init__(self,url,content):self.url=url;self.content=content
 def raise_for_status(self):pass
empty=b'<rss version="2.0"><channel><title>QA empty feed</title></channel></rss>'
def request_empty(url,**kwargs):
 host=m.urlsplit(url).hostname
 content=('<rss version="2.0"><channel><title>QA empty feed</title><link>https://'+host+'/</link><description>Controlled RSS feed with zero publications</description></channel></rss>').encode()
 assert not m.feedparser.parse(content).bozo
 return Response(url,content)
def request_nodate(url,**kwargs):
 domain='cointelegraph.com' if 'cointelegraph' in url else 'www.coindesk.com'
 return Response(url,('<rss version="2.0"><channel><item><title>QA controlled headline without date</title><link>https://'+domain+'/news/qa-controlled</link></item></channel></rss>').encode())
def get_news(fn):
 m.news_raw.update(ts=0,items=[],feeds=[],source='unavailable')
 with patch.object(m.requests,'get',side_effect=fn),patch.object(m,'translate',return_value=None):
  res=c.get('/api/news?lang=ua');assert res.status_code==200;return res.json
empty_data=get_news(request_empty)
def timeout(url,**kwargs):raise m.requests.exceptions.Timeout('QA controlled RSS timeout')
error_data=get_news(timeout)
nodate=get_news(request_nodate)
for name,data in [('news-empty',empty_data),('news-error',error_data),('news-nodate',nodate)]: (R/'fixtures'/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
observations.append({'id':'RSS-empty-vs-timeout','expected':'Successful empty feed remains distinguishable from transport failure','actual':{'empty':{'source':empty_data['source'],'feeds':empty_data['feeds'],'items':len(empty_data['items'])},'timeout':{'source':error_data['source'],'feeds':error_data['feeds'],'items':len(error_data['items'])}},'status':'fail' if empty_data['source']==error_data['source'] and [f['ok'] for f in empty_data['feeds']]==[f['ok'] for f in error_data['feeds']] else 'inspect'})
observations.append({'id':'news-date-null','status':'pass' if nodate['items'] and all(i['published'] is None for i in nodate['items']) else 'fail','items':len(nodate['items'])})
old_epoch=1577836800;old_iso='2020-01-01T00:00:00+00:00'
with m.prices_lock:
 m.prices_state.update(source='binance',updated_at=old_iso,updated_epoch=old_epoch,coins={})
 for sym,meta in m.COINS.items():m.prices_state['coins'][sym]={'symbol':sym,'name':meta['name'],'price':meta['base'],'change_1h':1.,'signal':'neutral','alert':False}
res=c.get('/api/prices?lang=ua');(R/'fixtures/prices-stale.json').write_text(json.dumps(res.json,ensure_ascii=False,indent=2))
signals=c.get('/api/signals?lang=ua').json
observations.append({'id':'stale-signals-live-flag','status':'pass' if signals['live'] is False else 'fail','live':signals['live'],'scope':'Only live flag; not full journal creation test'})
(R/'backend-results.json').write_text(json.dumps({'actor':'AI assistant','observations':observations,'sourceSHA256':{str(p.relative_to(A)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [A/'app.py',A/'templates/index.html']}},ensure_ascii=False,indent=2))
print(json.dumps([{'id':r['id'],'status':r['status']} for r in observations]));tmp.cleanup()
