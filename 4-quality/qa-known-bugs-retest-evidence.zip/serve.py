import os,sys,tempfile
sys.path.insert(0,'/data/all-known-bugs-fix/app')
tmp=tempfile.TemporaryDirectory(prefix='reliability-browser-')
os.environ['CRYPTO_TRACKER_DB']=tmp.name+'/test.db'
import app as m
m.init_db()
now=m.time.time()
with m.prices_lock:
 m.prices_state.update(source='simulation',updated_at=m.now_iso(),coins={})
 for sym,meta in m.COINS.items():
  m.prices_state['coins'][sym]={'symbol':sym,'name':meta['name'],'price':meta['base'],'change_1h':1.,'signal':'neutral','alert':False}
  m.price_history[sym].extend((now-60*(59-i),meta['base']*(1+i*.0001)) for i in range(60))
m.app.run(host='127.0.0.1',port=5020,debug=False,use_reloader=False)
